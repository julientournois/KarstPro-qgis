# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Détection de **gouffres / puits verticaux** depuis le MNT LiDAR.

Un puits ouvert ne renvoie aucun point sol au LiDAR aéroporté (les impulsions
plongent dans le vide) → il apparaît dans le MNT comme un **trou de NODATA
compact**, entouré d'un **bord de sol valide** — et NON comme une cuvette. La
détection de dolines (cuvettes fermées) est donc structurellement aveugle à ces
puits ; ce module les rattrape par leur signature de vide.

Validé sur le Gouffre de la Peute Fosse (Écot-la-Combe) : puits vertical de 4 m
donnant sur une rivière souterraine, raté par la détection de dolines, capté ici.

numpy + rasterio purs (ni scipy ni whitebox).
"""


def _erode(mask):
    import numpy as np
    p = np.pad(mask, 1, constant_values=False)
    return (p[1:-1, 1:-1] & p[:-2, 1:-1] & p[2:, 1:-1]
            & p[1:-1, :-2] & p[1:-1, 2:])


def _dilate(mask, it):
    import numpy as np
    m = mask
    for _ in range(it):
        p = np.pad(m, 1, constant_values=False)
        m = (p[1:-1, 1:-1] | p[:-2, 1:-1] | p[2:, 1:-1]
             | p[1:-1, :-2] | p[1:-1, 2:])
    return m


def detect_shafts(mnt_path, min_area_m2=6.0, max_area_m2=400.0, min_fill=0.45,
                  min_valid_ring=0.6, ring_px=4, feedback=None):
    """Candidats gouffres/puits = trous de NODATA **compacts** du MNT, à
    **bord de sol valide**.

    Args:
        mnt_path       : MNT LiDAR (EPSG:2154 attendu), avec NODATA préservé.
        min/max_area_m2: gamme de surface du vide (un puits = quelques dizaines
                         de m² ; au-delà = plan d'eau / lacune de canopée).
        min_fill       : compacité minimale (aire / aire de la bbox) — un puits
                         est rond/compact, une trouée de canopée est filandreuse.
        min_valid_ring : fraction minimale de **sol valide** dans la couronne
                         autour du vide (un puits a un bord net ; une trouée de
                         canopée baigne dans le NODATA).
        ring_px        : épaisseur de la couronne testée (cellules).
    Returns:
        GeoDataFrame (Point, EPSG:2154) : `surface_m2`, `compacite`,
        `couronne_sol`, `diametre_m`.
    """
    import numpy as np
    import rasterio
    import geopandas as gpd
    from shapely.geometry import Point
    from collections import deque

    def log(m):
        if feedback:
            feedback.pushInfo(m)

    with rasterio.open(str(mnt_path)) as src:
        a = src.read(1)
        nod = src.nodata
        tr = src.transform
        res = abs(tr.a)
        crs = src.crs
    nodata = (a == nod) if nod is not None else ~np.isfinite(a.astype("float64"))
    nodata = nodata | ~np.isfinite(a.astype("float64"))
    H, W = nodata.shape

    # Érosion : casse les fils fins (≤ 2 px) de canopée qui relient les vides ;
    # les cœurs compacts (un puits) survivent.
    core = _erode(nodata)

    seen = np.zeros_like(core)
    rs, cs = np.where(core)
    rows, attrs = [], []
    for r0, c0 in zip(rs.tolist(), cs.tolist()):
        if seen[r0, c0]:
            continue
        q = deque([(r0, c0)]); seen[r0, c0] = True; cells = []
        while q:
            r, c = q.popleft(); cells.append((r, c))
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    rr, cc = r + dr, c + dc
                    if 0 <= rr < H and 0 <= cc < W and core[rr, cc] and not seen[rr, cc]:
                        seen[rr, cc] = True; q.append((rr, cc))
        ys = [p[0] for p in cells]; xs = [p[1] for p in cells]
        area = len(cells) * res * res
        if not (min_area_m2 <= area <= max_area_m2):
            continue
        y0, y1, x0, x1 = min(ys), max(ys), min(xs), max(xs)
        fill = len(cells) / ((y1 - y0 + 1) * (x1 - x0 + 1))
        if fill < min_fill:
            continue
        # Couronne de sol valide autour du vide
        pad = ring_px
        ry0, ry1 = max(0, y0 - pad), min(H, y1 + pad + 1)
        rx0, rx1 = max(0, x0 - pad), min(W, x1 + pad + 1)
        sub_nod = nodata[ry0:ry1, rx0:rx1]
        blob = np.zeros_like(sub_nod)
        for r, c in cells:
            blob[r - ry0, c - rx0] = True
        ring = _dilate(blob, pad) & ~blob
        valid_ring = float((ring & ~sub_nod).sum()) / max(int(ring.sum()), 1)
        if valid_ring < min_valid_ring:
            continue
        cy = sum(ys) / len(ys); cx = sum(xs) / len(xs)
        rows.append(Point(tr.c + (cx + 0.5) * tr.a, tr.f + (cy + 0.5) * tr.e))
        attrs.append((round(area, 1), round(fill, 3), round(valid_ring, 3),
                      round(2 * (area / 3.14159) ** 0.5, 1)))

    if not rows:
        log("Gouffres : aucun vide compact à bord de sol valide détecté.")
        return gpd.GeoDataFrame(
            {"surface_m2": [], "compacite": [], "couronne_sol": [], "diametre_m": []},
            geometry=[], crs=(crs or "EPSG:2154"))
    gdf = gpd.GeoDataFrame(
        {"surface_m2": [x[0] for x in attrs], "compacite": [x[1] for x in attrs],
         "couronne_sol": [x[2] for x in attrs], "diametre_m": [x[3] for x in attrs]},
        geometry=rows, crs=(crs or "EPSG:2154"))
    log(f"Gouffres : {len(gdf)} candidat(s) (vides LiDAR compacts à bord de sol). "
        "⚠️ À filtrer (plans d'eau / bâti via BD Topo) et à vérifier sur le terrain.")
    return gdf


def flag_anthropic(gouffres, obstacles, buffer_m=5.0):
    """Marque les candidats gouffres qui tombent sur un obstacle BD Topo (bâti /
    eau) : leur vide de NODATA vient du bâtiment ou de l'eau, pas d'un puits.
    Ajoute une colonne `flag` ('bati' / 'eau' / '').

    Args:
        gouffres  : GeoDataFrame de candidats (Point, EPSG:2154).
        obstacles : GeoDataFrame BD Topo (Polygone, colonne `classe`).
        buffer_m  : tolérance de proximité (m).
    """
    import geopandas as gpd
    g = gouffres.copy()
    if obstacles is None or len(obstacles) == 0 or len(g) == 0:
        g["flag"] = ""
        return g
    j = gpd.sjoin_nearest(g, obstacles[["classe", "geometry"]], how="left",
                          max_distance=buffer_m, distance_col="_d")
    j = j[~j.index.duplicated(keep="first")]
    g["flag"] = j["classe"].fillna("").values
    return g
