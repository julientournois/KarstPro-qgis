# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Géologie IGME (Espagne) — équivalent espagnol de core/geology.py.

Deux niveaux ArcGIS REST, endpoints confirmés par requête réelle le
2026-07-31 (cf. Task 6 du plan routeur-pays-lidar) :

- 1:50 000 (local, comme BD Charm-50) : IGME_Geode_50, layer id=8
  « Recintos geología » (les polygones de formations — id relu dans la
  réponse JSON du service, pas fixé au hasard).
- 1:1 000 000 (repli national, comme le WFS BRGM 1/1M) : IGME_Litologias_1M.

⚠️ Le segment `/rest/` dans l'URL est obligatoire — sans lui, le serveur
ArcGIS renvoie une page d'erreur générique, pas du JSON.
"""
import requests
import geopandas as gpd
from shapely.geometry import Polygon

_TARGET_CRS = "EPSG:25830"  # UTM 30N ETRS89 — CRS de travail Espagne par défaut

_GEODE_50K_URL = (
    "https://mapas.igme.es/gis/rest/services/Cartografia_Geologica/"
    "IGME_Geode_50/MapServer/8/query"
)
_LITOLOGIAS_1M_URL = (
    "https://mapas.igme.es/gis/rest/services/Cartografia_Geologica/"
    "IGME_Litologias_1M/MapServer/0/query"
)


def _rings_to_polygon(rings: list) -> Polygon:
    """Convertit des `rings` ArcGIS REST en Polygon Shapely.

    Le format ArcGIS ne distingue pas explicitement anneau extérieur/trous
    dans la réponse JSON brute (c'est le sens de rotation qui les distingue
    normalement), mais en pratique les services IGME renvoient l'anneau
    extérieur en premier suivi des trous — on ne peut pas juste supposer un
    seul ring : une feature avec plusieurs rings est un polygone à trou(s).
    """
    if not rings:
        return None
    if len(rings) == 1:
        return Polygon(rings[0])
    return Polygon(rings[0], holes=rings[1:])


def _epsg_code(crs: str) -> str:
    """"EPSG:25830" -> "25830". Sans ça, inSR/outSR partiraient vides et
    ArcGIS retomberait sur la référence native du service (Web Mercator,
    wkid 102100) — la bbox en UTM serait alors interprétée comme des mètres
    Web Mercator, donnant une zone totalement fausse en silence."""
    return crs.split(":")[-1]


def _query_arcgis(url: str, bbox: tuple, crs: str, timeout: int = 60):
    """Requête ArcGIS REST query, renvoie le JSON décodé ou None en cas
    d'échec (HTTP non-200 ou erreur réseau)."""
    xmin, ymin, xmax, ymax = bbox
    epsg = _epsg_code(crs)
    params = {
        "geometry": f"{xmin},{ymin},{xmax},{ymax}",
        "geometryType": "esriGeometryEnvelope",
        "inSR": epsg,
        "outSR": epsg,
        "outFields": "*",
        "f": "json",
        "returnGeometry": "true",
    }
    try:
        resp = requests.get(url, params=params, timeout=timeout)
    except requests.exceptions.RequestException:
        return None
    if resp.status_code != 200:
        return None
    try:
        return resp.json()
    except Exception:
        return None


def _payload_to_gdf(payload: dict, crs: str) -> gpd.GeoDataFrame:
    """Construit un GeoDataFrame depuis un payload ArcGIS REST JSON déjà
    décodé. GDF vide si aucune feature."""
    features = (payload or {}).get("features") or []
    rows = []
    for feat in features:
        rings = feat.get("geometry", {}).get("rings")
        geom = _rings_to_polygon(rings)
        if geom is None:
            continue
        row = dict(feat.get("attributes", {}))
        row["geometry"] = geom
        rows.append(row)
    if not rows:
        return _empty_gdf(crs)
    return gpd.GeoDataFrame(rows, crs=crs)


def _empty_gdf(crs: str) -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(columns=["geometry", "Litologia"], crs=crs)


def fetch_igme_geology(bbox: tuple, crs: str = _TARGET_CRS) -> gpd.GeoDataFrame:
    """Charge la géologie IGME (Espagne) pour la bbox.

    Même patron que `core.geology.fetch_geology_auto` : niveau local (1:50 000)
    d'abord, repli sur le niveau national (1:1M) si le premier échoue ou ne
    renvoie aucune feature dans la bbox.

    Args:
        bbox : (xmin, ymin, xmax, ymax) dans `crs`
        crs  : CRS de la bbox et de la couche retournée — envoyé en
            `inSR`/`outSR` à la requête ArcGIS (le service reprojette)

    Returns:
        GeoDataFrame avec une colonne `Litologia`, dans `crs`, vide en cas
        d'échec des deux niveaux.
    """
    payload = _query_arcgis(_GEODE_50K_URL, bbox, crs)
    if payload is not None:
        gdf = _payload_to_gdf(payload, crs)
        if not gdf.empty:
            return gdf

    payload = _query_arcgis(_LITOLOGIAS_1M_URL, bbox, crs)
    if payload is not None:
        gdf = _payload_to_gdf(payload, crs)
        if not gdf.empty:
            return gdf

    return _empty_gdf(crs)


# Table de correspondance lithologie (texte libre IGME, champ « Litologia »)
# → karstifiabilité. Approximation par analogie avec la table NOTATION de
# BD Charm-50 (core/geology.py) — PAS une vérité géologique établie, à
# affiner avec un géologue ou un retour terrain espagnol. Recherche par
# sous-chaîne (le champ IGME n'est pas un code court comme NOTATION).
IGME_KARSTIFIABILITE_KEYWORDS = [
    ("caliza", 1.0),
    ("dolom", 0.9),      # dolomía/dolomías
    ("yeso", 0.7),       # gypse, karstifiable mais évaporitique
    ("marga", 0.4),
    ("arenisca", 0.3),
    ("arcilla", 0.1),
]
DEFAULT_KARSTIFIABILITE = 0.5  # lithologie non reconnue : facteur neutre


def karstifiabilite_igme(litologia_text: str) -> float:
    """Cherche chaque mot-clé (insensible à la casse) dans `litologia_text`,
    renvoie le premier trouvé dans l'ordre de IGME_KARSTIFIABILITE_KEYWORDS
    (donc l'ordre de la liste = priorité), sinon DEFAULT_KARSTIFIABILITE."""
    text_low = (litologia_text or "").lower()
    for keyword, score in IGME_KARSTIFIABILITE_KEYWORDS:
        if keyword in text_low:
            return score
    return DEFAULT_KARSTIFIABILITE
