# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""LiDAR PNOA automatisé (1 m) — Espagne. Source LiDAR **prioritaire** pour
le profil "espagne" du routeur pays (Task 11 du plan routeur-pays-lidar,
révision v4) : `core.mdt_wcs_es` (5 m) devient le repli si ce module
échoue (zone hors couverture PNOA, commune introuvable, service en panne).

⚠️ Contrairement au WCS INSPIRE (standard OGC documenté), ce mécanisme
repose sur le portail web `centrodedescargas.cnig.es`, **non documenté
officiellement comme API** — retro-ingénierie d'un flux de téléchargement
navigateur. Vérifié par exécution réelle le 2026-07-31 (fichier LAZ de
75 Mo téléchargé de bout en bout, signature LASF valide, avec une session
`curl` entièrement neuve — aucune dépendance de cookie/authentification
préalable constatée). Peut casser sans préavis si le site change son
implémentation ; le repli WCS existe précisément pour ce cas.

Trois requêtes HTTP (toutes confirmées par appel réel, pas devinées) :

1. `POST .../archivosSerie` — liste (fragment HTML, PAS JSON) les fichiers
   LAZ disponibles pour une commune (`codIne`), paginée (~20/page). Les
   identifiants `sec=<id>` et noms de fichier (`PNOA-AAAA-REG-X-Y-HZZ-NPCnn.LAZ`)
   sont extraits par expression régulière — pas besoin de parser le HTML
   proprement.
2. `POST .../initDescargaDir` — accusé de réception JSON, sans dépendance
   de session réelle constatée.
3. `POST .../descargaDir` — le fichier LAZ binaire, nom réel donné par
   `Content-Disposition` (qui utilise `_` comme séparateur, alors que le
   HTML de la liste utilise `-` — les deux formes sont acceptées par
   `_parse_tile_grid_cell`).

Commune → code INE : WFS INSPIRE IGN `unidades-administrativas`, couche
unique `au:AdministrativeUnit` (le modèle INSPIRE AU ne sépare pas les
niveaux hiérarchiques en couches distinctes), champ `au:nationalCode`
filtré sur `au:nationalLevelName` == "Municipio" (4ᵉ niveau hiérarchique
national, `AdministrativeHierarchyLevel/4thOrder`) — confirmé par une
requête `GetFeature` réelle le 2026-07-31 : la bbox autour de Cangas de
Onís renvoie bien `nationalCode=34033333012` pour le "Municipio" nommé
"Cangas de Onís", code INE identique à celui déjà vérifié dans le
mécanisme de téléchargement (cf. plan Task 11 Step 1). La requête bbox
renvoie aussi les unités ancêtres (pays/région/province) qui intersectent
la même bbox géométriquement — normal en INSPIRE AU, filtré ici par
niveau.

Niveau NPC retenu : **NPC01** (classification automatique de base).
Confirmé par téléchargement réel d'une tuile + `pdal info` le 2026-07-31 :
la classe LAS 2 (sol), seule classe filtrée par `core.lidar.generate_mnt`,
est bien présente dans le fichier NPC01 testé (`Classification` ∈
{1,2,3,4,5,6,7,12}). Recherche web complémentaire (pnoa.ign.es) : NPC01 =
"nube de puntos clasificada automáticamente" (sol/végétation/bâti déjà
distingués), NPC02 = révision interactive, NPC03 = classification avancée
(>20 classes). Sur les 268 fichiers observés pour Cangas de Onís, la
totalité était en NPC01 — NPC02/NPC03 ne semblent pas systématiquement
disponibles pour chaque tuile, contrairement à NPC01. Filtrer sur NPC01
évite aussi de télécharger plusieurs fichiers redondants pour une même
cellule 1×1 km quand plusieurs niveaux coexistent.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

import requests
from karstpro.core.i18n import t

_ARCHIVOS_URL = "https://centrodedescargas.cnig.es/CentroDescargas/archivosSerie"
_INIT_DESCARGA_URL = "https://centrodedescargas.cnig.es/CentroDescargas/initDescargaDir"
_DESCARGA_URL = "https://centrodedescargas.cnig.es/CentroDescargas/descargaDir"

_WFS_URL = "https://contenido.ign.es/wfs-inspire/unidades-administrativas"
_WFS_CRS = "EPSG:4258"  # ETRS89 géographique, axe lat/lon — CRS natif du WFS INSPIRE AU

# Niveaux de classification acceptés, du MOINS au PLUS élaboré :
#   NPC01 = classification automatique de base
#   NPC02 = révision interactive
#   NPC03 = classification avancée (>20 classes)
# Tous portent la classe LAS 2 (sol), seule utilisée par `generate_mnt`.
#
# ⚠️ Ce filtre ne retenait QUE NPC01 jusqu'au 2026-08-03, sur la foi d'une
# généralisation abusive : « les 268 fichiers observés pour Cangas de Onís
# étaient tous en NPC01 ». Une seule commune. En Navarre (Isaba, 611 gouffres
# inventoriés), les dalles sont exclusivement en NPC02/NPC03 — le
# téléchargement PNOA échouait donc en silence et basculait sur le repli MDT
# 5 m, alors que du 1 m de MEILLEURE qualité était disponible. Révélé en
# testant la couverture d'un inventaire spéléo de Navarre.
_NPC_LEVELS = ("NPC03", "NPC02", "NPC01")   # ordre de préférence décroissant

# ⚠️ Obligatoires : sans ces en-têtes (signature "python-requests" par
# défaut), le WAF de centrodedescargas.cnig.es bloque TOUTE requête vers ce
# domaine avec un RemoteDisconnected — pas un rate-limit ni un bannissement
# d'IP comme diagnostiqué à tort le 2026-07-31/08-01 (2 jours perdus avant
# de comparer avec un HAR de navigateur réel, cf. JOURNAL_EXPERIENCES.md) :
# un simple ajout de ces en-têtes suffit, vérifié sur la même IP/machine qui
# était bloquée juste avant. Le WFS `contenido.ign.es` (communes), lui,
# n'a jamais été affecté — le blocage est spécifique à ce domaine.
_BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html, */*; q=0.01",
    "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": "https://centrodedescargas.cnig.es",
    "Referer": "https://centrodedescargas.cnig.es/CentroDescargas/lidar-tercera-cobertura",
}

_SEC_RE = re.compile(r"sec=([0-9]+)")
# Ordre X-Y toujours séparé par un tiret, quel que soit le séparateur des
# autres segments ("-" dans le HTML de la liste, "_" dans Content-Disposition).
_FILENAME_RE = re.compile(
    r"PNOA[-_](\d{4})[-_]([A-Za-z]+)[-_](\d+)-(\d+)[-_]H(\d+)[-_](NPC\d+)",
    re.IGNORECASE,
)
_GML_TAG_RE = re.compile(r"\{[^}]*\}")


def _local_tag(tag: str) -> str:
    return _GML_TAG_RE.sub("", tag)


def _reproject_bbox_corners(bbox: tuple, src_crs: str, dst_crs: str) -> tuple:
    """Reprojette les 4 coins de `bbox` (pas juste les 2 coins diagonaux),
    même patron que `mdt_wcs_es._reproject_bbox` — une bbox UTM reprojetée
    en géographique peut ne pas garder xmin/ymax sur les mêmes coins."""
    if src_crs == dst_crs:
        return bbox
    # PAS de pyproj : son `proj_create` n'est pas thread-safe dans QGIS et tue
    # le processus par une access violation, sans exception ni ligne de log.
    # Signalé par un utilisateur sur Ségovie le 2026-08-17 — cf.
    # `karstpro/core/projection.py`.
    from karstpro.core.projection import bbox_utm_vers_geographique

    return bbox_utm_vers_geographique(bbox, src_crs)


def find_communes_for_bbox(bbox: tuple, crs: str, timeout: int = 60) -> list:
    """Codes INE (`au:nationalCode`) des communes ("Municipio") qui
    intersectent `bbox` (dans `crs`), via le WFS INSPIRE IGN.

    Une bbox KarstPro peut chevaucher plusieurs communes limitrophes — la
    liste peut donc contenir 2+ codes.

    Returns:
        Liste de codes INE (str), triée, vide si aucune commune trouvée ou
        en cas d'échec réseau/HTTP (pas d'exception levée).
    """
    lon_min, lat_min, lon_max, lat_max = _reproject_bbox_corners(bbox, crs, _WFS_CRS)
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetFeature",
        "typeNames": "au:AdministrativeUnit",
        "bbox": f"{lat_min},{lon_min},{lat_max},{lon_max},urn:ogc:def:crs:EPSG::4258",
    }
    try:
        resp = requests.get(_WFS_URL, params=params, timeout=timeout)
    except requests.exceptions.RequestException:
        return []
    if resp.status_code != 200:
        return []

    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(resp.content)
    except ET.ParseError:
        return []

    codes = set()
    for member in root:
        for au in member:
            if _local_tag(au.tag) != "AdministrativeUnit":
                continue
            code = None
            level_name = None
            for child in au:
                child_tag = _local_tag(child.tag)
                if child_tag == "nationalCode":
                    code = (child.text or "").strip()
                elif child_tag == "nationalLevelName":
                    for grandchild in child:
                        if _local_tag(grandchild.tag) == "LocalisedCharacterString":
                            level_name = (grandchild.text or "").strip()
            if code and level_name == "Municipio":
                codes.add(code)
    return sorted(codes)


def list_commune_files(cod_ine: str, cod_sub_serie: str = "",
                        timeout: int = 60, max_pages: int = 50) -> list:
    """Liste les fichiers LAZ PNOA disponibles pour la commune `cod_ine`
    (endpoint `archivosSerie`, HTML paginé — `codSubSerie` vide = ensemble
    complet, cf. docstring module).

    Returns:
        Liste de dicts `{"sec": str, "filename": str}` — dédupliquée
        (chaque fichier apparaît deux fois dans le HTML source, avec et
        sans son millésime entre parenthèses). Liste vide en cas d'échec
        réseau/HTTP ou d'absence de fichiers.
    """
    files_by_sec = {}
    num_pagina = ""
    for _ in range(max_pages):
        data = {
            "codAgr": "MOMDT",
            "codSerie": "LIDA3",
            "codTipoArchivo": "LAZ",
            "todaEspania": "N",
            "todoMundo": "N",
            "codIne": cod_ine,
            "totalArchivos": "531665",
            "numPagina": str(num_pagina),
            "codSubSerie": cod_sub_serie,
        }
        try:
            resp = requests.post(_ARCHIVOS_URL, data=data,
                                  headers=_BROWSER_HEADERS, timeout=timeout)
        except requests.exceptions.RequestException:
            break
        if resp.status_code != 200:
            break

        text = resp.text
        secs = _SEC_RE.findall(text)
        names = [m.group(0) for m in re.finditer(r"PNOA[^<\"']*", text)]
        new_on_this_page = False
        # Les sec et les noms apparaissent dans le même ordre relatif dans
        # le HTML (une ligne de tableau par fichier, dupliquée) — on
        # associe par position en dédupliquant sur sec.
        for sec, raw_name in zip(dict.fromkeys(secs), dict.fromkeys(
                n.split(" (")[0].strip() for n in names)):
            if sec not in files_by_sec:
                files_by_sec[sec] = raw_name
                new_on_this_page = True

        if not new_on_this_page:
            break
        num_pagina = (int(num_pagina) if num_pagina else 1) + 1

    return [{"sec": sec, "filename": name} for sec, name in files_by_sec.items()]


def _parse_tile_grid_cell(filename: str):
    """Extrait la cellule de grille UTM 1×1 km (X, Y en km) et le fuseau
    UTM (H<zone>) d'un nom de fichier PNOA, ex. `PNOA_2025_CYL_338-4786_H30_NPC01.laz`
    ou `PNOA-2024-AST-323-4806-H30-NPC01.LAZ` (formes des deux endpoints
    réels, séparateurs différents — cf. docstring module).

    Returns:
        `(x_km, y_km, zone, npc_level)` ou `None` si le nom ne correspond
        pas au patron attendu (ne jamais lever d'exception sur un nom
        inattendu).
    """
    m = _FILENAME_RE.search(filename)
    if not m:
        return None
    x_km = int(m.group(3))
    y_km = int(m.group(4))
    zone = int(m.group(5))
    npc_level = m.group(6).upper()
    return (x_km, y_km, zone, npc_level)


def bbox_to_pnoa_tiles(bbox: tuple, crs: str) -> list:
    """Combine la recherche de communes et le listing de fichiers pour ne
    garder que les tuiles PNOA (niveau `NPC01`) dont la cellule 1×1 km
    touche réellement `bbox` (dans `crs`) — une commune de montagne peut
    renvoyer des centaines de fichiers hors de la petite zone d'étude.

    Returns:
        Liste de dicts `{"sec": str, "filename": str, "cod_ine": str}`,
        dédupliquée (une tuile près d'une frontière communale peut
        apparaître dans le listing de 2 communes). Vide si aucune commune
        ou aucun fichier pertinent trouvé.
    """
    communes = find_communes_for_bbox(bbox, crs)
    if not communes:
        return []

    zone_match = re.search(r"258(\d\d?)", crs)
    target_zone = int(zone_match.group(1)) if zone_match else None

    xmin, ymin, xmax, ymax = bbox
    # Sélection PAR CELLULE de grille et non par fichier : une même cellule
    # 1x1 km peut exister en plusieurs niveaux NPC, et une cellule proche
    # d'une limite communale apparaît dans le listing de 2 communes. On garde
    # un seul fichier par cellule, au niveau de classification le plus élaboré
    # disponible — télécharger deux niveaux de la même cellule doublerait le
    # volume et ferait traiter deux fois le même terrain par PDAL.
    meilleur = {}
    for cod_ine in communes:
        for f in list_commune_files(cod_ine):
            parsed = _parse_tile_grid_cell(f["filename"])
            if parsed is None:
                continue
            x_km, y_km, zone, npc_level = parsed
            if npc_level not in _NPC_LEVELS:
                continue
            if target_zone is not None and zone != target_zone:
                continue
            # Les dalles PNOA sont nommées par leur coin HAUT-gauche : X est le
            # bord ouest, mais Y est le bord NORD — la dalle `4793` couvre
            # [4792000, 4793000], pas [4793000, 4794000].
            #
            # Codé comme un coin bas-gauche jusqu'au 2026-08-06, ce qui décalait
            # toute la sélection d'une rangée vers le sud : il manquait jusqu'à
            # 999 m de LiDAR en haut de chaque emprise espagnole, et une rangée
            # entière était téléchargée pour rien en bas. Invisible sans contrôle
            # de couverture — révélé par la garde de mnt_cache le 2026-08-06.
            #
            # Mesuré sur deux études, au mètre près :
            #   cotera : dalles Y {4792, 4793} -> MNT [4791000, 4793000]
            #   Isaba  : dalles Y {4755..4758} -> MNT [4754000, 4758000]
            # Les deux collent à « étiquette = bord nord », et à rien d'autre
            # (un nommage par le centre donnerait [4791500, 4793500]).
            cell_xmin, cell_xmax = x_km * 1000, x_km * 1000 + 1000
            cell_ymax, cell_ymin = y_km * 1000, y_km * 1000 - 1000
            intersects = not (
                cell_xmax < xmin or cell_xmin > xmax or
                cell_ymax < ymin or cell_ymin > ymax
            )
            if not intersects:
                continue
            cle = (x_km, y_km, zone)
            rang = _NPC_LEVELS.index(npc_level)      # 0 = le plus élaboré
            actuel = meilleur.get(cle)
            if actuel is None or rang < actuel[0]:
                meilleur[cle] = (rang, {
                    "sec": f["sec"], "filename": f["filename"],
                    "cod_ine": cod_ine})

    return [v[1] for v in meilleur.values()]


class _AntiRobot(Exception):
    """Le CNIG a refusé la demande faute de vérification anti-robot.

    Interne : `download_tile` la rattrape et rend `None`, son contrat public
    est inchangé. Seul `download_pnoa_auto` s'en sert, pour cesser d'essayer.
    """


def _refus_anti_robot(resp) -> bool:
    """La réponse est-elle le refus d'autorisation du CNIG ?

    Depuis le **2026-09-29 à 12 h**, le bouton de téléchargement du CNIG passe
    par un reCAPTCHA v3 : la page appelle `grecaptcha.execute(...)` puis
    `preAutorizarDescarga`, et n'enchaîne sur `initDescargaDir` que si la
    réponse vaut `autorizado == 'S'`. Une requête programmatique n'a pas de
    jeton : le serveur rend 200 avec une page HTML disant « Error en el
    protocolo de descarga. No está autorizado ».

    KarstPro **ne contourne pas** cette vérification — c'est une mesure
    anti-automatisation, et la respecter n'est pas négociable. On se contente
    de la RECONNAÎTRE, pour l'écrire clairement dans le journal et proposer la
    voie officielle (panier de téléchargement du CNIG, cf.
    `ecrire_liste_manuelle`) au lieu de réessayer en vain sur chaque dalle.
    """
    type_contenu = (resp.headers.get("Content-Type") or "").lower()
    if "html" not in type_contenu:
        return False
    try:
        texte = resp.text[:60000].lower()
    except Exception:
        return False
    return "autorizado" in texte and "protocolo de descarga" in texte


def download_tile(sec: str, cod_ine: str, dest_dir, timeout: int = 120,
                  signaler_refus: bool = False) -> Optional[Path]:
    """Télécharge une tuile PNOA par son identifiant `sec` (les 2 POST
    confirmés par exécution réelle : `initDescargaDir` puis `descargaDir`).

    Args:
        sec : identifiant `sec` de la tuile (extrait de `list_commune_files`)
        cod_ine : code INE de la commune d'origine (renvoyé dans le corps
            de `descargaDir`, même valeur que celle utilisée pour lister)
        dest_dir : dossier de destination (créé si absent)
        timeout : secondes avant abandon de chaque requête HTTP
        signaler_refus : si vrai, lève `_AntiRobot` quand le CNIG refuse faute
            de vérification anti-robot, au lieu de rendre `None` comme pour
            n'importe quel autre échec. Réservé à `download_pnoa_auto`, qui
            s'en sert pour cesser d'essayer : le blocage est global au service,
            pas propre à une dalle. Faux par défaut — le contrat historique
            « jamais d'exception » est préservé pour tout autre appelant.

    Returns:
        Path du fichier `.laz` écrit (nom réel donné par
        `Content-Disposition`), ou `None` en cas d'échec réseau/HTTP/
        Content-Disposition manquant — jamais d'exception levée (même
        patron que `core.geology_igme`/`core.mdt_wcs_es`).
    """
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    try:
        init_resp = requests.post(
            _INIT_DESCARGA_URL, data={"secuencial": sec},
            headers=_BROWSER_HEADERS, timeout=timeout)
    except requests.exceptions.RequestException:
        return None
    if init_resp.status_code != 200:
        return None

    data = {
        "secDescDirLA": sec,
        "codAgr": "MOMDT",
        "codSerie": "LIDA3",
        "codIne": cod_ine,
        "codTipoArchivo": "LAZ",
        "totalArchivos": "1",
        "urlProd": "lidar-tercera-cobertura",
        "licenciaSeleccionada": "167",
        "todaEspania": "N",
        "todoMundo": "N",
        "sec": "",
        "coordenadas": "",
    }
    try:
        resp = requests.post(_DESCARGA_URL, data=data,
                              headers=_BROWSER_HEADERS, timeout=timeout)
    except requests.exceptions.RequestException:
        return None
    if resp.status_code != 200:
        return None

    disposition = resp.headers.get("Content-Disposition", "")
    m = re.search(r'filename=([^;]+)', disposition)
    if not m:
        # Pas de fichier : le CNIG a servi une page HTML à la place. Depuis le
        # 2026-09-29, c'est presque toujours son refus anti-robot — le
        # distinguer évite de réessayer 35 fois pour rien (cf. `_refus_anti_robot`).
        if signaler_refus and _refus_anti_robot(resp):
            raise _AntiRobot()
        return None
    filename = m.group(1).strip().strip('"')

    out_path = dest_dir / filename
    out_path.write_bytes(resp.content)
    return out_path


def _find_cached_tile(dest_dir: Path, tile: dict) -> Optional[Path]:
    """Cherche un fichier déjà présent dans `dest_dir` correspondant à la
    même cellule de grille 1×1 km (X, Y, fuseau UTM) que `tile` — même
    esprit que le cache par taille HTTP HEAD de
    `core.lidar.download_lidar_tiles` côté France, mais sans endpoint HEAD
    fiable côté PNOA (le nom final vient de `Content-Disposition`, pas de
    l'URL) : on compare la cellule extraite du nom plutôt que la taille.

    Returns:
        Path du fichier local existant et non vide, ou `None`.
    """
    parsed = _parse_tile_grid_cell(tile["filename"])
    if parsed is None:
        return None
    for existing in dest_dir.glob("PNOA*"):
        if not existing.is_file() or existing.stat().st_size == 0:
            continue
        if _parse_tile_grid_cell(existing.name) == parsed:
            return existing
    return None


#: Centre de téléchargement du CNIG.
_CNIG_ACCUEIL = "https://centrodedescargas.cnig.es/CentroDescargas/"

#: Fiche d'UNE dalle, ouvrable dans un navigateur : nom du fichier, taille,
#: et le bouton de téléchargement du site. Aucune URL de téléchargement
#: DIRECT n'existe — le flux impose deux POST enchaînés et le nom n'arrive
#: que dans `Content-Disposition` ; les variantes GET rendent 403 ou la page
#: d'erreur (vérifié le 2026-09-30). Mais cette fiche-ci suffit à un humain,
#: et évite de chercher chaque dalle à la main dans le catalogue.
_CNIG_FICHE = _CNIG_ACCUEIL + "detalleArchivo?sec={sec}"

NOM_LISTE_MANUELLE = "dalles_a_telecharger.txt"


def trouver_jnlp(dest_dir) -> Optional[Path]:
    """Cherche un `.jnlp` déposé par l'utilisateur, le plus récent d'abord.

    Deux emplacements acceptés : le dossier des dalles, et la racine de
    l'étude — personne ne retient qu'il faut descendre dans
    `lidar_work/laz/`, et refuser un fichier posé deux niveaux plus haut
    pour cette seule raison serait gratuit.
    """
    dest_dir = Path(dest_dir)
    candidats = []
    for dossier in (dest_dir, dest_dir.parent, dest_dir.parent.parent):
        try:
            candidats.extend(dossier.glob("*.jnlp"))
        except OSError:
            continue
    fichiers = [c for c in candidats if c.is_file() and c.stat().st_size > 0]
    if not fichiers:
        return None
    return max(fichiers, key=lambda p: p.stat().st_mtime)


def jnlp_hors_perimetre(dest_dir) -> Optional[Path]:
    """`.jnlp` posé JUSTE au-dessus du dossier de l'étude — un quasi-raté.

    Pourquoi ne pas simplement l'accepter. La racine des projets
    (`D:\\QGIS-Projects\\`) contient toutes les études : un `.jnlp` laissé là
    serait ramassé par chacune d'elles. Or un panier porte un jeu de dalles
    PRÉCIS — Segovia irait télécharger les dalles de Murcia, silencieusement,
    et `_find_cached_tile` n'y verrait rien puisqu'il juge sur le nom.

    On ne l'utilise donc pas, mais on le signale : l'utilisateur a fait 95 %
    du chemin, et c'est l'endroit naturel où il dépose le fichier (constaté
    le 2026-10-02). Un message vaut mieux qu'un silence.
    """
    dest_dir = Path(dest_dir)
    try:
        racine = dest_dir.parent.parent.parent
        fichiers = [c for c in racine.glob("*.jnlp")
                    if c.is_file() and c.stat().st_size > 0]
    except OSError:
        return None
    if not fichiers:
        return None
    return max(fichiers, key=lambda p: p.stat().st_mtime)


def _gestionnaire_jnlp(chemin: Path) -> bool:
    """Le système sait-il ouvrir un `.jnlp` ?

    Pourquoi ce contrôle est indispensable. Sous Windows, `os.startfile` sur
    une extension sans association **ne lève pas** : il rend la main sans
    rien ouvrir (Windows affiche au mieux un sélecteur d'application). Sans
    cette vérification, KarstPro annonçait « Fichier ouvert » alors que rien
    ne l'était — mesuré le 2026-10-02 sur une machine sans Java : message de
    succès, aucun processus lancé, utilisateur dans le noir.

    Or l'absence de Java est le cas NORMAL : Open Web Start est une
    installation à part, et personne ne l'a avant d'en avoir eu besoin.
    """
    try:
        if sys.platform.startswith("win"):
            import ctypes
            tampon = ctypes.create_unicode_buffer(1024)
            # FindExecutableW rend > 32 quand une application est associée.
            code = ctypes.windll.shell32.FindExecutableW(
                str(chemin), None, tampon)
            return int(code) > 32
        import shutil
        return shutil.which("open" if sys.platform == "darwin"
                            else "xdg-open") is not None
    except Exception:                                          # noqa: BLE001
        return False


def lancer_jnlp(chemin: Path, dest_dir, feedback=None) -> bool:
    """Ouvre un `.jnlp` avec l'application associée du système.

    Le `.jnlp` est l'outil de téléchargement en lot du CNIG : il lance leur
    application Java, qui demande un dossier de destination puis récupère
    toutes les dalles du panier d'affilée. C'est la voie que le CNIG
    recommande par écrit depuis que son portail exige une vérification
    anti-robot (2026-09-29), et la seule qui ramène du LiDAR 1 m.

    KarstPro se contente de **l'ouvrir** et de rappeler le dossier à
    indiquer. Il ne pilote pas l'application et ne touche à aucune
    vérification : l'utilisateur a franchi l'étape humaine dans son
    navigateur en constituant son panier.

    Returns:
        True si le système a accepté d'ouvrir le fichier. Jamais d'exception :
        un gestionnaire absent ne doit pas faire tomber la préparation, le
        message de repli suffit.
    """
    def _dire(msg):
        if feedback is not None and hasattr(feedback, "pushWarning"):
            feedback.pushWarning(msg)

    if not _gestionnaire_jnlp(chemin):
        _dire(t("Le fichier {nom} est en place, mais aucune application n'est "
                "installée pour l'ouvrir : les .jnlp exigent Open Web Start "
                "(https://openwebstart.com/download/), qui remplace Java 8 "
                "depuis le 2026-09-29. Installez-le, puis relancez la "
                "préparation — ou ouvrez le fichier à la main et indiquez-lui "
                "ce dossier : {dossier}",
                nom=chemin.name, dossier=dest_dir))
        return False

    ouvert = False
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(chemin))            # noqa: S606
            ouvert = True
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(chemin)])
            ouvert = True
        else:
            subprocess.Popen(["xdg-open", str(chemin)])
            ouvert = True
    except Exception:                                          # noqa: BLE001
        ouvert = False

    if ouvert:
        _dire(t("Fichier de téléchargement du CNIG ouvert : {nom}. Dans la "
                "fenêtre qui s'ouvre, indiquez ce dossier de destination : "
                "{dossier} — puis RELANCEZ la préparation quand les dalles "
                "sont téléchargées. Sans cela l'étude se fera sur le relief "
                "5 m, bien plus grossier.",
                nom=chemin.name, dossier=dest_dir))
    else:
        _dire(t("Un fichier {nom} est présent mais le système n'a pas pu "
                "l'ouvrir. Ouvrez-le à la main avec Open Web Start "
                "(https://openwebstart.com/download/) et indiquez-lui ce "
                "dossier : {dossier}", nom=chemin.name, dossier=dest_dir))
    return ouvert


def ecrire_liste_manuelle(dest_dir, echecs: list, feedback=None) -> Optional[Path]:
    """Écrit la liste des dalles à récupérer à la main, et le dit au journal.

    Pourquoi. Quand le téléchargement automatique tombe — le protocole du CNIG
    a changé le 2026-09-30, il répond « Error en el protocolo de descarga. No
    está autorizado » — l'étude bascule sur le MDT WCS 5 m. Or ce repli n'est
    pas une simple perte de précision : mesuré sur deux études espagnoles
    réelles, il efface la moitié à 93 % des dolines (leur surface médiane est
    de 26 m² à Isaba, soit UNE cellule de 5 m) et **toute** la détection de
    gouffres, qui se lit dans les trous de NODATA du semis LiDAR — un MDT
    interpolé n'en a aucun. Une carte presque vide est plus trompeuse qu'une
    erreur franche.

    L'échappatoire existe déjà et personne ne le sait : `_find_cached_tile`
    accepte n'importe quel fichier `PNOA*` non vide posé dans le dossier,
    en comparant la cellule de grille lue dans son nom. Déposer les dalles
    à la main SUFFIT — il manquait seulement de savoir lesquelles chercher.

    Écrite seulement en cas d'échec, contrairement au pendant français qui la
    produit à chaque fois : côté Espagne le téléchargement automatique est la
    voie normale, une liste systématique ne serait que du bruit.

    Args:
        dest_dir : dossier des `.laz` — c'est là qu'il faut déposer les dalles
        echecs : dicts de tuiles (clé `filename`) non téléchargées
        feedback : objet optionnel avec `.pushWarning(str)`

    Returns:
        `Path` du fichier écrit, ou `None` si `echecs` est vide ou si
        l'écriture échoue (ne doit jamais faire tomber la préparation).
    """
    if not echecs:
        return None
    dest_dir = Path(dest_dir)
    chemin = dest_dir / NOM_LISTE_MANUELLE
    # Dédupliqué par nom, en gardant un `sec` par dalle : une même cellule peut
    # revenir par deux communes voisines, avec deux identifiants différents.
    par_nom = {}
    for e in echecs:
        par_nom.setdefault(e["filename"], e.get("sec"))

    lignes = [
        t("# KarstPro — dalles PNOA à télécharger à la main"),
        t("# {n} dalle(s) n'ont pas pu être téléchargées automatiquement.",
          n=len(par_nom)),
        "#",
        t("# Le CNIG exige une vérification anti-robot depuis le 2026-09-29 : "
          "le téléchargement automatique n'est plus possible."),
        "#",
        t("# LE PLUS SÛR — panier du CNIG : les dalles atterrissent "
          "directement au bon endroit, sans fichier à déplacer."),
        t("#   1. ouvrir chaque lien ci-dessous et cliquer sur « Añadir a la "
          "cesta » (l'icône panier), sans télécharger dalle par dalle ;"),
        t("#   2. ouvrir la cesta, puis « Descarga automática » : le site rend "
          "un fichier .jnlp ;"),
        t("#   3. DÉPOSER ce .jnlp dans le dossier ci-dessous, puis relancer "
          "la préparation : KarstPro l'ouvrira pour vous."),
        t("#      (ou l'ouvrir soi-même avec Open Web Start, "
          "https://openwebstart.com/download/)"),
        t("#   4. quand l'application demande un dossier, indiquer CELUI "
          "ci-dessous. Elle télécharge alors toutes les dalles d'affilée."),
        t("#   5. relancer la préparation une dernière fois : les dalles "
          "seront reprises et l'étude se fera en 1 m."),
        "#",
        t("# Sinon, dalle par dalle : ouvrir chaque lien et cliquer sur le "
          "bouton de téléchargement. Pas de limite de nombre et pas "
          "d'Open Web Start à installer, mais il faut ensuite déplacer "
          "soi-même chaque fichier ici, SANS le renommer."),
        "#",
        t("# Où les déposer : {dossier}", dossier=dest_dir),
        t("#   Garder les noms de fichiers tels quels — c'est le nom qui "
          "porte la position de la dalle."),
        t("# Ensuite : relancer la préparation. Les dalles déposées seront "
          "reconnues « cache OK »."),
        "#",
        t("# Si un lien ne répond plus, chercher le nom du fichier depuis "
          "{url}", url=_CNIG_ACCUEIL),
        "#",
    ]
    for nom in sorted(par_nom):
        lignes.append(nom)
        if par_nom[nom]:
            lignes.append("    " + _CNIG_FICHE.format(sec=par_nom[nom]))
    try:
        chemin.write_text("\n".join(lignes) + "\n", encoding="utf-8")
    except OSError:
        return None
    if feedback is not None:
        feedback.pushWarning(t(
            "{n} dalle(s) PNOA n'ont pas pu être téléchargées. La liste des "
            "dalles à récupérer à la main est écrite dans {chemin} : les "
            "déposer dans ce dossier puis relancer la préparation évite le "
            "repli 5 m, qui fait perdre la plupart des dolines et TOUS les "
            "gouffres.", n=len(par_nom), chemin=chemin))
    return chemin


def download_pnoa_auto(bbox: tuple, crs: str, dest_dir, feedback=None) -> Optional[list]:
    """Orchestre le téléchargement PNOA automatique pour `bbox` : trouve
    les communes, liste et filtre les tuiles pertinentes, télécharge
    chacune.

    Args:
        bbox : (xmin, ymin, xmax, ymax) dans `crs`
        crs  : CRS de travail (ex. "EPSG:25830"/25829/25831 — target_crs
            du routeur pays)
        dest_dir : dossier de destination des `.laz`
        feedback : objet optionnel avec `.pushInfo(str)` (ex.
            `QgsProcessingFeedback`) — même patron que
            `core.lidar.download_lidar_tiles` côté France : un message
            `[i/N] fichier — ...` par tuile, pas juste avant/après le lot.

    Returns:
        Liste des `Path` téléchargés avec succès dès qu'au moins une
        tuile a réussi (comportement volontairement moins strict que
        `core.lidar.download_lidar_tiles` côté France, qui lève une
        exception au moindre échec après retries — ici l'échec de ce
        module signale simplement à l'appelant de basculer sur le repli
        WCS, cf. Task 11 du plan : mieux vaut un MNT 1 m partiel que de
        jeter tout le résultat pour une seule tuile en échec).
        `None` si aucune commune/tuile trouvée, ou si toutes les tuiles
        ont échoué.
    """
    def _alerte(msg: str) -> None:
        if feedback is not None and hasattr(feedback, "pushWarning"):
            feedback.pushWarning(msg)
        else:
            _log(msg)

    def _log(msg: str) -> None:
        if feedback:
            feedback.pushInfo(msg)

    # Ce message doit précéder la recherche, pas la suivre. `bbox_to_pnoa_tiles`
    # interroge le WFS des communes puis pagine le listing du CNIG pour chacune
    # d'elles : 52 s mesurées sur l'emprise de Murcia, davantage sur une zone à
    # cheval sur plusieurs communes. Sans lui, le journal s'arrête sur
    # « Recherche du MNT... » et rien ne dit si la recherche avance ou si elle
    # est bloquée — c'est exactement l'état du journal « segovia » du
    # 2026-08-17, qui n'a jamais pu être interprété.
    _log(t("  Recherche des dalles PNOA (communes puis listing CNIG)..."))

    tiles = bbox_to_pnoa_tiles(bbox, crs)
    if not tiles:
        return None

    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    _log(f"{len(tiles)} dalle(s) PNOA 1 m trouvée(s) pour la zone — téléchargement...")

    downloaded = []
    echecs = []
    bloque = False
    for i, tile in enumerate(tiles, start=1):
        cached = _find_cached_tile(dest_dir, tile)
        if cached is not None:
            downloaded.append(cached)
            _log(f"  [{i}/{len(tiles)}] {tile['filename']} — cache OK")
            continue

        if bloque:
            # Inutile de rejouer le refus sur chaque dalle : le blocage est
            # global au service, pas propre à une tuile. Sur l'emprise de
            # Segovia cela épargnait 35 requêtes et 35 lignes identiques.
            echecs.append(tile)
            continue

        try:
            path = download_tile(tile["sec"], tile["cod_ine"], dest_dir,
                                 signaler_refus=True)
        except _AntiRobot:
            bloque = True
            echecs.append(tile)
            _alerte(t(
                "Le CNIG exige désormais une vérification anti-robot pour "
                "télécharger (changement du 2026-09-29). Le téléchargement "
                "automatique des dalles PNOA n'est donc plus possible, et "
                "KarstPro ne contourne pas ce contrôle."))
            continue

        if path is not None:
            downloaded.append(path)
            _log(f"  [{i}/{len(tiles)}] {tile['filename']} — téléchargée")
        else:
            echecs.append(tile)
            _log(f"  [{i}/{len(tiles)}] {tile['filename']} — échec, ignorée")

    if echecs:
        # Un `.jnlp` déposé par l'utilisateur dit tout : il a constitué son
        # panier sur le portail, franchi la vérification humaine, et attend
        # que le téléchargement se fasse. On l'ouvre, plutôt que de lui
        # réécrire une liste de dalles qu'il a déjà sélectionnées.
        jnlp = trouver_jnlp(dest_dir)
        if jnlp is not None:
            lancer_jnlp(jnlp, dest_dir, feedback=feedback)
        else:
            # Quasi-raté fréquent : le fichier est à la racine des projets.
            # On ne s'en sert pas (il serait partagé par toutes les études),
            # mais le taire reviendrait à laisser l'utilisateur croire que le
            # dépôt ne marche pas.
            egare = jnlp_hors_perimetre(dest_dir)
            if egare is not None:
                _alerte(t(
                    "Un fichier de téléchargement du CNIG ({nom}) est posé "
                    "dans {ou}, trop haut pour être utilisé : un même panier "
                    "y serait partagé par toutes vos études. Déplacez-le "
                    "dans {cible} et relancez la préparation.",
                    nom=egare.name, ou=egare.parent, cible=dest_dir))
            # Écrite AVANT le retour, y compris quand tout a échoué : c'est
            # justement là que l'étude va basculer sur le MDT 5 m, et que
            # l'utilisateur a le plus besoin de savoir quoi récupérer.
            ecrire_liste_manuelle(dest_dir, echecs, feedback=feedback)

    return downloaded if downloaded else None
