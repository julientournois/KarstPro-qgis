# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Objets CRS construits **hors thread de travail**, et réutilisés partout.

## Le fait, isolé le 2026-08-20

Construire un CRS pyproj dans un **second** `QgsTask` tue le processus — une
*access violation* Windows dans `proj_create`, sans exception Python. Reproduit
en quarante lignes, sans KarstPro, et **sur les trois versions installées**
(QGIS 3.40.4 / PyQt5, 4.0.2 et 4.2.0 / PyQt6). Ce n'est donc ni un défaut de
KarstPro, ni un problème d'installation : c'est le comportement de la pile
pyproj/PROJ dans les threads de Processing.

Ce qui a été essayé et ne change rien :

- `pyproj.set_use_global_context(True)` — sans effet depuis pyproj 3.7, qui le
  signale lui-même ;
- passer par un WKT plutôt qu'un code EPSG — la base `proj.db` n'est pas en
  cause, `CRS.from_wkt` plante aussi ;
- préconstruire un CRS dans le thread principal puis reconstruire depuis une
  chaîne dans la tâche — le cache de pyproj est **thread-local**
  (`self._local.crs = _CRS(self.srs)`), il ne sert donc à rien.

Ce qui fonctionne, vérifié sur trois tâches successives :

- réutiliser l'**objet** `pyproj.CRS` construit hors tâche ;
- passer cet objet à `GeoDataFrame(crs=...)` ;
- ne pas mettre de CRS du tout.

D'où ce module : un cache d'objets, rempli au **chargement du greffon** (donc
dans le thread principal), puis simplement relu. Le mot d'ordre est
qu'aucun `proj_create` ne parte d'un thread de travail.

## Utilisation

    from karstpro.core.crs_thread import crs_pour
    gdf = gpd.GeoDataFrame(..., crs=crs_pour(target_crs))

`crs_pour` rend l'objet préchargé. Sur un code inconnu, elle le construit
quand même — mieux vaut un plantage identique à l'existant qu'une couche
silencieusement privée de son CRS — mais elle le journalise, ce qui rend
l'oubli repérable au lieu d'être mortel et muet.
"""
import threading

# Codes que le pipeline peut rencontrer : CRS de travail déclarés par les
# territoires (`crs_travail`), plus les repères géographiques des services.
CODES_PRECHARGES = (
    "EPSG:2154",                                   # France, Lambert-93
    "EPSG:25829", "EPSG:25830", "EPSG:25831",      # Espagne, ETRS89 / UTM
    "EPSG:3812",                                   # Wallonie, Lambert 2008
    "EPSG:4326", "EPSG:4258",                      # WGS84 / ETRS89 géographiques
    "EPSG:3857",                                   # Web Mercator (fonds)
    "EPSG:31370",                                  # Belgique, Lambert 72
)

_cache = {}
_verrou = threading.Lock()
_oublis = set()


def precharger(codes=CODES_PRECHARGES) -> int:
    """Construit et met en cache les objets CRS. À appeler **hors tâche**.

    Appelée au chargement du greffon (`karstpro/__init__.py`), donc dans le
    thread principal de QGIS. Retourne le nombre d'objets en cache.
    """
    from pyproj import CRS

    with _verrou:
        for code in codes:
            if code not in _cache:
                try:
                    _cache[code] = CRS.from_user_input(code)
                except Exception:                   # noqa: BLE001
                    # Un code refusé ne doit pas empêcher le greffon de charger.
                    pass
        return len(_cache)


def crs_pour(code):
    """Objet CRS pour ce code, depuis le cache si possible.

    Args:
        code: « EPSG:xxxx », un objet CRS déjà construit, ou None.

    Returns:
        L'objet `pyproj.CRS` préchargé, ou ce qui a été passé s'il n'y a rien
        à faire (None, ou déjà un objet).
    """
    if code is None or not isinstance(code, str):
        return code                    # déjà un objet CRS, ou pas de CRS
    cle = code.strip().upper()
    objet = _cache.get(cle)
    if objet is not None:
        return objet
    # Code hors liste : on le construit, mais on le signale une fois. Depuis un
    # thread de travail c'est le plantage assuré — autant que le journal le
    # dise avant, plutôt qu'un processus qui disparaît sans un mot.
    if cle not in _oublis:
        _oublis.add(cle)
        print(f"KarstPro/crs_thread : « {code} » absent du préchargement — "
              "construction dans le thread courant, plantage possible si "
              "c'est un thread de travail. À ajouter à CODES_PRECHARGES.")
    from pyproj import CRS

    with _verrou:
        _cache[cle] = CRS.from_user_input(code)
    return _cache[cle]


def codes_en_cache() -> tuple:
    """Codes actuellement préchargés — pour les tests et le diagnostic."""
    return tuple(sorted(_cache))
