# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Mises en page imprimables du projet QGIS généré.

Deux feuilles, parce qu'elles répondent à deux questions qu'aucune ne porte
ensemble :

* **Carte de décision** — *où aller*. Fond topographique, cibles P1/P2, cibles
  déjà visitées, cavités connues.
* **Carte morphologique** — *pourquoi c'est là*. Ombrage du MNT et TOUS les
  polygones de dolines colorés par priorité : ici les 1806 dolines de Bayard ne
  sont pas du bruit, elles sont le sujet.

Le papier sert à **préparer**, pas à naviguer (la navigation est sur QField) :
d'où une feuille par secteur, sans dallage ni tableau d'assemblage.

**La légende est curée, jamais automatique.** Une légende automatique listerait
l'hydrologie D8 (235 872 segments sur Bayard) et les 24 formations BD Charm-50.
Les listes ci-dessous sont le cœur de ce module ; le reste n'est que de la
composition.
"""

# Jeton remplacé par le nom du secteur : les couches de cibles s'appellent
# « {secteur} — cibles P1 », leur nom n'est donc pas connu à l'écriture.
SECTEUR_JETON = "{secteur}"

NOM_DECISION = "Carte de décision"
NOM_MORPHO = "Carte morphologique"
NOM_OMBRAGE = "MNT (ombrage)"

# Les fonds ne sont PLUS nommés en dur. Une liste ["Plan IGN", "SCAN25 …"] ne
# trouvait rien hors de France : la carte de décision wallonne sortait SANS
# AUCUN FOND (constaté le 2026-08-10). On prend désormais les rasters cochés du
# projet, dans leur ordre d'arbre — le territoire décide de ses fonds et de leur
# empilement, la mise en page se contente de les consommer.
#
# « Cochés » et non « tous » : un fond décoché est un fond que le territoire ne
# veut pas au premier plan. En France l'Ortho est décochée au profit du Plan
# IGN, en Wallonie au profit du PICC. Les prendre tous ferait passer le
# satellite par-dessus la carte topographique.
#
# Le SCAN25 reste ainsi empilé sur le Plan IGN quand une clé est fournie : il
# rend une couche VIDE SANS ERREUR si la clé est invalide, et l'empilement
# supprime ce cas au lieu de tenter de le détecter.

LEGENDE_DECISION = [
    (f"{SECTEUR_JETON} — cibles P1", "Cibles P1 (score ≥ 55)"),
    (f"{SECTEUR_JETON} — cibles P2", "Cibles P2 (score 35–54)"),
    (f"{SECTEUR_JETON} — cibles visitées", "Déjà prospecté"),
    ("gouffres", "Gouffres candidats"),
    ("cavites_connues", "Cavités connues"),
    ("cavites_georisques", "Cavités BRGM Géorisques"),
    ("topo_reseau", "Réseau topographié"),
    # Couches de contexte wallonnes (Atlas du Karst Wallon). Une entrée dont la
    # couche n'existe pas est ignorée — c'est déjà le cas de `cavites_georisques`
    # hors de France : la légende est curée pour TOUS les territoires, chacun
    # n'en voit que les lignes qu'il peut remplir.
    (f"{SECTEUR_JETON} — Sites karstiques (AKWA)", "Sites de l'Atlas du Karst Wallon"),
    (f"{SECTEUR_JETON} — Galeries (AKWA)", "Galeries topographiées (AKWA)"),
    ("bdtopo_eau", "Sources et pertes cartographiées"),
]

LEGENDE_MORPHO = [
    ("dolines", "Dépressions détectées, par priorité"),
    # Les cibles PAR-DESSUS les polygones : à 1:25 000 une doline de 400 m²
    # fait moins d'un millimètre, sa couleur de priorité est illisible
    # (constaté à l'impression le 2026-08-10). Le polygone donne la forme et
    # l'alignement, le symbole de cible donne la priorité.
    (f"{SECTEUR_JETON} — cibles P1", "Cibles P1 (score ≥ 55)"),
    (f"{SECTEUR_JETON} — cibles P2", "Cibles P2 (score 35–54)"),
    ("gouffres", "Gouffres candidats"),
]


def nom_affiche(nom_table, secteur):
    """Nom sous lequel une couche apparaît dans le projet.

    `_write_qgs_project` renomme chaque couche en « {secteur} — {libellé} »,
    où le libellé est TRADUIT (`libelle_couche`). Chercher « dolines » ne
    trouve donc rien : il faut refaire la même transformation, sinon le module
    compose une carte vide en silence — constaté le 2026-08-09, le cadre
    n'avait qu'une couche sur les huit attendues.

    Les couches de cibles font exception : elles portent déjà le secteur.
    """
    from karstpro.core.i18n import libelle_couche

    nom = nom_table.replace(SECTEUR_JETON, secteur)
    if nom.startswith(secteur):
        return nom
    return f"{secteur} — {libelle_couche(nom)}"


def couches_de_legende(modele, secteur):
    """Noms de couches d'un modèle de légende, tels qu'ils sont dans le projet."""
    return [nom_affiche(nom, secteur) for nom, _libelle in modele]


def pages_attendues(a_un_mnt: bool) -> list:
    """Noms des mises en page qui seront créées.

    Séparée de la création pour être testable sans Qt : c'est la règle de
    dégradation, et c'est elle qu'on veut verrouiller.
    """
    return [NOM_DECISION, NOM_MORPHO] if a_un_mnt else [NOM_DECISION]


# ── Composition (tout ce qui suit exige qgis.core) ──────────────────────────

def _par_nom(projet, noms):
    """Couches du projet portant ces noms, dans l'ordre demandé, sans trou."""
    trouvees = []
    for n in noms:
        for couche in projet.mapLayersByName(n):
            trouvees.append(couche)
            break
    return trouvees


def _fonds(projet, titres=None):
    """Fonds de carte du projet : TOUS les rasters hors ombrage, en ordre d'arbre.

    Territoire-agnostique — cf. le commentaire en tête de module sur l'échec
    d'une liste de noms codée en dur.

    « Tous » et non « cochés » : filtrer sur l'état coché a été essayé le
    2026-08-10 et a fait sortir la carte française avec le SEUL SCAN25, celui
    qui rend une page blanche sans clé. L'ordre de l'arbre porte déjà
    l'intention d'empilement du territoire ; s'y fier vaut mieux qu'une
    heuristique sur un état que la relecture du projet ne restitue pas.
    """
    fonds = []
    for couche in projet.layerTreeRoot().layerOrder():
        if couche.name() == NOM_OMBRAGE:
            continue
        if couche.__class__.__name__ != "QgsRasterLayer":
            continue
        if titres is not None and couche.name() not in titres:
            continue
        fonds.append(couche)
    return fonds


def _nouvelle_page(projet, nom):
    """Mise en page A3 paysage, vide, non encore enregistrée dans le projet."""
    from qgis.core import QgsLayoutSize, QgsPrintLayout, QgsUnitTypes

    layout = QgsPrintLayout(projet)
    layout.initializeDefaults()
    layout.setName(nom)
    page = layout.pageCollection().page(0)
    # setPageSize n'accepte PAS le couple (QgsLayoutSize, Orientation) : cette
    # surcharge attend un nom de format ("A3"). On passe donc la taille seule —
    # 420 x 297 mm EST un A3 paysage, l'orientation se deduit des dimensions,
    # et on evite au passage un enum dont la portee a change en PyQt6.
    page.setPageSize(QgsLayoutSize(420, 297, QgsUnitTypes.LayoutMillimeters))
    return layout


def _carte(layout, couches, emprise):
    """Cadre de carte occupant la zone utile, calé sur l'emprise de l'étude."""
    from qgis.core import (QgsLayoutItemMap, QgsLayoutPoint, QgsLayoutSize,
                           QgsUnitTypes)

    carte = QgsLayoutItemMap(layout)
    # PAS de setRect() : il force la geometrie de l'objet graphique en
    # court-circuitant la gestion de taille de la mise en page, et le projet
    # se relit alors avec un cadre de 0 x 0 mm — page blanche, emprise NaN.
    # Constate le 2026-08-09 en comparant un cadre cree avec et sans, apres
    # aller-retour ecriture/relecture. attemptResize suffit et persiste.
    carte.setLayers(couches)
    # Fige la sélection : sans ça, la mise en page suivrait les cases cochées
    # de l'arbre des couches, donc changerait selon ce que l'utilisateur a
    # affiché avant d'imprimer.
    carte.setKeepLayerSet(True)
    layout.addLayoutItem(carte)
    carte.attemptMove(QgsLayoutPoint(12, 20, QgsUnitTypes.LayoutMillimeters))
    carte.attemptResize(QgsLayoutSize(280, 245, QgsUnitTypes.LayoutMillimeters))
    rect = _rectangle(emprise)
    if rect is None or rect.isEmpty():
        rect = _emprise_des_couches(couches)
    if rect is not None:
        carte.zoomToExtent(rect)
    # Verifier le RESULTAT et pas seulement l'entree : une emprise finie peut
    # donner un cadrage non fini apres ajustement au format du cadre.
    if not _extent_finie(carte):
        repli = _emprise_des_couches(couches)
        if repli is not None:
            carte.zoomToExtent(repli)
    return carte


def _extent_finie(carte) -> bool:
    import math

    try:
        e = carte.extent()
        return all(math.isfinite(v) for v in
                   (e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum()))
    except Exception:
        return False


def _emprise_des_couches(couches):
    """Union des emprises, en repli quand l'emprise fournie est inexploitable.

    Constaté le 2026-08-09 : `zoom_extent` arrivait avec une hauteur NaN, et
    la carte sortait cadrée sur rien. Mieux vaut un cadrage large et juste
    qu'une page vide.
    """
    from qgis.core import QgsRectangle

    union = QgsRectangle()
    union.setNull()
    for c in couches:
        try:
            e = c.extent()
        except Exception:
            continue
        if e is None or e.isNull() or e.isEmpty():
            continue
        union.combineExtentWith(e)
    return None if union.isNull() else union


def _rectangle(emprise):
    """QgsRectangle depuis ce que l'appelant a sous la main.

    `_write_qgs_project` transporte l'emprise de zoom sous forme de tuple
    (xmin, ymin, xmax, ymax), alors que `zoomToExtent` exige un QgsRectangle.
    On accepte les deux plutot que d'imposer une conversion au seul appelant :
    le module serait sinon inutilisable depuis un test ou un script.
    """
    if emprise is None:
        return None
    from qgis.core import QgsRectangle

    if isinstance(emprise, QgsRectangle):
        return emprise
    import math

    try:
        x0, y0, x1, y1 = (float(v) for v in emprise)
    except (TypeError, ValueError):
        return None
    # Un NaN passe silencieusement dans QgsRectangle et donne une page cadree
    # sur rien : on le refuse ici pour tomber sur le repli.
    if not all(math.isfinite(v) for v in (x0, y0, x1, y1)):
        return None
    return QgsRectangle(x0, y0, x1, y1)


def _legende(layout, carte, projet, modele, secteur, titre):
    """Légende NON automatique, construite couche par couche.

    ``setAutoUpdateModel(False)`` est le seul moyen d'exclure l'hydrologie et
    les 24 formations sans les retirer du projet : le modèle automatique suit
    l'arbre des couches, on ne peut rien lui soustraire.
    """
    from qgis.core import QgsLayoutItemLegend, QgsLayoutPoint, QgsUnitTypes

    lg = QgsLayoutItemLegend(layout)
    lg.setLinkedMap(carte)
    lg.setTitle(titre)
    lg.setAutoUpdateModel(False)
    # VIDER le groupe racine, pas le remplacer. À sa création la légende copie
    # tout l'arbre du projet ; `setAutoUpdateModel(False)` ne l'en empêche pas
    # (méthode dépréciée) et `model().setRootGroup(...)` ne prend pas non plus.
    # Seul `removeAllChildren()` fait effet — sans lui la légende sortait avec
    # les 19 couches du projet, hydrologie et géologie comprises, en plus des
    # entrées curées (constaté le 2026-08-09 par le smoke test).
    racine = lg.model().rootGroup()
    racine.removeAllChildren()
    for nom, libelle in modele:
        reel = nom_affiche(nom, secteur)
        couches = projet.mapLayersByName(reel)
        if not couches:
            continue           # couche optionnelle absente : on saute
        noeud = racine.addLayer(couches[0])
        # setUseLayerName(False) AVANT setName : sans lui, setName renomme la
        # COUCHE DU PROJET, pas seulement l'entree de legende. Effet constate
        # le 2026-08-09 — les couches s'appelaient « Cibles P1 (score >= 55) »
        # dans le panneau QGIS, et la seconde mise en page ne retrouvait plus
        # « {secteur} — gouffres », deja renommee par la premiere.
        noeud.setUseLayerName(False)
        noeud.setName(libelle)
    lg.adjustBoxSize()
    layout.addLayoutItem(lg)
    lg.attemptMove(QgsLayoutPoint(300, 20, QgsUnitTypes.LayoutMillimeters))
    return lg


def _habillage(layout, carte, secteur, sous_titre, version, date_iso):
    """Titre, mentions, barre d'échelle et flèche nord — communs aux deux feuilles."""
    from pathlib import Path

    from qgis.core import (QgsApplication, QgsLayoutItemLabel,
                           QgsLayoutItemPicture, QgsLayoutItemScaleBar,
                           QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes)

    titre = QgsLayoutItemLabel(layout)
    titre.setText(f"{secteur} — {sous_titre}")
    titre.adjustSizeToText()
    layout.addLayoutItem(titre)
    titre.attemptMove(QgsLayoutPoint(12, 8, QgsUnitTypes.LayoutMillimeters))

    pied = QgsLayoutItemLabel(layout)
    pied.setText(
        f"KarstPro {version} — préparé le {date_iso}\n"
        "Fonds : IGN (licence ouverte). Cibles : détection automatique, "
        "à vérifier sur le terrain.")
    pied.adjustSizeToText()
    layout.addLayoutItem(pied)
    # 282 et non 278 : la barre d'echelle mesure ~10 mm de haut depuis 266,
    # elle mordait sur la premiere ligne du pied de page (constate a
    # l'impression le 2026-08-10).
    pied.attemptMove(QgsLayoutPoint(12, 282, QgsUnitTypes.LayoutMillimeters))

    barre = QgsLayoutItemScaleBar(layout)
    barre.setStyle("Single Box")
    layout.addLayoutItem(barre)
    # setLinkedMap AVANT applyDefaultSize : sans carte liee, la barre n'a
    # aucune echelle a mesurer et s'imprime avec un seul « 0 » — constate le
    # 2026-08-09 sur les deux feuilles.
    barre.setLinkedMap(carte)
    barre.applyDefaultSize()
    # Juste sous la carte, qui se termine a y=265.
    barre.attemptMove(QgsLayoutPoint(12, 266, QgsUnitTypes.LayoutMillimeters))

    # Fleche nord : SVG livre avec QGIS. Best-effort — une fleche manquante
    # ne doit pas faire echouer la mise en page.
    try:
        svg = (Path(QgsApplication.pkgDataPath())
               / "svg" / "arrows" / "NorthArrow_02.svg")
        if svg.exists():
            fleche = QgsLayoutItemPicture(layout)
            fleche.setPicturePath(str(svg))
            layout.addLayoutItem(fleche)
            fleche.setLinkedMap(carte)     # oriente selon la rotation de la carte
            fleche.attemptResize(
                QgsLayoutSize(14, 14, QgsUnitTypes.LayoutMillimeters))
            # Meme bande que la barre d'echelle, a l'autre bout : la
            # fleche debordait du haut de la page a 258.
            fleche.attemptMove(
                QgsLayoutPoint(272, 266, QgsUnitTypes.LayoutMillimeters))
    except Exception:
        pass


def ajouter_mises_en_page(projet, secteur, emprise, version, date_iso,
                          fonds_impression=None) -> list:
    """Ajoute les mises en page au projet. Retourne les noms créés.

    ``fonds_impression`` : titres des fonds à mettre sur la feuille. C'est le
    TERRITOIRE qui décide (clé ``impression`` de sa déclaration), pas la mise en
    page : l'orthophoto est dans le projet mais masquerait le fond
    topographique si on l'imprimait par-dessus. ``None`` = tous les fonds.

    Ne lit ni fichier ni réseau : le projet est déjà peuplé de ses couches.
    La présence du MNT se déduit de la présence de la couche d'ombrage, pas
    d'un accès disque — le projet est la seule source de vérité ici.
    """
    ombrage = _par_nom(projet, [NOM_OMBRAGE])
    crees = []

    couches_dec = (
        _par_nom(projet, couches_de_legende(LEGENDE_DECISION, secteur))
        + _fonds(projet, fonds_impression))
    page = _nouvelle_page(projet, NOM_DECISION)
    carte = _carte(page, couches_dec, emprise)
    _legende(page, carte, projet, LEGENDE_DECISION, secteur, "Légende")
    _habillage(page, carte, secteur, "où prospecter", version, date_iso)
    projet.layoutManager().addLayout(page)
    crees.append(NOM_DECISION)

    if ombrage:
        couches_mor = (
            _par_nom(projet, couches_de_legende(LEGENDE_MORPHO, secteur))
            + ombrage)
        page2 = _nouvelle_page(projet, NOM_MORPHO)
        carte2 = _carte(page2, couches_mor, emprise)
        _legende(page2, carte2, projet, LEGENDE_MORPHO, secteur, "Légende")
        _habillage(page2, carte2, secteur, "morphologie et relief", version, date_iso)
        projet.layoutManager().addLayout(page2)
        crees.append(NOM_MORPHO)

    return crees
