# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Identité des dolines d'une préparation à l'autre.

Le `fid` GeoPackage est un **rang d'écriture** : toute re-détection le décale
et périme les rapports MLL et les notes de terrain qui nomment `doline_1247`.

Ce module attribue un `doline_id` stable en appariant les dolines fraîchement
détectées à un **registre** persistant (table `doline_ids` du gpkg), par
recouvrement de polygones. Seules les dolines réellement nouvelles reçoivent un
numéro neuf ; un numéro retiré n'est **jamais** recyclé.

`apparier` est volontairement **pure** — géométries + registre en entrée,
identifiants + registre à jour en sortie, aucune entrée-sortie — pour que les
cinq cas d'identité (1:1, fusion, scission, disparition, réapparition) se
testent sur des polygones fabriqués.
"""

from shapely.strtree import STRtree

STATUT_VIVANTE = "vivante"
STATUT_RETIREE = "retiree"


def _meilleur_candidat(g, entrees: list, tree, seuil_iou: float,
                       exclus=()) -> tuple:
    """Entrée d'``entrees`` qui recouvre le plus ``g``, ou ``None``.

    ``tree`` est un STRtree bâti sur ``[e["emprise"] for e in entrees]``, dans
    le même ordre — il restreint les comparaisons aux emprises dont la boîte
    englobante intersecte, au lieu de balayer tout le registre.
    """
    meilleur, aire = None, 0.0
    for j in tree.query(g):
        e = entrees[int(j)]
        if e["doline_id"] in exclus:
            continue
        inter = g.intersection(e["emprise"]).area
        if inter <= 0.0:
            continue
        # À aire d'intersection strictement égale, le plus petit doline_id
        # l'emporte. L'ordre de STRtree.query() n'est pas garanti stable :
        # sans ce départage, deux emprises symétriques autour d'une même
        # doline donneraient un résultat dépendant de l'ordre de l'index.
        if meilleur is not None and (
                (inter, -e["doline_id"]) <= (aire, -meilleur["doline_id"])):
            continue
        # `aire` n'est mise à jour QUE si le candidat passe le seuil IoU : un
        # gros recouvrement rejeté par le seuil ne doit pas masquer un
        # candidat plus petit mais valide. Ne pas « simplifier » en sortant
        # l'affectation du test.
        union = g.area + e["emprise"].area - inter
        if union and inter / union >= seuil_iou:
            meilleur, aire = e, inter
    return meilleur, aire


def apparier(dolines: "geopandas.GeoDataFrame", registre: list,
             date_jour: str, seuil_iou: float = 0.1,
             part_kept_min: float = 0.60) -> tuple:
    """Attribue un ``doline_id`` à chaque doline de ``dolines``.

    Args:
        dolines: GeoDataFrame des dolines fraîchement détectées.
        registre: liste d'entrées (cf. docstring du module).
        date_jour: date ISO de la préparation en cours.
        seuil_iou: recouvrement minimal pour reconnaître la même doline.
        part_kept_min: en cas de scission, part de la surface **conservée**
            que la plus grosse pièce doit représenter pour hériter de
            l'identifiant. Le seuil est **inclus** (``part_kept ==
            part_kept_min`` conserve l'identifiant).

    Returns:
        ``(ids, registre_maj, stats)`` où :

        - ``ids`` : ``list[int]`` de la longueur de ``dolines``, alignée sur
          ses lignes ;
        - ``registre_maj`` : le registre à jour, à réécrire tel quel — copie,
          l'entrée n'est jamais modifiée en place ;
        - ``stats`` : ``dict`` de compteurs. ``apparies`` compte
          **indistinctement** les appariements 1:1 ordinaires et les
          scissions dont la plus grosse pièce a hérité de l'identifiant ;
          pour isoler ces dernières, lire ``scissions_conservees``.
          ``scissions_neuves`` compte les scissions trop équilibrées pour
          qu'un héritier soit désigné — leurs pièces sont toutes neuves et
          l'ancienne entrée est aussi comptée dans ``retirees``.
          ``neuves`` et ``reapparues`` comptent des dolines ;
          ``retirees`` compte des entrées de registre.
    """
    ids = [None] * len(dolines)
    registre_maj = [dict(e) for e in registre]
    stats = {"apparies": 0, "neuves": 0, "retirees": 0, "reapparues": 0,
             "scissions_conservees": 0, "scissions_neuves": 0}

    geoms = list(dolines.geometry)

    # Retirées AVANT cet appel : ce sont les seules candidates à la
    # réapparition. Une entrée retirée par l'arbitrage de scission ci-dessous
    # ne doit pas ressusciter dans la foulée — le garde-fou serait vide de sens.
    retirees_a_lentree = {e["doline_id"] for e in registre if
                          e["statut"] == STATUT_RETIREE}

    # Passe 1 — contre les entrées vivantes.
    #
    # On calcule d'abord, pour chaque nouvelle doline, sa meilleure entrée
    # candidate, SANS rien attribuer. L'arbitrage des scissions a besoin de
    # connaître toutes les pièces d'une même ancienne avant de décider qui
    # hérite : impossible de trancher doline par doline.
    vivantes = [e for e in registre_maj if e["statut"] == STATUT_VIVANTE]
    tree_vivantes = STRtree([e["emprise"] for e in vivantes])
    meilleur_par_doline = {}          # i -> (entree, aire_intersection)
    for i, g in enumerate(geoms):
        meilleur, aire = _meilleur_candidat(g, vivantes, tree_vivantes, seuil_iou)
        if meilleur is not None:
            meilleur_par_doline[i] = (meilleur, aire)

    # Regroupement par ancienne : les pièces d'une même doline scindée.
    pieces = {}                       # doline_id -> [(i, aire), ...]
    for i, (e, aire) in meilleur_par_doline.items():
        pieces.setdefault(e["doline_id"], []).append((i, aire))

    for doline_id, lot in pieces.items():
        entree = next(e for e in vivantes if e["doline_id"] == doline_id)
        # Tri déterministe : aire décroissante, puis rang de ligne pour
        # départager deux pièces d'aire strictement égale.
        lot.sort(key=lambda t: (-t[1], t[0]))
        gagnant, aire_gagnant = lot[0]
        if len(lot) > 1:
            # part_kept — part de la surface CONSERVÉE que représente la plus
            # grosse pièce. Comparer à l'ancienne emprise mesurerait l'érosion
            # du contour, pas le partage (cf. spec § 2).
            part_kept = aire_gagnant / sum(a for _, a in lot)
            if part_kept < part_kept_min:
                stats["scissions_neuves"] += 1
                continue              # personne n'hérite : toutes les pièces
                                      # sont neuves, l'entrée sera retirée
            stats["scissions_conservees"] += 1
        ids[gagnant] = doline_id
        entree["emprise"] = geoms[gagnant]
        entree["derniere_vue"] = date_jour
        stats["apparies"] += 1

    # Les vivantes que personne n'a réclamées ont disparu de la détection.
    # On garde leur emprise : c'est elle qui permettra de leur rendre leur
    # identifiant si elles réapparaissent (cf. passe 2).
    reclames = {did for did in ids if did is not None}
    for e in registre_maj:
        if e["statut"] == STATUT_VIVANTE and e["doline_id"] not in reclames:
            e["statut"] = STATUT_RETIREE
            stats["retirees"] += 1

    # Passe 2 — réapparition. Une doline non appariée à une vivante peut
    # reprendre l'identifiant d'une retirée occupant le même lieu :
    # l'identifiant désigne un LIEU, pas une détection.
    candidates = [e for e in registre_maj
                  if e["doline_id"] in retirees_a_lentree]
    deja_pris = {did for did in ids if did is not None}
    tree_candidates = STRtree([e["emprise"] for e in candidates])
    for i, g in enumerate(geoms):
        if ids[i] is not None:
            continue
        meilleur, _aire = _meilleur_candidat(
            g, candidates, tree_candidates, seuil_iou, exclus=deja_pris)
        if meilleur is not None:
            ids[i] = meilleur["doline_id"]
            meilleur["emprise"] = g
            meilleur["statut"] = STATUT_VIVANTE
            meilleur["derniere_vue"] = date_jour
            deja_pris.add(meilleur["doline_id"])
            stats["reapparues"] += 1

    # Numéros neufs.
    #
    # Registre VIDE (première préparation d'un secteur) : on suit l'ordre
    # d'écriture, donc ``doline_id == fid``. Le mécanisme est alors strictement
    # invisible — une étude neuve porte exactement les numéros qu'elle aurait
    # portés avant son existence, et le numéro reste celui de la ligne dans la
    # table attributaire. Renuméroter une étude neuve n'apporterait rien : le
    # registre ne commence à servir qu'à la re-détection suivante.
    #
    # Registre PEUPLÉ : tri spatial (x puis y). Il n'y a plus d'égalité
    # fid/doline_id à préserver, mais deux polygonisations dans un ordre
    # différent doivent donner le même numéro à la même doline — sinon on
    # reproduit le défaut du fid qu'on corrige.
    suivant = max((e["doline_id"] for e in registre_maj), default=0) + 1
    restants = [i for i in range(len(geoms)) if ids[i] is None]
    if registre:
        restants.sort(key=lambda i: (geoms[i].centroid.x, geoms[i].centroid.y))
    for i in restants:
        ids[i] = suivant
        registre_maj.append({
            "doline_id": suivant,
            "emprise": geoms[i],
            "statut": STATUT_VIVANTE,
            "premiere_vue": date_jour,
            "derniere_vue": date_jour,
        })
        stats["neuves"] += 1
        suivant += 1

    return ids, registre_maj, stats


TABLE_REGISTRE = "doline_ids"

_DDL_REGISTRE = f"""
CREATE TABLE IF NOT EXISTS {TABLE_REGISTRE} (
    doline_id    INTEGER PRIMARY KEY,
    emprise      BLOB,
    statut       TEXT NOT NULL,
    premiere_vue TEXT,
    derniere_vue TEXT
)
"""


def charger_registre(gpkg_path) -> list:
    """Entrées du registre, emprises désérialisées en shapely.

    Retourne ``[]`` si la table n'existe pas encore (gpkg d'avant la
    migration) — c'est le signal qu'il faut amorcer.

    L'emprise est du **WKB brut** (``shapely.wkb``), pas un blob géométrie
    GeoPackage : ce dernier porte un en-tête de 8 octets ou plus avant le WKB
    (cf. ``core/gpkg.py::read_gpkg_layer``). Le registre n'est pas une couche —
    il n'a pas vocation à s'afficher dans QGIS.
    """
    import sqlite3
    from shapely import wkb

    con = sqlite3.connect(str(gpkg_path))
    try:
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        if TABLE_REGISTRE not in tables:
            return []
        out = []
        for did, blob, statut, prem, dern in con.execute(
                f"SELECT doline_id, emprise, statut, premiere_vue, "
                f"derniere_vue FROM {TABLE_REGISTRE}"):
            out.append({
                "doline_id": int(did),
                "emprise": wkb.loads(bytes(blob)) if blob else None,
                "statut": statut,
                "premiere_vue": prem or "",
                "derniere_vue": dern or "",
            })
        return out
    finally:
        con.close()


def ecrire_registre(gpkg_path, registre: list) -> None:
    """Réécrit intégralement la table ``doline_ids`` (SQL pur).

    SQL pur (``sqlite3``) et non geopandas, comme ``core/cibles_carryover.py``
    et pour la même raison : geopandas construit un CRS via pyproj, dont le
    ``proj_create`` plante au 2ᵉ lancement d'un algorithme Processing.

    Réécriture totale plutôt qu'incrémentale : ``apparier`` rend le registre
    entier à jour, et un registre partiellement écrit vaudrait un registre
    faux.
    """
    import sqlite3
    from shapely import wkb

    con = sqlite3.connect(str(gpkg_path))
    try:
        con.execute(_DDL_REGISTRE)
        con.execute(f"DELETE FROM {TABLE_REGISTRE}")
        con.executemany(
            f"INSERT INTO {TABLE_REGISTRE} (doline_id, emprise, statut, "
            f"premiere_vue, derniere_vue) VALUES (?, ?, ?, ?, ?)",
            [(int(e["doline_id"]),
              wkb.dumps(e["emprise"]) if e.get("emprise") is not None else None,
              e["statut"], e.get("premiere_vue", ""), e.get("derniere_vue", ""))
             for e in registre])
        con.commit()
    finally:
        con.close()


def amorcer_registre(gpkg_path, date_jour: str, couche: str = "dolines") -> int:
    """Amorce le registre d'un gpkg d'avant la migration : ``doline_id = fid``.

    Les `fid` GPKG sont ceux sur lesquels reposent tous les rapports MLL et
    notes de terrain déjà produits. Les reprendre **tels quels** est la
    condition pour que ce chantier soit une correction et non une dernière
    casse : décaler ne serait-ce que d'un rang périmerait ce qu'on prétend
    stabiliser.

    On ne renumérote donc **pas**, même si les `fid` sont troués : une doline
    supprimée à la main dans QGIS laisse un trou, et l'ancienne `doline_3`
    doit rester `doline_3`. La préparation force certes ``reset_index``, mais
    un gpkg qu'on amorce a pu être édité depuis.

    On passe par :func:`~karstpro.core.gpkg.read_gpkg_layer` plutôt que par un
    ``SELECT`` brut : il expose déjà le ``fid`` sous ``__fid__`` et sait
    décoder l'en-tête GeoPackage qui précède le WKB des couches. Le refaire
    ici dupliquerait ce décodage — et un troisième décodeur est un troisième
    endroit où se tromper.

    Ne fait rien si le registre existe déjà. Retourne le nombre d'entrées
    créées.
    """
    import sqlite3

    if charger_registre(gpkg_path):
        return 0

    from karstpro.core.gpkg import read_gpkg_layer
    try:
        dolines = read_gpkg_layer(gpkg_path, couche)
    except sqlite3.Error:
        # Couche « dolines » absente (gpkg d'un autre type, ou étude sans
        # détection) : il n'y a rien à amorcer, ce n'est pas une erreur. On
        # n'attrape QUE les erreurs sqlite : un bug de décodage doit remonter.
        return 0
    if dolines.empty:
        return 0

    registre = [{
        "doline_id": int(row["__fid__"]),
        "emprise": row.geometry,
        "statut": STATUT_VIVANTE,
        "premiere_vue": date_jour,
        "derniere_vue": date_jour,
    } for _, row in dolines.iterrows()]
    ecrire_registre(gpkg_path, registre)
    return len(registre)
