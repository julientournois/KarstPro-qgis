# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Lancement d'un travail lourd dans un **processus séparé**.

Pourquoi. Construire un CRS pyproj dans un second `QgsTask` tue le processus
QGIS — access violation dans `proj_create`, sans exception Python, sur les
trois versions testées (cf. `karstpro/core/crs_thread.py`). Relancer une
préparation dans la même session suffit. Un processus neuf n'a qu'un thread :
la classe entière de plantages disparaît, au lieu d'être contenue site par
site. Conception :
`docs/superpowers/specs/2026-08-20-preparation-en-sous-processus-design.md`.

Bénéfice au-delà de ce bug : un plantage tue l'enfant, **pas QGIS**.

Ce module ne connaît rien à la préparation. Il sait lancer un script, rejouer
ses événements vers un `feedback` QGIS, et tuer proprement l'arbre de processus
en cas d'annulation.
"""
import json
import os
import subprocess
import threading
import sys
import tempfile
from pathlib import Path

# Marqueur qui distingue les événements structurés du bruit de PDAL et de
# WhiteboxTools, qui écrivent abondamment sur la même sortie.
MARQUEUR = "@@KP "
# Borne mémoire du drainage de stderr : Whitebox peut en produire des
# mégaoctets. Seul le début importe — le traceback de l'enfant y est.
MAX_LIGNES_ERREUR = 5000


def interpreteur() -> str:
    """Chemin de l'interpréteur Python à lancer.

    `sys.executable` ne convient pas : dans QGIS il vaut `qgis-bin.exe`. On part
    de `sys.exec_prefix`, qui désigne le Python **embarqué** de QGIS quel que
    soit l'exécutable hôte. Vérifié le 2026-08-20 : `<exec_prefix>/python.exe`
    importe `pyproj` ET `qgis.core` sans préparation d'environnement.

    Les `python-qgis*.bat` servent de repli : ils fonctionnent aussi, mais un
    `.bat` ajoute un niveau de shell qui complique l'annulation.
    """
    prefixe = Path(sys.exec_prefix)
    candidats = [prefixe / "python.exe", prefixe / "python3.exe",
                 prefixe / "bin" / "python3", prefixe / "bin" / "python"]
    racine = prefixe.parents[1] if len(prefixe.parents) > 1 else prefixe
    candidats += [racine / "bin" / "python-qgis.bat",
                  racine / "bin" / "python-qgis-ltr.bat"]
    for c in candidats:
        if c.exists():
            return str(c)
    return sys.executable          # dernier recours : au moins ça se diagnostique


def environnement_enfant() -> dict:
    """`os.environ` enrichi d'un `PYTHONPATH` qui rend `qgis` importable.

    **Le piège qui a fait échouer la première version.** L'environnement hérité
    ne suffit PAS : dans l'interface, QGIS ajoute son propre Python à
    `sys.path` **au démarrage**, il ne le publie pas dans `PYTHONPATH`. Un
    enfant lancé depuis la fenêtre QGIS échouait donc sur
    `ModuleNotFoundError: No module named 'qgis'` — alors que le même lancement
    depuis `python-qgis.bat`, qui prépare l'environnement, fonctionnait. C'est
    exactement la différence que la vérification initiale n'a pas vue, parce
    qu'elle a été faite depuis le `.bat`.

    On recopie donc le `sys.path` du parent : si le parent sait importer
    quelque chose, l'enfant le saura aussi. Le reste de l'environnement
    (`PATH`, `GDAL_DATA`, `PROJ_LIB`) est hérité tel quel — le reconstruire à
    la main est le moyen le plus sûr de charger le mauvais `proj.db`.
    """
    env = os.environ.copy()
    chemins = [c for c in sys.path if c and Path(c).is_dir()]
    ancien = env.get("PYTHONPATH", "")
    if ancien:
        chemins.append(ancien)
    env["PYTHONPATH"] = os.pathsep.join(dict.fromkeys(chemins))

    # Le parent lit l'enfant en UTF-8 (cf. `executer`). Sans cette variable,
    # l'enfant encode sa sortie avec la page de code ANSI de Windows (cp1252)
    # et TOUT accent revient en U+FFFD — y compris dans les chemins rendus par
    # `resultat` et dans les tracebacks. `errors="replace"` rend la corruption
    # parfaitement muette : rien n'échoue, les caractères sont juste faux.
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def _tuer_arbre(proc) -> None:
    """Tue le processus ET sa descendance.

    PDAL et WhiteboxTools sont lancés par l'enfant : ne tuer que lui les
    laisserait mouliner en orphelins, invisibles et sans personne pour lire
    leur sortie.
    """
    if proc.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                       capture_output=True, check=False)
    else:
        import signal
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except OSError:
            proc.terminate()
    try:
        proc.wait(timeout=15)
    except subprocess.TimeoutExpired:
        proc.kill()


def executer(script: Path, parametres: dict, feedback=None,
             journal=None) -> dict:
    """Lance `script` dans un processus séparé et rejoue ses événements.

    Args:
        script: point d'entrée de l'enfant (reçoit en argument le chemin d'un
            fichier JSON de paramètres — **pas** les paramètres en ligne de
            commande, où un chemin Windows accentué est un piège).
        parametres: dict sérialisable en JSON.
        feedback: `QgsProcessingFeedback` — `pushInfo`, `pushWarning`,
            `setProgress`, `isCanceled` sont utilisés s'ils existent.
        journal: fichier ouvert en écriture, ou None. Reçoit TOUTES les lignes,
            marquées ou non : la sortie de PDAL ne doit jamais être perdue.

    Returns:
        Le dict de l'événement « resultat », ou {} si l'enfant n'en a pas émis.

    Raises:
        RuntimeError: l'enfant a échoué (code non nul), avec sa sortie d'erreur.
    """
    def _info(m):
        if feedback is not None:
            feedback.pushInfo(m)

    def _annule():
        return feedback is not None and feedback.isCanceled()

    dossier = Path(tempfile.mkdtemp(prefix="karstpro_sp_"))
    fichier_params = dossier / "parametres.json"
    fichier_params.write_text(json.dumps(parametres, ensure_ascii=False),
                              encoding="utf-8")

    commande = [interpreteur(), str(script), str(fichier_params)]
    creation = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    proc = subprocess.Popen(
        commande, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace", bufsize=1,
        env=environnement_enfant(), creationflags=creation,
        start_new_session=(os.name != "nt"))

    # ── Drainer stderr EN PARALLÈLE ──────────────────────────────────────
    # Sans ce fil, le parent parcourt `proc.stdout` jusqu'à épuisement et ne
    # lit `proc.stderr` qu'ensuite. Dès que l'enfant remplit le tampon de tube
    # de stderr (~64 Ko sur Windows), il BLOQUE en écriture : plus rien ne sort
    # sur stdout, et le parent attend une ligne qui ne viendra jamais. Aucune
    # exception, aucun CPU consommé — la préparation reste figée
    # indéfiniment. PDAL, WhiteboxTools et GDAL écrivent abondamment sur
    # stderr : 64 Ko sont atteints sans effort sur un secteur réel.
    #
    # Diagnostiqué le 2026-08-23 sur trois préparations d'un utilisateur en
    # 1.18.2, arrêtées en pleine étape sans le moindre message. Mesuré :
    # 1 Ko de stderr passe en 0,1 s, 200 Ko ne rendaient jamais la main.
    # Régression introduite avec le sous-processus en 1.18.0.
    lignes_err: list = []

    def _drainer():
        try:
            for ligne in proc.stderr:
                if len(lignes_err) < MAX_LIGNES_ERREUR:
                    lignes_err.append(ligne)
        except Exception:
            pass

    fil_err = threading.Thread(target=_drainer, name="karstpro-stderr",
                               daemon=True)
    fil_err.start()

    resultat = {}
    try:
        for ligne in proc.stdout:
            ligne = ligne.rstrip("\r\n")
            if journal is not None:
                journal.write(ligne + "\n")
            if _annule():
                _tuer_arbre(proc)
                raise RuntimeError("Préparation annulée par l'utilisateur.")
            if not ligne.startswith(MARQUEUR):
                continue                      # bruit PDAL/Whitebox : journalisé
            try:
                evt = json.loads(ligne[len(MARQUEUR):])
            except json.JSONDecodeError:
                continue
            genre = evt.get("type")
            if genre == "progress" and feedback is not None:
                feedback.setProgress(float(evt.get("valeur", 0)))
            elif genre == "warning" and feedback is not None:
                feedback.pushWarning(evt.get("message", ""))
            elif genre == "info":
                _info(evt.get("message", ""))
            elif genre == "resultat":
                resultat = {k: v for k, v in evt.items() if k != "type"}
        code = proc.wait()
        fil_err.join(timeout=10)
        erreur = "".join(lignes_err)
        if erreur and journal is not None:
            journal.write(erreur if erreur.endswith("\n") else erreur + "\n")
    finally:
        _tuer_arbre(proc)
        # Fermer les tuyaux explicitement. `Popen` ne le fait pas pour nous :
        # sans cela, chaque préparation laisse deux `TextIOWrapper` au
        # ramasse-miettes, qui émet un `ResourceWarning` — bruit permanent
        # dans le journal QGIS, et descripteurs retenus jusqu'à la collecte.
        for tuyau in (proc.stdout, proc.stderr):
            if tuyau is not None:
                tuyau.close()

    if code != 0:
        # Le traceback de l'enfant remonte INTÉGRALEMENT : un « échec » sans
        # cause est exactement ce qu'on cherche à supprimer.
        detail = erreur.strip() or f"code de sortie {code}, aucune sortie d'erreur"
        raise RuntimeError(f"La préparation a échoué dans son processus :\n{detail}")
    return resultat


def emettre(genre: str, **champs) -> None:
    """Émet un événement depuis l'ENFANT. Aucune dépendance à QGIS."""
    charge = {"type": genre}
    charge.update(champs)
    print(MARQUEUR + json.dumps(charge, ensure_ascii=False), flush=True)
