# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Validation du cache de travail ``lidar_work/``.

Le dossier de travail est **unique par dossier de sortie** et le seul critère de
réutilisation était l'existence du fichier. Deux études préparées dans le même
dossier de sortie réutilisaient donc silencieusement les intermédiaires de la
première : MNT, dolines, gouffres, hydrologie et courbes de niveau sortaient
tous parfaitement cohérents entre eux — mais sur l'autre zone.

Constaté le 2026-08-05 (secteur « cotera », Cantabrie) : emprise demandée
correcte (centre à 1,3 km de La Cotera), résultats pourtant décalés, et une
préparation bouclée en 40 s affichant quatre « étape ignorée » d'affilée. Le
message « MNT déjà présent » se présentait comme une optimisation rassurante
alors qu'il masquait l'incohérence.

Règle appliquée ici : **un intermédiaire ne se réutilise que s'il prouve qu'il
couvre la zone demandée.** Un skip doit justifier sa validité, pas la supposer.

Aucune reprojection n'est tentée : les bornes du raster sont comparées
directement à la bbox, toutes deux exprimées dans le CRS de travail. Un cache
produit dans un autre CRS (autre pays, autre fuseau UTM) donne des nombres sans
recouvrement — il est donc invalidé, ce qui est le comportement voulu.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple

# Tolérance sur le recouvrement. Absorbe l'alignement au pixel : le MNT espagnol
# issu du WCS MDT est découpé exactement sur la bbox et peut manquer une
# fraction de pixel sur un bord. 5 m reste très inférieur à un vrai décalage
# (des centaines de mètres au minimum), donc aucun faux négatif utile n'est
# masqué, et aucun cache légitime de 7 Go n'est jeté pour un arrondi.
TOLERANCE_M = 5.0

# Intermédiaires dérivés du MNT. Si le MNT est invalidé, ceux-ci le sont aussi :
# les conserver reproduirait exactement le bug (dolines d'une zone sur le MNT
# d'une autre). Les chemins proviennent de karst_prep_algorithm et core/lidar.
#: Témoin posé à côté de ``gouffres.gpkg`` quand le filtrage des faux gouffres
#: (bâti/eau, végétation dense) n'a PAS pu être appliqué faute de service
#: distant. Sans lui, une panne passagère se figeait dans le cache : la couche
#: brute était relue à chaque préparation suivante et le filtrage, sauté avec
#: le reste de l'étape, ne se retentait jamais. Listé dans
#: ``CACHES_DERIVES`` : un MNT reconstruit rend ce témoin sans objet.
NOM_FILTRAGE_INCOMPLET = "gouffres_filtrage_incomplet.txt"

CACHES_DERIVES = (
    "mnt_filled.tif",
    "dolines.gpkg",
    "gouffres.gpkg",
    NOM_FILTRAGE_INCOMPLET,
    "reseau.gpkg",
    "absorptions.gpkg",
    "flow_acc.tif",
    "streams.tif",
    "sinks.tif",
    "points_eau.gpkg",
    "pc_rasters.tif",
    "rgealti.tif",
)

Bbox = Tuple[float, float, float, float]


def raster_bbox(path) -> Optional[Bbox]:
    """Bornes ``(xmin, ymin, xmax, ymax)`` du raster, ou ``None`` si illisible.

    Best-effort : un fichier absent, tronqué ou corrompu renvoie ``None``, ce
    que l'appelant traite comme « cache inutilisable » — jamais comme une
    erreur bloquante.
    """
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return None
    try:
        import rasterio

        with rasterio.open(str(path)) as src:
            b = src.bounds
            return (float(b.left), float(b.bottom), float(b.right), float(b.top))
    except Exception:
        return None


def couvre_bbox(path, bbox: Bbox, tolerance_m: float = TOLERANCE_M) -> bool:
    """``True`` si le raster contient entièrement ``bbox``.

    La containment stricte est voulue : un MNT qui ne couvre qu'une partie de
    l'emprise produirait des dolines tronquées au bord sans le signaler.
    """
    bornes = raster_bbox(path)
    if bornes is None:
        return False
    rxmin, rymin, rxmax, rymax = bornes
    xmin, ymin, xmax, ymax = bbox
    t = tolerance_m
    return (rxmin - t <= xmin and rymin - t <= ymin
            and rxmax + t >= xmax and rymax + t >= ymax)


def invalider_caches_derives(work_dir) -> list:
    """Supprime les intermédiaires dérivés du MNT. Renvoie les noms supprimés.

    Ne touche ni au MNT lui-même (l'appelant le régénère ou l'écrase) ni au
    dossier ``laz/`` : les dalles LAZ sont nommées par coordonnées de dalle,
    donc réutilisables sans risque de confusion entre secteurs.
    """
    work_dir = Path(work_dir)
    supprimes = []
    for nom in CACHES_DERIVES:
        cible = work_dir / nom
        try:
            if cible.exists():
                cible.unlink()
                supprimes.append(nom)
        except OSError:
            # Fichier verrouillé (couche encore ouverte dans QGIS) : on le
            # signale par omission plutôt que de faire échouer la préparation.
            pass
    return supprimes


def cache_mnt_perime(work_dir, mnt_path=None) -> str:
    """Le MNT en cache est-il dépassé par ce que contient ``laz/`` ?

    Renvoie une raison courte (non vide = périmé), ou ``""``.

    Pourquoi ce contrôle existe. La préparation saute toute la recherche du
    MNT dès que ``mnt.tif`` existe — un raccourci qui fait gagner des minutes
    à chaque relance, et qui était juste tant que le MNT ne pouvait venir que
    des dalles. Ce n'est plus le cas :

    - **Espagne** : depuis que le portail du CNIG exige une vérification
      anti-robot (2026-09-29), la première préparation retombe sur le relief
      WCS **5 m** et écrit ``mnt.tif``. L'utilisateur dépose ensuite les
      dalles 1 m récupérées par le panier du CNIG — et le raccourci les
      ignorait toutes, sans un mot. L'étude restait en 5 m, c'est-à-dire sans
      aucun gouffre.
    - Même chose pour le ``.jnlp`` déposé mais pas encore ouvert : sans
      repasser par la capacité MNT, personne ne l'ouvre jamais.
    - **France** : un MNT bâti sur un lot de dalles incomplet ne se refaisait
      pas quand les manquantes arrivaient, alors que c'est la procédure
      documentée pour contourner le bridage du CDN de l'IGN.

    Ce contrôle est volontairement **grossier** : il dit seulement « va
    regarder ». La décision fine de reconstruire appartient à l'adaptateur du
    territoire (``_mnt_a_refaire``), qui seul sait quelles dalles il a.
    """
    work_dir = Path(work_dir)
    mnt = Path(mnt_path) if mnt_path is not None else work_dir / "mnt.tif"
    if not (mnt.exists() and mnt.stat().st_size > 0):
        return ""                      # pas de cache : rien à périmer
    laz_dir = work_dir / "laz"
    if not laz_dir.is_dir():
        return ""

    for dossier in (laz_dir, work_dir, work_dir.parent):
        try:
            if any(f.is_file() and f.stat().st_size > 0
                   for f in dossier.glob("*.jnlp")):
                return "jnlp"
        except OSError:
            pass

    try:
        date_mnt = mnt.stat().st_mtime
        for motif in ("*.laz", "*.LAZ"):
            for dalle in laz_dir.glob(motif):
                if dalle.is_file() and dalle.stat().st_mtime > date_mnt:
                    return "dalles"
    except OSError:
        pass
    return ""
