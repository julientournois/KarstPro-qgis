# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterDefinition,
    QgsProcessing,
    QgsProcessingException,
)

# NOTE: imports lourds différés dans processAlgorithm (cf. autres algorithmes) —
# QGIS injecte qgis.core avant le chargement des modules du plugin, et un
# import précoce de numpy/geopandas/sklearn peut casser certaines extensions C.


class KarstDiagnosticAlgorithm(QgsProcessingAlgorithm):
    """Diagnostic empirique : mesure si un modèle appris (Barrois, Jura
    plateau…) s'applique à une commune donnée, à partir d'un inventaire
    même partiel de cavités connues fourni par l'utilisateur.

    Ne PRÉDIT rien (impossible sans cavités déjà connues, cf.
    docs/JOURNAL_EXPERIENCES.md) : applique chaque modèle disponible aux
    dolines déjà détectées, calcule l'AUC réel contre l'inventaire fourni,
    et journalise le résultat. Read-only : aucune couche n'est modifiée.
    """

    GPKG_FILE = "GPKG_FILE"
    CAVITES_LAYER = "CAVITES_LAYER"
    MIN_CAVITES = "MIN_CAVITES"

    def name(self):
        return "karst_diagnostic_domaine"

    def displayName(self):
        return "KarstPro — Diagnostiquer un modèle"

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstDiagnosticAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        return help_html(
            "<b>Diagnostiquer un modèle appris.</b><br><br>"
            "<b>À quoi ça sert :</b> savoir si un modèle appris (Barrois, "
            "Jura plateau…) s'applique à une commune que tu prospectes, "
            "<b>sans deviner</b> — en le mesurant directement contre des "
            "cavités que tu connais déjà, même une poignée.<br><br>"
            "<b>Pourquoi cet outil existe :</b> deviner à l'avance si une zone "
            "jamais explorée est un « bon » domaine pour un modèle est "
            "<b>impossible</b> depuis le relief seul (documenté dans "
            "<i>docs/JOURNAL_EXPERIENCES.md</i> — 7 pistes testées, 7 "
            "échecs). Mais dès qu'on connaît déjà quelques cavités dans la "
            "zone, on n'a plus besoin de deviner : on applique le modèle aux "
            "dolines déjà détectées et on regarde s'il classe bien les "
            "dolines proches d'une cavité connue au-dessus des autres. C'est "
            "une <b>vérification</b>, pas une prédiction.<br><br>"
            "<b>Comment l'utiliser :</b><br>"
            "• <b>GeoPackage KarstPro</b> — le .gpkg d'une commune déjà "
            "préparée (couche <i>dolines</i> requise).<br>"
            "• <b>Cavités connues, en plus de Géorisques</b> (optionnel) — ton "
            "inventaire personnel (Karst Entry exporté en couche, club, "
            "etc.). La couche <b><i>cavites_georisques</i></b> (BRGM, déjà "
            "téléchargée automatiquement à la préparation) est <b>toujours "
            "utilisée en plus</b> si elle existe dans le gpkg — laisse ce "
            "champ vide pour te baser sur Géorisques seule, ce qui permet de "
            "tester un modèle même sans inventaire personnel. Attention : "
            "Géorisques est exhaustive dans certains massifs (Jura, "
            "Dordogne, Ardèche) mais lacunaire ailleurs (Champagne-Ardenne) — "
            "une couche vide n'y est pas anormale.<br>"
            "• <b>Minimum de cavités</b> (avancé, défaut 10) — en dessous, "
            "l'AUC est quand même calculé mais signalé comme peu fiable.<br><br>"
            "<b>Résultat (dans le journal) :</b> un AUC par modèle disponible "
            "(0,5 = hasard, proche de 1 = très bon classement), et une "
            "recommandation. <b>Rien n'est appliqué automatiquement</b> — "
            "le choix d'activer un modèle reste dans le menu « Priorisation » "
            "de « Préparer une sortie »."
        )

    def _add_advanced(self, param):
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GPKG_FILE,
            "GeoPackage KarstPro (.gpkg, déjà préparé)",
            extension="gpkg"))
        # Libellé court (le détail — fusion automatique avec cavites_georisques
        # — vit dans l'aide, cf. note sur les QLabel qui justifient les textes
        # longs dans karst_refaire_etude_algorithm.py).
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.CAVITES_LAYER,
            "Cavités connues, en plus de Géorisques (optionnel)",
            types=[QgsProcessing.TypeVectorPoint],
            optional=True))
        self._add_advanced(QgsProcessingParameterNumber(
            self.MIN_CAVITES,
            "Minimum de cavités appariées pour une estimation fiable (avancé)",
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=10,
            minValue=1,
            maxValue=1000))

    def processAlgorithm(self, parameters, context, feedback):
        import traceback
        try:
            return self._run(parameters, context, feedback)
        except QgsProcessingException:
            raise
        except Exception:
            feedback.reportError(
                f"ERREUR dans KarstDiagnosticAlgorithm :\n{traceback.format_exc()}",
                fatalError=True)
            raise

    def _run(self, parameters, context, feedback):
        from datetime import datetime
        from karstpro.core.gpkg import read_gpkg_layer, read_vlayer_geometries_2154
        from karstpro.core.model_score import list_models
        from karstpro.core.domain_diagnostic import (
            diagnose_models, format_diagnostic_report, combine_cavity_sources)
        from karstpro.core.log_feedback import write_log_header, wrap_feedback

        gpkg_path = Path(self.parameterAsFile(parameters, self.GPKG_FILE, context))
        cavites_vlayer = self.parameterAsVectorLayer(parameters, self.CAVITES_LAYER, context)
        min_cavites = self.parameterAsInt(parameters, self.MIN_CAVITES, context)

        if not gpkg_path.exists():
            raise QgsProcessingException(f"GeoPackage introuvable : {gpkg_path}")

        # Journal persistant dans logs/ (à côté du gpkg), comme les autres
        # algorithmes — utile si la fenêtre se ferme avant la fin.
        logs_dir = gpkg_path.parent / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / (
            f"karstpro_diagnostic_{gpkg_path.stem}_{datetime.now():%Y%m%d_%H%M%S}.log")
        write_log_header(log_file, "KarstPro — Diagnostiquer un modèle", parameters)
        feedback = wrap_feedback(feedback, log_file)

        # ── Lecture SANS pyproj (sqlite+shapely / API QGIS thread-safe) ──────
        # geopandas.read_file() et pyogrio construisent un CRS via pyproj ->
        # crash proj_create (DatabaseContext non thread-safe) au 2e run
        # Processing dans QGIS 4.0.2. On évite tout chemin qui y passe.
        dolines = read_gpkg_layer(gpkg_path, "dolines")
        if dolines.empty:
            raise QgsProcessingException(
                f"Couche « dolines » vide ou absente dans {gpkg_path}. "
                "Ce GeoPackage a-t-il bien été préparé par KarstPro ?")
        feedback.pushInfo(f"{len(dolines)} doline(s) lue(s) depuis « dolines ».")

        # ── Cavités connues : couche fournie + cavites_georisques (BRGM) ─────
        # cavites_georisques est déjà téléchargée automatiquement à chaque
        # « Préparer une sortie » (donnée publique, jamais un souci de
        # confidentialité) : utilisée seule si aucune couche n'est fournie,
        # ou en complément sinon. Absente d'un gpkg plus ancien -> ignorée.
        fournie = (read_vlayer_geometries_2154(cavites_vlayer)
                   if cavites_vlayer is not None else None)
        if fournie is not None:
            feedback.pushInfo(f"{len(fournie)} cavité(s) fournie(s) chargée(s).")

        try:
            georisques = read_gpkg_layer(gpkg_path, "cavites_georisques")
        except Exception as exc:
            georisques = None
            feedback.pushInfo(f"cavites_georisques indisponible ({exc}).")
        if georisques is not None and not georisques.empty:
            feedback.pushInfo(
                f"{len(georisques)} cavité(s) Géorisques (BRGM) chargée(s) "
                "depuis le gpkg.")
        else:
            georisques = None
            feedback.pushInfo("cavites_georisques vide ou absente du gpkg.")

        cavites = combine_cavity_sources(fournie, georisques)
        if cavites.empty:
            feedback.pushWarning(
                "Aucune cavité connue (ni fournie, ni Géorisques) — tous les "
                "diagnostics seront non calculables.")
        else:
            feedback.pushInfo(f"{len(cavites)} cavité(s) connue(s) au total "
                              "pour le diagnostic.")

        models = list_models()
        if not models:
            raise QgsProcessingException(
                "Aucun modèle appris trouvé dans karstpro/models/ — "
                "installation du plugin incomplète ?")
        feedback.pushInfo(
            f"Modèles disponibles : {', '.join(m.get('model_id', '?') for m in models)}")

        entries = diagnose_models(dolines, cavites, models, min_cavites=min_cavites)

        feedback.pushInfo("")
        feedback.pushInfo("=== Diagnostic empirique de domaine ===")
        for line in format_diagnostic_report(entries):
            feedback.pushInfo(line)

        return {}
