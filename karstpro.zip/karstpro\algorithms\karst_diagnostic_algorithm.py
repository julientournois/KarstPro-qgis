# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterDefinition,
    QgsProcessing,
    QgsProcessingException,
)
from karstpro.core.i18n import t

# NOTE: imports lourds différés dans processAlgorithm (cf. autres algorithmes) —
# QGIS injecte qgis.core avant le chargement des modules du plugin, et un
# import précoce de numpy/geopandas/sklearn peut casser certaines extensions C.


class KarstDiagnosticAlgorithm(QgsProcessingAlgorithm):
    """Diagnostic empirique : mesure si un modèle appris (Barrois, Jura
    plateau…) s'applique à une commune donnée, à partir d'un inventaire
    même partiel de cavités connues fourni par l'utilisateur.

    Ne PRÉDIT rien (impossible sans cavités déjà connues, cf.
    docs/JOURNAL_EXPERIENCES.md) : applique chaque modèle disponible aux
    dolines déjà détectées, calcule l'AUC réel contre l'inventaire fourni,
    et journalise le résultat. Read-only : aucune couche n'est modifiée.
    """

    GPKG_FILE = "GPKG_FILE"
    CAVITES_LAYER = "CAVITES_LAYER"
    MIN_CAVITES = "MIN_CAVITES"

    def name(self):
        return "karst_diagnostic_domaine"

    def displayName(self):
        return t("KarstPro — Diagnostiquer un modèle")

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstDiagnosticAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        from karstpro.core.i18n import aide
        # Corps du panneau dans i18n/aide/<module>.<langue>.html — le nom du
        # module vient de __name__, il ne peut pas diverger du fichier.
        return help_html(aide(__name__.rsplit(".", 1)[-1]))

    def _add_advanced(self, param):
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GPKG_FILE,
            t("GeoPackage KarstPro (.gpkg, déjà préparé)"),
            extension="gpkg"))
        # Libellé court (le détail — fusion automatique avec cavites_georisques
        # — vit dans l'aide, cf. note sur les QLabel qui justifient les textes
        # longs dans karst_refaire_etude_algorithm.py).
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.CAVITES_LAYER,
            t("Cavités connues, en plus de Géorisques (optionnel)"),
            types=[QgsProcessing.TypeVectorPoint],
            optional=True))
        self._add_advanced(QgsProcessingParameterNumber(
            self.MIN_CAVITES,
            t("Minimum de cavités appariées pour une estimation fiable (avancé)"),
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=10,
            minValue=1,
            maxValue=1000))

    def processAlgorithm(self, parameters, context, feedback):
        import traceback
        try:
            return self._run(parameters, context, feedback)
        except QgsProcessingException:
            raise
        except Exception:
            feedback.reportError(
                t("ERREUR dans KarstDiagnosticAlgorithm :\n{v0}", v0=traceback.format_exc()),
                fatalError=True)
            raise

    def _run(self, parameters, context, feedback):
        from datetime import datetime
        from karstpro.core.gpkg import read_gpkg_layer, read_vlayer_geometries_2154
        from karstpro.core.model_score import list_models
        from karstpro.core.domain_diagnostic import (
            diagnose_models, format_diagnostic_report, combine_cavity_sources)
        from karstpro.core.log_feedback import write_log_header, wrap_feedback

        gpkg_path = Path(self.parameterAsFile(parameters, self.GPKG_FILE, context))
        cavites_vlayer = self.parameterAsVectorLayer(parameters, self.CAVITES_LAYER, context)
        min_cavites = self.parameterAsInt(parameters, self.MIN_CAVITES, context)

        if not gpkg_path.exists():
            raise QgsProcessingException(f"GeoPackage introuvable : {gpkg_path}")

        # Journal persistant dans logs/ (à côté du gpkg), comme les autres
        # algorithmes — utile si la fenêtre se ferme avant la fin.
        logs_dir = gpkg_path.parent / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / (
            f"karstpro_diagnostic_{gpkg_path.stem}_{datetime.now():%Y%m%d_%H%M%S}.log")
        write_log_header(log_file, t("KarstPro — Diagnostiquer un modèle"), parameters)
        feedback = wrap_feedback(feedback, log_file)

        # ── Lecture SANS pyproj (sqlite+shapely / API QGIS thread-safe) ──────
        # geopandas.read_file() et pyogrio construisent un CRS via pyproj ->
        # crash proj_create (DatabaseContext non thread-safe) au 2e run
        # Processing dans QGIS 4.0.2. On évite tout chemin qui y passe.
        # Garde-fou CRS : les cavités fournies sont ramenées en Lambert-93
        # (read_vlayer_geometries_2154) puis comparées aux dolines lues telles
        # quelles du gpkg. Sur un projet non-français, les deux jeux seraient
        # dans des repères différents — distances aberrantes, diagnostic faux
        # sans le moindre signe. Même famille de bug que l'export MLL
        # (cf. JOURNAL_EXPERIENCES.md, 2026-08-02). Le diagnostic de modèle ne
        # s'applique de toute façon qu'à la France (modèles appris français).
        from karstpro.core.gpkg import gpkg_srs_id
        srs_id = gpkg_srs_id(gpkg_path, "dolines")
        if srs_id is not None and srs_id != 2154:
            raise QgsProcessingException(
                f"Le diagnostic de modèle ne gère que les projets français "
                f"(Lambert-93 / EPSG:2154) ; ce GeoPackage est en EPSG:{srs_id}. "
                f"Les distances cavités↔dolines seraient calculées entre deux "
                f"repères différents, donc fausses.")

        dolines = read_gpkg_layer(gpkg_path, "dolines")
        if dolines.empty:
            raise QgsProcessingException(
                f"Couche « dolines » vide ou absente dans {gpkg_path}. "
                "Ce GeoPackage a-t-il bien été préparé par KarstPro ?")
        feedback.pushInfo(t("{n} doline(s) lue(s) depuis « dolines ».", n=len(dolines)))

        # ── Cavités connues : couche fournie + cavites_georisques (BRGM) ─────
        # cavites_georisques est déjà téléchargée automatiquement à chaque
        # « Préparer une étude » (donnée publique, jamais un souci de
        # confidentialité) : utilisée seule si aucune couche n'est fournie,
        # ou en complément sinon. Absente d'un gpkg plus ancien -> ignorée.
        fournie = (read_vlayer_geometries_2154(cavites_vlayer)
                   if cavites_vlayer is not None else None)
        if fournie is not None:
            feedback.pushInfo(t("{n} cavité(s) fournie(s) chargée(s).", n=len(fournie)))

        try:
            georisques = read_gpkg_layer(gpkg_path, "cavites_georisques")
        except Exception as exc:
            georisques = None
            feedback.pushInfo(t("cavites_georisques indisponible ({exc}).", exc=exc))
        if georisques is not None and not georisques.empty:
            feedback.pushInfo(
                t("{n} cavité(s) Géorisques (BRGM) chargée(s) depuis le gpkg.", n=len(georisques)))
        else:
            georisques = None
            feedback.pushInfo(t("cavites_georisques vide ou absente du gpkg."))

        cavites = combine_cavity_sources(fournie, georisques)
        if cavites.empty:
            feedback.pushWarning(
                t("Aucune cavité connue (ni fournie, ni Géorisques) — tous les "
                "diagnostics seront non calculables."))
        else:
            feedback.pushInfo(t("{n} cavité(s) connue(s) au total pour le diagnostic.", n=len(cavites)))

        models = list_models()
        if not models:
            raise QgsProcessingException(
                "Aucun modèle appris trouvé dans karstpro/models/ — "
                "installation du plugin incomplète ?")
        feedback.pushInfo(
            t("Modèles disponibles : {v0}", v0=', '.join(m.get('model_id', '?') for m in models)))

        entries = diagnose_models(dolines, cavites, models, min_cavites=min_cavites)

        feedback.pushInfo("")
        feedback.pushInfo(t("=== Diagnostic empirique de domaine ==="))
        for line in format_diagnostic_report(entries):
            feedback.pushInfo(line)

        return {}
