# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from qgis.core import QgsProcessingProvider
from karstpro.algorithms.karst_prep_algorithm import KarstPrepAlgorithm
from karstpro.algorithms.karst_sync_algorithm import KarstSyncAlgorithm
from karstpro.algorithms.karst_export_mll_algorithm import KarstExportMllAlgorithm
from karstpro.algorithms.karst_update_cibles_algorithm import KarstUpdateCiblesAlgorithm
from karstpro.algorithms.karst_refaire_etude_algorithm import KarstRefaireEtudeAlgorithm
from karstpro.algorithms.karst_diagnostic_algorithm import KarstDiagnosticAlgorithm


class KarstProProvider(QgsProcessingProvider):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Injection de la locale : core/i18n.py n'importe pas Qt (core reste
        # importable sans QGIS), c'est donc la couche QGIS qui lui dit dans
        # quelle langue travailler. QgsApplication.locale() renvoie un code à
        # deux lettres déjà résolu ; les clés QgsSettings « locale/userLocale »
        # et « locale/overrideFlag » valent None tant que l'utilisateur n'a
        # rien forcé (vérifié le 2026-08-08) — s'y fier seul échouerait.
        from qgis.core import QgsApplication
        from karstpro.core.i18n import definir_langue
        definir_langue(QgsApplication.locale())

    def loadAlgorithms(self):
        self.addAlgorithm(KarstPrepAlgorithm())
        self.addAlgorithm(KarstSyncAlgorithm())
        self.addAlgorithm(KarstExportMllAlgorithm())
        self.addAlgorithm(KarstUpdateCiblesAlgorithm())
        self.addAlgorithm(KarstRefaireEtudeAlgorithm())
        self.addAlgorithm(KarstDiagnosticAlgorithm())

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def id(self):
        return "karstpro"

    def name(self):
        return "KarstPro"

    def longName(self):
        return "KarstPro — Prospection karstique"
