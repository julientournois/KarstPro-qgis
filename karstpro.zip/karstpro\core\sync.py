# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
import geopandas as gpd
import pandas as pd


def deduplicate_by_proximity(gdf: gpd.GeoDataFrame,
                              threshold_m: float = 10.0) -> gpd.GeoDataFrame:
    """Supprime les doublons à moins de threshold_m l'un de l'autre. Garde le 1er."""
    if len(gdf) <= 1:
        return gdf
    keep = [True] * len(gdf)
    geoms = list(gdf.geometry)
    for i in range(len(geoms)):
        if not keep[i]:
            continue
        for j in range(i + 1, len(geoms)):
            if not keep[j]:
                continue
            if geoms[i].distance(geoms[j]) < threshold_m:
                keep[j] = False
    return gdf[keep].reset_index(drop=True)


def fill_altitude_from_mnt(gdf: gpd.GeoDataFrame, mnt_path) -> gpd.GeoDataFrame:
    """Renseigne ``altitude`` (m) de chaque cavité par échantillonnage du MNT
    IGN 1 m, au retour terrain (le MNT n'est pas embarqué sur le téléphone).

    N'écrit que sur les valeurs manquantes (None/NaN) : une altitude déjà saisie
    à la main n'est pas écrasée. Sans effet si le MNT est absent ou illisible
    (échantillonnage best-effort, jamais bloquant). gdf attendu en EPSG:2154.
    """
    from pathlib import Path
    import math

    if gdf is None or len(gdf) == 0:
        return gdf
    mnt_path = Path(mnt_path)
    if not mnt_path.exists():
        return gdf

    import rasterio

    if "altitude" not in gdf.columns:
        gdf = gdf.copy()
        gdf["altitude"] = None

    def _missing(v):
        return v is None or (isinstance(v, float) and math.isnan(v))

    with rasterio.open(str(mnt_path)) as src:
        band = src.read(1)
        transform = src.transform
        nodata = src.nodata
        h, w = band.shape
        alt = list(gdf["altitude"])
        for i, geom in enumerate(gdf.geometry):
            if geom is None or not _missing(alt[i]):
                continue
            c = geom.centroid
            try:
                r, cc = rasterio.transform.rowcol(transform, c.x, c.y)
                if 0 <= r < h and 0 <= cc < w:
                    val = float(band[r, cc])
                    if nodata is None or val != nodata:
                        alt[i] = round(val, 1)
            except Exception:
                pass
        gdf = gdf.copy()
        gdf["altitude"] = alt
    return gdf


def _last3(coord) -> str:
    """3 derniers chiffres de la partie entière d'une coordonnée (zfill)."""
    return str(abs(int(coord)))[-3:].zfill(3)


def build_reference(feature_id, x, y) -> str:
    """Référence unique au format Karst Entry : ``{fid}-{last3X}{last3Y}``.

    Ex. fid=1, x=543210, y=4891234 → '1-210234'. Copié à l'identique de Karst
    Entry pour que les références auto soient cohérentes entre les deux outils.
    """
    return f"{feature_id}-{_last3(x)}{_last3(y)}"


def _fetch_commune_with_contour(lat, lon, timeout=3.0):
    """Géocodage inverse via geo.api.gouv.fr (point-dans-polygone communal).

    Miroir de Karst Entry. Retourne ``(admin_dict|None, polygon|None)`` :
    le dict commune/code_insee/code_postal/departement/code_dept, et le polygone
    communal (shapely) pour le cache. ``(None, None)`` en cas d'échec (réseau,
    hors France, réponse vide). Ne lève jamais d'exception."""
    import json
    import urllib.parse
    import urllib.request
    params = urllib.parse.urlencode({
        "lat": f"{lat:.6f}", "lon": f"{lon:.6f}",
        "fields": "nom,code,codesPostaux,departement,contour", "format": "json",
    })
    url = f"https://geo.api.gouv.fr/communes?{params}"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None, None
    if not data:
        return None, None
    c = data[0]
    cps = c.get("codesPostaux") or []
    dep = c.get("departement") or {}
    admin = {
        "commune":     c.get("nom", ""),
        "code_insee":  c.get("code", ""),
        "code_postal": cps[0] if cps else "",
        "departement": dep.get("nom", ""),
        "code_dept":   dep.get("code", ""),
    }
    poly = None
    contour = c.get("contour")
    if contour:
        try:
            from shapely.geometry import shape
            poly = shape(contour)
        except Exception:
            poly = None
    return admin, poly


def make_cached_geocoder(fetch=None):
    """Géocodeur (lat, lon) -> dict|None avec cache de polygones communaux.

    Pour un lot de cavités groupées (cas terrain typique : 1-2 communes), une
    seule requête réseau par commune au lieu d'une par cavité. Exact : test
    point-dans-polygone sur les contours déjà résolus avant tout appel réseau.

    ``fetch`` : callable ``(lat, lon) -> (admin_dict|None, polygon|None)``,
    injecté pour les tests (défaut : ``_fetch_commune_with_contour``)."""
    from shapely.geometry import Point as _Point
    if fetch is None:
        fetch = _fetch_commune_with_contour
    cache = []  # [(polygon, admin_dict)]

    def geocode(lat, lon):
        pt = _Point(lon, lat)  # x=lon, y=lat
        for poly, admin in cache:
            if poly is not None and poly.contains(pt):
                return admin
        admin, poly = fetch(lat, lon)
        if admin is None:
            return None
        cache.append((poly, admin))
        return admin

    return geocode


def _cibles_to_do_layers(secteur: str) -> dict:
    """Couches de cibles à prospecter (P1/P2/P3) d'un secteur — sans l'archive."""
    return {
        "P1": f"{secteur} — cibles P1",
        "P2": f"{secteur} — cibles P2",
        "P3": f"{secteur} — cibles P3",
    }


def collect_field_findings(gpkg_path, secteur: str) -> gpd.GeoDataFrame:
    """Rassemble **toutes les trouvailles terrain** d'un GeoPackage QField en un
    GeoDataFrame unifié (orienté cavité, géométrie L93 native, ``crs=None``) :

      - couche ``cavites`` — saisies directes (toutes) ;
      - cibles P1/P2/P3 avec ``interet ∈ {1, 2}`` (promues comme cavités —
        décision : un « indice à creuser » va aussi à l'inventaire) ;
      - couche ``gouffres`` avec ``interet ∈ {1, 2}`` (cibles de terrain visitées).

    ``interet = 0`` (« visité, rien ») est **exclu** : il va à « cibles visitées »
    et au CSV d'apprentissage, jamais à l'inventaire.

    Colonnes : name, type, comment, developpement_estime, photos, origine,
    geometry. Lecture en sqlite pur (pas de pyproj — crash ``proj_create`` au 2ᵉ
    run Processing).
    """
    import sqlite3
    from karstpro.core.gpkg import read_gpkg_layer

    con = sqlite3.connect(str(gpkg_path))
    try:
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
    finally:
        con.close()

    rows, geoms = [], []

    def _clean_str(v):
        if v is None:
            return ""
        try:
            if pd.isna(v):
                return ""
        except (TypeError, ValueError):
            pass
        return str(v).strip()

    def _add(layer, origine, interet_filter):
        if layer not in tables:
            return
        try:
            gdf = read_gpkg_layer(gpkg_path, layer)
        except Exception:
            return
        if gdf is None or gdf.empty:
            return
        cols = set(gdf.columns)
        for _, r in gdf.iterrows():
            g = r.geometry
            if g is None or not hasattr(g, "is_empty") or g.is_empty:
                continue
            interet = None
            if interet_filter is not None:
                if "interet" not in cols:
                    continue
                try:
                    interet = int(r["interet"])
                except (TypeError, ValueError):
                    continue
                if interet not in interet_filter:
                    continue
            typ = _clean_str(r["type"]) if "type" in cols else ""
            comment = _clean_str(r["comment"]) if "comment" in cols else ""
            # Cible/gouffre promu sans type explicite → « Cavité » (décision :
            # interet≥1 traité comme cavité). Le verdict d'origine est tracé dans
            # le commentaire pour ne rien perdre de l'info terrain.
            if interet is not None:
                if not typ:
                    typ = "Cavité"
                note = {1: "Verdict terrain : indice à creuser",
                        2: "Verdict terrain : cavité"}.get(interet)
                if note:
                    comment = f"{comment} | {note}" if comment else note
            rows.append({
                "name": _clean_str(r["name"]) if "name" in cols else "",
                "type": typ,
                "comment": comment,
                "developpement_estime": (r["developpement_estime"]
                                         if "developpement_estime" in cols else None),
                "photos": _clean_str(r["photos"]) if "photos" in cols else "",
                "origine": origine,
            })
            geoms.append(g)

    _add("cavites", "Saisie directe", None)
    for prio, lname in _cibles_to_do_layers(secteur).items():
        _add(lname, f"Cible {prio}", {1, 2})
    _add("gouffres", "Gouffre", {1, 2})

    if not rows:
        return gpd.GeoDataFrame(
            {c: [] for c in ("name", "type", "comment", "developpement_estime",
                             "photos", "origine")},
            geometry=[], crs=None)
    return gpd.GeoDataFrame(rows, geometry=geoms, crs=None)


def reset_gouffres_interet(gpkg_path, interet_values=(1, 2)) -> int:
    """Remet à ``-1`` (non visité) l'``interet`` des gouffres déjà exportés.

    La couche ``gouffres`` est une **référence** (gouffres connus) : on ne
    supprime pas l'entité, on neutralise seulement le verdict terrain une fois
    qu'il est parti à l'inventaire (CSV), pour qu'il ne soit pas ré-exporté à une
    prochaine synchro.

    L'UPDATE se fait en sqlite pur, mais les triggers rtree de GDAL appellent
    ``ST_IsEmpty``/``ST_MinX`` (absents du sqlite3 Python) et feraient échouer
    l'UPDATE. On retire donc temporairement les triggers de la couche (leur SQL
    exact est relu depuis ``sqlite_master``, donc sans dépendre de la version de
    GDAL), on met à jour ``interet`` seul, puis on les recrée. La géométrie ne
    changeant pas, l'index spatial reste cohérent. Retourne le nombre remis à -1.
    """
    import sqlite3
    vals = [int(v) for v in interet_values]
    if not vals:
        return 0
    con = sqlite3.connect(str(gpkg_path))
    try:
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        if "gouffres" not in tables:
            return 0
        cols = {c[1] for c in con.execute('PRAGMA table_info("gouffres")')}
        if "interet" not in cols:
            return 0
        triggers = [(r[0], r[1]) for r in con.execute(
            "SELECT name, sql FROM sqlite_master "
            "WHERE type='trigger' AND tbl_name='gouffres'") if r[1]]
        for tname, _ in triggers:
            con.execute(f'DROP TRIGGER IF EXISTS "{tname}"')
        try:
            m = ",".join("?" * len(vals))
            cur = con.execute(
                f'UPDATE "gouffres" SET interet=-1 WHERE interet IN ({m})', vals)
            n = cur.rowcount
        finally:
            for _, tsql in triggers:
                con.execute(tsql)
        con.commit()
        return n
    finally:
        con.close()


# Colonnes du CSV importable par Karst Entry (gestion d'inventaire). Ordre et
# noms calqués sur l'export BaseKarst → KarstEntry (importeur tolérant : délim
# auto, CRS EPSG:4326 auto-détecté depuis x/y, mapping de colonnes par synonymes,
# photos relatives recopiées). `altitude` ajoutée (schéma cavites_connues v1.3.0).
_KARSTENTRY_COLS = [
    "reference", "name", "type", "x", "y", "comment", "developpement_estime",
    "altitude", "explorers", "date_disc", "commune", "code_insee",
    "code_postal", "departement", "code_dept", "photos",
]


_PHOTO_EXT = (".jpg", ".jpeg", ".png", ".heic", ".webp")


def _resolve_photos_abs(value, base_dir) -> str:
    """Convertit le champ ``photos`` (chemins relatifs au projet QField, séparés
    par ``;`` ou ``,``) en chemins **absolus**, pour que le CSV reste importable
    même déplacé (KarstEntry résout les relatifs au dossier du CSV). Cherche sous
    ``base_dir`` puis ``base_dir/DCIM``. Garde le token tel quel si introuvable.
    """
    from pathlib import Path
    if value is None or base_dir is None:
        return value or ""
    raw = str(value).strip()
    if not raw:
        return ""
    base = Path(base_dir)
    out = []
    for tok in raw.replace(",", ";").split(";"):
        tok = tok.strip()
        if not tok:
            continue
        p = Path(tok)
        if p.is_absolute():
            out.append(str(p))
            continue
        found = None
        for cand in (base / tok, base / "DCIM" / tok, base / "DCIM" / p.name,
                     base / p.name):
            try:
                if cand.is_file() and cand.suffix.lower() in _PHOTO_EXT:
                    found = cand
                    break
            except OSError:
                continue
        out.append(str(found) if found is not None else str(base / tok))
    return ";".join(out)


def write_karstentry_csv(findings, out_csv, geocoder=None, ref_start=1,
                         photos_base_dir=None) -> int:
    """Écrit les trouvailles terrain en **CSV importable par Karst Entry**.

    Format : délimiteur ``;``, encodage UTF-8-BOM, ``x``/``y`` = lon/lat WGS84
    (EPSG:4326, KarstEntry les détecte). ``reference`` auto-générée si vide
    (format Karst Entry ``{n}-{last3X}{last3Y}`` sur coordonnées L93). La commune
    et les codes admin sont géocodés (inverse geo.api.gouv.fr, avec cache).

    ``photos_base_dir`` : si fourni, les chemins ``photos`` (relatifs au projet
    QField) sont résolus en **absolus** sous ce dossier — le CSV reste alors
    importable même placé ailleurs (ex. dossier du rapport). Sinon les chemins
    sont laissés tels quels (relatifs au dossier du CSV).

    Conversion L93→WGS84 en pur Python (pas de pyproj : crash ``proj_create`` au
    2ᵉ run Processing). Retourne le nombre de lignes écrites (l'en-tête est
    toujours écrit, même à 0 ligne — fichier visible et ré-importable).
    """
    import csv
    from pathlib import Path
    from karstpro.core.geology import _l93_to_wgs84

    out_csv = Path(out_csv)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    if geocoder is None:
        geocoder = make_cached_geocoder()

    has_col = (lambda c: findings is not None and c in findings.columns)

    def _s(r, c):
        if not has_col(c):
            return ""
        v = r.get(c)
        if v is None:
            return ""
        try:
            if pd.isna(v):
                return ""
        except (TypeError, ValueError):
            pass
        if isinstance(v, float) and v.is_integer():
            v = int(v)
        return str(v).strip()

    out_rows = []
    if findings is not None and len(findings):
        for i, (_idx, r) in enumerate(findings.iterrows()):
            geom = r.geometry
            x = y = ""
            admin = {}
            ref = _s(r, "reference")
            if geom is not None and not geom.is_empty:
                try:
                    lon, lat = _l93_to_wgs84(geom.x, geom.y)
                    x, y = round(lon, 6), round(lat, 6)
                    if not ref:
                        ref = build_reference(ref_start + i, geom.x, geom.y)
                    a = geocoder(lat, lon) if geocoder else None
                    if a:
                        admin = a
                except Exception:
                    pass
            out_rows.append({
                "reference": ref,
                "name": _s(r, "name"),
                "type": _s(r, "type"),
                "x": x, "y": y,
                "comment": _s(r, "comment"),
                "developpement_estime": _s(r, "developpement_estime"),
                "altitude": _s(r, "altitude"),
                "explorers": _s(r, "explorers"),
                "date_disc": _s(r, "date_disc"),
                "commune": admin.get("commune", ""),
                "code_insee": admin.get("code_insee", ""),
                "code_postal": admin.get("code_postal", ""),
                "departement": admin.get("departement", ""),
                "code_dept": admin.get("code_dept", ""),
                "photos": (_resolve_photos_abs(_s(r, "photos"), photos_base_dir)
                           if photos_base_dir else _s(r, "photos")),
            })

    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=_KARSTENTRY_COLS, delimiter=";")
        w.writeheader()
        w.writerows(out_rows)
    return len(out_rows)


def find_inventory_layer(gpkg_path, preferred: str = "Inventaire Cavités",
                         exclude=("cavites",)):
    """Nom de la couche inventaire dans un GeoPackage.

    Ordre : ``preferred`` puis ``cavites_connues`` si elles portent le noyau
    cavite, sinon la première couche features avec ``name`` + ``reference``.
    Les couches listées dans ``exclude`` (par défaut le tampon ``cavites``) sont
    ignorées — sans quoi, dans le gpkg principal, on détecterait le tampon
    lui-même comme inventaire et on y réinjecterait ses propres points.
    ``None`` si aucune ne convient.

    Lecture via sqlite (pas de dépendance fiona/pyogrio pour le listing)."""
    import sqlite3
    exclude_l = {e.lower() for e in exclude}
    with sqlite3.connect(str(gpkg_path)) as con:
        cur = con.cursor()
        try:
            tables = [r[0] for r in cur.execute(
                "SELECT table_name FROM gpkg_contents WHERE data_type='features'")]
        except sqlite3.Error:
            return None

        def has_core(t):
            cols = {r[1] for r in cur.execute(f'PRAGMA table_info("{t}")')}
            return {"name", "reference"}.issubset(cols)

        for cand in (preferred, "cavites_connues"):
            if (cand in tables and cand.lower() not in exclude_l
                    and has_core(cand)):
                return cand
        for t in tables:
            if t.lower() in exclude_l:
                continue
            if has_core(t):
                return t
    return None


def find_tracages_layer(gpkg_path, preferred: str = "Inventaire Traçages"):
    """Nom de la couche traçages dans un GeoPackage : ``preferred`` puis
    ``tracages``, sinon la première couche portant un champ traçage typique
    (``colorant`` ou ``point_injection``). ``None`` si aucune ne convient."""
    import sqlite3
    markers = {"colorant", "point_injection", "point_sortie"}
    with sqlite3.connect(str(gpkg_path)) as con:
        cur = con.cursor()
        try:
            tables = [r[0] for r in cur.execute(
                "SELECT table_name FROM gpkg_contents WHERE data_type='features'")]
        except sqlite3.Error:
            return None

        def is_tracage(t):
            cols = {r[1] for r in cur.execute(f'PRAGMA table_info("{t}")')}
            return bool(markers & cols)

        for cand in (preferred, "tracages"):
            if cand in tables and is_tracage(cand):
                return cand
        for t in tables:
            if is_tracage(t):
                return t
    return None


# Vecteur de features pour la boucle de labels (aligné sur prototypes/train_model.py).
_LABEL_FEATURES = [
    "surface_m2", "profondeur_m", "ratio_ps", "pente_max_bord", "lisere",
    "bassin_versant_m2", "comp_geologie_dist_m", "circularite",
    "tpi_500m",
]


def _cibles_layers(gpkg_path):
    """Noms des couches de cibles d'un GeoPackage : P1/P2/P3 **et** l'archive
    « cibles visitées ».

    L'archive est essentielle : « Mettre à jour les cibles » y **déplace** les
    cibles dont un verdict `interet` a été saisi (elles quittent P1/P2/P3). Sans
    lire l'archive, l'extraction de labels raterait justement les cibles visitées.
    """
    import sqlite3
    with sqlite3.connect(str(gpkg_path)) as con:
        try:
            return [r[0] for r in con.execute(
                "SELECT table_name FROM gpkg_contents WHERE data_type='features'")
                if "cibles P" in r[0] or "cibles visitées" in r[0]]
        except sqlite3.Error:
            return []


def extract_terrain_labels(qfield_gpkg, secteur: str, out_csv) -> int:
    """Extrait les labels terrain saisis (`interet`) des couches cibles vers un
    CSV cumulatif — **boucle de données P3** (saisie QField → exemple).

    Pour chaque cible visitée (`interet` ∈ {0, 1, 2}) on joint, par l'id de
    doline (`name` = ``doline_{fid}`` = fid de la couche ``dolines``), le vecteur
    morphométrique complet, puis on ajoute une ligne avec provenance (secteur,
    date). Les négatifs (`interet=0`) sont conservés : c'est le signal que
    l'inventaire ne contient jamais.

    Le CSV est **cumulatif et dédoublonné** par (secteur, doline) — un 2ᵉ sync
    du même secteur met à jour le label plutôt que d'empiler des doublons.

    Returns: nombre de lignes (labels) écrites pour ce secteur.
    """
    import re
    from datetime import date
    from pathlib import Path
    from karstpro.core.gpkg import read_gpkg_layer

    out_csv = Path(out_csv)
    layers = _cibles_layers(qfield_gpkg)
    if not layers:
        return 0

    # Features morphométriques complètes, indexées par fid de doline.
    try:
        dolines = read_gpkg_layer(qfield_gpkg, "dolines")
        dolines = dolines.set_index("__fid__")
    except Exception:
        dolines = None

    rows = []
    today = date.today().isoformat()
    for lyr in layers:
        try:
            cib = read_gpkg_layer(qfield_gpkg, lyr)
        except Exception:
            continue
        if "interet" not in cib.columns:
            continue
        for _, c in cib.iterrows():
            try:
                interet = int(c["interet"])
            except (TypeError, ValueError):
                continue
            if interet < 0:           # non visité → pas un label
                continue
            m = re.match(r"doline_(\d+)", str(c.get("name", "")))
            fid = int(m.group(1)) if m else None
            row = {
                "secteur": secteur,
                "date": today,
                "doline": c.get("name", ""),
                "fid": fid,
                "priorite": c.get("priorite", ""),
                "score": c.get("score"),
                "interet": interet,
                # Convention d'entraînement : 1 (indice à creuser) ET 2 (cavité)
                # = positifs ; 0 (visité, rien) = négatif. L'indice est conservé
                # comme positif (décision spéléo : un indice mérite la cible).
                "y": 1 if interet >= 1 else 0,
            }
            # Vecteur de features : depuis la couche dolines si dispo, sinon
            # depuis les colonnes portées par la cible elle-même.
            src = None
            if dolines is not None and fid in dolines.index:
                src = dolines.loc[fid]
            for f in _LABEL_FEATURES:
                v = src.get(f) if src is not None else c.get(f)
                row[f] = v
            rows.append(row)

    if not rows:
        return 0

    new = pd.DataFrame(rows)
    if out_csv.exists():
        try:
            old = pd.read_csv(out_csv)
            old = old[old["secteur"] != secteur]   # ce secteur est ré-extrait
            new = pd.concat([old, new], ignore_index=True)
        except Exception:
            pass
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    new.to_csv(out_csv, index=False, encoding="utf-8")
    return len(rows)
