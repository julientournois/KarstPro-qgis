# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
import io
from pathlib import Path
import requests
import geopandas as gpd

# BRGM WFS — geoservices.brgm.fr/geologie
# Layer ms:LITHO_1M_SIMPLIFIEE : simplified 1:1 000 000 lithology polygons.
# The WFS returns GML 3.2 (not JSON) in EPSG:4326; we reproject to EPSG:2154.
# ms:GEOLOGIE does not exist on this endpoint — LITHO_1M_SIMPLIFIEE is the
# correct polygon layer for karst scoring (limestone/dolomite detection).
_BRGM_WFS_URL = "https://geoservices.brgm.fr/geologie"
_LAYER = "ms:LITHO_1M_SIMPLIFIEE"
_TARGET_CRS = "EPSG:2154"


def fetch_brgm_geology(bbox_l93: tuple) -> gpd.GeoDataFrame:
    """Downloads BRGM simplified lithology layer for the given Lambert-93 bbox.

    Queries the BRGM WFS (GML 3.2 output, reprojected to EPSG:2154).
    Returns an empty GeoDataFrame on failure rather than crashing the pipeline.

    Args:
        bbox_l93: Tuple (xmin, ymin, xmax, ymax) in Lambert-93 (metres)

    Returns:
        GeoDataFrame with lithology polygons in EPSG:2154, or empty GDF on error
    """
    xmin, ymin, xmax, ymax = bbox_l93
    params = {
        "SERVICE": "WFS",
        "VERSION": "2.0.0",
        "REQUEST": "GetFeature",
        "TYPENAMES": _LAYER,
        "BBOX": f"{xmin},{ymin},{xmax},{ymax},EPSG:2154",
        "SRSNAME": "EPSG:2154",
    }
    try:
        resp = requests.get(_BRGM_WFS_URL, params=params, timeout=60)
    except requests.exceptions.RequestException as exc:
        return _empty_gdf(f"BRGM WFS connexion impossible : {exc}")

    if resp.status_code != 200:
        return _empty_gdf(
            f"BRGM WFS HTTP {resp.status_code} : {resp.text[:200]}"
        )

    # The service returns GML 3.2 — geopandas reads it via fiona/GDAL
    try:
        gdf = gpd.read_file(io.BytesIO(resp.content))
    except Exception as exc:
        return _empty_gdf(f"BRGM WFS : impossible de lire le GML — {exc}")

    if gdf.empty:
        return _empty_gdf("BRGM WFS : aucune entité dans la bbox")

    # Reproject to Lambert-93 if needed
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326")
    if gdf.crs.to_epsg() != 2154:
        gdf = gdf.to_crs(_TARGET_CRS)

    return gdf


# dep_envelopes.gpkg est embarqué dans le plugin (karstpro/data/) — toujours dispo.
_DEP_ENVELOPES = Path(__file__).resolve().parent.parent / "data" / "dep_envelopes.gpkg"

# Cache BD Charm-50 : cherché dans plusieurs emplacements dans l'ordre.
# Si un cache existe déjà, on le réutilise (repo en dev, ou home). Sinon, le
# défaut d'ÉCRITURE est le dossier du plugin lui-même (karstpro/data/geo50k),
# pour que les cartes téléchargées restent rangées DANS le plugin.
_PLUGIN_GEO50K = Path(__file__).resolve().parent.parent / "data" / "geo50k"  # karstpro/data/geo50k


def _find_geo50k_root() -> Path:
    existing = [
        Path(__file__).resolve().parent.parent.parent / "data" / "geo50k",  # repo (dev)
        _PLUGIN_GEO50K,                                                      # plugin
        Path.home() / "karstpro_data" / "geo50k",                           # home
    ]
    for p in existing:
        if p.exists():
            return p
    # Aucun cache existant : télécharger DANS le plugin (karstpro/data/geo50k).
    return _PLUGIN_GEO50K

_GEO50K_ROOT  = _find_geo50k_root()
_BRGM_ZIP_URL = "https://infoterre.brgm.fr/telechargements/BDCharm50/GEO050K_HARM_{code}.zip"

# Mapping code département → (région, nom_dep)
# Noms en ASCII sans accents pour compatibilité chemins Windows/Linux.
# Source : découpage administratif INSEE + URL Infoterre BDCharm-50.
_DEP_REGISTRY = {
    # Auvergne-Rhône-Alpes
    "001": ("Auvergne_Rhone_Alpes",      "Ain"),
    "003": ("Auvergne_Rhone_Alpes",      "Allier"),
    "007": ("Auvergne_Rhone_Alpes",      "Ardeche"),
    "015": ("Auvergne_Rhone_Alpes",      "Cantal"),
    "026": ("Auvergne_Rhone_Alpes",      "Drome"),
    "038": ("Auvergne_Rhone_Alpes",      "Isere"),
    "042": ("Auvergne_Rhone_Alpes",      "Loire"),
    "043": ("Auvergne_Rhone_Alpes",      "Haute-Loire"),
    "063": ("Auvergne_Rhone_Alpes",      "Puy-de-Dome"),
    "069": ("Auvergne_Rhone_Alpes",      "Rhone"),
    "073": ("Auvergne_Rhone_Alpes",      "Savoie"),
    "074": ("Auvergne_Rhone_Alpes",      "Haute-Savoie"),
    # Bourgogne-Franche-Comté
    "021": ("Bourgogne_Franche_Comte",   "Cote-dOr"),
    "025": ("Bourgogne_Franche_Comte",   "Doubs"),
    "039": ("Bourgogne_Franche_Comte",   "Jura"),
    "058": ("Bourgogne_Franche_Comte",   "Nievre"),
    "070": ("Bourgogne_Franche_Comte",   "Haute-Saone"),
    "071": ("Bourgogne_Franche_Comte",   "Saone-et-Loire"),
    "089": ("Bourgogne_Franche_Comte",   "Yonne"),
    "090": ("Bourgogne_Franche_Comte",   "Territoire-de-Belfort"),
    # Bretagne
    "022": ("Bretagne",                  "Cotes-dArmor"),
    "029": ("Bretagne",                  "Finistere"),
    "035": ("Bretagne",                  "Ille-et-Vilaine"),
    "056": ("Bretagne",                  "Morbihan"),
    # Centre-Val de Loire
    "018": ("Centre_Val_de_Loire",       "Cher"),
    "028": ("Centre_Val_de_Loire",       "Eure-et-Loir"),
    "036": ("Centre_Val_de_Loire",       "Indre"),
    "037": ("Centre_Val_de_Loire",       "Indre-et-Loire"),
    "041": ("Centre_Val_de_Loire",       "Loir-et-Cher"),
    "045": ("Centre_Val_de_Loire",       "Loiret"),
    # Corse
    "02A": ("Corse",                     "Corse-du-Sud"),
    "02B": ("Corse",                     "Haute-Corse"),
    # Grand Est
    "008": ("Grand_Est",                 "Ardennes"),
    "010": ("Grand_Est",                 "Aube"),
    "051": ("Grand_Est",                 "Marne"),
    "052": ("Grand_Est",                 "Haute-Marne"),
    "054": ("Grand_Est",                 "Meurthe-et-Moselle"),
    "055": ("Grand_Est",                 "Meuse"),
    "057": ("Grand_Est",                 "Moselle"),
    "067": ("Grand_Est",                 "Bas-Rhin"),
    "068": ("Grand_Est",                 "Haut-Rhin"),
    "088": ("Grand_Est",                 "Vosges"),
    # Hauts-de-France
    "002": ("Hauts_de_France",           "Aisne"),
    "059": ("Hauts_de_France",           "Nord"),
    "060": ("Hauts_de_France",           "Oise"),
    "062": ("Hauts_de_France",           "Pas-de-Calais"),
    "080": ("Hauts_de_France",           "Somme"),
    # Île-de-France
    "075": ("Ile_de_France",             "Paris"),
    "077": ("Ile_de_France",             "Seine-et-Marne"),
    "078": ("Ile_de_France",             "Yvelines"),
    "091": ("Ile_de_France",             "Essonne"),
    "092": ("Ile_de_France",             "Hauts-de-Seine"),
    "093": ("Ile_de_France",             "Seine-Saint-Denis"),
    "094": ("Ile_de_France",             "Val-de-Marne"),
    "095": ("Ile_de_France",             "Val-dOise"),
    # Normandie
    "014": ("Normandie",                 "Calvados"),
    "027": ("Normandie",                 "Eure"),
    "050": ("Normandie",                 "Manche"),
    "061": ("Normandie",                 "Orne"),
    "076": ("Normandie",                 "Seine-Maritime"),
    # Nouvelle-Aquitaine
    "016": ("Nouvelle_Aquitaine",        "Charente"),
    "017": ("Nouvelle_Aquitaine",        "Charente-Maritime"),
    "019": ("Nouvelle_Aquitaine",        "Correze"),
    "023": ("Nouvelle_Aquitaine",        "Creuse"),
    "024": ("Nouvelle_Aquitaine",        "Dordogne"),
    "033": ("Nouvelle_Aquitaine",        "Gironde"),
    "040": ("Nouvelle_Aquitaine",        "Landes"),
    "047": ("Nouvelle_Aquitaine",        "Lot-et-Garonne"),
    "064": ("Nouvelle_Aquitaine",        "Pyrenees-Atlantiques"),
    "079": ("Nouvelle_Aquitaine",        "Deux-Sevres"),
    "086": ("Nouvelle_Aquitaine",        "Vienne"),
    "087": ("Nouvelle_Aquitaine",        "Haute-Vienne"),
    # Occitanie
    "009": ("Occitanie",                 "Ariege"),
    "011": ("Occitanie",                 "Aude"),
    "012": ("Occitanie",                 "Aveyron"),
    "030": ("Occitanie",                 "Gard"),
    "031": ("Occitanie",                 "Haute-Garonne"),
    "032": ("Occitanie",                 "Gers"),
    "034": ("Occitanie",                 "Herault"),
    "046": ("Occitanie",                 "Lot"),
    "048": ("Occitanie",                 "Lozere"),
    "065": ("Occitanie",                 "Hautes-Pyrenees"),
    "066": ("Occitanie",                 "Pyrenees-Orientales"),
    "081": ("Occitanie",                 "Tarn"),
    "082": ("Occitanie",                 "Tarn-et-Garonne"),
    # Pays de la Loire
    "044": ("Pays_de_la_Loire",          "Loire-Atlantique"),
    "049": ("Pays_de_la_Loire",          "Maine-et-Loire"),
    "053": ("Pays_de_la_Loire",          "Mayenne"),
    "072": ("Pays_de_la_Loire",          "Sarthe"),
    "085": ("Pays_de_la_Loire",          "Vendee"),
    # Provence-Alpes-Côte d'Azur
    "004": ("Provence_Alpes_Cote_Azur",  "Alpes-de-Haute-Provence"),
    "005": ("Provence_Alpes_Cote_Azur",  "Hautes-Alpes"),
    "006": ("Provence_Alpes_Cote_Azur",  "Alpes-Maritimes"),
    "013": ("Provence_Alpes_Cote_Azur",  "Bouches-du-Rhone"),
    "083": ("Provence_Alpes_Cote_Azur",  "Var"),
    "084": ("Provence_Alpes_Cote_Azur",  "Vaucluse"),
}


def _dep_gpkg_path(code: str) -> Path:
    """Retourne le chemin attendu du GPKG département dans le cache local."""
    region, dep_name = _DEP_REGISTRY[code]
    return (
        _GEO50K_ROOT / region
        / f"GEO050K_HARM_{code}_{dep_name}"
        / f"GEO050K_HARM_{code}_{dep_name}.gpkg"
    )


def _download_dep(code: str, feedback=None) -> Path | None:
    """Télécharge, extrait et construit le GPKG département si absent du cache.

    Args:
        code    : code département 3 chiffres (ex. '051')
        feedback: QgsProcessingFeedback optionnel pour les logs QGIS

    Returns:
        Path vers le GPKG département, ou None en cas d'échec.
    """
    import zipfile

    def log(msg):
        if feedback:
            feedback.pushInfo(msg)
        else:
            print(msg)

    region, dep_name = _DEP_REGISTRY[code]
    gpkg_path = _dep_gpkg_path(code)
    if gpkg_path.exists():
        return gpkg_path

    dep_dir = gpkg_path.parent
    dep_dir.mkdir(parents=True, exist_ok=True)

    url = _BRGM_ZIP_URL.format(code=code)
    log(f"  Telechargement BD Charm-50 departement {dep_name} ({code})...")

    try:
        resp = requests.get(url, timeout=120, stream=True)
        if resp.status_code != 200:
            log(f"  ERREUR HTTP {resp.status_code} pour {url}")
            return None

        zip_path = dep_dir / f"GEO050K_HARM_{code}.zip"
        with open(zip_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 256):
                f.write(chunk)

        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(dep_dir)
        zip_path.unlink(missing_ok=True)
        log(f"  Extraction OK : {dep_dir.name}")

    except Exception as exc:
        log(f"  ERREUR telechargement {dep_name} : {exc}")
        # Supprimer le ZIP partiel pour éviter un état corrompu au prochain appel
        zip_path = dep_dir / f"GEO050K_HARM_{code}.zip"
        zip_path.unlink(missing_ok=True)
        return None

    # Construire le GPKG département
    shp = dep_dir / f"GEO050K_HARM_{code}_S_FGEOL_2154.shp"
    if not shp.exists():
        log(f"  SHP introuvable apres extraction : {shp.name}")
        return None

    try:
        gdf = gpd.read_file(shp).to_crs("EPSG:2154")
        gdf["DEP"] = code
        gdf["DEP_NOM"] = dep_name
        gdf["REGION"] = region
        gdf.to_file(str(gpkg_path), layer="formations_geologiques", driver="GPKG")
        sz = gpkg_path.stat().st_size / 1024 / 1024
        log(f"  GPKG cree : {gpkg_path.name} ({len(gdf)} formations, {sz:.1f} MB)")
    except Exception as exc:
        log(f"  ERREUR construction GPKG {dep_name} : {exc}")
        return None

    return gpkg_path


def fetch_geology_auto(bbox_l93: tuple, feedback=None) -> gpd.GeoDataFrame:
    """Charge la géologie BD Charm-50 1/50 000 automatiquement pour la bbox.

    Algorithme :
    1. Lit dep_envelopes.gpkg (112 KB) pour trouver les départements intersectant la bbox.
    2. Pour chaque département : vérifie le cache local, télécharge si absent.
    3. Charge et filtre les formations karstiques (calcaire/dolomie) dans la bbox.
    4. Fallback sur WFS BRGM 1/1 000 000 si aucun département connu ou échec.

    Args:
        bbox_l93 : (xmin, ymin, xmax, ymax) en EPSG:2154
        feedback : QgsProcessingFeedback optionnel

    Returns:
        GeoDataFrame formations karstiques en EPSG:2154.
    """
    from shapely.geometry import box

    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    # 1. Trouver les départements concernés via les enveloppes
    if not _DEP_ENVELOPES.exists():
        log("dep_envelopes.gpkg absent — fallback WFS BRGM.")
        return fetch_brgm_geology(bbox_l93)

    try:
        envelopes = gpd.read_file(str(_DEP_ENVELOPES), layer="departements")
        bbox_geom = box(*bbox_l93)
        hits = envelopes[envelopes.intersects(bbox_geom)]
    except Exception as exc:
        log(f"Enveloppes : erreur lecture ({exc}) — fallback WFS BRGM.")
        return fetch_brgm_geology(bbox_l93)

    if hits.empty:
        log("Bbox hors des departements en cache — fallback WFS BRGM.")
        return fetch_brgm_geology(bbox_l93)

    codes = list(hits["DEP"].values)
    log(
        f"Geologie BD Charm-50 1/50 000 — "
        f"{len(codes)} departement(s) : {', '.join(hits['DEP_NOM'].values)}"
    )

    # 2. Télécharger les départements manquants + charger
    gdfs = []
    for code in codes:
        if code not in _DEP_REGISTRY:
            log(f"  Departement {code} non repertorie — ignore.")
            continue

        gpkg: Path | None = _dep_gpkg_path(code)
        if gpkg is None or not gpkg.exists():
            gpkg = _download_dep(code, feedback=feedback)
        if gpkg is None:
            continue

        try:
            gdf = gpd.read_file(str(gpkg), layer="formations_geologiques",
                                bbox=bbox_l93)
            if not gdf.empty:
                gdfs.append(gdf)
        except Exception as exc:
            log(f"  Erreur lecture {code} : {exc}")

    if not gdfs:
        log("Aucune formation chargee depuis le cache — fallback WFS BRGM.")
        return fetch_brgm_geology(bbox_l93)

    import pandas as pd
    merged = gpd.GeoDataFrame(
        pd.concat(gdfs, ignore_index=True), crs="EPSG:2154"
    )

    # Géologie COMPLÈTE (toutes formations, couleurs BRGM conservées). Le
    # sous-ensemble karstifiable pour le scoring est dérivé à la volée
    # (filter_karstifiable) — pas de couche dédiée au score.
    n_karst = len(filter_karstifiable(merged))
    log(f"  {len(merged)} formation(s) dans la bbox ({n_karst} karstifiable(s)).")
    return merged


def filter_karstifiable(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Sous-ensemble **karstifiable** d'une couche géologie : formations dont la
    DESCR contient « calcaire » / « dolomie » (les carbonates, seuls à se
    dissoudre en karst). Utilisé par le scoring (proximité au calcaire).

    La couche géologie livrée, elle, reste **complète** (toutes formations, pour
    l'interprétation) : on dérive le karstifiable à la volée, sans persister de
    couche dédiée au score.

    Sans colonne DESCR → renvoie tout (le scoring retombe sur le bord externe).
    GDF vide → GDF vide.
    """
    if gdf is None or gdf.empty or "DESCR" not in gdf.columns:
        return gdf
    # case=False avec ArrowStringArray nécessite RE2 (absent QGIS 4.0.2) : on
    # normalise en minuscule et on compare avec case=True.
    descr_low = gdf["DESCR"].str.lower()
    mask = (
        descr_low.str.contains("calcaire", case=True, na=False, regex=False)
        | descr_low.str.contains("dolomie",  case=True, na=False, regex=False)
        | descr_low.str.contains("dolomit",  case=True, na=False, regex=False)
    )
    return gdf[mask].copy()


def load_local_geology(geo_path: str, bbox_l93: tuple) -> gpd.GeoDataFrame:
    """Charge la géologie locale BD Charm-50 (1/50 000) depuis un GPKG ou shapefile.

    Renvoie la géologie **complète** sur la bbox (toutes formations, couleurs
    BRGM conservées), normalisée vers DESCR / NOTATION. Le sous-ensemble
    karstifiable pour le scoring est dérivé à la volée (:func:`filter_karstifiable`).

    Args:
        geo_path : chemin vers le GPKG Grand Est ou un shapefile département
        bbox_l93 : (xmin, ymin, xmax, ymax) en EPSG:2154

    Returns:
        GeoDataFrame des formations en EPSG:2154, ou GDF vide en cas d'erreur.
    """
    from pathlib import Path

    path = Path(geo_path)
    if not path.exists():
        return _empty_gdf(f"Géologie locale introuvable : {geo_path}")

    try:
        # Lire avec filtre bbox (bbox= dans geopandas déclenche un filtre spatial GDAL)
        xmin, ymin, xmax, ymax = bbox_l93
        gdf = gpd.read_file(str(path), bbox=(xmin, ymin, xmax, ymax))
    except Exception as exc:
        return _empty_gdf(f"Géologie locale : impossible de lire {path.name} — {exc}")

    if gdf.empty:
        return _empty_gdf(f"Géologie locale : aucune formation dans la bbox ({path.name})")

    # Reprojection EPSG:2154 si nécessaire
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:2154")
    elif gdf.crs.to_epsg() != 2154:
        gdf = gdf.to_crs("EPSG:2154")

    # Normalisation des colonnes : BD Charm-50 → DESCR / NOTATION (les autres
    # colonnes, dont les couleurs CMJN C_FOND/M_FOND/J_FOND/N_FOND, sont conservées).
    col_map = {}
    cols_upper = {c.upper(): c for c in gdf.columns}
    for target, candidates in [
        ("DESCR",    ["DESCR", "DESCRIPTION", "LIBELLE", "NOM"]),
        # CODE_LEG explicitement EXCLU des candidats NOTATION : c'est un index
        # de légende par feuille BD Charm-50 (entier : 28, 61…), pas un préfixe
        # stratigraphique stable. scoring.py lit CODE_LEG comme repli DÉDIÉ
        # (colonne nommée telle quelle, cf. `has_code_leg`) quand NOTATION est
        # absente — le renommer ici masquerait ce repli et ferait échouer
        # silencieusement le facteur karstifiabilité (defaut=1.0 partout).
        ("NOTATION", ["NOTATION", "CODE", "CODE_GEOL"]),
    ]:
        for cand in candidates:
            if cand in cols_upper:
                col_map[cols_upper[cand]] = target
                break
    if col_map:
        gdf = gdf.rename(columns=col_map)

    return gdf


def fetch_georisques_cavites(bbox_l93: tuple) -> gpd.GeoDataFrame:
    """Télécharge les cavités souterraines Géorisques (BRGM) pour la bbox.

    Source : WFS Géorisques, layer CAVITE_LOCALISEE
      https://www.georisques.gouv.fr/services
    Requête en EPSG:2154 directement pour éviter le problème d'ordre d'axes
    lat/lon de WFS 1.1.0 + EPSG:4326 (qui inverse X et Y lors de la lecture GML).

    Champs retournés :
      nom_cavite, type_cavite, identifiant, date_validite, reperage_geographique

    La base Géorisques est lacunaire dans certaines régions (ex. karst sous
    couverture en Champagne-Ardenne). Un résultat vide est normal et non bloquant.

    Args:
        bbox_l93: Tuple (xmin, ymin, xmax, ymax) en Lambert-93 (EPSG:2154)

    Returns:
        GeoDataFrame des cavités en EPSG:2154, ou GeoDataFrame vide en cas d'erreur.
    """
    xmin, ymin, xmax, ymax = bbox_l93

    params = {
        "SERVICE": "WFS",
        "VERSION": "1.1.0",
        "REQUEST": "GetFeature",
        "TYPENAME": "CAVITE_LOCALISEE",
        # Requête directement en L93 : pas de conversion WGS84, pas de problème
        # d'inversion lat/lon propre au GML WFS 1.1.0 + EPSG:4326.
        "BBOX": f"{xmin},{ymin},{xmax},{ymax},EPSG:2154",
        "SRSNAME": "EPSG:2154",
    }
    try:
        resp = requests.get(
            "https://www.georisques.gouv.fr/services",
            params=params,
            timeout=30,
        )
    except requests.exceptions.RequestException as exc:
        return _empty_cavites_gdf(f"Géorisques WFS connexion impossible : {exc}")

    if resp.status_code != 200:
        return _empty_cavites_gdf(
            f"Géorisques WFS HTTP {resp.status_code} : {resp.text[:200]}"
        )

    try:
        gdf = gpd.read_file(io.BytesIO(resp.content))
    except Exception as exc:
        return _empty_cavites_gdf(f"Géorisques WFS : impossible de lire le GML — {exc}")

    if gdf.empty:
        return _empty_cavites_gdf()  # normal dans les zones peu inventoriées

    # Sélectionner uniquement les colonnes utiles (présentes ou non)
    cols_wanted = ["nom_cavite", "type_cavite", "identifiant",
                   "date_validite", "reperage_geographique", "geometry"]
    cols_present = [c for c in cols_wanted if c in gdf.columns]
    gdf = gdf[cols_present].copy()

    # S'assurer que le CRS est bien L93 (le serveur renvoie EPSG:2154 si SRSNAME=EPSG:2154,
    # mais on normalise au cas où fiona/GDAL déclarerait un CRS null)
    if gdf.crs is None:
        gdf = gdf.set_crs(_TARGET_CRS)
    elif str(gdf.crs).upper() != _TARGET_CRS:
        gdf = gdf.to_crs(_TARGET_CRS)

    return gdf


def _empty_cavites_gdf(warning: str = "") -> gpd.GeoDataFrame:
    """GeoDataFrame vide aux colonnes de cavites_georisques."""
    import warnings
    if warning:
        warnings.warn(f"KarstPro/geology: {warning}", stacklevel=2)
    return gpd.GeoDataFrame(
        columns=["nom_cavite", "type_cavite", "identifiant",
                 "date_validite", "reperage_geographique", "geometry"],
        crs=_TARGET_CRS,
    )


def _l93_to_wgs84(x: float, y: float) -> tuple:
    """Lambert-93 (EPSG:2154) → WGS84 (lon, lat), pur Python sans pyproj.

    Formule LCC 2SP inverse (EPSG méthode 9802) sur ellipsoïde GRS80.
    RGF93 ≡ WGS84 à < 1 m — aucune transformation de datum nécessaire.
    Évite `proj_create`, qui n'est PAS thread-safe dans QGIS 4.0.2 (access
    violation au 2ᵉ lancement d'un algorithme dans le même processus).
    """
    import math

    a   = 6_378_137.0
    f   = 1 / 298.257_222_101
    e2  = 2 * f - f * f
    e   = math.sqrt(e2)

    lam0 = math.radians(3.0)
    phi0 = math.radians(46.5)
    phi1 = math.radians(44.0)
    phi2 = math.radians(49.0)
    E_F  = 700_000.0
    N_F  = 6_600_000.0

    def _m(phi):
        sp = math.sin(phi)
        return math.cos(phi) / math.sqrt(1 - e2 * sp * sp)

    def _t(phi):
        sp = math.sin(phi)
        return math.tan(math.pi / 4 - phi / 2) / ((1 - e * sp) / (1 + e * sp)) ** (e / 2)

    m1 = _m(phi1); m2 = _m(phi2)
    t1 = _t(phi1); t2 = _t(phi2); t0 = _t(phi0)

    n  = (math.log(m1) - math.log(m2)) / (math.log(t1) - math.log(t2))
    F  = m1 / (n * t1 ** n)
    r0 = a * F * t0 ** n

    dE = x - E_F
    dN = r0 - (y - N_F)
    r_prime = math.copysign(math.hypot(dE, dN), n)
    t_prime = (r_prime / (a * F)) ** (1.0 / n)
    theta   = math.atan2(dE, dN)

    lam = theta / n + lam0

    phi = math.pi / 2 - 2 * math.atan(t_prime)
    for _ in range(10):
        sp = math.sin(phi)
        phi_new = math.pi / 2 - 2 * math.atan(
            t_prime * ((1 - e * sp) / (1 + e * sp)) ** (e / 2))
        if abs(phi_new - phi) < 1e-12:
            phi = phi_new
            break
        phi = phi_new

    return math.degrees(lam), math.degrees(phi)


def _wgs84_to_utm(lon: float, lat: float) -> tuple:
    """WGS84 (lon, lat en degrés) → UTM (easting, northing en m, fuseau).

    Transverse Mercator directe (USGS Snyder) sur ellipsoïde WGS84, pur Python
    sans pyproj (proj_create n'est pas thread-safe dans QGIS 4.0.2). Le fuseau
    est déduit de la longitude — une zone à cheval ne peut donc pas produire de
    coordonnées fausses silencieusement : le numéro de fuseau est retourné.

    Hémisphère Nord uniquement (France) : pas de décalage de 10 000 000 m.
    Retourne (easting, northing, zone). EPSG = 32600 + zone.
    """
    import math

    a  = 6_378_137.0
    f  = 1 / 298.257_223_563          # WGS84 (≠ GRS80 mais identique à < 1 mm ici)
    e2 = f * (2 - f)
    ep2 = e2 / (1 - e2)
    k0 = 0.9996

    zone = int((lon + 180.0) / 6.0) + 1
    lon0 = math.radians(zone * 6 - 183)

    phi = math.radians(lat)
    lam = math.radians(lon)
    sp, cp, tp = math.sin(phi), math.cos(phi), math.tan(phi)

    N = a / math.sqrt(1 - e2 * sp * sp)
    T = tp * tp
    C = ep2 * cp * cp
    A = cp * (lam - lon0)

    M = a * ((1 - e2 / 4 - 3 * e2**2 / 64 - 5 * e2**3 / 256) * phi
             - (3 * e2 / 8 + 3 * e2**2 / 32 + 45 * e2**3 / 1024) * math.sin(2 * phi)
             + (15 * e2**2 / 256 + 45 * e2**3 / 1024) * math.sin(4 * phi)
             - (35 * e2**3 / 3072) * math.sin(6 * phi))

    easting = (k0 * N * (A + (1 - T + C) * A**3 / 6
                         + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A**5 / 120)
               + 500_000.0)
    northing = k0 * (M + N * tp * (A * A / 2
                                   + (5 - T + 9 * C + 4 * C * C) * A**4 / 24
                                   + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A**6 / 720))
    return easting, northing, zone


def _l93_to_utm(x: float, y: float) -> tuple:
    """Lambert-93 (EPSG:2154) → UTM WGS84 (easting, northing en m, fuseau).

    Enchaîne L93→WGS84→UTM, le tout en pur Python (pas de pyproj).
    """
    lon, lat = _l93_to_wgs84(x, y)
    return _wgs84_to_utm(lon, lat)


def check_bdlisa_karst(bbox_l93: tuple) -> bool:
    """Vérifie si la bbox intersecte une entité karstique BDLISA (SURCOUCHE_KARST).

    Conserve l'API booléenne historique (fail-open). Pour distinguer « confirmé »
    d'« indisponible », utiliser ``check_bdlisa_karst_status``.
    """
    return check_bdlisa_karst_status(bbox_l93)[0]


def check_bdlisa_karst_status(bbox_l93: tuple) -> tuple:
    """Comme ``check_bdlisa_karst``, mais dit AUSSI si la vérification a
    réellement eu lieu.

    Requête WFS légère (maxFeatures=1) — sert de guard clause dans
    karst_prep_algorithm pour avertir l'utilisateur si la zone n'est pas
    karstique.

    Args:
        bbox_l93: Tuple (xmin, ymin, xmax, ymax) en Lambert-93 (EPSG:2154)

    Returns:
        ``(karstique: bool, verifie: bool)``
        - ``(True, True)``  → au moins une entité karstique intersecte la bbox.
        - ``(False, True)`` → aucune entité karstique (zone probablement non karstique).
        - ``(True, False)`` → **service indisponible** : rien n'a pu être vérifié.
          On renvoie ``True`` (fail-open : une panne externe ne doit jamais
          bloquer une préparation), mais l'appelant DOIT alors dire « non
          vérifié », pas « confirmé ».

    ⚠️ Constaté le 2026-07-25 : le serveur eaufrance redirige désormais
    http→https (301) mais son handshake TLS échoue
    (``UNEXPECTED_EOF_WHILE_READING``, reproduit en TLS brut avec ET sans
    vérification de certificat) — la vérification est donc actuellement
    toujours en fail-open. C'est précisément pour ça que l'état
    « vérifié / non vérifié » doit remonter jusqu'à l'utilisateur : avant ce
    correctif, le journal affichait « ✓ Zone karstique BDLISA confirmée »
    alors qu'aucun appel n'avait abouti.
    """
    try:
        xmin, ymin, xmax, ymax = bbox_l93
        # L93 → WGS84 en pur Python (PAS pyproj : proj_create n'est pas
        # thread-safe dans QGIS 4.0.2 → access violation au 2e lancement de la
        # préparation depuis l'historique).
        lon_min, lat_min = _l93_to_wgs84(xmin, ymin)
        lon_max, lat_max = _l93_to_wgs84(xmax, ymax)

        # WFS 1.1.0 — BBOX en ordre lat,lon pour ce serveur
        params = {
            "SERVICE": "WFS",
            "VERSION": "1.1.0",
            "REQUEST": "GetFeature",
            "TYPENAME": "SURCOUCHE_KARST",
            "BBOX": f"{lat_min},{lon_min},{lat_max},{lon_max}",
            "outputFormat": "application/json",
            "maxFeatures": "1",
        }
        # https:// et non http:// — le serveur redirige de toute façon (301),
        # autant ne pas faire circuler la requête en clair au premier saut.
        resp = requests.get(
            "https://www.reseau.eaufrance.fr/geotraitements/bdlisa/services/carto/",
            params=params,
            timeout=10,
        )
        if resp.status_code != 200:
            return (True, False)  # fail-open, NON vérifié
        return (len(resp.json().get("features", [])) > 0, True)
    except Exception:
        return (True, False)  # fail-open : erreur réseau → non vérifié


def _empty_gdf(warning: str = "") -> gpd.GeoDataFrame:
    """Returns an empty GeoDataFrame, optionally printing a warning."""
    import warnings
    if warning:
        warnings.warn(f"KarstPro/geology: {warning}", stacklevel=2)
    return gpd.GeoDataFrame(columns=["geometry", "LIBELLE"], crs=_TARGET_CRS)


_GEOPF_WFS = "https://data.geopf.fr/wfs/ows"


def _fetch_bdtopo_polygons(bbox_l93: tuple, layers, feedback=None) -> gpd.GeoDataFrame:
    """Récupère des polygones BD Topo (Géoplateforme) pour un jeu de couches.

    `layers` : liste de tuples (classe, typename WFS) OU
    (classe, typename, (colonne, {valeurs_gardées})) pour ne conserver côté
    client que les entités dont `colonne` ∈ valeurs (ex. nature='Carrière').
    Retourne un GeoDataFrame (EPSG:2154) avec une colonne `classe`, vide si
    rien / hors couverture.

    Le WFS Géoplateforme plafonne à 5000 features par réponse : en zone dense
    (bourg) le bâti dépasse largement ce seuil → sans pagination des milliers
    d'entités manquent. On pagine par STARTINDEX jusqu'à une page incomplète.
    """
    import io
    import pandas as pd

    def log(m):
        if feedback:
            feedback.pushInfo(m)

    xmin, ymin, xmax, ymax = bbox_l93
    parts = []
    _PAGE = 5000
    for spec in layers:
        classe, tn = spec[0], spec[1]
        attr_filter = spec[2] if len(spec) > 2 else None
        start = 0
        while True:
            params = {"SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature",
                      "TYPENAMES": tn, "SRSNAME": "EPSG:2154",
                      "BBOX": f"{xmin},{ymin},{xmax},{ymax},EPSG:2154",
                      "COUNT": str(_PAGE), "STARTINDEX": str(start)}
            try:
                r = requests.get(_GEOPF_WFS, params=params, timeout=90)
                if r.status_code != 200:
                    break
                g = gpd.read_file(io.BytesIO(r.content))
            except Exception as exc:
                log(f"  BD Topo {tn} : {exc}")
                break
            n = len(g)
            if n:
                # Filtre attributaire client (ex. nature='Carrière') : la couche
                # zone_d_activite mélange carrières, mairies, églises… seules les
                # carrières sont de vraies dépressions excavées.
                if attr_filter is not None:
                    col, keep = attr_filter
                    if col in g.columns:
                        g = g[g[col].isin(keep)]
                    else:
                        g = g.iloc[0:0]
                # On a demandé SRSNAME=EPSG:2154 : les coordonnées SONT en L93 même
                # si le GML ne déclare pas de CRS. On le force pour éviter tout
                # conflit au concat.
                if len(g):
                    g = g[["geometry"]].copy().set_crs(_TARGET_CRS, allow_override=True)
                    g["classe"] = classe
                    parts.append(g)
            if n < _PAGE:
                break
            start += _PAGE
    if not parts:
        return gpd.GeoDataFrame({"classe": []}, geometry=[], crs=_TARGET_CRS)
    out = gpd.GeoDataFrame(pd.concat(parts, ignore_index=True))
    return out.set_crs(_TARGET_CRS, allow_override=True)


def fetch_bdtopo_obstacles(bbox_l93: tuple, feedback=None) -> gpd.GeoDataFrame:
    """Polygones BD Topo (Géoplateforme) qui créent des vides de NODATA dans le
    MNT LiDAR — pour écarter les **faux positifs de gouffres** : **bâtiments**
    (le LiDAR voit le toit) et **surfaces d'eau** (le LiDAR ne revient pas de
    l'eau). Retourne un GeoDataFrame (polygones, EPSG:2154) avec une colonne
    `classe` ('bati' / 'eau'), vide si rien / hors couverture.
    """
    out = _fetch_bdtopo_polygons(
        bbox_l93,
        [("bati", "BDTOPO_V3:batiment"),
         ("eau", "BDTOPO_V3:plan_d_eau"),
         ("eau", "BDTOPO_V3:surface_hydrographique")],
        feedback=feedback)
    if feedback:
        feedback.pushInfo(f"  BD Topo : {len(out)} obstacle(s) bâti/eau dans l'emprise.")
    return out


def fetch_bdtopo_anthropic(bbox_l93: tuple, feedback=None) -> gpd.GeoDataFrame:
    """Polygones de **carrières** BD Topo, pour déclasser les **dolines** qui
    sont en réalité des excavations artificielles. Colonne `classe` ='carriere'.

    Source : `zone_d_activite_ou_d_interet` filtré sur `nature='Carrière'`.
    Cette couche mélange carrières, mairies, églises, écoles, stades… (vérifié
    sur Bayard : 1 carrière sur 33 entités) : SANS le filtre nature, on
    déclasserait des dolines tombant sur une église — absurde, ce ne sont pas
    des dépressions. Seule la carrière est une vraie dépression non karstique.

    ⚠️ N'inclut NI plans d'eau (une doline peut être un étang/mardelle réel) NI
    bâti (un bâtiment n'est pas une dépression). On **étiquette et déclasse**,
    jamais on ne supprime. Valeur ZONE-DÉPENDANTE (utile en secteur extractif).
    """
    out = _fetch_bdtopo_polygons(
        bbox_l93,
        [("carriere", "BDTOPO_V3:zone_d_activite_ou_d_interet",
          ("nature", {"Carrière"}))],
        feedback=feedback)
    if feedback:
        feedback.pushInfo(f"  BD Topo : {len(out)} carrière(s) dans l'emprise.")
    return out


_VEGETATION_NATURES = {
    "Bois", "Forêt fermée de feuillus", "Forêt fermée de conifères",
    "Forêt fermée mixte", "Forêt ouverte", "Haie", "Verger", "Peupleraie",
    "Lande ligneuse",
}


def fetch_bdtopo_vegetation(bbox_l93: tuple, feedback=None) -> gpd.GeoDataFrame:
    """Polygones de végétation à canopée fermée (BD Topo), pour repérer les
    **faux positifs de gouffres dus à la canopée** : un trou de NODATA sous
    forêt dense a la MÊME signature qu'un puits (vide compact à bord de sol
    valide) — `detect_shafts` ne peut pas les distinguer avec la géométrie
    seule. Colonne `classe` = 'vegetation'.

    Source : `zone_de_vegetation`, filtrée aux natures à canopée fermée
    (bois, forêt, haie, verger, peupleraie, lande ligneuse) — vérifié sur
    Sommelonne : 83,5 % des 647 candidats détectés tombaient dans une de ces
    zones (90,6 % avec 5 m de tolérance).

    ⚠️ Filtre PROBABILISTE, pas une vérité terrain (BD Topo peut avoir un
    trou/une imprécision locale) : on **déclasse** (`interet=0`), on ne
    supprime jamais — cf. `flag_vegetation`.
    """
    out = _fetch_bdtopo_polygons(
        bbox_l93,
        [("vegetation", "BDTOPO_V3:zone_de_vegetation",
          ("nature", _VEGETATION_NATURES))],
        feedback=feedback)
    if feedback:
        feedback.pushInfo(f"  BD Topo : {len(out)} zone(s) de végétation dans l'emprise.")
    return out


def fetch_points_eau(bbox_l93: tuple, feedback=None) -> gpd.GeoDataFrame:
    """Points d'eau karstiques **référencés** (BD Topo, Géoplateforme) : sources,
    pertes, inversacs, résurgences, exutoires — sur le réseau hydrographique.

    Complément des gouffres pour les entrées **NOYÉES**, invisibles au MNT (le
    LiDAR se réfléchit sur l'eau). ⚠️ C'est du **référencement** (donnée déjà
    cartographiée), PAS de la détection — comme les cavités Géorisques.

    Sources :
      - `noeud_hydrographique` : categorie Source / Perte / Exutoire de plan d'eau ;
      - `detail_hydrographique` : nature karstique (source, perte, gouffre…).

    Retourne un GeoDataFrame (Point, EPSG:2154) : `type`, `toponyme`, `code`.
    """
    import io
    import pandas as pd

    def log(m):
        if feedback:
            feedback.pushInfo(m)

    xmin, ymin, xmax, ymax = bbox_l93
    bbox = f"{xmin},{ymin},{xmax},{ymax},EPSG:2154"
    noeud_keep = {"source", "perte", "exutoire de plan d'eau"}
    detail_kw = ("source", "perte", "gouffre", "doline", "résurgence",
                 "resurgence", "aven", "exsurgence", "exutoire")
    parts = []

    def _get(tn):
        try:
            r = requests.get(_GEOPF_WFS, params={
                "SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature",
                "TYPENAMES": tn, "SRSNAME": "EPSG:2154", "BBOX": bbox}, timeout=90)
            if r.status_code != 200:
                return None
            g = gpd.read_file(io.BytesIO(r.content))
            return g if not g.empty else None
        except Exception as exc:
            log(f"  {tn} : {exc}")
            return None

    # 1. Nœuds hydrographiques (sources / pertes / exutoires)
    g = _get("BDTOPO_V3:noeud_hydrographique")
    if g is not None and "categorie" in g.columns:
        keep = g[g["categorie"].fillna("").str.lower().isin(noeud_keep)].copy()
        if not keep.empty:
            keep["type"] = keep["categorie"]
            parts.append(keep)

    # 2. Détails hydrographiques ponctuels (sources, pertes, gouffres…)
    g = _get("BDTOPO_V3:detail_hydrographique")
    if g is not None and "nature" in g.columns:
        low = g["nature"].fillna("").str.lower()
        mask = low.apply(lambda s: any(k in s for k in detail_kw))
        keep = g[mask].copy()
        if not keep.empty:
            keep["type"] = keep["nature"]
            parts.append(keep)

    if not parts:
        return gpd.GeoDataFrame({"type": [], "toponyme": [], "code": []},
                                geometry=[], crs=_TARGET_CRS)

    rows = []
    for p in parts:
        p = p.set_crs(_TARGET_CRS, allow_override=True)
        p["toponyme"] = p["toponyme"] if "toponyme" in p.columns else None
        codec = next((c for c in ("code_hydrographique", "cleabs") if c in p.columns), None)
        p["code"] = p[codec] if codec else None
        rows.append(p[["geometry", "type", "toponyme", "code"]])
    out = gpd.GeoDataFrame(pd.concat(rows, ignore_index=True))
    out = out.set_crs(_TARGET_CRS, allow_override=True)
    log(f"  Points d'eau karstiques (BD Topo) : {len(out)} référencé(s) "
        "(sources / pertes / exutoires) — référence, pas détection.")
    return out
