# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Détection des dépendances Python de KarstPro — sans AUCUN effet de bord.

Source de vérité unique des noms de paquets/modules, réutilisée par
`karstpro/install_dependencies.py` (qui, lui, installe réellement — au
moment de l'import, volontairement, pour l'usage « coller dans la console
Python de QGIS ») et par `karstpro_plugin.py` (détection au chargement du
plugin, pour avertir sans jamais installer quoi que ce soit tout seul).

⚠️ Ce module ne doit JAMAIS installer ni modifier l'environnement Python —
contrairement à `install_dependencies`, il doit rester strictement sûr à
importer n'importe où, y compris à chaque démarrage de QGIS.
"""
from __future__ import annotations

import importlib

# Paquets à installer via pip (cf. requirements.txt, install_deps.bat/.sh).
PACKAGES = ["geopandas", "rasterio", "reportlab", "whitebox", "pyproj"]

# Modules importés pour vérifier que l'installation a réussi (inclut des
# dépendances transitives critiques — shapely, pandas — pas seulement les
# paquets pip de premier niveau).
CHECK_MODULES = ["geopandas", "rasterio", "reportlab", "whitebox", "shapely", "pandas"]


def missing_dependencies(modules: list[str] | None = None) -> list[str]:
    """Modules de `modules` (défaut `CHECK_MODULES`) qui échouent à l'import.

    Ne lève jamais d'exception : une dépendance cassée (pas seulement
    absente) compte aussi comme manquante.
    """
    candidates = modules if modules is not None else CHECK_MODULES
    missing = []
    for mod in candidates:
        try:
            importlib.import_module(mod)
        except Exception:
            missing.append(mod)
    return missing
