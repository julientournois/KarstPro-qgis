# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Reproductibilité des études KarstPro.

À chaque préparation, on écrit ``karstpro_etude.json`` à côté du gpkg : tous les
paramètres d'entrée + la version du plugin + la date. « Refaire une étude » relit
ce fichier (ou, pour les anciennes préparations, **parse le dernier log** qui
contient déjà les paramètres) et relance la préparation à l'identique, sans
re-saisie. Le nom du secteur y est **résolu** (auto-détection figée) pour que le
carryover (cibles visitées) et le gpkg soient retrouvés de façon fiable.
"""
import ast
import glob
import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path

ETUDE_FILE = "karstpro_etude.json"

# Clés de paramètres de « Préparer une sortie » (cf. karst_prep_algorithm).
PREP_PARAM_KEYS = [
    "EXTENT", "TOPO_FILE", "SCORING_CONFIG", "OUTPUT_DIR", "SECTEUR_NAME",
    "CAVITES_CONNUES", "TRACAGES", "MNT_FILES", "GEO_LOCAL", "SCAN25_APIKEY",
    "CONTOUR_INTERVAL", "FILTER_ANTHROPIC", "KEEP_VISITED", "USE_LEARNED_MODEL",
    "SEUIL_SURFACE_PC", "SIGNAL_RGEALTI",
]


def _json_safe(v):
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, (list, tuple)):
        return [_json_safe(x) for x in v]
    return str(v)


def serialize_params(parameters, keys=PREP_PARAM_KEYS):
    """Dict {clé: valeur JSON-safe} des paramètres de préparation présents."""
    return {k: _json_safe(parameters.get(k)) for k in keys if k in parameters}


def plugin_version(default="?"):
    p = Path(__file__).resolve().parent.parent / "metadata.txt"
    try:
        m = re.search(r"^version\s*=\s*(.+)$", p.read_text(encoding="utf-8"), re.M)
        return m.group(1).strip() if m else default
    except Exception:
        return default


def write_etude_json(output_dir, parameters, secteur, gpkg_path, version=None):
    """Écrit ``karstpro_etude.json`` dans ``output_dir``. ``secteur`` est le nom
    **résolu** (pas le paramètre brut, qui peut être vide/auto). Best-effort."""
    output_dir = Path(output_dir)
    params = serialize_params(parameters)
    params["SECTEUR_NAME"] = secteur          # fige l'auto-détection
    params["OUTPUT_DIR"] = str(output_dir)
    data = {
        "plugin_version": version or plugin_version(),
        "date": datetime.now().isoformat(timespec="seconds"),
        "secteur": secteur,
        "gpkg": str(gpkg_path) if gpkg_path else None,
        "params": params,
    }
    path = output_dir / ETUDE_FILE
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                        encoding="utf-8")
    except Exception:
        pass
    return path


def parse_prep_log(log_path):
    """Extrait le dict de paramètres de l'en-tête « Paramètres en entrée : » d'un
    log de préparation (chaque ligne ``  CLÉ = <repr Python>``)."""
    params = {}
    try:
        lines = Path(log_path).read_text(encoding="utf-8").splitlines()
    except Exception:
        return params
    inside = False
    for ln in lines:
        if ln.strip().startswith("Paramètres en entrée"):
            inside = True
            continue
        if inside:
            s = ln.strip()
            if s and set(s) <= {"="}:          # ligne de séparation ==== → fin
                break
            m = re.match(r"\s*([A-Z0-9_]+)\s*=\s*(.+)$", ln)
            if m:
                k, rhs = m.group(1), m.group(2).strip()
                try:
                    params[k] = ast.literal_eval(rhs)
                except Exception:
                    params[k] = rhs
    return params


def _guess_gpkg(output_dir, secteur):
    output_dir = Path(output_dir)
    if secteur:
        p = output_dir / f"{secteur}.gpkg"
        if p.exists():
            return p
    cands = [Path(x) for x in glob.glob(str(output_dir / "*.gpkg"))]
    return max(cands, key=lambda q: q.stat().st_size) if cands else None


def read_etude_params(etude_path):
    """Lit les paramètres d'une étude. Accepte un ``.json`` ou un **dossier**
    (cherche ``karstpro_etude.json``, sinon le dernier ``karstpro_prep_*.log``).

    Retourne ``(params_dict, gpkg_path|None, source_str)``. ``params_dict`` vide
    si rien trouvé.
    """
    etude_path = Path(etude_path)
    if etude_path.is_file() and etude_path.suffix.lower() == ".json":
        data = json.loads(etude_path.read_text(encoding="utf-8"))
        gp = data.get("gpkg")
        return data.get("params", {}), (Path(gp) if gp else None), str(etude_path)

    d = etude_path if etude_path.is_dir() else etude_path.parent
    jf = d / ETUDE_FILE
    if jf.exists():
        data = json.loads(jf.read_text(encoding="utf-8"))
        gp = data.get("gpkg")
        gpath = Path(gp) if gp else _guess_gpkg(d, data.get("secteur", ""))
        return data.get("params", {}), gpath, str(jf)

    # Tri par NOM (l'horodatage AAAAMMJJ_HHMMSS est en fin de nom) plutôt que par
    # mtime : la date de création réelle de la prép survit à une copie/restauration
    # du dossier (qui, elle, réécrit les mtime). Suppose un dossier = une étude.
    # Cherche dans logs/ (rangement actuel) ET à la racine (études préparées
    # avant ce rangement — ne pas casser « Refaire une étude » sur elles).
    logs = sorted(
        glob.glob(str(d / "logs" / "karstpro_prep_*.log"))
        + glob.glob(str(d / "karstpro_prep_*.log")),
        key=lambda p: Path(p).name)
    if logs:
        params = parse_prep_log(logs[-1])
        gpath = _guess_gpkg(params.get("OUTPUT_DIR", d),
                            params.get("SECTEUR_NAME", ""))
        return params, gpath, logs[-1]
    return {}, None, ""


def count_layer_features(gpkg_path, layer):
    """Nombre d'entités d'une couche (0 si absente/illisible) — garde-fou pour
    ne pas écraser des saisies terrain non synchronisées."""
    try:
        con = sqlite3.connect(str(gpkg_path))
        try:
            tables = {r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if layer not in tables:
                return 0
            r = con.execute(f'SELECT count(*) FROM "{layer}"').fetchone()
            return int(r[0]) if r else 0
        finally:
            con.close()
    except Exception:
        return 0


def count_pending_findings(gpkg_path, secteur: str, interet_values=(1, 2)) -> list:
    """Cibles P1/P2/P3 et gouffres **à intérêt** (`interet` ∈ ``interet_values``)
    pas encore synchronisés (exportés vers le CSV Karst Entry).

    Garde-fou pour « Refaire une étude » : sans synchro préalable, une
    re-préparation les **piège dans l'archive** « cibles visitées »
    (`capture_visited_as_archive` capture tout `interet != -1`, sans distinguer
    0 de 1/2) au lieu de les exporter — la trouvaille ne rejoint alors jamais
    l'inventaire. Retourne une liste de dicts ``{"layer": <nom>, "count": <n>}``
    pour les couches concernées (vide si rien en attente).
    """
    vals = [int(v) for v in interet_values]
    layers = [f"{secteur} — cibles P1", f"{secteur} — cibles P2",
             f"{secteur} — cibles P3", "gouffres"]
    out = []
    try:
        con = sqlite3.connect(str(gpkg_path))
    except Exception:
        return out
    try:
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        for lyr in layers:
            if lyr not in tables:
                continue
            cols = {c[1] for c in con.execute(f'PRAGMA table_info("{lyr}")')}
            if "interet" not in cols:
                continue
            m = ",".join("?" * len(vals))
            n = con.execute(
                f'SELECT count(*) FROM "{lyr}" WHERE interet IN ({m})', vals
            ).fetchone()[0]
            if n:
                out.append({"layer": lyr, "count": int(n)})
    except Exception:
        return out
    finally:
        con.close()
    return out


def capture_priorites(gpkg_path) -> dict:
    """Photographie ``{__fid__: priorite}`` de la couche ``dolines`` d'un
    GeoPackage KarstPro, pour comparer avant/après une re-préparation avec un
    modèle différent (cf. « Refaire une étude »).

    ⚠️ La couche ``dolines`` n'a **jamais** de colonne ``name`` (réservée aux
    couches cibles P1/P2/P3 exportées) — un bug réel (2026-07) utilisait
    ``name`` ici, si bien que cette capture ne renvoyait jamais rien et que la
    comparaison de palier restait **silencieusement** vide. L'identifiant de
    ligne fiable est ``__fid__`` (exposé par
    :func:`karstpro.core.gpkg.read_gpkg_layer`, stable tant que le MNT n'est
    pas régénéré entre les deux préparations : détection déterministe -> même
    ordre d'écriture -> même ``rowid`` GeoPackage).

    Ne lève jamais d'exception : retourne ``{}`` si le fichier, la couche, ou
    les colonnes attendues sont absents (gpkg absent, couche vide, ancien
    format sans ``__fid__``…).
    """
    from pathlib import Path as _Path
    from karstpro.core.gpkg import read_gpkg_layer

    if gpkg_path is None or not _Path(gpkg_path).exists():
        return {}
    try:
        dolines = read_gpkg_layer(gpkg_path, "dolines")
    except Exception:
        return {}
    if dolines.empty or "__fid__" not in dolines.columns or "priorite" not in dolines.columns:
        return {}
    return dict(zip(dolines["__fid__"], dolines["priorite"]))


def compare_priorites(old_priorites: dict, new_names, new_priorites) -> dict:
    """Compare la priorité des dolines avant/après une re-préparation (ex. avec
    un modèle forcé différent, cf. « Refaire une étude »).

    ``old_priorites`` : ``{identifiant: priorite}`` lu **avant** l'écrasement
    du gpkg (typiquement produit par :func:`capture_priorites`).
    ``new_names``/``new_priorites`` : identifiants/priorités **après** (même
    espace d'identifiants que ``old_priorites``).

    Ne compte que les dolines présentes dans les deux jeux (même identifiant,
    stable si le MNT n'est pas régénéré entre-temps) dont la priorité a
    changé. Retourne ``{(ancienne, nouvelle): compte}``, vide si rien ne
    change ou si aucune correspondance n'est trouvée.
    """
    changes: dict = {}
    for name, new_p in zip(new_names, new_priorites):
        old_p = old_priorites.get(name)
        if old_p is not None and old_p != new_p:
            key = (old_p, new_p)
            changes[key] = changes.get(key, 0) + 1
    return changes


def format_priorite_changes(changes: dict) -> str:
    """Formate le résultat de :func:`compare_priorites` en une ligne lisible,
    triée par nombre de dolines concernées décroissant. Chaîne vide si
    ``changes`` est vide."""
    if not changes:
        return ""
    return ", ".join(
        f"{a} → {b} : {n}"
        for (a, b), n in sorted(changes.items(), key=lambda kv: -kv[1]))
