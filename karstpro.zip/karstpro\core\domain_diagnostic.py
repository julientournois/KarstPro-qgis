# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Diagnostic empirique de domaine : mesurer, plutôt que deviner, si un
modèle appris (Barrois, Jura plateau…) s'applique à une commune donnée.

Contexte : détecter automatiquement le régime géologique d'une zone jamais
explorée est impossible depuis le relief seul (concept drift, cf.
docs/JOURNAL_EXPERIENCES.md — 7 pistes testées, 7 échecs). Mais dès qu'un
inventaire même partiel de cavités connues existe pour la commune cible, la
question change de nature : on n'a plus besoin de deviner, on **mesure**
l'AUC réel d'un modèle appliqué à cette commune contre ses propres cavités
connues (même principe que la validation LOCO utilisée à l'entraînement,
appliquée ici à une seule commune cible plutôt qu'en validation croisée).

Validé empiriquement (session 2026-07-06, prototypes/diagnose_domain.py) :
l'AUC ainsi mesuré tombe à ≤ 0,013 du LOCO complet sur les 7 communes déjà
étudiées (2 communes à l'écart exact de 0,000).
"""
from __future__ import annotations

import numpy as np


def combine_cavity_sources(*sources):
    """Concatène plusieurs GeoDataFrame de points (géométries seules) en un
    seul, en ignorant les sources ``None`` ou vides. Utilisé pour fusionner
    l'inventaire fourni par l'utilisateur avec `cavites_georisques` (BRGM,
    déjà présente dans le GeoPackage de toute préparation) — les deux sont
    de simples sources de labels, jamais dédupliquées entre elles (un
    doublon proche n'affecte pas le résultat du diagnostic : la doline la
    plus proche compte, peu importe si deux points la référencent)."""
    import geopandas as gpd
    import pandas as pd

    valid = [s for s in sources if s is not None and len(s) > 0]
    if not valid:
        return gpd.GeoDataFrame({"geometry": []})
    return gpd.GeoDataFrame(
        pd.concat([s[["geometry"]] for s in valid], ignore_index=True))


def label_known_cavities(dolines, cavites, radius_m: float) -> np.ndarray:
    """Label binaire par doline : 1 si une cavité connue est à ``radius_m``
    mètres ou moins du centroïde, 0 sinon.

    ``dolines`` et ``cavites`` : GeoDataFrame (même repère, ex. EPSG:2154 ou
    ``crs=None`` avec coordonnées déjà dans le même système). Une couche
    ``cavites`` vide renvoie un label entièrement à 0 (aucun positif).
    """
    n = len(dolines)
    if n == 0:
        return np.zeros(0, dtype=int)
    cx = dolines.geometry.centroid.x.to_numpy()
    cy = dolines.geometry.centroid.y.to_numpy()
    y = np.zeros(n, dtype=int)
    if cavites is None or len(cavites) == 0:
        return y
    px = cavites.geometry.x.to_numpy()
    py = cavites.geometry.y.to_numpy()
    for i in range(n):
        d = np.hypot(px - cx[i], py - cy[i])
        if d.min() <= radius_m:
            y[i] = 1
    return y


def _roc_auc(y: np.ndarray, scores: np.ndarray) -> float:
    """AUC en numpy pur (statistique de Mann-Whitney, rangs moyens en cas
    d'égalité) — équivalent à ``sklearn.metrics.roc_auc_score`` sans en
    dépendre : le plugin distribué n'embarque ni sklearn ni joblib (même
    convention que :mod:`karstpro.core.model_score`)."""
    order = np.argsort(scores, kind="mergesort")
    sorted_scores = scores[order]
    ranks = np.empty(len(scores), dtype=float)
    i = 0
    n = len(scores)
    while i < n:
        j = i
        while j < n - 1 and sorted_scores[j + 1] == sorted_scores[i]:
            j += 1
        avg_rank = (i + j) / 2.0 + 1.0  # rangs 1-based
        ranks[order[i:j + 1]] = avg_rank
        i = j + 1
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def diagnose_models(dolines, cavites, models: list, min_cavites: int = 10) -> list:
    """Diagnostic empirique de chaque modèle de ``models`` (issus de
    :func:`karstpro.core.model_score.list_models`) contre l'inventaire
    ``cavites`` fourni pour cette commune.

    Le rayon d'appariement utilisé est celui **propre à chaque modèle**
    (``label_radius_m``, défaut 100 m si absent) — pas un rayon global —
    pour rester cohérent avec la calibration de validation de ce modèle.

    Retourne une liste de dicts, un par modèle :
      ``model_id``, ``radius_m``, ``n_dolines``, ``n_positifs``, ``auc``
      (``None`` si indéterminable), ``warning`` (``None`` ou message).
    Triée par ``auc`` décroissant (les indéterminés en fin de liste).
    """
    from karstpro.core.model_score import predict_proba

    out = []
    for model in models:
        radius = float(model.get("label_radius_m", 100.0))
        y = label_known_cavities(dolines, cavites, radius)
        n = len(y)
        n_pos = int(y.sum())
        entry = {
            "model_id": model.get("model_id", "?"),
            "radius_m": radius,
            "n_dolines": n,
            "n_positifs": n_pos,
            "auc": None,
            "warning": None,
        }
        if n_pos == 0:
            entry["warning"] = (
                "aucune cavité connue à moins de "
                f"{radius:.0f} m d'une doline — AUC non calculable")
        elif n_pos == n:
            entry["warning"] = "toutes les dolines ont une cavité connue à proximité — AUC non calculable"
        else:
            proba = predict_proba(dolines, model)
            entry["auc"] = _roc_auc(y, np.asarray(proba, dtype=float))
            if n_pos < min_cavites:
                entry["warning"] = (
                    f"seulement {n_pos} cavité(s) connue(s) apparié(es) "
                    f"(< {min_cavites}) — estimation d'AUC peu fiable, à "
                    "prendre avec prudence")
        out.append(entry)

    out.sort(key=lambda e: (e["auc"] is None, -(e["auc"] or 0.0)))
    return out


def format_diagnostic_report(entries: list) -> list:
    """Formate les entrées de :func:`diagnose_models` en lignes de texte
    prêtes à être poussées dans le journal (une ligne par modèle + une
    recommandation finale)."""
    lines = []
    for e in entries:
        if e["auc"] is None:
            lines.append(
                f"  {e['model_id']:20s} — {e['warning']}")
            continue
        verdict = ("s'applique bien" if e["auc"] >= 0.60 else
                   "s'applique faiblement" if e["auc"] >= 0.55 else
                   "ne s'applique pas")
        line = (f"  {e['model_id']:20s} AUC = {e['auc']:.3f}  "
                f"({e['n_positifs']} cavité(s) à ≤ {e['radius_m']:.0f} m, "
                f"{e['n_dolines']} dolines) — {verdict}")
        if e["warning"]:
            line += f"  ⚠ {e['warning']}"
        lines.append(line)

    usable = [e for e in entries if e["auc"] is not None]
    if not usable:
        lines.append("Aucun modèle diagnosticable — inventaire trop pauvre "
                     "ou hors de portée des modèles disponibles.")
    else:
        best = usable[0]
        if best["auc"] >= 0.60:
            lines.append(
                f"→ Recommandation : « {best['model_id']} » semble le mieux "
                f"adapté à cette commune (AUC {best['auc']:.3f}). Le choix "
                "final d'activation reste le tien (menu « Priorisation »).")
        else:
            lines.append(
                "→ Recommandation : aucun modèle ne se distingue nettement "
                "ici (meilleur AUC "
                f"{best['auc']:.3f}) — reste sur le calcul manuel exploratoire.")
    return lines
