# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Inférence du modèle appris (régression logistique par domaine) en numpy pur.

Pourquoi pas sklearn : le plugin distribué n'embarque ni sklearn ni joblib.
Le modèle est exporté en JSON (coef, intercept, scaler, médianes) et rejoué ici
par une simple combinaison linéaire — vérifié identique à sklearn à l'epsilon
machine (cf. export dans prototypes / commit d'intégration).

⚠️ DOMAINE DE VALIDITÉ. Ce modèle (`barrois_model.json`) n'est calibré que pour
le Barrois. Validation hors-échantillon (2 communes inédites, inventaire GERSM
indépendant) : AUC 0,65 (Beurey) et 0,72 (Robert-Espagne), contre 0,57 pour le
score morphologique manuel. La généralisation s'arrête à la frontière
géologique : ne PAS appliquer hors Barrois (AUC ~0,45 hors domaine). C'est
pourquoi l'activation est un choix explicite de l'utilisateur, jamais silencieux.
"""
import json
from pathlib import Path

import numpy as np

MODELS_DIR = Path(__file__).parent.parent / "models"
DEFAULT_MODEL = MODELS_DIR / "barrois_model.json"


def load_model(path: "Path | str | None" = None) -> dict:
    """Charge un modèle JSON. None → modèle Barrois par défaut."""
    p = Path(path) if path else DEFAULT_MODEL
    return json.loads(p.read_text(encoding="utf-8"))


def _is_model(d: dict) -> bool:
    """Un JSON est un modèle exploitable s'il porte au moins coef + features."""
    return isinstance(d, dict) and "coef" in d and "features" in d


def list_models(models_dir: "Path | str | None" = None) -> list:
    """Registre : tous les modèles JSON valides du dossier models/.

    Chaque modèle est auto-descriptif (features, signature de domaine,
    seuils). Pas d'index central : déposer un *.json valide suffit à
    l'enregistrer. Trié par model_id pour un comportement déterministe.
    """
    d = Path(models_dir) if models_dir else MODELS_DIR
    out = []
    for p in sorted(d.glob("*.json")):
        try:
            m = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if _is_model(m):
            m.setdefault("model_id", p.stem)
            out.append(m)
    return out


def predict_proba(dolines, model: dict) -> np.ndarray:
    """Probabilité [0–1] d'intérêt spéléo par doline (inférence logistique).

    Reproduit exactement le préprocessing d'entraînement :
    transform log1p(clip(x,0)) sur les features 'log', imputation médiane des
    NaN, standardisation (scaler), combinaison linéaire, sigmoïde.

    Args:
        dolines : GeoDataFrame/DataFrame portant les colonnes de model['features'].
                  Colonne manquante → traitée comme entièrement NaN (→ médiane).
        model   : dict issu de load_model().

    Returns:
        np.ndarray de probabilités, aligné sur l'ordre des lignes de `dolines`.
    """
    import pandas as pd

    feats = model["features"]
    modes = model["feature_modes"]
    n = len(dolines)
    cols = []
    for c in feats:
        if c in dolines.columns:
            v = pd.to_numeric(dolines[c], errors="coerce").to_numpy("float64")
        else:
            v = np.full(n, np.nan)
        if modes[c] == "log":
            v = np.log1p(np.clip(v, 0, None))
        cols.append(v)
    X = np.column_stack(cols) if cols else np.empty((n, 0))

    med = np.asarray(model["median"], dtype="float64")
    idx = np.where(np.isnan(X))
    X[idx] = np.take(med, idx[1])

    mean = np.asarray(model["scaler_mean"], dtype="float64")
    scale = np.asarray(model["scaler_scale"], dtype="float64")
    Xs = (X - mean) / scale

    z = float(model["intercept"]) + Xs @ np.asarray(model["coef"], dtype="float64")
    return 1.0 / (1.0 + np.exp(-z))


def domain_warning(dolines, model: dict) -> "str | None":
    """Avertit si la zone traitée est loin du domaine géologique d'entraînement.

    HEURISTIQUE GROSSIÈRE — la distance géographique n'est qu'un proxy du domaine
    géologique : un point à 30 km peut relever d'une autre formation, et le
    Barrois s'étend au-delà du rayon. Ne change RIEN au calcul : retourne juste
    un message d'alerte (ou None) à afficher. Le vrai garde-fou reste le choix
    explicite de l'utilisateur d'activer le modèle.

    Returns:
        Message d'avertissement si le centroïde de la zone est au-delà de
        ``domain_radius_warn_m`` du centre du domaine, sinon None.
    """
    cx, cy = model.get("domain_centroid_l93", (None, None))
    rad = model.get("domain_radius_warn_m")
    if cx is None or rad is None or len(dolines) == 0:
        return None
    try:
        c = dolines.geometry.centroid
        mx, my = float(c.x.mean()), float(c.y.mean())
    except Exception:
        return None
    d = ((mx - cx) ** 2 + (my - cy) ** 2) ** 0.5
    if d > rad:
        return (f"Zone à {d / 1000:.0f} km du domaine d'entraînement "
                f"({model.get('domain_name', 'modèle')}). Le modèle appris n'y "
                f"est PAS validé — résultats probablement non fiables. "
                f"Envisagez les poids manuels.")
    return None


def _notation_prefix(val) -> "str | None":
    """j7f → j7, j6c-7a → j6, n4a → n4. None si vide/illisible."""
    import re
    if val is None:
        return None
    m = re.match(r"\s*([a-zA-Z]+\d+)", str(val))
    return m.group(1).lower() if m else None


def lithology_fraction(dolines, geology, model: dict) -> "float | None":
    """Fraction des dolines posées sur le faciès d'entraînement du modèle.

    Compare le préfixe NOTATION BD Charm-50 (stable entre feuilles, contrairement
    à CODE_LEG) des formations sous chaque doline à ``domain_notations``.
    None si non calculable (pas de géologie, pas de NOTATION, pas de signature).
    """
    dom = model.get("domain_notations")
    if not dom or geology is None or len(geology) == 0 or len(dolines) == 0:
        return None
    dom = {str(d).lower() for d in dom}
    try:
        import geopandas as gpd
        geo = geology
        if geo.crs is not None and dolines.crs is not None and geo.crs != dolines.crs:
            geo = geo.to_crs(dolines.crs)
        col = next((c for c in ("NOTATION", "notation") if c in geo.columns), None)
        if col is None:
            return None
        cent = dolines.copy()
        cent["geometry"] = dolines.geometry.centroid
        j = gpd.sjoin(cent[["geometry"]], geo[["geometry", col]],
                      how="left", predicate="within")
        prefs = j[col].map(_notation_prefix).dropna()
    except Exception:
        return None
    if len(prefs) == 0:
        return None
    return float(prefs.isin(dom).mean())


def _geo_distance_m(dolines, model: dict) -> "float | None":
    """Distance (m) du centroïde de la zone au centre du domaine du modèle."""
    cx, cy = model.get("domain_centroid_l93", (None, None))
    if cx is None or len(dolines) == 0:
        return None
    try:
        c = dolines.geometry.centroid
        return float(((c.x.mean() - cx) ** 2 + (c.y.mean() - cy) ** 2) ** 0.5)
    except Exception:
        return None


def geology_domain_warning(dolines, geology, model: dict) -> "str | None":
    """Avertit si la lithologie sous les dolines sort du faciès d'entraînement.

    Limite : un même faciès ailleurs (n4 dans une autre région) passerait le
    test sans être le même système karstique. La garde attrape les changements
    francs de domaine (autre étage, craie, socle), pas les analogues lointains.
    Ne modifie RIEN au calcul : retourne un message ou None.
    """
    frac = lithology_fraction(dolines, geology, model)
    if frac is None:
        return None
    min_frac = float(model.get("domain_notation_min_frac", 0.5))
    if frac < min_frac:
        dom = "/".join(sorted(str(d).lower() for d in model["domain_notations"]))
        return (f"Seulement {frac * 100:.0f}% des dolines sont sur le faciès "
                f"d'entraînement ({dom}) du modèle "
                f"{model.get('domain_name', '')}. Lithologie probablement hors "
                f"domaine validé — résultats du modèle peu fiables.")
    return None


def select_model(dolines, geology, models_dir: "Path | str | None" = None):
    """Routeur : choisit le modèle de domaine adapté à la zone, ou aucun.

    Critère primaire = lithologie (fraction de dolines sur le faciès du modèle,
    ≥ son ``domain_notation_min_frac``). Critère secondaire / de repli quand la
    lithologie n'est pas calculable = distance géographique au domaine
    (≤ ``domain_radius_warn_m``). Entre plusieurs modèles éligibles, on prend la
    plus forte fraction lithologique, puis la plus faible distance.

    Conçu pour rester juste : si aucun modèle ne correspond, retourne
    ``(None, raison)`` → l'appelant retombe sur les poids manuels exploratoires.
    Ne JAMAIS appliquer un modèle hors de son domaine validé en silence.

    Returns:
        (model_dict | None, message_explicatif)
    """
    models = list_models(models_dir)
    if not models:
        return None, "Aucun modèle appris disponible."

    scored = []  # (eligible, frac_or_-1, dist_or_inf, model)
    for m in models:
        frac = lithology_fraction(dolines, geology, m)
        dist = _geo_distance_m(dolines, m)
        # Veto géographique DUR : les préfixes NOTATION (n4, j7…) sont régionaux,
        # donc une concordance lithologique seule peut matcher à 200 km sur le
        # même étage géologique sans être le même karst. Au-delà de
        # domain_radius_max_m, on refuse même si la lithologie colle.
        hard = m.get("domain_radius_max_m")
        too_far = (hard is not None and dist is not None and dist > float(hard))
        if frac is not None:
            # lithologie calculable : sur faciès ET pas géographiquement absurde
            eligible = (frac >= float(m.get("domain_notation_min_frac", 0.5))
                        and not too_far)
        elif dist is not None:
            # pas de lithologie : repli géographique sur le rayon d'alerte
            rad = m.get("domain_radius_warn_m")
            eligible = rad is not None and dist <= float(rad)
        else:
            eligible = False  # ni lithologie ni géo → on n'ose pas appliquer
        scored.append((eligible, frac if frac is not None else -1.0,
                       dist if dist is not None else float("inf"), m))

    eligibles = [s for s in scored if s[0]]
    if not eligibles:
        ids = ", ".join(m.get("model_id", "?") for m in models)
        return None, (f"Aucun des {len(models)} modèle(s) de domaine ne "
                      f"correspond à cette zone ({ids}). Repli sur les poids "
                      f"manuels exploratoires.")
    # tri : plus forte fraction lithologique, puis plus faible distance
    eligibles.sort(key=lambda s: (-s[1], s[2]))
    best = eligibles[0][3]
    frac, dist = eligibles[0][1], eligibles[0][2]
    why = []
    if frac >= 0:
        why.append(f"{frac * 100:.0f}% des dolines sur son faciès")
    if dist != float("inf"):
        why.append(f"{dist / 1000:.0f} km du centre de domaine")
    extra = ""
    if len(eligibles) > 1:
        extra = f" ({len(eligibles)} modèles éligibles, meilleur retenu)"
    return best, (f"Modèle « {best.get('model_id', '?')} » "
                  f"({best.get('karst_type', best.get('domain_name', ''))}) "
                  f"sélectionné : {', '.join(why)}{extra}.")


def proba_to_priority(proba: np.ndarray, model: dict) -> list:
    """Convertit les probabilités en priorités rouge/orange/jaune/gris.

    Seuils = prio_thresholds du modèle (calibrés sur les quantiles du score
    appris, pas sur les seuils du score manuel).
    """
    t = model["prio_thresholds"]
    p1, p2, p3 = t["P1"], t["P2"], t["P3"]
    out = []
    for p in proba:
        if p >= p1:
            out.append("rouge")
        elif p >= p2:
            out.append("orange")
        elif p >= p3:
            out.append("jaune")
        else:
            out.append("gris")
    return out
