# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Inférence du modèle appris (régression logistique par domaine) en numpy pur.

Pourquoi pas sklearn : le plugin distribué n'embarque ni sklearn ni joblib.
Le modèle est exporté en JSON (coef, intercept, scaler, médianes) et rejoué ici
par une simple combinaison linéaire — vérifié identique à sklearn à l'epsilon
machine (cf. export dans prototypes / commit d'intégration).

⚠️ DOMAINE DE VALIDITÉ. Ce modèle (`barrois_model.json`) n'est calibré que pour
le Barrois. Validation hors-échantillon (2 communes inédites, inventaire GERSM
indépendant) : AUC 0,65 (Beurey) et 0,72 (Robert-Espagne), contre 0,57 pour le
score morphologique manuel. La généralisation s'arrête à la frontière
géologique : ne PAS appliquer hors Barrois (AUC ~0,45 hors domaine). C'est
pourquoi l'activation est un choix explicite de l'utilisateur, jamais silencieux.
"""
import json
from pathlib import Path

import numpy as np

DEFAULT_MODEL = Path(__file__).parent.parent / "models" / "barrois_model.json"


def load_model(path: "Path | str | None" = None) -> dict:
    """Charge le modèle JSON. None → modèle Barrois par défaut."""
    p = Path(path) if path else DEFAULT_MODEL
    return json.loads(p.read_text(encoding="utf-8"))


def predict_proba(dolines, model: dict) -> np.ndarray:
    """Probabilité [0–1] d'intérêt spéléo par doline (inférence logistique).

    Reproduit exactement le préprocessing d'entraînement :
    transform log1p(clip(x,0)) sur les features 'log', imputation médiane des
    NaN, standardisation (scaler), combinaison linéaire, sigmoïde.

    Args:
        dolines : GeoDataFrame/DataFrame portant les colonnes de model['features'].
                  Colonne manquante → traitée comme entièrement NaN (→ médiane).
        model   : dict issu de load_model().

    Returns:
        np.ndarray de probabilités, aligné sur l'ordre des lignes de `dolines`.
    """
    import pandas as pd

    feats = model["features"]
    modes = model["feature_modes"]
    n = len(dolines)
    cols = []
    for c in feats:
        if c in dolines.columns:
            v = pd.to_numeric(dolines[c], errors="coerce").to_numpy("float64")
        else:
            v = np.full(n, np.nan)
        if modes[c] == "log":
            v = np.log1p(np.clip(v, 0, None))
        cols.append(v)
    X = np.column_stack(cols) if cols else np.empty((n, 0))

    med = np.asarray(model["median"], dtype="float64")
    idx = np.where(np.isnan(X))
    X[idx] = np.take(med, idx[1])

    mean = np.asarray(model["scaler_mean"], dtype="float64")
    scale = np.asarray(model["scaler_scale"], dtype="float64")
    Xs = (X - mean) / scale

    z = float(model["intercept"]) + Xs @ np.asarray(model["coef"], dtype="float64")
    return 1.0 / (1.0 + np.exp(-z))


def domain_warning(dolines, model: dict) -> "str | None":
    """Avertit si la zone traitée est loin du domaine géologique d'entraînement.

    HEURISTIQUE GROSSIÈRE — la distance géographique n'est qu'un proxy du domaine
    géologique : un point à 30 km peut relever d'une autre formation, et le
    Barrois s'étend au-delà du rayon. Ne change RIEN au calcul : retourne juste
    un message d'alerte (ou None) à afficher. Le vrai garde-fou reste le choix
    explicite de l'utilisateur d'activer le modèle.

    Returns:
        Message d'avertissement si le centroïde de la zone est au-delà de
        ``domain_radius_warn_m`` du centre du domaine, sinon None.
    """
    cx, cy = model.get("domain_centroid_l93", (None, None))
    rad = model.get("domain_radius_warn_m")
    if cx is None or rad is None or len(dolines) == 0:
        return None
    try:
        c = dolines.geometry.centroid
        mx, my = float(c.x.mean()), float(c.y.mean())
    except Exception:
        return None
    d = ((mx - cx) ** 2 + (my - cy) ** 2) ** 0.5
    if d > rad:
        return (f"Zone à {d / 1000:.0f} km du domaine d'entraînement "
                f"({model.get('domain_name', 'modèle')}). Le modèle appris n'y "
                f"est PAS validé — résultats probablement non fiables. "
                f"Envisagez les poids manuels.")
    return None


def proba_to_priority(proba: np.ndarray, model: dict) -> list:
    """Convertit les probabilités en priorités rouge/orange/jaune/gris.

    Seuils = prio_thresholds du modèle (calibrés sur les quantiles du score
    appris, pas sur les seuils du score manuel).
    """
    t = model["prio_thresholds"]
    p1, p2, p3 = t["P1"], t["P2"], t["P3"]
    out = []
    for p in proba:
        if p >= p1:
            out.append("rouge")
        elif p >= p2:
            out.append("orange")
        elif p >= p3:
            out.append("jaune")
        else:
            out.append("gris")
    return out
