# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""
karstpro.core.cold_air
----------------------
Attributs morphométriques dérivés du MNT LiDAR 1 m, calculés par doline :

  - ``compute_slope_max_bord`` : pente maximale (p90) sur l'anneau de bord.
  - ``compute_tpi_500m``       : indice de position topographique (500 m).

NB : le nom de fichier ``cold_air`` est historique. L'indice de piégeage d'air
froid qu'il hébergeait a été **retiré** (non-discriminant : ablation LOCO sur
le Barrois → AUC inchangée, cf. modèles appris ; redondant avec profondeur et
ratio P/√S). Le fichier conserve son nom pour ne pas casser les imports
existants ; il ne contient plus que les attributs morphométriques ci-dessus.

Pas de dépendance externe. Résolution native : 1 m (LiDAR IGN).
"""

from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import geopandas as gpd


def _streamed_median(src, nodata) -> float:
    """Médiane des cellules valides en streaming (mémoire bornée).

    Reproduit ``np.nanmedian`` du MNT entier (valeur de remplissage du nodata)
    SANS charger tout le raster : on accumule un histogramme fin (~0,5 mm) en
    lisant le MNT par blocs de lignes. L'écart à la médiane exacte est < 0,5 mm,
    invisible au niveau des scores (seuils de pente en degrés).
    """
    import numpy as np
    from rasterio.windows import Window

    H, W = src.height, src.width
    lo, hi, cnt = np.inf, -np.inf, 0
    for b0 in range(0, H, 2048):
        a = src.read(1, window=Window(0, b0, W, min(H, b0 + 2048) - b0)).astype(np.float32)
        m = np.isfinite(a)
        if nodata is not None:
            m &= (a != nodata)
        if m.any():
            vv = a[m]
            lo = min(lo, float(vv.min())); hi = max(hi, float(vv.max())); cnt += int(vv.size)
    if cnt == 0:
        return 0.0
    if hi <= lo:
        return float(lo)
    nb = min(20_000_000, max(2, int((hi - lo) / 0.00002) + 1))  # pas ~0,02 mm
    scale = (nb - 1) / (hi - lo)
    hist = np.zeros(nb, dtype=np.int64)
    for b0 in range(0, H, 2048):
        a = src.read(1, window=Window(0, b0, W, min(H, b0 + 2048) - b0)).astype(np.float32)
        m = np.isfinite(a)
        if nodata is not None:
            m &= (a != nodata)
        vv = a[m]
        if vv.size:
            hist += np.bincount(
                np.clip(((vv - lo) * scale).astype(np.int64), 0, nb - 1), minlength=nb)
    k = int(np.searchsorted(np.cumsum(hist), cnt / 2.0))
    return float(lo + k / scale)


def compute_slope_max_bord(
    dolines: "gpd.GeoDataFrame",
    mnt_path: Path,
    ring_width: float = 5.0,
    feedback=None,
) -> "gpd.GeoDataFrame":
    """
    Ajoute la colonne ``pente_max_bord`` (degrés) : 90e percentile de pente
    mesuré sur l'anneau périphérique de chaque doline.

    Principe physique
    -----------------
    Un versant subvertical (pente > 45–70°) est la signature d'un soutirage
    actif — le fond s'est affaissé brutalement, laissant des parois raides.
    Un effondrement ancien stabilisé présente des bords adoucis (< 20°).
    Sur LiDAR 1 m, cette distinction est discriminante sans ambiguïté.

    Paramètres v2 (ScoringReview 2026)
    -----------------------------------
    ring_width : largeur de l'anneau en mètres de part et d'autre de la
                 bordure extérieure (défaut 5 m, était 3 m).
                 5 m échantillonne mieux les parois de grandes dolines.
    p90        : on utilise le 90e percentile plutôt que le maximum brut.
                 Le max était trop sensible aux artefacts LiDAR ponctuels
                 (arbres en bordure, piquet de clôture) qui faisaient sauter
                 une doline de 35° à 85° sur un seul pixel.
                 Le p90 reste discriminant pour les parois vraiment raides
                 tout en éliminant les outliers isolés.
    """
    import numpy as np
    import rasterio
    from rasterio.features import geometry_mask

    def log(msg: str) -> None:
        if feedback:
            feedback.pushInfo(msg)

    dolines = dolines.copy()

    if dolines.empty:
        dolines["pente_max_bord"] = float("nan")
        return dolines

    log("Pente max bord : calcul du gradient MNT 1 m...")

    # Mémoire bornée : au lieu de calculer le gradient sur tout le MNT (dem +
    # dem_filled + dx + dy + slope, plusieurs Gio sur grande emprise), on lit
    # pour chaque doline la fenêtre de son anneau (élargie d'1 px pour le
    # gradient) et on calcule localement. Le gradient des pixels intérieurs est
    # identique aux différences centrées globales ; le remplissage local des
    # trous n'a d'effet qu'en bordure de footprint (anneau déjà incomplet).
    from rasterio.windows import Window

    src = rasterio.open(mnt_path)
    try:
        transform = src.transform
        res = abs(float(transform.a))
        nodata = src.nodata
        H, W = src.height, src.width
        orig_x = float(transform.c)   # coin supérieur gauche X
        orig_y = float(transform.f)   # coin supérieur gauche Y
        # Remplissage nodata = médiane globale (identique au calcul global).
        fill_val = _streamed_median(src, nodata)

        pentes: list[float] = []
        margin = ring_width + 2 * res  # marge pour capturer l'anneau complet

        for geom in dolines.geometry:
            if geom is None or geom.is_empty:
                pentes.append(float("nan"))
                continue
            try:
                minx, miny, maxx, maxy = geom.bounds

                # Fenêtre pixel avec marge
                col0 = max(0, int((minx - margin - orig_x) / res))
                row0 = max(0, int((orig_y - maxy - margin) / res))
                col1 = min(W, int((maxx + margin - orig_x) / res) + 1)
                row1 = min(H, int((orig_y - miny + margin) / res) + 1)

                if row0 >= row1 or col0 >= col1:
                    pentes.append(float("nan"))
                    continue

                # Lecture élargie d'1 px (gradient central), puis extraction
                # de la fenêtre [row0:row1, col0:col1] exacte.
                rr0, cc0 = max(0, row0 - 1), max(0, col0 - 1)
                rr1, cc1 = min(H, row1 + 1), min(W, col1 + 1)
                dem_w = src.read(1, window=Window(cc0, rr0, cc1 - cc0, rr1 - rr0)).astype(np.float32)
                if nodata is not None:
                    dem_w[dem_w == nodata] = np.nan
                if np.isnan(dem_w).any():
                    dem_w = np.nan_to_num(dem_w, nan=fill_val)
                dy, dx = np.gradient(dem_w, res)
                slope_w = np.degrees(np.arctan(np.sqrt(dx ** 2 + dy ** 2)))
                local_slope = slope_w[row0 - rr0:row0 - rr0 + (row1 - row0),
                                      col0 - cc0:col0 - cc0 + (col1 - col0)]

                # Transform local (coin sup-gauche de la fenêtre)
                local_x0 = orig_x + col0 * res
                local_y0 = orig_y - row0 * res
                local_transform = rasterio.transform.from_origin(
                    local_x0, local_y0, res, res
                )

                # Anneau autour de la bordure extérieure
                ring_geom = geom.exterior.buffer(ring_width)
                mask = geometry_mask(
                    [ring_geom],
                    transform=local_transform,
                    invert=True,
                    out_shape=local_slope.shape,
                )
                vals = local_slope[mask]
                # p90 : robuste aux artefacts LiDAR ponctuels (arbres, clôtures)
                # tout en restant discriminant pour les parois vraiment raides.
                pentes.append(float(np.nanpercentile(vals, 90)) if vals.size > 0 else float("nan"))
            except Exception:
                pentes.append(float("nan"))

        dolines["pente_max_bord"] = pentes
    finally:
        src.close()
    import math
    valid = sum(1 for p in pentes if not math.isnan(p))
    log(f"Pente max bord OK : {valid}/{len(dolines)} dolines calculées (p90, anneau {ring_width} m)")
    return dolines


def compute_tpi_500m(
    dolines: "gpd.GeoDataFrame",
    mnt_path: Path,
    radius_m: float = 500.0,
    feedback=None,
) -> "gpd.GeoDataFrame":
    """
    Ajoute la colonne ``tpi_500m`` : Topographic Position Index **réel**.

        TPI = altitude du centroïde − altitude moyenne du MNT dans ``radius_m``

      TPI > 0  : doline en position haute (sommet, replat) → absorption directe
      TPI < 0  : doline en creux / fond de vallon

    Contrairement à l'ancien proxy (altitude vs dolines voisines), la référence
    est le **terrain** (toutes les cellules du MNT), donc indépendante de la
    densité et de la répartition des dolines.

    Sans scipy : moyenne par fenêtre carrée via image intégrale (summed-area
    table numpy), robuste au nodata grâce à une table de comptage séparée.

    Parameters
    ----------
    dolines  : GeoDataFrame en EPSG:2154
    mnt_path : raster MNT (GeoTIFF, même CRS que dolines)
    radius_m : rayon du voisinage en mètres (défaut 500)
    feedback : QgsProcessingFeedback ou None
    """
    import numpy as np
    import rasterio

    def log(msg: str) -> None:
        if feedback:
            feedback.pushInfo(msg)

    dolines = dolines.copy()
    if dolines.empty:
        dolines["tpi_500m"] = float("nan")
        return dolines

    log("TPI 500 m : moyenne focale du MNT (bandes, image intégrale)...")

    # Mémoire bornée par BANDES horizontales : on ne matérialise jamais le MNT
    # entier ni son image intégrale globale. Chaque bande [s0:s1) est lue avec
    # un halo = rayon (r px) de part et d'autre, ce qui couvre exactement la
    # fenêtre focale de toute doline du cœur -> résultat strictement identique
    # au calcul global. La moyenne (soustraite pour la précision float32) est
    # calculée en streaming en un premier passage.
    from rasterio.windows import Window

    src = rasterio.open(mnt_path)
    try:
        transform = src.transform
        res = abs(float(transform.a))      # résolution (m)
        nodata = src.nodata
        H, W = src.height, src.width
        r = max(1, int(round(radius_m / res)))

        centroids = dolines.geometry.centroid
        rows, cols = rasterio.transform.rowcol(
            transform, [c.x for c in centroids], [c.y for c in centroids],
        )
        rows = np.asarray(rows, dtype=np.int64)
        cols = np.asarray(cols, dtype=np.int64)

        # ── Passage 1 : moyenne des altitudes valides (streaming) ──────────
        tot_sum, tot_cnt = 0.0, 0
        for b0 in range(0, H, 2048):
            b1 = min(H, b0 + 2048)
            arr = src.read(1, window=Window(0, b0, W, b1 - b0))
            v = np.isfinite(arr)
            if nodata is not None:
                v &= (arr != nodata)
            if v.any():
                tot_sum += float(arr[v].sum())
                tot_cnt += int(v.sum())
        mean_alt = tot_sum / tot_cnt if tot_cnt else 0.0

        # ── Passage 2 : par bande, image intégrale locale (cœur + halo r) ──
        TARGET = 512 * 1024 * 1024                       # ~512 Mo de pic visé
        read_h = max(int(TARGET / (max(W, 1) * 12)), 2 * r + 512)
        core = max(1, read_h - 2 * r)
        tpi_vals = [0.0] * len(dolines)

        for s0 in range(0, H, core):
            s1 = min(H, s0 + core)
            rd0, rd1 = max(0, s0 - r), min(H, s1 + r)
            arr = src.read(1, window=Window(0, rd0, W, rd1 - rd0)).astype(np.float32)
            v = np.isfinite(arr)
            if nodata is not None:
                v &= (arr != nodata)
            data0 = np.where(v, arr - np.float32(mean_alt), np.float32(0.0)).astype(np.float32)
            sum_i = np.pad(
                np.cumsum(np.cumsum(data0, axis=0, dtype=np.float32), axis=1, dtype=np.float32),
                ((1, 0), (1, 0)), mode="constant")
            cnt_i = np.pad(
                np.cumsum(np.cumsum(v.astype(np.int32), axis=0, dtype=np.int32), axis=1, dtype=np.int32),
                ((1, 0), (1, 0)), mode="constant")

            idx = np.where((rows >= s0) & (rows < s1))[0]
            for i in idx:
                row, col = int(rows[i]), int(cols[i])
                if not (0 <= row < H and 0 <= col < W):
                    continue
                lr = row - rd0
                if not v[lr, col]:
                    continue                              # reste 0.0
                a0, a1 = max(0, row - r), min(H, row + r + 1)
                b0, b1 = max(0, col - r), min(W, col + r + 1)
                la0, la1 = a0 - rd0, a1 - rd0
                s = float(sum_i[la1, b1] - sum_i[la0, b1] - sum_i[la1, b0] + sum_i[la0, b0])
                n = int(cnt_i[la1, b1] - cnt_i[la0, b1] - cnt_i[la1, b0] + cnt_i[la0, b0])
                if n > 0:
                    tpi_vals[i] = round(float(arr[lr, col]) - (s / n + mean_alt), 1)
    finally:
        src.close()

    dolines["tpi_500m"] = tpi_vals
    nz = sum(1 for v in tpi_vals if v != 0.0)
    log(f"TPI 500 m OK : {nz}/{len(dolines)} dolines (rayon {radius_m:.0f} m, "
        f"fenêtre {2 * r + 1} cellules)")
    return dolines
