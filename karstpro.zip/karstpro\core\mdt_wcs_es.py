# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""MDT WCS INSPIRE (Espagne) — MNT 5 m automatique, repli quand aucun LAZ
PNOA n'est fourni manuellement (`MNT_FILES`, cf. Task 10 du plan
routeur-pays-lidar, révision v3).

Endpoint confirmé par requête réelle le 2026-07-31 :
`https://servicios.idee.es/wcs-inspire/mdt`, WCS 2.0.1. Réponse : GeoTIFF
direct (sol nu), pas de LAZ/PDAL — le service sert déjà un raster prêt à
l'emploi.

⚠️ Hypothèse initiale du plan invalidée par `GetCapabilities` : il n'existe
PAS de coverage par fuseau UTM (`Elevacion25829_5`/`Elevacion25831_5`
n'existent pas). Le seul coverage projeté est `Elevacion25830_5` (UTM 30N
ETRS89, 5 m/px) — et son enveloppe (`DescribeCoverage`) couvre déjà toute
l'Espagne continentale (x: -19452..1140352, soit ~1160 km de large, largement
plus qu'un seul fuseau UTM) : l'IGN espagnol a mosaïqué les trois fuseaux
dans une unique grille 25830. `_COVERAGE_ID` est donc fixe, pas dérivé du
CRS cible — le déduire dynamiquement du CRS aurait juste reproduit
l'hypothèse fausse.

Pour les zones 29/31 (bbox hors UTM 30N), la bbox est reprojetée vers
EPSG:25830 avant la requête, et le GeoTIFF renvoyé est reprojeté vers le
CRS cible avant d'être rendu à l'appelant — pour rester cohérent avec le
contrat de `core.lidar.generate_mnt(target_crs=...)` côté France (le MNT
produit est toujours dans le CRS de travail attendu par le reste du
pipeline, jamais dans un CRS qui dépend de la source).
"""
from pathlib import Path

import requests

_WCS_URL = "https://servicios.idee.es/wcs-inspire/mdt"
_WCS_CRS = "EPSG:25830"
_COVERAGE_ID = "Elevacion25830_5"


def _reproject_bbox(bbox: tuple, src_crs: str, dst_crs: str) -> tuple:
    """Reprojette les 4 coins de `bbox` (pas juste les 2 coins diagonaux :
    une rotation/déformation de projection peut faire qu'aucun des 2 coins
    diagonaux ne porte le xmin ou le ymax reprojeté)."""
    if src_crs == dst_crs:
        return bbox
    from pyproj import Transformer

    xmin, ymin, xmax, ymax = bbox
    transformer = Transformer.from_crs(src_crs, dst_crs, always_xy=True)
    xs, ys = [], []
    for x, y in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
        tx, ty = transformer.transform(x, y)
        xs.append(tx)
        ys.append(ty)
    return (min(xs), min(ys), max(xs), max(ys))


def _reproject_raster(src_path: Path, dst_path: Path, dst_crs: str) -> Path:
    import rasterio
    from rasterio.warp import Resampling, calculate_default_transform, reproject

    with rasterio.open(src_path) as src:
        transform, width, height = calculate_default_transform(
            src.crs, dst_crs, src.width, src.height, *src.bounds
        )
        meta = src.meta.copy()
        meta.update({
            "crs": dst_crs, "transform": transform,
            "width": width, "height": height,
        })
        with rasterio.open(dst_path, "w", **meta) as dst:
            for band in range(1, src.count + 1):
                reproject(
                    source=rasterio.band(src, band),
                    destination=rasterio.band(dst, band),
                    src_transform=src.transform,
                    src_crs=src.crs,
                    dst_transform=transform,
                    dst_crs=dst_crs,
                    resampling=Resampling.bilinear,
                )
    return dst_path


def fetch_mdt_wcs(bbox: tuple, crs: str, dest_dir, timeout: int = 60):
    """Télécharge le MNT WCS IGN Espagne (5 m, sol nu) pour `bbox`.

    Args:
        bbox : (xmin, ymin, xmax, ymax) dans `crs`
        crs  : CRS de `bbox` ET du GeoTIFF retourné (ex. "EPSG:25830",
            "EPSG:25829", "EPSG:25831" — target_crs du routeur pays)
        dest_dir : dossier de destination (créé si absent)
        timeout : secondes avant abandon de la requête HTTP

    Returns:
        Path du GeoTIFF écrit dans `dest_dir`, ou `None` en cas d'échec
        réseau/HTTP (même patron que `core.geology_igme` : pas d'exception
        levée, retour `None` explicite que l'appelant doit tester).
    """
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    wcs_bbox = _reproject_bbox(bbox, crs, _WCS_CRS)
    params = {
        "service": "WCS",
        "version": "2.0.1",
        "request": "GetCoverage",
        "coverageId": _COVERAGE_ID,
        "subset": [
            f"x({wcs_bbox[0]},{wcs_bbox[2]})",
            f"y({wcs_bbox[1]},{wcs_bbox[3]})",
        ],
        "format": "image/tiff",
    }
    try:
        resp = requests.get(_WCS_URL, params=params, timeout=timeout)
    except requests.exceptions.RequestException:
        return None
    if resp.status_code != 200:
        return None

    raw_path = dest_dir / (
        "mnt_wcs_25830.tif" if crs != _WCS_CRS else "mnt_wcs.tif"
    )
    raw_path.write_bytes(resp.content)

    if crs == _WCS_CRS:
        return raw_path

    return _reproject_raster(raw_path, dest_dir / "mnt_wcs.tif", crs)
