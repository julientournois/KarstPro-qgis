# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Reprojection UTM → géographique en **Python pur**, sans pyproj.

`pyproj.Transformer.from_crs` déclenche un `proj_create` qui n'est pas
thread-safe dans le processus QGIS : il tue le processus par une *access
violation* Windows, sans exception Python rattrapable et sans rien écrire dans
le journal de la préparation. Le dépôt a purgé pyproj de six chemins (export
MLL, synchronisation, mise à jour des cibles, diagnostic, report de cibles,
identité des dolines) — mais **les trois chemins espagnols avaient été
oubliés**, et c'est un utilisateur qui l'a découvert sur Ségovie le 2026-08-17.

Périmètre volontairement étroit : les seules reprojections dont le pipeline
espagnol a besoin sont UTM ETRS89 → géographique, pour poser une bbox à un
service WFS/WCS. Rien ici ne prétend remplacer PROJ.

**ETRS89 ≡ WGS84 à moins d'un mètre** (dérive continentale depuis 1989) : les
codes `EPSG:4258` et `EPSG:4326` sont donc traités comme équivalents, ce qui
est sans effet sur une requête d'emprise. De même, GRS80 et WGS84 ne diffèrent
que par l'aplatissement, à 0,1 mm près sur le demi-grand axe.
"""
import math

# GRS80 — ellipsoïde d'ETRS89. Identique à WGS84 aux tolérances utiles ici.
_A = 6_378_137.0
_F = 1 / 298.257_222_101
_E2 = 2 * _F - _F * _F
_K0 = 0.9996                 # facteur d'échelle UTM
_FAUX_EST = 500_000.0

# Codes déjà géographiques : rien à faire, la bbox est en degrés.
_GEOGRAPHIQUES = {"EPSG:4258", "EPSG:4326"}


def _zone_utm(crs: str) -> int:
    """Numéro de zone UTM d'un code EPSG, ou ValueError.

    Accepte les UTM nord ETRS89 (258xx) et WGS84 (326xx) : le pipeline espagnol
    travaille en 258xx, mais une emprise saisie par l'utilisateur peut arriver
    en 326xx (c'est le cas du rapport de bug de Ségovie, EPSG:32630).
    """
    code = str(crs).strip().upper()
    if not code.startswith("EPSG:"):
        raise ValueError(
            f"CRS « {crs} » non reconnu : un code « EPSG:xxxxx » est attendu.")
    try:
        numero = int(code.split(":", 1)[1])
    except ValueError:
        raise ValueError(f"CRS « {crs} » non reconnu.") from None
    # 25829-25838 : ETRS89 / UTM zones 29N à 38N. 32601-32660 : WGS84 / UTM Nord.
    if 25828 <= numero <= 25838:
        return numero - 25800
    if 32601 <= numero <= 32660:
        return numero - 32600
    raise ValueError(
        f"CRS « {crs} » n'est pas une UTM nord ETRS89/WGS84 (ex. EPSG:25830). "
        "Ce module ne couvre que les reprojections dont le pipeline espagnol a "
        "besoin — il ne remplace pas PROJ.")


def utm_vers_geographique(x: float, y: float, crs: str) -> tuple:
    """(x, y) UTM nord → (longitude, latitude) en degrés.

    Série inverse de la projection transverse de Mercator (Krüger), tronquée à
    l'ordre 4 en excentricité : l'erreur reste sous le millimètre dans la bande
    utile d'une zone UTM, très au-delà de ce qu'exige une emprise de requête.
    Vérifié contre pyproj sur toute l'Espagne (cf. `tests/test_projection.py`).
    """
    zone = _zone_utm(crs)
    lambda0 = math.radians(zone * 6 - 183)   # méridien central de la zone

    e2 = _E2
    ep2 = e2 / (1 - e2)

    m = y / _K0
    mu = m / (_A * (1 - e2 / 4 - 3 * e2**2 / 64 - 5 * e2**3 / 256))

    e1 = (1 - math.sqrt(1 - e2)) / (1 + math.sqrt(1 - e2))
    phi1 = (mu
            + (3 * e1 / 2 - 27 * e1**3 / 32) * math.sin(2 * mu)
            + (21 * e1**2 / 16 - 55 * e1**4 / 32) * math.sin(4 * mu)
            + (151 * e1**3 / 96) * math.sin(6 * mu)
            + (1097 * e1**4 / 512) * math.sin(8 * mu))

    sin1, cos1, tan1 = math.sin(phi1), math.cos(phi1), math.tan(phi1)
    c1 = ep2 * cos1 * cos1
    t1 = tan1 * tan1
    n1 = _A / math.sqrt(1 - e2 * sin1 * sin1)
    r1 = _A * (1 - e2) / (1 - e2 * sin1 * sin1) ** 1.5
    d = (x - _FAUX_EST) / (n1 * _K0)

    phi = phi1 - (n1 * tan1 / r1) * (
        d**2 / 2
        - (5 + 3 * t1 + 10 * c1 - 4 * c1 * c1 - 9 * ep2) * d**4 / 24
        + (61 + 90 * t1 + 298 * c1 + 45 * t1 * t1
           - 252 * ep2 - 3 * c1 * c1) * d**6 / 720)
    lam = lambda0 + (
        d
        - (1 + 2 * t1 + c1) * d**3 / 6
        + (5 - 2 * c1 + 28 * t1 - 3 * c1 * c1
           + 8 * ep2 + 24 * t1 * t1) * d**5 / 120) / cos1

    return (math.degrees(lam), math.degrees(phi))


def geographique_vers_utm(lon: float, lat: float, crs: str) -> tuple:
    """(longitude, latitude) en degrés → (x, y) UTM nord.

    Projection directe, nécessaire pour les changements de zone : `mdt_wcs_es`
    envoie son emprise au WCS en EPSG:25830, alors qu'une étude peut travailler
    en zone 29 ou 31. Séries USGS 8-15, mêmes tolérances que l'inverse.
    """
    zone = _zone_utm(crs)
    lambda0 = math.radians(zone * 6 - 183)

    phi = math.radians(lat)
    lam = math.radians(lon)
    e2 = _E2
    ep2 = e2 / (1 - e2)

    sinp, cosp, tanp = math.sin(phi), math.cos(phi), math.tan(phi)
    n = _A / math.sqrt(1 - e2 * sinp * sinp)
    t = tanp * tanp
    c = ep2 * cosp * cosp
    a = (lam - lambda0) * cosp

    m = _A * ((1 - e2 / 4 - 3 * e2**2 / 64 - 5 * e2**3 / 256) * phi
              - (3 * e2 / 8 + 3 * e2**2 / 32 + 45 * e2**3 / 1024)
              * math.sin(2 * phi)
              + (15 * e2**2 / 256 + 45 * e2**3 / 1024) * math.sin(4 * phi)
              - (35 * e2**3 / 3072) * math.sin(6 * phi))

    x = _K0 * n * (a
                   + (1 - t + c) * a**3 / 6
                   + (5 - 18 * t + t * t + 72 * c - 58 * ep2) * a**5 / 120
                   ) + _FAUX_EST
    y = _K0 * (m + n * tanp * (a * a / 2
                               + (5 - t + 9 * c + 4 * c * c) * a**4 / 24
                               + (61 - 58 * t + t * t + 600 * c - 330 * ep2)
                               * a**6 / 720))
    return (x, y)


def bbox_vers_crs(bbox: tuple, src_crs: str, dst_crs: str) -> tuple:
    """Emprise d'un CRS vers un autre, parmi ceux que ce module couvre.

    Les quatre coins sont transformés (cf. `bbox_utm_vers_geographique`).
    Source et cible identiques : l'emprise est rendue telle quelle, sans
    aller-retour numérique.
    """
    src = str(src_crs).strip().upper()
    dst = str(dst_crs).strip().upper()
    if src == dst:
        return bbox
    if dst in _GEOGRAPHIQUES:
        return bbox_utm_vers_geographique(bbox, src)

    xmin, ymin, xmax, ymax = bbox
    xs, ys = [], []
    for x, y in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
        lon, lat = (x, y) if src in _GEOGRAPHIQUES else utm_vers_geographique(
            x, y, src)
        nx, ny = geographique_vers_utm(lon, lat, dst)
        xs.append(nx)
        ys.append(ny)
    return (min(xs), min(ys), max(xs), max(ys))


def bbox_utm_vers_geographique(bbox: tuple, crs: str) -> tuple:
    """Emprise UTM → (lon_min, lat_min, lon_max, lat_max) en degrés.

    Les **quatre** coins sont transformés, pas les deux coins diagonaux : une
    bbox UTM reprojetée en géographique ne garde pas ses extrêmes sur les mêmes
    coins, et n'en prendre que deux rétrécit l'emprise en silence.

    Une bbox déjà en degrés (`EPSG:4258`/`4326`) est rendue telle quelle : la
    reprojeter reviendrait à traiter des degrés comme des mètres.
    """
    if str(crs).strip().upper() in _GEOGRAPHIQUES:
        return bbox
    xmin, ymin, xmax, ymax = bbox
    lons, lats = [], []
    for x, y in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
        lon, lat = utm_vers_geographique(x, y, crs)
        lons.append(lon)
        lats.append(lat)
    return (min(lons), min(lats), max(lons), max(lats))
