# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Modèle territoires / capacités — routage multi-pays de KarstPro.

Le pipeline nomme ses BESOINS (capacités), jamais ses fournisseurs. Voir
docs/superpowers/specs/2026-08-02-architecture-territoires-capacites-design.md
"""
from karstpro.core.territoires.types import (  # noqa: F401
    Absente, Capacite, ContexteEtude,
    ConfigurationIncomplete, ConfigurationInconnue, ConfigurationInvalide,
)
from karstpro.core.territoires.registre import (  # noqa: F401
    CAPACITES_OBLIGATOIRES, CAPACITES_REQUISES, Territoire,
)
from karstpro.core.territoires.chargeur import get_territoire  # noqa: F401
