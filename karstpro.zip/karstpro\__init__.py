# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
import sys
import io


class _SafeStream:
    """Null stream that silently absorbs writes.

    QGIS sets sys.stdout/stderr to None during plugin loading, which crashes
    numpy, whitebox and other C-extensions that write deprecation warnings.
    This safe fallback prevents those crashes without polluting any real output.
    """
    def write(self, *args, **kwargs):
        pass

    def flush(self, *args, **kwargs):
        pass

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


# Patch unconditionally at module level — QGIS may reset these to None at any
# point during startup. We replace None with a safe no-op stream; real streams
# are left untouched so normal output still works.
if sys.stdout is None:
    sys.stdout = _SafeStream()
if sys.stderr is None:
    sys.stderr = _SafeStream()

# Belt-and-suspenders: install a module __getattr__ so that if QGIS resets
# sys.stderr/stdout to None AFTER this module runs, the patch re-applies on
# any subsequent attribute access (Python 3.7+).
def _ensure_streams():
    if sys.stdout is None:
        sys.stdout = _SafeStream()
    if sys.stderr is None:
        sys.stderr = _SafeStream()


def classFactory(iface):
    """QGIS plugin entry point.

    KarstPro dépend de paquets Python absents de l'environnement QGIS par
    défaut (geopandas, rasterio, reportlab, whitebox, pyproj). Une installation
    via le dépôt QGIS (custom ou officiel) n'exécute jamais install_deps.bat/.sh
    — seul un zip est extrait, aucun hook post-install (vérifié dans le code
    source de QGIS, pyplugin_installer).

    Détection en deux temps :
    1. Vérification PROACTIVE (core.dependencies.missing_dependencies) — le
       cas réel le plus fréquent : les imports lourds sont différés dans les
       algorithmes (convention du projet), donc l'import ci-dessous réussit
       même si geopandas etc. sont absents. Sans cette vérification, on ne
       le saurait qu'au premier run d'un algorithme, avec un traceback bien
       moins clair.
    2. Filet de sécurité `except ImportError` — au cas où une dépendance non
       couverte par CHECK_MODULES manquerait et ferait échouer l'import pour
       de vrai.

    Dans les deux cas : proposer une installation automatique (avec
    confirmation), jamais silencieuse.
    """
    _ensure_streams()  # re-apply patch in case QGIS reset streams after module load
    from karstpro.core.dependencies import missing_dependencies
    missing = missing_dependencies()
    if missing:
        return _handle_missing_dependencies(
            iface, "modules manquants : " + ", ".join(missing))
    try:
        from karstpro.karstpro_plugin import KarstProPlugin
        return KarstProPlugin(iface)
    except ImportError as exc:
        return _handle_missing_dependencies(iface, str(exc))


def _handle_missing_dependencies(iface, reason):
    """Propose d'installer les dépendances manquantes, puis réessaie le
    chargement. Retourne toujours un objet plugin valide (jamais d'exception
    remontée à QGIS, qui afficherait un traceback brut sans piste d'action).

    `reason` : texte libre pour l'utilisateur (liste de modules manquants,
    ou message de la ImportError du filet de sécurité)."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QApplication, QMessageBox

    # PyQt5 expose QMessageBox.Yes / Qt.WaitCursor à plat ; PyQt6 (toute la
    # branche QGIS 4.x, vérifié sur 4.0.2 et 4.2.0) les a déplacés dans des
    # sous-enums scopés (StandardButton, CursorShape) — même piège que
    # QSettings.Format dans add_qgis_repo.py. Vérifié en conditions réelles
    # sur QGIS 3.40.4/PyQt5 5.15.11 : ce PyQt5 expose *aussi* les sous-enums
    # scopés (ajoutés en 5.15 pour préparer la migration PyQt6), donc le
    # getattr() ci-dessous y résout la même valeur que sur PyQt6 — repli
    # défensif confirmé sur les deux familles, pas seulement en théorie.
    _btn = getattr(QMessageBox, "StandardButton", QMessageBox)
    _cursor = getattr(Qt, "CursorShape", Qt)
    MB_YES, MB_NO = _btn.Yes, _btn.No
    WAIT_CURSOR = _cursor.WaitCursor

    parent = iface.mainWindow() if iface else None

    reply = QMessageBox.question(
        parent, "KarstPro — dépendances manquantes",
        "KarstPro a besoin de paquets Python absents de l'environnement QGIS "
        f"({reason}).\n\nLes installer maintenant ? Nécessite une connexion "
        "internet, peut prendre quelques minutes.",
        MB_YES | MB_NO, MB_YES)

    if reply != MB_YES:
        QMessageBox.information(
            parent, "KarstPro",
            "KarstPro ne peut pas fonctionner sans ces paquets. Vous pourrez "
            "les installer plus tard via Extensions → Console Python → "
            "import karstpro.install_dependencies.")
        return _StubPlugin()

    if parent:
        QApplication.setOverrideCursor(WAIT_CURSOR)
    try:
        # Importer install_dependencies déclenche install()+verify() (voir ce
        # module : main() s'exécute au chargement, pensé pour être collé dans
        # la console Python). verify() est ré-appelé ensuite : idempotent
        # (réimporte juste chaque paquet), ça donne un booléen exploitable ici
        # sans dupliquer l'installation elle-même.
        from karstpro import install_dependencies
        ok = install_dependencies.verify()
    except Exception:
        ok = False
    finally:
        if parent:
            QApplication.restoreOverrideCursor()

    if not ok:
        QMessageBox.critical(
            parent, "KarstPro",
            "L'installation a échoué ou est incomplète. Réessayez via "
            "Extensions → Console Python → "
            "import karstpro.install_dependencies, ou consultez la console "
            "pour le détail de l'erreur.")
        return _StubPlugin()

    try:
        from karstpro.karstpro_plugin import KarstProPlugin
    except ImportError:
        QMessageBox.warning(
            parent, "KarstPro",
            "Les dépendances semblent installées mais KarstPro ne peut "
            "toujours pas se charger. Redémarrez QGIS.")
        return _StubPlugin()

    QMessageBox.information(
        parent, "KarstPro",
        "Dépendances installées avec succès. KarstPro est prêt.")
    return KarstProPlugin(iface)


class _StubPlugin:
    """Instance minimale retournée quand les dépendances manquent ou que
    l'utilisateur refuse l'installation — évite qu'une exception remonte au
    gestionnaire d'extensions de QGIS (qui afficherait un traceback brut)."""
    def initGui(self):
        pass

    def unload(self):
        pass
