# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from __future__ import annotations  # must be first non-comment statement

from pathlib import Path
from typing import TYPE_CHECKING

# NOTE: qgis.core imports are at module level because QGIS injects these
# before loading plugin modules. All karstpro.core.* and heavy third-party
# imports (numpy, geopandas, rasterio) are deferred to inside
# processAlgorithm() — QGIS sets sys.stderr=None during plugin load which
# crashes C-extensions that emit deprecation warnings.
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterDefinition,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessing,
)
from karstpro.core.i18n import t
from karstpro.core.crs_thread import crs_pour

if TYPE_CHECKING:
    import geopandas as gpd


class KarstPrepAlgorithm(QgsProcessingAlgorithm):
    """Algorithme « Préparer une étude » — pipeline complet bureau.

    Enchaîne : téléchargement LiDAR HD IGN (COPC LAZ) → MNT 1 m (TIN, classe
    sol LAS 2) → détection des dépressions (dolines : fill Wang & Liu + seuil
    0,1 m / 10 m²) **et des gouffres / puits verticaux** (vides de NODATA
    compacts du MNT, signature d'un puits ouvert que le LiDAR ne sonde pas) +
    **points d'eau karstiques référencés** (sources/pertes/inversacs BD Topo,
    pour les entrées noyées invisibles au MNT) → attributs morphométriques (pente bord, cold air, TPI 500 m, bassin D8) →
    scoring (poids manuels ou modèle appris via routeur de domaine) → GeoPackage
    + projet QGIS/QField prêts pour le terrain.
    """

    EXTENT = "EXTENT"
    TOPO_FILE = "TOPO_FILE"
    SCORING_CONFIG = "SCORING_CONFIG"
    OUTPUT_DIR = "OUTPUT_DIR"
    SECTEUR_NAME = "SECTEUR_NAME"
    CAVITES_CONNUES = "CAVITES_CONNUES"
    TRACAGES = "TRACAGES"
    MNT_FILES = "MNT_FILES"
    GEO_LOCAL = "GEO_LOCAL"
    SCAN25_APIKEY = "SCAN25_APIKEY"
    CONTOUR_INTERVAL = "CONTOUR_INTERVAL"
    # Pas de widget dans la boîte de dialogue (retiré des paramètres avancés,
    # 2026-07-29) : réglage qu'on ne change quasiment jamais d'une prép à
    # l'autre. Valeur par défaut ci-dessous ; pour la changer, éditer
    # karstpro_etude.json à la main puis relancer « Refaire une étude ».
    DEFAULT_CONTOUR_INTERVAL_M = 5.0
    FILTER_ANTHROPIC = "FILTER_ANTHROPIC"
    KEEP_VISITED = "KEEP_VISITED"
    USE_LEARNED_MODEL = "USE_LEARNED_MODEL"
    SEUIL_SURFACE_PC = "SEUIL_SURFACE_PC"
    # Pas de widget dans la boîte de dialogue (retiré des paramètres avancés,
    # 2026-07-29) : réglage qu'on ne change quasiment jamais d'une prép à
    # l'autre. Valeur par défaut ci-dessous ; pour la changer, éditer
    # karstpro_etude.json à la main puis relancer « Refaire une étude ».
    DEFAULT_SEUIL_SURFACE_PC_M2 = 100000.0
    SIGNAL_RGEALTI = "SIGNAL_RGEALTI"
    PAYS = "PAYS"

    def name(self):
        return "karst_prep"

    def displayName(self):
        return t("KarstPro — Préparer une étude")

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstPrepAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        from karstpro.core.i18n import aide
        # Corps du panneau dans i18n/aide/<module>.<langue>.html — le nom du
        # module vient de __name__, il ne peut pas diverger du fichier.
        return help_html(aide(__name__.rsplit(".", 1)[-1]))

    def _add_advanced(self, param):
        """Place le paramètre dans la section repliable « Paramètres avancés »."""
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        # ── Paramètres requis (toujours visibles) ──────────────────────────
        self.addParameter(QgsProcessingParameterString(
            self.SECTEUR_NAME,
            t("Nom du secteur (laisser vide = commune au centre de l'emprise, auto)"),
            optional=True))
        self.addParameter(QgsProcessingParameterExtent(
            self.EXTENT, t("Zone d'étude (bbox)")))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR, t("Dossier de sortie")))
        # Routeur pays : sélectionne la source LiDAR, la source géologie, le
        # CRS de travail et l'éligibilité au modèle appris. Toujours visible
        # (pas dans les paramètres avancés) — c'est un choix structurant, pas
        # un réglage secondaire. Cf. karstpro/core/territoires/.
        self.addParameter(QgsProcessingParameterEnum(
            self.PAYS,
            t("Pays (source LiDAR/géologie/modèle)"),
            options=["France", "Espagne (expérimental)",
                     "Belgique — Wallonie (expérimental)"],
            defaultValue=0,
        ))

        # ── Paramètres optionnels (section « avancés », repliée par défaut) ─
        self._add_advanced(QgsProcessingParameterFile(
            self.TOPO_FILE, t("Topo réseau existant (.shp ou .kml)"), optional=True))
        # GeoPackage inventaire (cavités connues) — fichier partagé Karst Entry.
        # Doit contenir la couche « Inventaire Cavités » / cavites_connues. Il
        # est ajouté au projet en lecture seule (NON copié dans le package).
        self._add_advanced(QgsProcessingParameterFile(
            self.CAVITES_CONNUES,
            t("GeoPackage inventaire cavités (.gpkg avec « Inventaire Cavités »)"),
            optional=True, extension="gpkg",
        ))
        # GeoPackage traçages — doit contenir « Inventaire Traçages » / tracages.
        self._add_advanced(QgsProcessingParameterFile(
            self.TRACAGES,
            t("GeoPackage traçages (.gpkg avec « Inventaire Traçages »)"),
            optional=True, extension="gpkg",
        ))
        self._add_advanced(QgsProcessingParameterFile(
            self.SCORING_CONFIG, t("Config scoring JSON"), optional=True))
        self._add_advanced(QgsProcessingParameterMultipleLayers(
            self.MNT_FILES,
            t("MNT pré-téléchargé(s) — OBLIGATOIRE en Wallonie (seule "
            "source : aucun service ne sert le MNT wallon), dernier "
            "recours en France, optionnel en Espagne (priorité sur le "
            "PNOA 1 m auto et son repli WCS 5 m sinon)"),
            layerType=QgsProcessing.TypeRaster,
            optional=True,
        ))
        self._add_advanced(QgsProcessingParameterFile(
            self.GEO_LOCAL,
            t("Géologie locale BD Charm-50 1/50 000 (optionnel — GPKG ou shapefile) "
            "— France uniquement"),
            optional=True,
            extension="",  # accepte .gpkg et .shp
        ))
        self._add_advanced(QgsProcessingParameterString(
            self.SCAN25_APIKEY,
            t("Clé API SCAN25 personnelle (optionnel — voir l'aide) — France uniquement"),
            defaultValue="",
            optional=True,
        ))
        # Signal RGE ALTI (affaissement historique) : contrairement au signal
        # ponctuel ci-dessus, CONTRIBUE au score (feature du modèle appris,
        # cf. plan docs/superpowers/plans/2026-07-28-signal-rgealti.md).
        # Désactivé automatiquement par secteur si le RGE ALTI local n'est
        # pas d'origine LiDAR (core.rgealti.is_secteur_eligible) — jamais
        # bloquant pour le reste de la préparation.
        self._add_advanced(QgsProcessingParameterBoolean(
            self.SIGNAL_RGEALTI,
            t("Signal RGE ALTI — affaissement historique (contribue au score) "
            "— France uniquement"),
            defaultValue=True,
        ))
        # L'ombrage MNT est toujours ajouté au projet. Pour un paquet QFieldCloud
        # léger, l'utilisateur retire la couche MNT du projet avant le packaging
        # (QFieldCloud copie tous les rasters et ignore le flag remove).
        # Filtre faux positifs anthropiques : BD Topo, CARRIÈRES UNIQUEMENT.
        # Une carrière est une vraie dépression mais pas un karst → déclassée en
        # gris (étiquetée flag_anthropique, jamais supprimée). Décocher en secteur
        # sans activité extractive (gain nul) ou pour tout réexaminer à la main.
        # Le bâti et les zones d'activité sont volontairement EXCLUS (un bâtiment
        # n'est pas une dépression) — cf. geology.fetch_bdtopo_anthropic et
        # scoring.flag_anthropic_dolines pour la mesure qui justifie ce choix.
        self.addParameter(QgsProcessingParameterBoolean(
            self.FILTER_ANTHROPIC,
            t("Déclasser les dolines anthropiques (carrières BD Topo) "
            "— France uniquement"),
            defaultValue=True,
        ))
        # Report des cibles déjà prospectées : si une préparation existe déjà
        # pour ce secteur (même dossier de sortie), les cibles visitées (verdict
        # `interet`) sont conservées dans la couche « cibles visitées » et les
        # nouvelles cibles tombant au même endroit sont retirées de la to-do.
        # Décocher = table rase (repartir de zéro).
        self.addParameter(QgsProcessingParameterBoolean(
            self.KEEP_VISITED,
            t("Retirer les cibles déjà prospectées ou connues"),
            defaultValue=True,
        ))
        # Méthode de priorisation. Index 0 = automatique (routeur : modèle appris
        # selon le domaine, repli poids manuels si aucun ne correspond) ;
        # index 0 = automatique (routeur, modèles AUTO seulement), 1 = poids
        # manuels forcés (exploratoire), >=2 = forcer un modèle OPT-IN.
        # Les modèles opt-in (auto_select=false, ex. Jura plateau) ne sont JAMAIS
        # auto-appliqués — leur régime n'est pas détectable de façon fiable
        # (cf. Arbois/Besançon). L'utilisateur les active sciemment, sur son
        # jugement géologique. La liste est construite depuis le registre.
        prio_options = [
            "Automatique — modèle appris selon le domaine (recommandé)",
            "Poids manuels (exploratoire)",
        ]
        try:
            from karstpro.core.model_score import list_models
            self._optin_models = sorted(
                (m for m in list_models() if not m.get("auto_select", True)),
                key=lambda m: m.get("model_id", ""))
        except Exception:
            self._optin_models = []
        for m in self._optin_models:
            prio_options.append(
                f"Forcer « {m.get('model_id', '?')} » — {m.get('domain_name', '')} "
                f"(OPT-IN : uniquement si le terrain est confirmé de ce type)")
        self.addParameter(QgsProcessingParameterEnum(
            self.USE_LEARNED_MODEL,
            t("Priorisation. « Automatique » applique un modèle appris si la zone "
            "est dans un domaine validé (Barrois aujourd'hui), sinon poids "
            "manuels. Les options « Forcer … » activent un modèle OPT-IN, non "
            "auto-détectable — à n'utiliser que si vous savez être sur ce karst. "
            "Modèles appris — France uniquement (repli automatique sur les poids "
            "manuels hors de France)."),
            options=prio_options,
            defaultValue=0,
        ))

    # Champs qui n'ont de sens qu'en France ET dont la valeur par défaut est
    # vide : les renseigner est un ACTE DÉLIBÉRÉ, donc une vraie erreur hors de
    # France, qu'il vaut mieux signaler avant 20 min de traitement.
    # SIGNAL_RGEALTI / FILTER_ANTHROPIC / USE_LEARNED_MODEL sont volontairement
    # ABSENTS de cette liste : cochés par défaut, les refuser rejetterait toute
    # étude non française. Ils restent neutralisés à l'exécution.
    _CHAMPS_FRANCE_ACTE_DELIBERE = (
        ("SCAN25_APIKEY", "la clé SCAN25 IGN"),
        ("GEO_LOCAL", "le fichier de géologie locale (BD Charm-50)"),
    )

    def checkParameterValues(self, parameters, context):
        pays_idx = parameters.get("PAYS", 0) or 0
        # L'ordre DOIT suivre celui des options de l'énumération PAYS.
        pays = ["france", "espagne", "wallonie"][int(pays_idx)]
        if pays == "france":
            return True, ""
        renseignes = [
            libelle for cle, libelle in self._CHAMPS_FRANCE_ACTE_DELIBERE
            if str(parameters.get(cle) or "").strip()
        ]
        if renseignes:
            return False, (
                f"Territoire « {pays} » : {', '.join(renseignes)} "
                f"({', '.join(c for c, _ in self._CHAMPS_FRANCE_ACTE_DELIBERE)}) "
                f"ne concerne(nt) que la France. Videz ce(s) champ(s) ou "
                f"sélectionnez « France »."
            )
        return True, ""

    # ── Helpers UI ────────────────────────────────────────────────────────────

    def _log(self, feedback: "QgsProcessingFeedback", msg: str,
             log_file: "Path | None" = None, warn: bool = False) -> None:
        """pushInfo/pushWarning (le proxy feedback recopie dans le fichier) + processEvents."""
        from qgis.core import QgsApplication
        if warn:
            feedback.pushWarning(msg)
        else:
            feedback.pushInfo(msg)
        # Laisser Qt traiter ses événements (repaint log, barre de progression…)
        QgsApplication.processEvents()

    def _step(self, feedback: "QgsProcessingFeedback", msg: str,
              progress: int, log_file: "Path | None" = None) -> None:
        """Checkpoint : titre de section + progression + processEvents."""
        from qgis.core import QgsApplication
        feedback.setProgress(progress)
        feedback.pushInfo(t("\n{v0}\n{msg}\n{v2}", v0='─'*60, msg=msg, v2='─'*60))
        QgsApplication.processEvents()

    @staticmethod
    def _sanitize_name(s: str) -> str:
        """Rend un nom de commune sûr pour un nom de fichier/couche : ASCII,
        sans espaces ni apostrophes. Ex. « L'Île-d'Elle » → « L-Ile-d-Elle »."""
        import re
        import unicodedata
        s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii")
        s = re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-")
        return s or "Secteur"

    def _auto_secteur_name(self, extent, extent_crs, feedback) -> str:
        """Déduit le nom du secteur de la commune au centre de l'emprise
        (géocodage inverse geo.api.gouv.fr). Repli « Secteur » si échec réseau.
        """
        commune = ""
        try:
            from qgis.core import (
                QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
            )
            from karstpro.core.sync import _fetch_commune_with_contour
            center = extent.center()  # QgsPointXY dans extent_crs
            wgs = QgsCoordinateReferenceSystem("EPSG:4326")
            if extent_crs.isValid() and extent_crs != wgs:
                tr = QgsCoordinateTransform(extent_crs, wgs, QgsProject.instance())
                center = tr.transform(center)
            admin, _ = _fetch_commune_with_contour(center.y(), center.x())
            commune = (admin or {}).get("commune", "").strip()
        except Exception as exc:
            feedback.pushWarning(t("Géocodage commune échoué : {exc}", exc=exc))
        if commune:
            name = self._sanitize_name(commune)
            feedback.pushInfo(
                t("Nom du secteur auto : « {name} » (commune au centre de l'emprise).", name=name))
            return name
        feedback.pushWarning(
            t("Commune non résolue (réseau ?) — nom de secteur par défaut "
            "« Secteur ». Renomme le projet si besoin."))
        return "Secteur"

    # Paramètres transmis à l'enfant. Tous primitifs (chaîne, booléen, nombre,
    # liste de chemins) : `EXTENT` arrive déjà sous sa forme textuelle
    # « xmin,xmax,ymin,ymax [EPSG:xxxx] », que QGIS sait relire.
    _PARAMS_TRANSMIS = (
        "EXTENT", "TOPO_FILE", "SCORING_CONFIG", "OUTPUT_DIR", "SECTEUR_NAME",
        "CAVITES_CONNUES", "TRACAGES", "MNT_FILES", "GEO_LOCAL",
        "SCAN25_APIKEY", "CONTOUR_INTERVAL", "FILTER_ANTHROPIC", "KEEP_VISITED",
        "USE_LEARNED_MODEL", "SEUIL_SURFACE_PC", "SIGNAL_RGEALTI", "PAYS",
    )

    def _deleguer(self, parameters, context, feedback):
        """Relance la préparation dans un processus neuf et rejoue son journal.

        Les paramètres sont sérialisés tels quels : ceux de cet algorithme sont
        tous primitifs. Une valeur non sérialisable est convertie en texte
        plutôt que de faire échouer la délégation — mieux vaut un paramètre
        dégradé qu'une préparation impossible.
        """
        from karstpro.core.sous_processus import executer, normaliser_parametre

        # Un paramètre optionnel vide vaut NULL côté Qt. Le convertir en texte
        # produisait la chaîne « NULL », non vide donc « vraie » : l'enfant
        # recevait un chemin de fichier nommé NULL. Cf. normaliser_parametre().
        charge = {}
        for cle in self._PARAMS_TRANSMIS:
            if cle not in parameters:
                continue
            valeur = normaliser_parametre(parameters[cle])
            if valeur is None:
                continue          # absent chez le parent = absent chez l'enfant
            charge[cle] = valeur

        script = Path(__file__).resolve().parents[1] / "prep_worker.py"
        feedback.pushInfo(t(
            "Préparation lancée dans un processus séparé — un incident n'y "
            "emportera pas QGIS."))
        # Un échec doit atterrir DANS LE FICHIER .log, pas seulement dans la
        # fenêtre QGIS. L'exception remontait telle quelle : le journal — le
        # seul artefact qu'un utilisateur nous envoie — s'arrêtait alors en
        # pleine étape, sans le moindre indice. C'est exactement ce qui a rendu
        # indéchiffrables les trois journaux reçus le 2026-08-23.
        # `reportError` est recopié par le proxy de journalisation.
        try:
            return executer(script, charge, feedback=feedback)
        except Exception as exc:
            feedback.reportError(t("Échec de la préparation : {exc}", exc=exc),
                                 fatalError=True)
            raise

    def processAlgorithm(self, parameters, context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        """Exécute le pipeline de préparation (voir docstring de la classe).

        Retourne {"OUTPUT_GPKG": chemin} ; journalise chaque étape dans un
        fichier .log persistant du dossier de sortie (proxy _LogFeedback).

        **Délégation à un processus séparé.** Construire un CRS pyproj dans un
        second `QgsTask` tue le processus QGIS : relancer une préparation dans
        la même session suffisait à tout perdre, quel que soit le pays (cf.
        `karstpro/core/crs_thread.py`). L'algorithme se relance donc lui-même
        dans un processus neuf, où il est le premier et unique run. Un plantage
        y tue l'enfant, plus QGIS.
        """
        import os as _os

        if not _os.environ.get("KARSTPRO_ENFANT"):
            return self._deleguer(parameters, context, feedback)
        # Lazy imports — deferred until algorithm actually runs (sys.stderr is
        # properly set by then, so C-extension deprecation warnings are safe).
        import shutil
        import geopandas as gpd
        from karstpro.core.lidar import (
            bbox_to_ign_tiles, download_lidar_tiles, generate_mnt,
            detect_dolines, compute_hydrology, compute_bassin_versant,
        )
        from karstpro.core.geology import fetch_brgm_geology, load_local_geology, fetch_geology_auto, check_bdlisa_karst_status, fetch_georisques_cavites
        from karstpro.core.topo import load_topo
        from karstpro.core.scoring import compute_scores, load_config, compute_cavites_connues_proximity
        from karstpro.core.qfield import package_qfield_project, write_cibles_from_scored_dolines
        from karstpro.core.gpkg import CAVITES_SCHEMA, read_gpkg_layer
        from karstpro.core.crs_thread import crs_pour

        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsProject,
        )

        from datetime import datetime
        name = self.parameterAsString(parameters, self.SECTEUR_NAME, context)
        extent = self.parameterAsExtent(parameters, self.EXTENT, context)

        # Routeur pays — résolu tôt (ne dépend que du paramètre PAYS, pas de
        # la bbox) : détermine ensuite le CRS de travail, la source géologie,
        # l'éligibilité au modèle appris et si le LiDAR manuel est requis.
        pays_idx = self.parameterAsEnum(parameters, self.PAYS, context)
        # L'ordre DOIT suivre celui des options de l'énumération PAYS.
        pays = ["france", "espagne", "wallonie"][pays_idx]
        from karstpro.core.territoires import get_territoire
        from karstpro.core.territoires.types import ContexteEtude
        territoire = get_territoire(pays)
        feedback.pushInfo(
            t("Pays : {pays} — pipeline exploratoire (pas de modèle appris)",
              pays=pays)
            if territoire.capacite("modele_appris").absente else
            t("Pays : {pays} — pipeline complet (modèle appris)", pays=pays)
        )

        # GeoPackage inventaire (cavités connues) et traçages : on récupère le
        # chemin + la couche (détectée par schéma). Ils ne sont PAS copiés : ils
        # sont lus pour la proximité (cavités) et référencés en lecture seule.
        from karstpro.core.sync import find_inventory_layer, find_tracages_layer
        cc_gpkg_str = self.parameterAsFile(parameters, self.CAVITES_CONNUES, context)
        tr_gpkg_str = self.parameterAsFile(parameters, self.TRACAGES, context)
        cavites_connues_gpkg = Path(cc_gpkg_str) if cc_gpkg_str else None
        tracages_gpkg = Path(tr_gpkg_str) if tr_gpkg_str else None
        cavites_connues_layer_name = None
        tracages_layer_name = None
        if cavites_connues_gpkg is not None and cavites_connues_gpkg.exists():
            cavites_connues_layer_name = find_inventory_layer(cavites_connues_gpkg)
            if cavites_connues_layer_name is None:
                feedback.pushWarning(
                    t("« {cavites_connues_gpkg_name} » ne contient pas de couche inventaire valide (name/reference) — ignoré.", cavites_connues_gpkg_name=cavites_connues_gpkg.name))
        if tracages_gpkg is not None and tracages_gpkg.exists():
            tracages_layer_name = find_tracages_layer(tracages_gpkg)
            if tracages_layer_name is None:
                feedback.pushWarning(
                    t("« {tracages_gpkg_name} » ne contient pas de couche traçages valide (colorant/point_injection) — ignoré.", tracages_gpkg_name=tracages_gpkg.name))
        mnt_layers = self.parameterAsLayerList(parameters, self.MNT_FILES, context)
        geo_local_file = self.parameterAsFile(parameters, self.GEO_LOCAL, context)
        scan25_apikey = self.parameterAsString(parameters, self.SCAN25_APIKEY, context).strip()
        extent_crs = self.parameterAsExtentCrs(parameters, self.EXTENT, context)
        topo_file = self.parameterAsFile(parameters, self.TOPO_FILE, context)
        config_file = self.parameterAsFile(parameters, self.SCORING_CONFIG, context)
        # Pas de widget dans la boîte de dialogue (cf. initAlgorithm) : lu
        # directement dans le dict brut, comme CONTOUR_INTERVAL. Modifiable
        # en éditant karstpro_etude.json puis « Refaire une étude ».
        try:
            seuil_surface_pc = float(parameters.get(
                self.SEUIL_SURFACE_PC, self.DEFAULT_SEUIL_SURFACE_PC_M2))
        except (TypeError, ValueError):
            seuil_surface_pc = self.DEFAULT_SEUIL_SURFACE_PC_M2
        parameters[self.SEUIL_SURFACE_PC] = seuil_surface_pc
        signal_rgealti = self.parameterAsBoolean(parameters, self.SIGNAL_RGEALTI, context)
        output_dir = Path(self.parameterAsString(parameters, self.OUTPUT_DIR, context))
        output_dir.mkdir(parents=True, exist_ok=True)

        # Nom du secteur auto : si vide, commune au centre de l'emprise.
        if not name.strip():
            name = self._auto_secteur_name(extent, extent_crs, feedback)

        # Log fichier — persiste même si la boîte de dialogue se ferme.
        # Dans logs/ (pas à la racine) pour ne pas encombrer le dossier
        # d'étude — voir read_etude_params qui cherche aussi à la racine
        # pour les études préparées avant ce rangement.
        logs_dir = output_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / f"karstpro_prep_{name}_{datetime.now():%Y%m%d_%H%M%S}.log"
        from karstpro.core.log_feedback import write_log_header, wrap_feedback
        write_log_header(log_file, f"{t('KarstPro — Préparer une étude')} ({name})", parameters)
        feedback = wrap_feedback(feedback, log_file)
        _t0 = datetime.now()

        # Deux secteurs dans un même dossier de sortie partagent lidar_work/ :
        # le MNT et ses dérivés du premier seront invalidés et retéléchargés.
        # Averti ici, en tête de journal, tant que l'utilisateur peut encore
        # changer de dossier — plutôt qu'après une heure de téléchargement.
        # Dossier de sortie sous un client de synchronisation : le dossier de
        # travail reçoit plusieurs gigaoctets de dalles LiDAR, que le client
        # téléverse pendant que PDAL les lit — et qu'il peut déshydrater, si
        # bien qu'une dalle « en cache » redevient un téléchargement réseau
        # silencieux. Averti ICI, avant le premier octet téléchargé.
        from karstpro.core.etude import dossier_synchronise, secteur_precedent
        _sync = dossier_synchronise(output_dir)
        if _sync:
            feedback.pushWarning(t(
                "Le dossier de sortie est dans « {sync} », un espace "
                "synchronisé dans le nuage. Le dossier de travail lidar_work/ "
                "y recevra plusieurs gigaoctets de dalles LiDAR : la "
                "synchronisation ralentit fortement le calcul du relief, et "
                "les fichiers « à la demande » peuvent être vidés puis "
                "retéléchargés à chaque lecture — la préparation paraît alors "
                "figée. Utilisez un dossier LOCAL, hors synchronisation.",
                sync=_sync))
        _precedent = secteur_precedent(output_dir)
        if _precedent and _precedent != name:
            feedback.pushWarning(
                t("⚠ Ce dossier contient déjà l'étude « {_precedent} ». Le dossier de travail lidar_work/ est partagé : préparer « {name} » ici invalidera son MNT (retéléchargement) et le projet QGIS de « {_precedent2} » affichera ensuite le relief de « {name2} ». Un dossier de sortie par secteur est recommandé.", _precedent=_precedent, name=name, _precedent2=_precedent, name2=name)
            )

        # target_crs_fn (routeur pays) attend une bbox WGS84 (lon/lat) pour en
        # déduire la zone UTM (Espagne) — le profil France l'ignore. Reprojection
        # WGS84 systématique, indépendante du CRS de travail choisi ensuite.
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        if extent_crs.isValid() and extent_crs != wgs84:
            wgs84_transform = QgsCoordinateTransform(extent_crs, wgs84, QgsProject.instance())
            wgs84_extent = wgs84_transform.transformBoundingBox(extent)
        else:
            wgs84_extent = extent
        wgs84_bbox = (
            wgs84_extent.xMinimum(), wgs84_extent.yMinimum(),
            wgs84_extent.xMaximum(), wgs84_extent.yMaximum(),
        )
        from karstpro.core.territoires.types import ConfigurationInvalide
        try:
            target_crs = territoire.capacite("crs_travail").resoudre(wgs84_bbox)
        except ConfigurationInvalide as exc:
            feedback.reportError(t("Territoire « {pays} » : {exc}", pays=pays, exc=exc), fatalError=True)
            return {}

        # Reproject extent to the working CRS (EPSG:2154 France, EPSG:258XX
        # Espagne) — QGIS returns the extent in the project CRS which may be
        # WGS84 degrees or anything else.
        target_crs_obj = QgsCoordinateReferenceSystem(target_crs)
        if extent_crs.isValid() and extent_crs.authid() != target_crs:
            transform = QgsCoordinateTransform(extent_crs, target_crs_obj, QgsProject.instance())
            extent = transform.transformBoundingBox(extent)
            feedback.pushInfo(
                t("Bbox reprojetée {v0} → {target_crs} : ({v2:.0f}, {v3:.0f}, {v4:.0f}, {v5:.0f})", v0=extent_crs.authid(), target_crs=target_crs, v2=extent.xMinimum(), v3=extent.yMinimum(), v4=extent.xMaximum(), v5=extent.yMaximum())
            )
        else:
            feedback.pushInfo(
                t("Bbox {target_crs} : ({v1:.0f}, {v2:.0f}, {v3:.0f}, {v4:.0f})", target_crs=target_crs, v1=extent.xMinimum(), v2=extent.yMinimum(), v3=extent.xMaximum(), v4=extent.yMaximum())
            )

        bbox = (
            extent.xMinimum(), extent.yMinimum(),
            extent.xMaximum(), extent.yMaximum(),
        )

        # --- Guard clause : vérification BDLISA (fail-open, non bloquant) ---
        # BDLISA (Systèmes Aquifères) est une base FRANÇAISE — aucune couverture
        # hors de France. Appelée sans garde jusqu'au 2026-08-02, elle passait la
        # bbox (en target_crs, EPSG:258XX pour l'Espagne) à une conversion codée
        # en dur pour Lambert-93 (_l93_to_wgs84) : résultat WGS84 n'importe quoi,
        # et un avertissement « zone non karstique » trompeur même en pleine zone
        # karstique espagnole (ex. Picos de Europa). Repéré sur signalement
        # utilisateur (menu PAYS = Espagne).
        self._step(feedback, t("Vérification zone karstique BDLISA"), 3, log_file)
        cap_karst = territoire.capacite("contexte_karstique")
        if cap_karst.absente:
            feedback.pushInfo(cap_karst.raison)
        else:
            try:
                karstique, verifie = check_bdlisa_karst_status(bbox)
                if not verifie:
                    # Ne JAMAIS afficher « confirmée » quand rien n'a été vérifié :
                    # le fail-open renvoie True par principe (une panne externe ne
                    # doit pas bloquer une préparation), pas parce que le serveur a
                    # répondu. Constaté le 2026-07-25 : le service BDLISA est en
                    # panne TLS, donc ce cas est aujourd'hui le cas NOMINAL.
                    feedback.pushWarning(
                        t("⚠ Service BDLISA indisponible — contexte karstique NON "
                        "vérifié. (Le traitement continue normalement.)")
                    )
                elif not karstique:
                    feedback.pushWarning(
                        t("⚠ La zone sélectionnée ne semble pas intersecter une entité "
                        "karstique référencée dans BDLISA. Vérifiez que votre secteur "
                        "est bien en contexte karstique avant de continuer. "
                        "(Le traitement continue normalement.)")
                    )
                else:
                    feedback.pushInfo(t("✓ Zone karstique BDLISA confirmée."))
            except Exception as exc:
                feedback.pushWarning(
                    t("⚠ Contexte karstique NON vérifié (BDLISA : {exc}).", exc=exc))

        work_dir = output_dir / "lidar_work"
        work_dir.mkdir(parents=True, exist_ok=True)

        mnt_path = work_dir / "mnt.tif"
        laz_dir = work_dir / "laz"

        # --- Step 1 & 2 : LIDAR download + MNT generation ---
        # Court-circuit : si des MNT pré-téléchargés sont fournis (TIF IGN),
        # on les mosaïque directement dans work_dir/mnt.tif sans passer par les LAZ.
        self._step(feedback, t("Étape 1-2 — LiDAR / MNT"), 5, log_file)
        # Le nuage de points brut n'existe qu'en mode auto (téléchargement
        # LiDAR HD) : en mode MNT manuel, seules les dalles rasterisées sont
        # fournies. La détection ponctuelle de puits (étape 3) s'appuie sur
        # ce nuage brut et devient best-effort (skip) si vide.
        laz_files: list = []

        # --- Garde de cohérence du cache lidar_work/ -----------------------
        # work_dir est unique par dossier de sortie et le seul critère de
        # réutilisation était « le fichier existe ». Deux études dans le même
        # dossier réutilisaient donc les intermédiaires de la première : MNT,
        # dolines, gouffres et hydrologie sortaient cohérents entre eux mais
        # sur l'autre zone (incident « cotera », Cantabrie, 2026-08-05 —
        # préparation bouclée en 40 s, quatre « étape ignorée » d'affilée).
        # Un skip doit prouver sa validité, pas la supposer.
        from karstpro.core.mnt_cache import (
            couvre_bbox, invalider_caches_derives, raster_bbox)
        if mnt_path.exists() and mnt_path.stat().st_size > 0 \
                and not couvre_bbox(mnt_path, bbox):
            bornes = raster_bbox(mnt_path)
            ou = (f"({bornes[0]:.0f}, {bornes[1]:.0f}, {bornes[2]:.0f}, "
                  f"{bornes[3]:.0f})") if bornes else "illisible"
            feedback.pushWarning(
                t("⚠ Cache lidar_work/ périmé : le MNT présent ne couvre pas l'emprise demandée.\n    MNT en cache : {ou}\n    Emprise demandée : ({v1:.0f}, {v2:.0f}, {v3:.0f}, {v4:.0f})\n    Ce dossier de sortie a déjà servi à une autre zone. Recalcul complet — prévoir le temps de téléchargement.", ou=ou, v1=bbox[0], v2=bbox[1], v3=bbox[2], v4=bbox[3])
            )
            supprimes = invalider_caches_derives(work_dir)
            if supprimes:
                feedback.pushInfo(
                    t("  Intermédiaires invalidés : {v0}", v0=', '.join(supprimes)))
            try:
                mnt_path.unlink()
            except OSError:
                feedback.pushWarning(
                    t("  Impossible de supprimer {mnt_path_name} (fichier verrouillé ?) — fermez la couche dans QGIS et relancez.", mnt_path_name=mnt_path.name))

        if mnt_layers:
            mnt_src_paths = [Path(lyr.source()) for lyr in mnt_layers]
            feedback.pushInfo(
                t("Mode MNT manuel : {n} dalle(s) IGN fournies — étapes téléchargement LAZ et PDAL ignorées.", n=len(mnt_src_paths))
            )
            feedback.setProgress(20)
            if not mnt_path.exists() or mnt_path.stat().st_size == 0:
                if len(mnt_src_paths) == 1:
                    shutil.copy2(mnt_src_paths[0], mnt_path)
                    feedback.pushInfo(t("  MNT copié : {v0}", v0=mnt_src_paths[0].name))
                else:
                    import rasterio
                    from rasterio.merge import merge as rio_merge
                    datasets = [rasterio.open(p) for p in mnt_src_paths]
                    mosaic, out_transform = rio_merge(datasets)
                    out_meta = datasets[0].meta.copy()
                    out_meta.update({
                        "driver": "GTiff",
                        "height": mosaic.shape[1],
                        "width": mosaic.shape[2],
                        "transform": out_transform,
                        "compress": "lzw",
                    })
                    with rasterio.open(mnt_path, "w", **out_meta) as dest:
                        dest.write(mosaic)
                    for ds in datasets:
                        ds.close()
                    feedback.pushInfo(
                        t("  Mosaïque de {n} dalles → {mnt_path_name}", n=len(mnt_src_paths), mnt_path_name=mnt_path.name)
                    )
            else:
                feedback.pushInfo(
                    t("MNT déjà présent et couvrant l'emprise — étape ignorée."))
        else:
            if mnt_path.exists() and mnt_path.stat().st_size > 0:
                feedback.pushInfo(
                    t("MNT déjà présent et couvrant l'emprise — étape ignorée."))
                if laz_dir.exists():
                    vus = {}
                    for p in list(laz_dir.glob("*.laz")) + list(laz_dir.glob("*.LAZ")):
                        vus[p.name.lower()] = p
                    laz_files = sorted(vus.values())
                    if laz_files:
                        feedback.pushInfo(
                            t("  {n} fichier(s) .laz retrouvé(s) sur disque — disponibles pour la détection ponctuelle de puits.", n=len(laz_files)))
            else:
                feedback.pushInfo(t("Recherche du MNT (source du territoire)..."))
                resultat = territoire.capacite("mnt").executer(ContexteEtude(
                    bbox=bbox, crs=target_crs, work_dir=work_dir, feedback=feedback))
                if not resultat:
                    feedback.reportError(
                        t("Aucune source de MNT disponible pour cette zone, et "
                        "aucun MNT_FILES fourni — impossible de continuer."),
                        fatalError=True)
                    return {}
                laz_files = resultat.get("laz") or []
                produit = resultat["mnt"]
                if produit != mnt_path:
                    shutil.copy2(produit, mnt_path)
            feedback.setProgress(20)

        # Contrôle final : le MNT effectivement en place couvre-t-il l'emprise ?
        # Attrape aussi le cas « mauvaises dalles fournies » en mode MNT manuel,
        # que la garde de cache ci-dessus ne voit pas. Non bloquant : le MNT est
        # peut-être volontairement rogné, mais l'utilisateur doit le savoir
        # plutôt que de découvrir des dolines tronquées au bord.
        if mnt_path.exists() and not couvre_bbox(mnt_path, bbox):
            feedback.pushWarning(
                t("⚠ Le MNT ne couvre pas toute l'emprise demandée — les "
                "résultats seront tronqués sur les bords manquants.")
            )

        # --- Step 3 : Dolines (skipped if intermediate file exists) ---
        self._step(feedback, t("Étape 3 — Détection des dolines et gouffres"), 35, log_file)
        mnt_filled = work_dir / "mnt_filled.tif"
        if mnt_filled.exists() and mnt_filled.stat().st_size > 0:
            dolines_path = work_dir / "dolines.gpkg"
            if dolines_path.exists():
                feedback.pushInfo(t("Dolines déjà calculées — étape ignorée."))
                # PAS `gpd.read_file` : la construction du CRS passe par
                # pyproj, dont `proj_create` n'est pas thread-safe — le
                # 2ᵉ lancement dans le même processus QGIS **segfault**.
                # Reproduit le 2026-08-19 par `run_pipeline_pays.py`, qui
                # relance la préparation une seconde fois exprès. Le CRS est
                # réimposé juste après : il est connu, c'est celui de l'étude.
                dolines = read_gpkg_layer(dolines_path, dolines_path.stem)
                # `read_gpkg_layer` rend `crs=None` par construction. Le
                # laisser ainsi ferait diverger la 2ᵉ préparation de la 1ʳᵉ
                # (jointures et distances sans contrôle de repère) : on repose
                # le CRS depuis l'OBJET préchargé, seul moyen de le faire sans
                # `proj_create` dans le thread de travail.
                dolines = dolines.set_crs(crs_pour(target_crs),
                                          allow_override=True)
            else:
                # Le message ne doit PAS dire « étape ignorée » ici : la
                # détection re-tourne pour de vrai, et c'est exactement le cas
                # où les identifiants de dolines peuvent bouger. Le journal est
                # le seul endroit où l'utilisateur peut le constater.
                feedback.pushInfo(t(
                    "MNT rempli en cache mais dolines absentes — "
                    "re-détection des dolines."))
                dolines = detect_dolines(mnt_path, work_dir)
                if not dolines.empty:
                    dolines.to_file(dolines_path, driver="GPKG")
        else:
            feedback.pushInfo(t("Détection des dolines..."))
            dolines = detect_dolines(mnt_path, work_dir)
            # Cache dolines to disk for potential restart
            if not dolines.empty:
                dolines.to_file(work_dir / "dolines.gpkg", driver="GPKG")

        # Gouffres / puits verticaux : les dolines sont des cuvettes ; un puits
        # ouvert ne renvoie pas de point sol (LiDAR) → trou de NODATA, invisible
        # à la détection de cuvettes. On le rattrape par sa signature de vide.
        gouffres_path = work_dir / "gouffres.gpkg"
        if gouffres_path.exists():
            gouffres = read_gpkg_layer(gouffres_path, gouffres_path.stem)
            feedback.pushInfo(t("Gouffres déjà calculés ({n}) — étape ignorée.", n=len(gouffres)))
        else:
            from karstpro.core.shafts import detect_shafts, flag_anthropic, flag_vegetation
            feedback.pushInfo(t("Détection des gouffres / puits (vides LiDAR)..."))
            gouffres = detect_shafts(mnt_path, feedback=feedback)
            # `detect_shafts` rend une couche SANS CRS : le poser depuis un
            # objet préchargé évite `proj_create` dans le thread de travail.
            gouffres = gouffres.set_crs(crs_pour(target_crs), allow_override=True)
            if not gouffres.empty:
                cap_obst = territoire.capacite("obstacles_gouffres")
                if cap_obst.absente:
                    feedback.pushWarning(cap_obst.raison)
                    gouffres.to_file(gouffres_path, driver="GPKG")
                else:
                    # Emprise des GOUFFRES et non de l'étude : le MNT couvre des
                    # dalles entières, les candidats débordent donc la bbox
                    # demandée. Marge de 100 m, identique des deux côtés.
                    bx0, by0, bx1, by1 = gouffres.total_bounds
                    ctx_gouffres = ContexteEtude(
                        bbox=(bx0 - 100, by0 - 100, bx1 + 100, by1 + 100),
                        crs=target_crs, work_dir=work_dir, feedback=feedback)

                    # Un vide de NODATA sur un bâtiment (toit) ou un plan d'eau
                    # (réflexion) n'est pas un gouffre — on l'écarte
                    # (quasi-certain, contrairement à la végétation ci-dessous).
                    obstacles = cap_obst.executer(ctx_gouffres)
                    gouffres = flag_anthropic(gouffres, obstacles)
                    n_flag = int((gouffres["flag"] != "").sum())
                    gouffres = gouffres[gouffres["flag"] == ""].drop(columns=["flag"]).copy()
                    feedback.pushInfo(
                        t("Gouffres : {n_flag} candidat(s) écarté(s) (bâti/eau), {n} retenu(s) — à vérifier sur le terrain.", n_flag=n_flag, n=len(gouffres)))
                    if not gouffres.empty:
                        # Canopée dense = même signature de vide qu'un puits (bord
                        # de sol valide compact) — filtre PROBABILISTE (pas
                        # bâti/eau) : le candidat est marqué `veg_dense` et écarté
                        # du GeoPackage livré, mais CONSERVÉ ici dans
                        # `lidar_work/gouffres.gpkg` (écrit juste après), donc
                        # récupérable sans relancer la détection.
                        cap_veg = territoire.capacite("vegetation_gouffres")
                        if cap_veg.absente:
                            feedback.pushWarning(cap_veg.raison)
                        else:
                            vegetation = cap_veg.executer(ctx_gouffres)
                            gouffres = flag_vegetation(gouffres, vegetation)
                            n_veg = int((gouffres["interet"] == 0).sum())
                            if n_veg:
                                feedback.pushInfo(
                                    t("Gouffres : {n_veg} candidat(s) en zone de végétation dense (trouées de canopée) — écarté(s) du projet, conservé(s) dans lidar_work/gouffres.gpkg.", n_veg=n_veg))
                    if not gouffres.empty:
                        gouffres.to_file(gouffres_path, driver="GPKG")

        # Détection ponctuelle de puits (best-effort, Phase 1 informatif) —
        # cf. docs/superpowers/specs/2026-07-24-detection-ponctuelle-puits-design.md.
        # Nécessite le nuage de points brut (absent en mode MNT manuel) et
        # un seuil > 0 ; un échec ici n'empêche jamais le reste de la
        # préparation (colonnes pc_* laissées absentes).
        if seuil_surface_pc > 0 and laz_files and not dolines.empty:
            try:
                from karstpro.core.lidar import generate_pc_rasters
                from karstpro.core.pc_anomaly import sample_dolines
                import rasterio

                pc_tif = work_dir / "pc_rasters.tif"
                feedback.pushInfo(t("Détection ponctuelle de puits (nuage brut)..."))
                generate_pc_rasters(laz_files, mnt_path, pc_tif)
                # generate_pc_rasters cale sa grille pixel pour pixel sur le
                # MNT (origin_x/origin_y/width/height PDAL) : simple lecture
                # directe, pas de fenêtre/rééchantillonnage (un déphasage
                # même sous-pixel entre deux rasters générés séparément
                # produirait des "plongées" de plusieurs dizaines de mètres
                # sans rapport avec un vrai puits — bug réel trouvé en
                # vérifiant sur données réelles avant de livrer cette
                # fonctionnalité).
                with rasterio.open(pc_tif) as pc_src, rasterio.open(mnt_path) as mnt_src:
                    pc_min = pc_src.read(1)
                    pc_count = pc_src.read(2)
                    mnt_arr = mnt_src.read(1)
                    transform = pc_src.transform
                dolines = sample_dolines(
                    dolines, pc_min, pc_count, mnt_arr, transform,
                    surface_threshold_m2=seuil_surface_pc,
                )
                n_signal = int(dolines["pc_plongee_m"].notna().sum())
                n_sous_seuil = int((dolines["surface_m2"] < seuil_surface_pc).sum())
                feedback.pushInfo(
                    t("  {n_sous_seuil} doline(s) sous le seuil de surface ({seuil_surface_pc:.0f} m²), {n_signal} avec un signal ponctuel.", n_sous_seuil=n_sous_seuil, seuil_surface_pc=seuil_surface_pc, n_signal=n_signal)
                )
            except Exception as e:
                feedback.pushWarning(t("Détection ponctuelle de puits ignorée : {e}", e=e))
        elif seuil_surface_pc > 0 and not laz_files:
            feedback.pushInfo(
                t("Détection ponctuelle de puits ignorée : nuage de points "
                "brut indisponible (mode MNT manuel).")
            )

        # Signal RGE ALTI (affaissement historique) — best-effort, contribue
        # au score (contrairement au signal ponctuel ci-dessus, purement
        # informatif). Cf. plan
        # docs/superpowers/plans/2026-07-28-signal-rgealti.md. Un échec ici
        # (réseau, WMS indisponible) n'empêche jamais le reste de la
        # préparation (colonnes rge_* laissées absentes) ; un secteur dont
        # le RGE ALTI local n'est pas d'origine LiDAR (corrélation
        # photogrammétrique) est marqué non éligible plutôt que d'injecter
        # du bruit dans le score.
        cap_rge = territoire.capacite("affaissement_historique")
        if signal_rgealti and cap_rge.absente:
            feedback.pushInfo(cap_rge.raison)
        elif signal_rgealti and not dolines.empty:
            try:
                from karstpro.core.rgealti import (
                    fetch_rgealti_for_secteur, sample_dolines_rgealti,
                )

                rgealti_tif = work_dir / "rgealti.tif"
                feedback.pushInfo(t("Signal RGE ALTI (affaissement historique)..."))
                fetch_rgealti_for_secteur(mnt_path, rgealti_tif, feedback=feedback)
                dolines = sample_dolines_rgealti(dolines, mnt_path, rgealti_tif)
                if not bool(dolines["rge_eligible"].iloc[0]):
                    feedback.pushWarning(
                        t("RGE ALTI non exploitable pour ce secteur — hors "
                        "couverture LiDAR historique ou données trop "
                        "imprécises (corrélation photogrammétrique). "
                        "Signal désactivé pour cette préparation.")
                    )
                else:
                    n_rge = int(dolines["rge_contrast_m"].notna().sum())
                    feedback.pushInfo(
                        t("  {n_rge} doline(s) avec un contraste RGE ALTI calculable.", n_rge=n_rge)
                    )
            except Exception as e:
                feedback.pushWarning(t("Signal RGE ALTI ignoré : {e}", e=e))

        # Points d'eau karstiques référencés (BD Topo) : sources, pertes,
        # exutoires. Ce N'EST PAS de la détection — on localise des features
        # déjà connues. Indispensable pour les gouffres noyés (inversac) :
        # invisibles au MNT (le LiDAR réfléchit sur l'eau, pas de vide), mais
        # présents en base comme nœud hydrographique Source/Perte.
        points_eau_path = work_dir / "points_eau.gpkg"
        if points_eau_path.exists():
            points_eau = read_gpkg_layer(points_eau_path, points_eau_path.stem)
            feedback.pushInfo(
                t("Points d'eau déjà récupérés ({n}) — étape ignorée.", n=len(points_eau)))
        else:
            # 4e appel BD Topo du pipeline — le seul que la refonte territoires
            # avait manqué : le balayage recensait les MARQUEURS (« bdtopo »)
            # sans compter les SITES D'APPEL. Il tournait donc sans garde ET
            # sans target_crs pour l'Espagne, exactement comme BDLISA,
            # Géorisques et BD Topo avant leur correction du 2026-08-02.
            cap_eau = territoire.capacite("points_eau_karstiques")
            if cap_eau.absente:
                feedback.pushInfo(cap_eau.raison)
                points_eau = gpd.GeoDataFrame(
                    columns=["geometry"], geometry="geometry", crs=crs_pour(target_crs))
            else:
                points_eau = cap_eau.executer(ContexteEtude(
                    bbox=bbox, crs=target_crs, work_dir=work_dir,
                    feedback=feedback))
                if points_eau is not None and not points_eau.empty:
                    points_eau.to_file(points_eau_path, driver="GPKG")

        # --- Step 4 : Hydrology (skipped if intermediate files exist) ---
        self._step(feedback, t("Étape 4 — Hydrologie"), 50, log_file)
        streams_path = work_dir / "streams.tif"
        if streams_path.exists() and streams_path.stat().st_size > 0:
            feedback.pushInfo(t("Hydrologie déjà calculée — étape ignorée."))
            reseau_path = work_dir / "reseau.gpkg"
            absorb_path = work_dir / "absorptions.gpkg"
            if reseau_path.exists() and absorb_path.exists():
                reseau = read_gpkg_layer(reseau_path, reseau_path.stem)
                absorptions = read_gpkg_layer(absorb_path, absorb_path.stem)
            else:
                reseau, absorptions = compute_hydrology(mnt_path, work_dir, feedback=feedback)
        else:
            feedback.pushInfo(t("Calcul de l'hydrologie..."))
            reseau, absorptions = compute_hydrology(mnt_path, work_dir, feedback=feedback)
            # Cache to disk
            if not reseau.empty:
                reseau.to_file(work_dir / "reseau.gpkg", driver="GPKG")
            if not absorptions.empty:
                absorptions.to_file(work_dir / "absorptions.gpkg", driver="GPKG")

        # --- Step 4b : Bassin versant amont (flow accumulation D8) -------------
        flow_acc_path = work_dir / "flow_acc.tif"
        if not dolines.empty and flow_acc_path.exists():
            feedback.pushInfo(t("Calcul des bassins versants amont (flow accumulation)..."))
            try:
                dolines = compute_bassin_versant(dolines, flow_acc_path)
                n_pertes       = (dolines["type_doline"] == "perte").sum()
                n_doline_perte = (dolines["type_doline"] == "doline-perte").sum()
                feedback.pushInfo(
                    t("  Types détectés : {n_pertes} perte(s), {n_doline_perte} doline-perte(s), {v2} doline(s) simples.", n_pertes=n_pertes, n_doline_perte=n_doline_perte, v2=len(dolines) - n_pertes - n_doline_perte)
                )
                self._log(feedback,
                          t("Bassins versants : {n_pertes} perte(s), "
                            "{n_dp} doline(s)-perte(s)",
                            n_pertes=n_pertes, n_dp=n_doline_perte),
                          log_file=log_file)
            except Exception as exc:
                feedback.pushWarning(t("Bassin versant ignoré : {exc}", exc=exc))
                dolines["bassin_versant_m2"] = float("nan")
                dolines["type_doline"] = "doline"
        elif not dolines.empty:
            feedback.pushWarning(
                t("flow_acc.tif absent — bassin versant non calculé. "
                "Relancer la préparation complète pour obtenir la classification perte/doline-perte.")
            )
            dolines["bassin_versant_m2"] = float("nan")
            dolines["type_doline"] = "doline"

        # --- Step 4c : Pente bord + TPI (MNT 1 m) --------------------------
        if not dolines.empty:
            feedback.setProgress(57)
            feedback.pushInfo(t("Calcul de la pente maximale des bords de dolines..."))
            try:
                from karstpro.core.cold_air import compute_slope_max_bord
                dolines = compute_slope_max_bord(dolines, mnt_path, feedback=feedback)
            except Exception as exc:
                feedback.pushWarning(t("Pente bord ignorée : {exc}", exc=exc))
                dolines["pente_max_bord"] = float("nan")

            feedback.setProgress(59)
            feedback.pushInfo(t("Calcul du TPI (position topographique, MNT 1 m)..."))
            try:
                from karstpro.core.cold_air import compute_tpi_500m
                dolines = compute_tpi_500m(dolines, mnt_path, feedback=feedback)
            except Exception as exc:
                feedback.pushWarning(t("TPI ignoré : {exc}", exc=exc))
                dolines["tpi_500m"] = float("nan")

        self._step(feedback, t("Étape 5 — Géologie"), 60, log_file)
        if geo_local_file:
            # Fichier géologie fourni manuellement — priorité absolue
            feedback.pushInfo(
                t("Import géologie locale BD Charm-50 1/50 000 : {geo_local_file}", geo_local_file=geo_local_file)
            )
            geology = load_local_geology(geo_local_file, bbox)
            if geology.empty:
                feedback.pushWarning(
                    t("Géologie locale vide dans la bbox — fallback WFS BRGM 1/1 000 000.")
                )
                geology = fetch_brgm_geology(bbox)
            else:
                from karstpro.core.geology import filter_karstifiable
                n_karst = len(filter_karstifiable(geology))
                feedback.pushInfo(
                    t("Geologie locale : {n} formation(s) dans la bbox ({n_karst} karstifiable(s) pour le score ; couche complète conservée pour l'interprétation).", n=len(geology), n_karst=n_karst)
                )
        else:
            # Pas de message générique ici : chaque source annonce ce qu'elle
            # fait dans son propre fournisseur (adaptateur BRGM ou type arcgis
            # IGME), ce qui préserve les messages d'origine au caractère près.
            cap_geo = territoire.capacite("geologie")
            try:
                geology = cap_geo.executer(ContexteEtude(
                    bbox=bbox, crs=target_crs, work_dir=work_dir,
                    feedback=feedback))
            except Exception as exc:                           # noqa: BLE001
                # La dégradation était PRÉVUE (message ci-dessous) mais ne
                # rattrapait que `None`/vide, jamais une exception. Un service
                # tiers en panne tuait donc une préparation de dix-sept
                # minutes : constaté le 2026-08-22, le service géologie wallon
                # refusant toutes ses requêtes (HTTP 400) alors que ses
                # métadonnées répondaient normalement. La géologie pèse sur le
                # score, elle ne conditionne pas la détection.
                feedback.pushWarning(t(
                    "Géologie : le service a échoué ({exc}) — la préparation "
                    "continue avec un scoring géologique dégradé.", exc=exc))
                geology = None
            if geology is None or geology.empty:
                feedback.pushWarning(
                    t("Géologie indisponible ou vide sur cette zone "
                    "(service en panne, hors couverture, ou zone sans "
                    "formation cartographiée) — scoring géologique dégradé.")
                )

        # Géorisques (BRGM) est une base FRANÇAISE. Appelée sans garde pays ET
        # sans target_crs avant le 2026-08-02 : la bbox espagnole (EPSG:258XX)
        # partait étiquetée Lambert-93 vers un service français — au mieux vide,
        # au pire des cavités aberrantes. Même famille que BDLISA / BD Topo.
        cavites_georisques = None
        cap_cav = territoire.capacite("cavites_connues")
        if cap_cav.absente:
            feedback.pushInfo(cap_cav.raison)
        else:
            feedback.pushInfo(t("Import cavités Géorisques BRGM..."))
            try:
                cavites_georisques = fetch_georisques_cavites(
                    bbox, target_crs=target_crs)
                if cavites_georisques.empty:
                    feedback.pushInfo(
                        t("Géorisques : aucune cavité référencée dans la zone "
                        "(normal dans les karsts sous couverture peu inventoriés).")
                    )
                else:
                    feedback.pushInfo(
                        t("Géorisques : {n} cavité(s) trouvée(s).", n=len(cavites_georisques))
                    )
            except Exception as exc:
                feedback.pushWarning(t("Géorisques ignoré : {exc}", exc=exc))
                cavites_georisques = None

        # Couches de contexte propres au territoire : l'Atlas du Karst Wallon
        # côté wallon, rien côté France/Espagne. Le pipeline ne sait pas ce
        # qu'elles contiennent — il les transporte jusqu'au projet. Elles ne
        # nourrissent AUCUN calcul de score (cf. la conception du 2026-08-10).
        couches_contexte = []
        cap_ctx = territoire.capacite("couches_contexte")
        if cap_ctx.absente:
            feedback.pushInfo(cap_ctx.raison)
        else:
            for couche in (cap_ctx.executer(ContexteEtude(
                    bbox=bbox, crs=target_crs, work_dir=work_dir,
                    feedback=feedback)) or []):
                donnees = couche.get("donnees")
                if donnees is None or donnees.empty:
                    feedback.pushInfo(t(
                        "  « {titre} » : aucun objet sur l'emprise.",
                        titre=couche.get("titre", "")))
                    continue
                feedback.pushInfo(t("  « {titre} » : {n} objet(s).",
                                    titre=couche["titre"], n=len(donnees)))
                couches_contexte.append(couche)

        topo = None
        if topo_file:
            feedback.pushInfo(t("Import topo réseau : {topo_file}", topo_file=topo_file))
            topo = load_topo(Path(topo_file))
            if topo.passages.empty:
                feedback.pushInfo(t("⚠ Topo chargée mais passages vides — vérifiez le format du fichier (LineString attendu)."))
            else:
                feedback.pushInfo(
                    t("Topo OK : {n} segment(s), CRS={v1}", n=len(topo.passages), v1=topo.passages.crs.to_epsg())
                )
                if not dolines.empty:
                    sample_centroid = dolines.geometry.iloc[0].centroid
                    min_dist = topo.passages.geometry.distance(sample_centroid).min()
                    feedback.pushInfo(t("Distance doline[0] → réseau : {min_dist:.0f} m", min_dist=min_dist))
        else:
            feedback.pushInfo(t("Pas de topo fournie — score positionnel désactivé."))

        self._step(feedback, t("Étape 6 — Scoring"), 70, log_file)
        config = load_config(Path(config_file)) if config_file else None
        # 0 = automatique (routeur, modèles auto) ; 1 = poids manuels forcés ;
        # >=2 = modèle OPT-IN forcé par l'utilisateur.
        prio_mode = self.parameterAsEnum(parameters, self.USE_LEARNED_MODEL, context)
        model = None
        modele_dispo = not territoire.capacite("modele_appris").absente
        if prio_mode == 0 and modele_dispo:
            try:
                from karstpro.core.model_score import select_model
                # Routeur : sélectionne le modèle AUTO adapté à la zone
                # (lithologie NOTATION en priorité, géo en repli). Aucun match
                # → model=None → poids manuels exploratoires (jamais appliqué
                # hors domaine validé en silence). Suggère un opt-in compatible.
                model, why = select_model(dolines, geology)
                if model is not None:
                    self._log(feedback,
                              t("Modèle appris — {pourquoi}", pourquoi=why),
                              log_file)
                    self._log(feedback,
                              t("⚠️ Modèle validé sur son domaine uniquement ; "
                                "reste exploratoire au sommet du classement "
                                "(cf. précision@P1)."), log_file, warn=True)
                else:
                    self._log(feedback, why, log_file, warn=True)
            except Exception as exc:
                self._log(feedback, f"Routeur de modèles indisponible ({exc}) — "
                          "repli sur les poids manuels.", log_file, warn=True)
                model = None
        elif prio_mode == 0:
            self._log(feedback,
                      t("Pays hors domaine à modèle appris — scoring "
                        "exploratoire (barème manuel)."),
                      log_file, warn=True)
            model = None
        elif prio_mode >= 2:
            # Modèle OPT-IN explicitement forcé. L'index suit la liste construite
            # à l'initialisation (déterministe : list_models trié par model_id).
            try:
                from karstpro.core.model_score import list_models, incision_note
                optin = sorted(
                    (m for m in list_models() if not m.get("auto_select", True)),
                    key=lambda m: m.get("model_id", ""))
                idx = prio_mode - 2
                if 0 <= idx < len(optin):
                    model = optin[idx]
                    self._log(feedback, "Modèle OPT-IN forcé par l'utilisateur : "
                              f"« {model.get('model_id', '?')} » "
                              f"({model.get('domain_name', '')}).", log_file)
                    self._log(feedback, "⚠️ Modèle OPT-IN : applicabilité NON "
                              "garantie par les données — vous l'activez sur votre "
                              "jugement géologique. Il échoue hors de son régime "
                              "(reculée, urbain) même si la lithologie correspond."
                              + incision_note(dolines, model),
                              log_file, warn=True)
                else:
                    self._log(feedback, "Index de modèle opt-in invalide — repli "
                              "poids manuels.", log_file, warn=True)
            except Exception as exc:
                self._log(feedback, f"Modèle opt-in indisponible ({exc}) — repli "
                          "poids manuels.", log_file, warn=True)
                model = None
        # prio_mode == 1 → model reste None (poids manuels exploratoires).
        scored_dolines = compute_scores(
            dolines, geology, topo=topo, config=config, model=model
        )

        # --- Step 6b : Cavités connues — flag proximité (informatif, hors score) ---
        # Sources fusionnées pour le calcul : couche utilisateur + Géorisques BRGM.
        # Les deux sont normalisées sur le schéma (name, type, reference) avant fusion.
        cavites_connues_gdf = None
        if cavites_connues_layer_name is not None:
            feedback.pushInfo(t("Chargement des cavités connues (proximité)..."))
            try:
                cavites_connues_gdf = gpd.read_file(
                    cavites_connues_gpkg, layer=cavites_connues_layer_name)
                # Aligner sur le CRS de travail (et non EPSG:2154 en dur —
                # cf. correctif 2026-08-02) : l'inventaire peut être en WGS84.
                if cavites_connues_gdf.crs is None:
                    cavites_connues_gdf = cavites_connues_gdf.set_crs(crs_pour(target_crs))
                elif cavites_connues_gdf.crs != crs_pour(target_crs):
                    cavites_connues_gdf = cavites_connues_gdf.to_crs(crs_pour(target_crs))
                feedback.pushInfo(t("  {n} cavité(s) connue(s) chargée(s).", n=len(cavites_connues_gdf)))
            except Exception as exc:
                feedback.pushWarning(t("Cavités connues ignorées : {exc}", exc=exc))

        # Traçages : NON copiés. Référencés en lecture seule (cf. external_layers).
        # Plus de chargement gdf ici — le MLL les lira depuis le gpkg traçages.

        # Normaliser et fusionner les cavités Géorisques avec les cavités utilisateur
        cavites_pour_proximite = _merge_cavites_sources(
            cavites_connues_gdf, cavites_georisques, target_crs=target_crs)

        if not cavites_pour_proximite.empty:
            scored_dolines = compute_cavites_connues_proximity(
                scored_dolines, cavites_pour_proximite, radius_m=20.0
            )
            n_proches = scored_dolines["cavite_connue_proche"].sum()
            feedback.pushInfo(
                t("  {n_proches} doline(s) à moins de 20 m d'une cavité connue — marquées cavite_connue_proche=True (sources : utilisateur + Géorisques BRGM).", n_proches=n_proches)
            )
        else:
            # Colonnes vides pour cohérence du schéma GPKG
            scored_dolines = compute_cavites_connues_proximity(scored_dolines, None)

        # --- Step 6c : Filtre anthropique (P2) — déclasse les fausses dolines ---
        # Carrières / zones d'activité / bâti BD Topo = vraies dépressions mais
        # non karstiques. Déclassement en gris (étiqueté), jamais suppression.
        cap_anthro = territoire.capacite("anthropique_dolines")
        veut_filtre = self.parameterAsBool(parameters, self.FILTER_ANTHROPIC, context)
        if veut_filtre and cap_anthro.absente:
            feedback.pushWarning(cap_anthro.raison)
            scored_dolines["flag_anthropique"] = ""
            scored_dolines["anthropique_distance_m"] = float("nan")
        elif veut_filtre:
            from karstpro.core.geology import fetch_bdtopo_anthropic
            from karstpro.core.scoring import flag_anthropic_dolines
            feedback.pushInfo(t("Filtre anthropique (BD Topo, carrières uniquement)..."))
            try:
                anthropic = fetch_bdtopo_anthropic(bbox, feedback=feedback)
                before = (scored_dolines["priorite"] != "gris").sum() \
                    if "priorite" in scored_dolines.columns else 0
                scored_dolines = flag_anthropic_dolines(scored_dolines, anthropic)
                n_flag = int((scored_dolines["flag_anthropique"] != "").sum())
                after = (scored_dolines["priorite"] != "gris").sum() \
                    if "priorite" in scored_dolines.columns else 0
                feedback.pushInfo(
                    t("  {n_flag} doline(s) sur emprise anthropique → déclassées en gris ({v1} retirée(s) des cibles P1/P2/P3). Colonne flag_anthropique conservée — réhabilitable à la main.", n_flag=n_flag, v1=before - after))
            except Exception as exc:
                feedback.pushWarning(t("Filtre anthropique ignoré : {exc}", exc=exc))
        else:
            # Colonnes vides pour cohérence du schéma GPKG quand le filtre est off.
            scored_dolines["flag_anthropique"] = ""
            scored_dolines["anthropique_distance_m"] = float("nan")

        self._step(feedback, t("Étape 7 — Packaging QField / GPKG"), 85, log_file)
        cav_empty = gpd.GeoDataFrame(
            columns=list(CAVITES_SCHEMA.keys()) + ["geometry"], crs=crs_pour(target_crs)
        )
        # Index contigu 0..N-1 — ordre d'écriture seulement. L'identité ne
        # repose PLUS sur le fid : elle est portée par la colonne doline_id,
        # attribuée juste après par appariement au registre.
        scored_dolines = scored_dolines.reset_index(drop=True)

        # ── Identifiants stables entre préparations ───────────────────────
        # Le fid GPKG est un rang d'écriture : dès qu'une doline apparaît,
        # disparaît, fusionne ou se scinde, toutes les suivantes se décalent et
        # `doline_1247` d'un rapport MLL ou d'une note de terrain devient faux.
        #
        # Le registre `doline_ids` vit dans le gpkg — et non dans lidar_work/,
        # dont la suppression est précisément ce qui force une re-détection.
        # Lu AVANT que package_qfield_project n'écrase le gpkg, comme le report
        # des cibles visitées. Indépendant de KEEP_VISITED : l'identité des
        # dolines n'est pas la même question que la conservation de la to-do.
        from datetime import date as _date
        from karstpro.core.doline_identity import (
            charger_registre, amorcer_registre, apparier, ecrire_registre)
        _jour = _date.today().isoformat()
        _gpkg_precedent = output_dir / f"{name}.gpkg"
        _registre = []
        if _gpkg_precedent.exists():
            try:
                # Amorçage : un gpkg d'avant la migration n'a pas de registre.
                # On le seed sur ses fid, sinon les rapports déjà imprimés se
                # décaleraient une dernière fois — on provoquerait le problème
                # en le corrigeant.
                n_amorce = amorcer_registre(_gpkg_precedent, _jour)
                if n_amorce:
                    feedback.pushInfo(t(
                        "  Identifiants : registre amorcé sur {n} doline(s) de "
                        "l'étude précédente.", n=n_amorce))
                _registre = charger_registre(_gpkg_precedent)
            except Exception as exc:
                feedback.pushWarning(t(
                    "Registre d'identité illisible ({exc}) — les dolines "
                    "reçoivent de nouveaux identifiants.", exc=exc))
                _registre = []
        _avait_registre = bool(_registre)
        _ids, _registre, _stats = apparier(scored_dolines, _registre, _jour)
        scored_dolines["doline_id"] = _ids
        if _avait_registre:
            feedback.pushInfo(t(
                "  Identifiants : {app} conservé(s), {neuves} nouveau(x), "
                "{reap} réapparu(s), {ret} retiré(s).",
                app=_stats["apparies"], neuves=_stats["neuves"],
                reap=_stats["reapparues"], ret=_stats["retirees"]))
        else:
            # Première étude de ce dossier : « 0 conservé(s) » n'aurait aucun
            # sens à afficher. Le message dit AUSSI qu'il n'y avait pas d'étude
            # antérieure ici — seul indice si l'utilisateur croyait re-préparer
            # un secteur déjà traité ailleurs (le registre vit dans le gpkg du
            # dossier de sortie, il ne suit pas la zone géographique).
            feedback.pushInfo(t(
                "  Identifiants : première étude de ce dossier — {n} doline(s) "
                "numérotée(s), identifiants conservés aux préparations "
                "suivantes.", n=_stats["neuves"]))

        # ── Courbes de niveau (optionnel) ─────────────────────────────────
        # Pas de widget dans la boîte de dialogue (cf. initAlgorithm) : lu
        # directement dans le dict brut plutôt que via parameterAsDouble, qui
        # exige un paramètre enregistré. Reste modifiable en éditant
        # karstpro_etude.json puis « Refaire une étude ». Valeur toujours
        # réinjectée dans `parameters` ci-dessous pour être écrite dans ce
        # même fichier au prochain run.
        try:
            contour_interval = float(parameters.get(
                self.CONTOUR_INTERVAL, self.DEFAULT_CONTOUR_INTERVAL_M))
        except (TypeError, ValueError):
            contour_interval = self.DEFAULT_CONTOUR_INTERVAL_M
        parameters[self.CONTOUR_INTERVAL] = contour_interval
        contours = None
        if contour_interval and contour_interval > 0 and mnt_path.exists():
            try:
                from karstpro.core.lidar import generate_contours
                contours = generate_contours(mnt_path, interval=contour_interval)
                feedback.pushInfo(
                    t("Courbes de niveau : {n} segments (équidistance {contour_interval:g} m, maîtresses tous les 10 m)", n=len(contours), contour_interval=contour_interval)
                )
            except Exception as e:
                feedback.pushWarning(t("Courbes de niveau non générées : {e}", e=e))

        # Emprise des cibles P1 (dolines rouges) pour le zoom initial du projet.
        # Calculée ici car le .qgs est écrit avant le remplissage des couches P1.
        zoom_extent = None
        try:
            if "priorite" in scored_dolines.columns:
                _p1 = scored_dolines[scored_dolines["priorite"] == "rouge"]
                if not _p1.empty:
                    zoom_extent = tuple(_p1.total_bounds)  # (minx,miny,maxx,maxy) L93
        except Exception:
            zoom_extent = None

        # Pass topo passages GeoDataFrame if available (included as layer in gpkg)
        topo_gdf = topo.passages if topo is not None and not topo.passages.empty else None
        # Couches inventaire externes référencées (NON copiées), lecture seule.
        external_layers = []
        if cavites_connues_layer_name is not None:
            external_layers.append({
                "gpkg": str(cavites_connues_gpkg),
                "layer": cavites_connues_layer_name,
                "name": "Inventaire Cavités"})
        if tracages_layer_name is not None:
            external_layers.append({
                "gpkg": str(tracages_gpkg),
                "layer": tracages_layer_name,
                "name": "Inventaire Traçages"})
        # Report des cibles déjà prospectées : capturer AVANT que
        # package_qfield_project n'écrase le gpkg du dossier (sinon les verdicts
        # terrain de la préparation précédente seraient perdus). Le gpkg cible
        # vaut output_dir/{name}.gpkg (cf. package_qfield_project).
        keep_visited = self.parameterAsBool(parameters, self.KEEP_VISITED, context)
        captured_visited = []
        if keep_visited:
            target_gpkg = output_dir / f"{name}.gpkg"
            if target_gpkg.exists():
                # ── Garde-fous : mêmes risques qu'une « Refaire une étude » ──
                # (cette prép RÉ-ÉCRIT le même gpkg si target_gpkg existe déjà).
                # Sans eux, le carryover ci-dessous piégerait des saisies ou
                # des verdicts terrain non exportés dans l'archive, sans
                # jamais les envoyer au CSV Karst Entry.
                from karstpro.core.etude import count_layer_features, count_pending_findings
                n_cav = count_layer_features(target_gpkg, "cavites")
                if n_cav > 0:
                    raise QgsProcessingException(
                        f"{n_cav} cavité(s) dans la couche « cavites » du gpkg "
                        f"existant ({target_gpkg.name}) — saisies terrain non "
                        "exportées. Repréparer écraserait le gpkg et les "
                        "perdrait. → Lance d'abord « Synchroniser le retour "
                        "terrain » (export CSV Karst Entry), puis recommence.")
                pending = count_pending_findings(target_gpkg, name, (1, 2))
                if pending:
                    detail = ", ".join(f"{p['count']} dans « {p['layer']} »"
                                       for p in pending)
                    raise QgsProcessingException(
                        f"Cibles ou gouffres à intérêt (indice/cavité) non "
                        f"exportés : {detail}. Repréparer les piégerait dans "
                        "l'archive « cibles visitées » sans jamais les envoyer "
                        "au CSV Karst Entry. → Lance d'abord « Synchroniser le "
                        "retour terrain », puis recommence.")
                try:
                    from karstpro.core.cibles_carryover import capture_visited_as_archive
                    captured_visited = capture_visited_as_archive(target_gpkg, name)
                    if captured_visited:
                        feedback.pushInfo(
                            t("Report cibles : {n} cible(s) déjà prospectée(s) capturée(s) avant ré-écriture.", n=len(captured_visited)))
                except Exception as exc:
                    feedback.pushWarning(t("Capture des cibles visitées échouée : {exc}", exc=exc))

                # Gouffres : signal physique re-détecté à l'identique à chaque
                # prép (indépendant du terrain) — sans ce report, un gouffre déjà
                # investigué (interet != -1) renaît à interet=-1 à chaque
                # régénération du gpkg. On reporte son verdict sur le gouffre
                # fraîchement re-détecté à la même position (tolérance stricte,
                # évite de fusionner deux gouffres voisins distincts).
                try:
                    from karstpro.core.cibles_carryover import (
                        capture_investigated_gouffres, apply_gouffres_carryover)
                    captured_gouffres = capture_investigated_gouffres(target_gpkg)
                    if captured_gouffres and gouffres is not None and not gouffres.empty:
                        n_carry = apply_gouffres_carryover(
                            gouffres, captured_gouffres, tol_m=3.0)
                        if n_carry:
                            feedback.pushInfo(
                                t("Report gouffres : {n_carry} gouffre(s) déjà investigué(s) — verdict conservé sur la nouvelle détection.", n_carry=n_carry))
                except Exception as exc:
                    feedback.pushWarning(t("Report des gouffres investigués échoué : {exc}", exc=exc))

        result = package_qfield_project(
            name, scored_dolines, cav_empty,
            output_dir, reseau=reseau, geology=geology, topo=topo_gdf,
            cavites_georisques=cavites_georisques,
            contours=contours,
            gouffres=gouffres,
            points_eau=points_eau,
            couches_contexte=couches_contexte,
            external_layers=external_layers,
            zoom_extent=zoom_extent,
            scan25_apikey=scan25_apikey or None,
            target_crs=target_crs,
            fonds_carte=territoire.capacite("fonds_carte"),
        )

        # Remplir les couches P1/P2/P3 immédiatement depuis les dolines scorées
        try:
            n_p1, n_p2, n_p3 = write_cibles_from_scored_dolines(
                result["gpkg"], name, scored_dolines, target_crs=target_crs
            )
            feedback.pushInfo(
                t("Cibles terrain : {n_p1} rouges (P1) + {n_p2} oranges (P2) + {n_p3} jaunes (P3)", n_p1=n_p1, n_p2=n_p2, n_p3=n_p3)
            )
        except Exception as exc:
            feedback.pushWarning(t("Écriture cibles P1/P2/P3 échouée : {exc}", exc=exc))

        # Registre d'identité — écrit dans le gpkg fraîchement créé. Doit
        # précéder suppress_already_visited, qui apparie désormais les cibles
        # par doline_id. Non bloquant : une préparation reste utilisable sans
        # registre, elle perd seulement la stabilité au prochain passage.
        try:
            ecrire_registre(result["gpkg"], _registre)
        except Exception as exc:
            feedback.pushWarning(t(
                "Registre d'identité non écrit ({exc}) — les identifiants ne "
                "seront pas stables à la prochaine préparation.", exc=exc))

        # Réinjecter les cibles déjà prospectées dans la nouvelle archive, puis
        # retirer de la to-do (P1/P2/P3) les cibles tombant au même endroit
        # (≤ 5 m) — déjà faites. Non bloquant.
        if keep_visited and captured_visited:
            try:
                from karstpro.core.cibles_carryover import (
                    restore_archive_rows, suppress_already_visited)
                n_rest = restore_archive_rows(result["gpkg"], name, captured_visited)
                n_sup = suppress_already_visited(result["gpkg"], name, tol_m=5.0)
                feedback.pushInfo(
                    t("Cibles visitées : {n_rest} conservée(s) dans l'archive, {n_sup} nouvelle(s) cible(s) retirée(s) de la to-do (déjà prospectées).", n_rest=n_rest, n_sup=n_sup))
            except Exception as exc:
                feedback.pushWarning(t("Report des cibles visitées échoué : {exc}", exc=exc))

        # Cibles déjà DANS L'INVENTAIRE fourni → retirées de la to-do (rayon serré
        # 3 m). Indépendant du carryover d'archive : l'inventaire est un paramètre
        # fiable (fourni à la prép), donc cohérent même si on re-prépare un autre
        # gpkg que celui synchronisé. Flag de proximité = 20 m (informatif) ;
        # suppression = 3 m (conservateur, ne retire que ce qui colle vraiment).
        if keep_visited and not cavites_pour_proximite.empty:
            try:
                from karstpro.core.cibles_carryover import suppress_cibles_near_inventory
                n_inv = suppress_cibles_near_inventory(
                    result["gpkg"], name, cavites_pour_proximite, tol_m=3.0)
                if n_inv:
                    feedback.pushInfo(
                        t("Cibles connues : {n_inv} cible(s) retirée(s) de la to-do (à ≤ 3 m d'une cavité de l'inventaire / Géorisques).", n_inv=n_inv))
            except Exception as exc:
                feedback.pushWarning(t("Suppression des cibles connues échouée : {exc}", exc=exc))

        # Carte d'identité reproductible de l'étude (params + version + date) :
        # relue par « Refaire une étude » pour rejouer la prép à l'identique.
        try:
            from karstpro.core.etude import write_etude_json
            ej = write_etude_json(output_dir, parameters, name, result["gpkg"])
            self._log(feedback,
                      t("Paramètres de l'étude enregistrés : {fichier}",
                        fichier=ej), log_file)
        except Exception as exc:
            feedback.pushWarning(t("Écriture de karstpro_etude.json ignorée : {exc}", exc=exc))

        self._log(feedback,
                  t("Projet QField prêt : {gpkg}", gpkg=result["gpkg"]), log_file)
        self._log(feedback, t("Log complet : {log}", log=log_file), log_file)
        _elapsed = (datetime.now() - _t0).total_seconds()
        self._log(feedback,
                  t("Exécution terminée en {s:.0f} s ({m} min {r} s)",
                    s=_elapsed, m=int(_elapsed // 60),
                    r=int(_elapsed % 60)), log_file)
        feedback.setProgress(100)
        return {self.OUTPUT_DIR: str(output_dir)}


def _merge_cavites_sources(
    cavites_utilisateur: "gpd.GeoDataFrame | None",
    cavites_georisques: "gpd.GeoDataFrame | None",
    target_crs: str = "EPSG:2154",
) -> "gpd.GeoDataFrame":
    """Fusionne les cavités utilisateur et Géorisques en un GDF normalisé.

    Normalise les colonnes Géorisques (nom_cavite→name, type_cavite→type,
    identifiant→reference) pour correspondre au schéma attendu par
    compute_cavites_connues_proximity().

    ``target_crs`` : repère de sortie (défaut EPSG:2154 = comportement France
    historique). Était codé en dur avant le 2026-08-02 — cf. le même correctif
    dans ``scoring.compute_cavites_connues_proximity``.

    Returns un GeoDataFrame vide si les deux sources sont absentes/vides.
    """
    import geopandas as gpd
    import pandas as pd

    TARGET_CRS = target_crs
    parts = []

    if cavites_utilisateur is not None and not cavites_utilisateur.empty:
        cav = cavites_utilisateur.copy()
        if cav.crs is None:
            cav = cav.set_crs(crs_pour(TARGET_CRS))
        elif cav.crs != crs_pour(TARGET_CRS):
            # Comparaison sur l'objet CRS, pas sur str(crs) : pour une couche
            # lue depuis un gpkg, str(crs) renvoie le WKT complet, jamais
            # "EPSG:xxxx" — l'ancien test était donc toujours vrai (reprojection
            # inutile, et idiome divergent du reste du fichier).
            cav = cav.to_crs(crs_pour(TARGET_CRS))
        # Tag de source : l'inventaire utilisateur est prioritaire sur Géorisques
        # pour l'étiquetage de proximité (noms/réfs fiables vs « anonyme »).
        cav["_source"] = "inventaire"
        parts.append(cav)

    if cavites_georisques is not None and not cavites_georisques.empty:
        geo = cavites_georisques.rename(columns={
            "nom_cavite": "name",
            "type_cavite": "type",
            "identifiant": "reference",
        }).copy()
        if geo.crs is None:
            geo = geo.set_crs(crs_pour(TARGET_CRS))
        elif geo.crs != crs_pour(TARGET_CRS):
            geo = geo.to_crs(crs_pour(TARGET_CRS))
        # Conserver uniquement les colonnes compatibles + geometry
        for col in ["name", "type", "reference", "geometry"]:
            if col not in geo.columns:
                geo[col] = ""
        geo = geo[["name", "type", "reference", "geometry"]].copy()
        geo["_source"] = "georisques"
        parts.append(geo)

    if not parts:
        return gpd.GeoDataFrame(
            columns=["name", "type", "reference", "geometry"], crs=TARGET_CRS
        )

    merged = gpd.GeoDataFrame(
        pd.concat(parts, ignore_index=True), crs=TARGET_CRS
    )
    return merged
