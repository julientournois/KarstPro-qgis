# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Report des **cibles déjà prospectées** d'une préparation à l'autre.

Problème : re-préparer un secteur réécrit les couches cibles P1/P2/P3 (les
verdicts terrain `interet` repartent à -1). On perdait le travail de terrain.

Modèle : une couche d'archive « <secteur> — cibles visitées » reçoit les cibles
prospectées (`interet != -1`). Elle sépare la to-do (P1/P2/P3) des cibles faites,
et **survit à une re-préparation** :

  1. ``capture_visited_as_archive`` — AVANT d'écraser le gpkg, on lit les cibles
     visitées (couche archive existante + verdicts résiduels dans P1/P2/P3) en
     mémoire (attributs + **blob géométrie brut**, sans ré-encodage).
  2. ``restore_archive_rows`` — APRÈS recréation du gpkg, on réinjecte ces lignes
     dans la couche archive (re)créée vide.
  3. ``suppress_already_visited`` — on retire de la nouvelle to-do toute cible à
     ≤ tol m d'un point archivé (lieu déjà prospecté).

  ``move_visited_to_archive`` — déplacement à chaud (au retour terrain, hors
  re-préparation), utilisé par « Mettre à jour les cibles ».

Tout en **SQL pur** (sqlite3) : pas de pyproj (crash ``proj_create`` au 2ᵉ run
Processing), pas de ré-encodage de géométrie (on copie le blob GeoPackage tel
quel — même CRS, en-tête srs_id identique). Les triggers rtree créés par GDAL
maintiennent l'index spatial sur INSERT/DELETE.
"""
from datetime import date

from karstpro.core.gpkg import ARCHIVE_SCHEMA, read_gpkg_layer, delete_features_by_fid


def archive_layer_name(secteur: str) -> str:
    return f"{secteur} — cibles visitées"


def _cible_layers(secteur: str) -> dict:
    return {
        "P1": f"{secteur} — cibles P1",
        "P2": f"{secteur} — cibles P2",
        "P3": f"{secteur} — cibles P3",
    }


def _tables(con) -> set:
    return {r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}


def _geom_col(con, layer: str) -> str:
    r = con.execute(
        "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
        (layer,)).fetchone()
    return r[0] if r else "geom"


def _q(identifier: str) -> str:
    """Échappe un identifiant SQL (table/colonne) pour usage entre guillemets
    doubles — un secteur (nom libre, tapé ou géocodé) contenant un guillemet
    ne doit pas produire du SQL invalide/injectable dans les f-strings de ce
    module (les noms de table sont construits depuis `secteur`, jamais des
    valeurs qu'on peut passer en paramètre lié ``?``)."""
    return '"' + str(identifier).replace('"', '""') + '"'


def _cols(con, layer: str) -> list:
    return [c[1] for c in con.execute(f"PRAGMA table_info({_q(layer)})")]


def _valid(g) -> bool:
    if g is None or not hasattr(g, "distance"):
        return False
    try:
        return not g.is_empty
    except Exception:
        return False


# ── Capture / restauration (autour d'une re-préparation) ────────────────────

def capture_visited_as_archive(gpkg_path, secteur: str) -> list:
    """Lit les cibles visitées de l'ANCIEN gpkg, normalisées au schéma archive.

    Source double, pour être robuste que l'utilisateur ait lancé « Mettre à jour
    les cibles » ou non :
      - la couche archive existante (toutes ses lignes), s'il y en a une ;
      - les verdicts résiduels (`interet != -1`) encore dans P1/P2/P3.

    Retourne une liste de dicts {col archive: valeur, "__geom__": blob brut}.
    """
    import sqlite3
    arch = archive_layer_name(secteur)
    arch_attrs = list(ARCHIVE_SCHEMA.keys())
    out = []
    con = sqlite3.connect(str(gpkg_path))
    try:
        tables = _tables(con)

        def _grab(layer, default_prio):
            if layer not in tables:
                return
            cols = _cols(con, layer)
            if "interet" not in cols and layer != arch:
                return  # vieille couche sans verdict possible
            gcol = _geom_col(con, layer)
            attrs = [c for c in cols if c not in (gcol, "fid")]
            sel = ", ".join(_q(c) for c in attrs) + f', {_q(gcol)}'
            where = ""
            if layer != arch:
                where = " WHERE interet IS NOT NULL AND interet != -1"
            for row in con.execute(f'SELECT {sel} FROM {_q(layer)}{where}'):
                d = {attrs[i]: row[i] for i in range(len(attrs))}
                blob = row[len(attrs)]
                rec = {k: d.get(k) for k in arch_attrs}
                if not rec.get("priorite_origine"):
                    rec["priorite_origine"] = default_prio
                if rec.get("date_visite") is None:
                    rec["date_visite"] = ""
                rec["__geom__"] = blob
                out.append(rec)

        _grab(arch, "")
        for prio, lname in _cible_layers(secteur).items():
            _grab(lname, prio)
        return out
    finally:
        con.close()


def restore_archive_rows(gpkg_path, secteur: str, records: list) -> int:
    """Réinjecte les lignes capturées dans la couche archive (re)créée vide.

    INSERT SQL (fid auto-incrémenté, blob géométrie réécrit tel quel). Les
    triggers rtree de GDAL maintiennent l'index. Retourne le nombre inséré.
    """
    import sqlite3
    if not records:
        return 0
    arch = archive_layer_name(secteur)
    con = sqlite3.connect(str(gpkg_path))
    try:
        if arch not in _tables(con):
            return 0
        gcol = _geom_col(con, arch)
        attrs = [c for c in _cols(con, arch) if c not in (gcol, "fid")]
        collist = ", ".join(_q(c) for c in attrs) + f', {_q(gcol)}'
        marks = ", ".join("?" * (len(attrs) + 1))
        n = 0
        for rec in records:
            vals = [rec.get(c) for c in attrs] + [rec.get("__geom__")]
            con.execute(
                f'INSERT INTO {_q(arch)} ({collist}) VALUES ({marks})', vals)
            n += 1
        con.commit()
        return n
    finally:
        con.close()


def _suppress_cibles_near(gpkg_path, secteur, pts, tol_m) -> int:
    """Retire des cibles P1/P2/P3 (jamais l'archive) celles à ≤ tol_m d'un des
    ``pts`` (points shapely). Appariement par proximité (la géométrie est stable,
    le fid ne l'est pas). Retourne le nombre retiré.

    Index spatial (STRtree) plutôt qu'une double boucle O(n_cibles × n_pts) —
    même piège de performance que ``apply_gouffres_carryover`` sur un grand
    inventaire de cavités ou une archive volumineuse."""
    import sqlite3
    if not pts:
        return 0
    from shapely.strtree import STRtree
    tree = STRtree(pts)
    total = 0
    for _prio, lname in _cible_layers(secteur).items():
        con = sqlite3.connect(str(gpkg_path))
        try:
            present = lname in _tables(con)
        finally:
            con.close()
        if not present:
            continue
        cibles = read_gpkg_layer(gpkg_path, lname)
        to_del = []
        for _, row in cibles.iterrows():
            g = row.geometry
            if not _valid(g):
                continue
            if len(tree.query(g, predicate="dwithin", distance=tol_m)) > 0:
                to_del.append(row["__fid__"])
        total += delete_features_by_fid(gpkg_path, lname, to_del)
    return total


def suppress_already_visited(gpkg_path, secteur: str, tol_m: float = 5.0) -> int:
    """Retire des nouvelles cibles P1/P2/P3 celles dont le lieu est déjà archivé
    (à ≤ tol_m d'un point de « cibles visitées ») — déjà prospectées.
    Retourne le nombre de cibles retirées.
    """
    import sqlite3
    arch = archive_layer_name(secteur)
    con = sqlite3.connect(str(gpkg_path))
    try:
        if arch not in _tables(con):
            return 0
    finally:
        con.close()
    archive = read_gpkg_layer(gpkg_path, arch)
    pts = [g for g in archive.geometry if _valid(g)]
    return _suppress_cibles_near(gpkg_path, secteur, pts, tol_m)


def suppress_cibles_near_inventory(gpkg_path, secteur: str, inventory_gdf,
                                   tol_m: float = 3.0) -> int:
    """Retire des cibles P1/P2/P3 celles à ≤ tol_m d'une cavité **déjà dans
    l'inventaire** fourni — inutile de re-prospecter du connu.

    Rayon serré (3 m par défaut) pour ne pas supprimer un phénomène voisin non
    prospecté. Complète le carryover d'archive : l'inventaire est un paramètre
    fourni à la prép, donc fiable quel que soit le gpkg ré-préparé. Retourne le
    nombre de cibles retirées.
    """
    if inventory_gdf is None or len(inventory_gdf) == 0:
        return 0
    pts = [g for g in inventory_gdf.geometry if _valid(g)]
    return _suppress_cibles_near(gpkg_path, secteur, pts, tol_m)


# ── Déplacement à chaud (au retour terrain, hors re-préparation) ────────────

def move_visited_to_archive(gpkg_path, secteur: str,
                            extra_fids: dict | None = None,
                            date_str: str | None = None,
                            only_interet=None, detail_out=None) -> int:
    """Déplace les cibles visitées de P1/P2/P3 vers l'archive « cibles visitées ».

    Par défaut, toute cible avec un verdict (`interet != -1`). ``only_interet``
    (itérable, ex. ``{0}`` ou ``{1, 2}``) restreint aux valeurs données. Au
    retour terrain, la synchro archive en deux passes : `{0}` (sans intérêt) via
    « Mettre à jour les cibles », puis `{1, 2}` (indice/cavité, déjà exportés au
    CSV Karst Entry) directement — **toujours archivées, jamais supprimées** :
    ``suppress_already_visited`` (re-préparation) ne lit QUE cette archive, donc
    une cible supprimée sans y passer reviendrait se faire re-proposer comme
    cible neuve à la préparation suivante.

    ``extra_fids`` : {nom_couche: set(fids)} — cibles à forcer comme visitées
    (ex. une cavité saisie tombe dessus mais l'opérateur n'a pas mis `interet`) ;
    leur `interet` passe à 2 avant déplacement.

    ``detail_out`` : liste optionnelle, remplie d'un dict par cible déplacée
    ``{"layer": <couche source>, "name": <nom>, "destination": <couche archive>}``
    — pour journaliser précisément couche source → destination (traçabilité).

    SQL pur : INSERT…SELECT (copie du blob géométrie) + DELETE. Retourne le
    nombre de cibles déplacées.
    """
    import sqlite3
    date_str = date_str or date.today().isoformat()
    if only_interet is not None:
        only_interet = [int(v) for v in only_interet]
    arch = archive_layer_name(secteur)
    con = sqlite3.connect(str(gpkg_path))
    try:
        tables = _tables(con)
        if arch not in tables:
            return 0
        arch_gcol = _geom_col(con, arch)
        arch_cols = _cols(con, arch)
        moved = 0
        for prio, lname in _cible_layers(secteur).items():
            if lname not in tables:
                continue
            pcols = _cols(con, lname)
            if "interet" not in pcols:
                continue
            pgcol = _geom_col(con, lname)

            # Cibles à déplacer : verdict réel (interet != -1), plus les fids
            # forcés (cavité trouvée, interet encore -1) → interet=2 à la copie.
            # On NE modifie PAS la couche P (un UPDATE déclencherait son trigger
            # rtree, qui appelle des fonctions ST absentes du sqlite3 Python) :
            # le forçage se fait par un littéral dans le SELECT d'insertion.
            if only_interet is not None:
                m = ",".join("?" * len(only_interet))
                normal = [r[0] for r in con.execute(
                    f'SELECT rowid FROM {_q(lname)} WHERE interet IN ({m})',
                    only_interet)]
            else:
                normal = [r[0] for r in con.execute(
                    f'SELECT rowid FROM {_q(lname)} '
                    "WHERE interet IS NOT NULL AND interet != -1")]
            force = []
            extra = {int(f) for f in (extra_fids or {}).get(lname, set())}
            if extra:
                m = ",".join("?" * len(extra))
                force = [r[0] for r in con.execute(
                    f'SELECT rowid FROM {_q(lname)} WHERE rowid IN ({m}) '
                    "AND (interet IS NULL OR interet=-1)", list(extra))]
            if not normal and not force:
                continue

            # Colonnes communes (hors fid + géométrie) à copier telles quelles ;
            # priorite_origine / date_visite posées explicitement.
            common = [c for c in pcols
                      if c in arch_cols and c not in ("fid", pgcol)]
            ins = (", ".join(_q(c) for c in common)
                   + ', "priorite_origine", "date_visite", ' + _q(arch_gcol))

            def _insert(fids, force_interet):
                if not fids:
                    return
                cols_sel = ", ".join(
                    "2" if (force_interet and c == "interet") else _q(c)
                    for c in common)
                selc = cols_sel + ", ?, ?, " + _q(pgcol)
                m = ",".join("?" * len(fids))
                con.execute(
                    f'INSERT INTO {_q(arch)} ({ins}) SELECT {selc} FROM {_q(lname)} '
                    f"WHERE rowid IN ({m})", [prio, date_str] + fids)

            _insert(normal, force_interet=False)
            _insert(force, force_interet=True)
            all_fids = normal + force
            if detail_out is not None and "name" in pcols:
                m = ",".join("?" * len(all_fids))
                for r in con.execute(
                        f'SELECT "name" FROM {_q(lname)} WHERE rowid IN ({m})',
                        all_fids):
                    detail_out.append({"layer": lname, "name": r[0] or "?",
                                       "destination": arch})
            m = ",".join("?" * len(all_fids))
            con.execute(f'DELETE FROM {_q(lname)} WHERE rowid IN ({m})', all_fids)
            moved += len(all_fids)
        con.commit()
        return moved
    finally:
        con.close()


# ── Report des gouffres investigués (re-préparation) ────────────────────────
#
# Les gouffres sont détectés depuis un **signal physique du MNT** (vide NODATA),
# indépendant du terrain : à chaque (re)préparation, la couche `gouffres` est
# entièrement régénérée avec `interet=-1`, sans lien avec les couches cibles/
# archive. Contrairement aux cibles, on ne les archive ni ne les supprime jamais
# (référence permanente) — on **reporte leur verdict** (interet/comment/photos)
# sur le gouffre fraîchement re-détecté à la même position (tolérance stricte,
# 3 m par défaut, pour ne pas fusionner deux gouffres voisins distincts).

def capture_investigated_gouffres(gpkg_path) -> list:
    """Lit les gouffres **déjà investigués** (`interet != -1`) de l'ANCIEN gpkg,
    avant qu'une re-préparation n'écrase la couche `gouffres`. Retourne une liste
    de dicts ``{"geometry": <shapely>, "interet": int, "comment": str,
    "photos": str}``, à reporter via ``apply_gouffres_carryover``.
    """
    import sqlite3
    with sqlite3.connect(str(gpkg_path)) as con:
        tables = {r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
    if "gouffres" not in tables:
        return []
    gdf = read_gpkg_layer(gpkg_path, "gouffres")
    if gdf.empty or "interet" not in gdf.columns:
        return []
    out = []
    for _, row in gdf.iterrows():
        try:
            interet = int(row["interet"])
        except (TypeError, ValueError):
            continue
        if interet == -1 or not _valid(row.geometry):
            continue
        out.append({
            "geometry": row.geometry,
            "interet": interet,
            "comment": row.get("comment") or "",
            "photos": row.get("photos") or "",
        })
    return out


def apply_gouffres_carryover(gouffres_gdf, captured: list, tol_m: float = 3.0) -> int:
    """Reporte ``interet``/``comment``/``photos`` des gouffres capturés (déjà
    investigués, ancien gpkg) sur les gouffres **fraîchement re-détectés** de
    ``gouffres_gdf`` situés à ≤ ``tol_m`` — appariement au plus proche, 1:1 (un
    gouffre capturé ne se reporte qu'une fois). Modifie ``gouffres_gdf`` **en
    place** (ajoute les colonnes si absentes). Un gouffre re-détecté sans
    correspondance garde son état par défaut (``interet=-1``). Retourne le
    nombre de gouffres reportés.
    """
    if gouffres_gdf is None or gouffres_gdf.empty or not captured:
        return 0
    if "interet" not in gouffres_gdf.columns:
        gouffres_gdf["interet"] = -1
    if "comment" not in gouffres_gdf.columns:
        gouffres_gdf["comment"] = ""
    if "photos" not in gouffres_gdf.columns:
        gouffres_gdf["photos"] = ""
    # Index spatial (STRtree) plutôt qu'une double boucle O(n_gouffres ×
    # n_captured) : sur un secteur boisé, la quasi-totalité des gouffres
    # détectés sous canopée fermée sont auto-déclassés interet=0 par
    # shafts.py (cf. son docstring) — capture_investigated_gouffres les
    # confond avec un vrai verdict terrain et en capture des dizaines à
    # centaines de milliers. La double boucle explosait alors en dizaines
    # de milliards de comparaisons (~14 Md constatés sur Poligny, 151 km²,
    # 118k gouffres) — un blocage de 8h+ reproduit sur 2 secteurs boisés
    # distincts avant d'être diagnostiqué et corrigé ici.
    from shapely.strtree import STRtree
    cap_geoms = [rec["geometry"] for rec in captured]
    tree = STRtree(cap_geoms)
    used = [False] * len(captured)
    n = 0
    for idx, row in gouffres_gdf.iterrows():
        g = row.geometry
        if not _valid(g):
            continue
        best_j, best_d = None, tol_m
        for j in tree.query(g, predicate="dwithin", distance=tol_m):
            j = int(j)
            if used[j]:
                continue
            d = g.distance(cap_geoms[j])
            if d <= best_d:
                best_j, best_d = j, d
        if best_j is not None:
            rec = captured[best_j]
            gouffres_gdf.at[idx, "interet"] = rec["interet"]
            gouffres_gdf.at[idx, "comment"] = rec["comment"]
            gouffres_gdf.at[idx, "photos"] = rec["photos"]
            used[best_j] = True
            n += 1
    return n
