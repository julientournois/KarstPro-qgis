# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Registre des territoires et contrôle d'exhaustivité des capacités."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Union

from karstpro.core.territoires.types import (
    Absente, Capacite, ConfigurationIncomplete, ConfigurationInconnue,
    ConfigurationInvalide,
)

# Liste FIGÉE, possédée par le pipeline. Un territoire ne peut pas inventer de
# capacité : ajouter une entrée ici oblige TOUS les territoires à se
# prononcer, ce qui est précisément le mécanisme anti-oubli.
CAPACITES_REQUISES = frozenset({
    "crs_travail",
    "mnt",
    "geologie",
    "contexte_karstique",
    "cavites_connues",
    "obstacles_gouffres",
    "vegetation_gouffres",
    "anthropique_dolines",
    "affaissement_historique",
    "modele_appris",
    "fonds_carte",
    "points_eau_karstiques",
})

# Sous-ensemble sans lequel le pipeline n'a aucun sens : les déclarer absentes
# n'est pas un mode dégradé, c'est une erreur de configuration. Sans CRS de
# travail rien ne peut être projeté ; sans MNT il n'y a ni doline, ni gouffre,
# ni hydrologie.
CAPACITES_OBLIGATOIRES = frozenset({"crs_travail", "mnt"})


@dataclass(frozen=True)
class Territoire:
    cle: str
    libelle: str
    capacites: Mapping[str, Union[Capacite, Absente]]

    def __post_init__(self):
        declarees = set(self.capacites)
        if manquantes := CAPACITES_REQUISES - declarees:
            raise ConfigurationIncomplete(
                f"Territoire « {self.cle} » ne déclare pas : "
                f"{sorted(manquantes)}")
        if inconnues := declarees - CAPACITES_REQUISES:
            raise ConfigurationInconnue(
                f"Territoire « {self.cle} » déclare des capacités inconnues : "
                f"{sorted(inconnues)}")
        absentes_interdites = sorted(
            nom for nom in CAPACITES_OBLIGATOIRES
            if isinstance(self.capacites[nom], Absente))
        if absentes_interdites:
            raise ConfigurationInvalide(
                f"Territoire « {self.cle} » déclare absente(s) des capacités "
                f"indispensables : {absentes_interdites}. Un territoire sans "
                f"CRS de travail ou sans source de MNT ne peut pas être traité.")

    def capacite(self, nom: str) -> Union[Capacite, Absente]:
        """Accès à une capacité. Lève KeyError sur un nom hors liste — ce cas
        est déjà impossible après __post_init__, sauf faute de frappe côté
        appelant, que l'on veut bruyante."""
        return self.capacites[nom]
