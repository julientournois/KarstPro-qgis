# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterDefinition,
    QgsProcessingOutputFolder,
    QgsProcessingException,
)

# NOTE: imports lourds différés dans processAlgorithm (cf. autres algorithmes).


class KarstRefaireEtudeAlgorithm(QgsProcessingAlgorithm):
    """Rejoue une préparation existante avec **les mêmes paramètres**, sans
    re-saisie : relit ``karstpro_etude.json`` (ou, pour une ancienne étude, le
    dernier log de préparation), et relance « Préparer une sortie ».

    Utile quand un traitement a changé (MNT, détection, scoring) et qu'on veut
    re-détecter une zone. Le report des cibles déjà prospectées/connues est
    **forcé** (comme à la préparation) ; les cavités saisies non synchronisées
    bloquent l'opération (garde-fou anti-perte).
    """

    ETUDE = "ETUDE"
    REGEN_MNT = "REGEN_MNT"
    REDOWNLOAD_LIDAR = "REDOWNLOAD_LIDAR"
    OUTPUT_DIR = "OUTPUT_DIR"

    def name(self):
        return "karst_refaire_etude"

    def displayName(self):
        return "KarstPro — Refaire une étude"

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstRefaireEtudeAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        return help_html(
            "<b>Refaire une étude (mêmes paramètres).</b><br><br>"
            "<b>But :</b> re-détecter une zone <b>déjà préparée</b> après un "
            "changement de traitement (MNT, détection, scoring), sans re-saisir "
            "l'emprise ni les options.<br><br>"
            "<b>Ce que ça fait :</b> lit les paramètres de l'étude "
            "(<i>karstpro_etude.json</i>, ou à défaut le dernier log de "
            "préparation du dossier), puis relance « Préparer une sortie » à "
            "l'identique. Le retrait des cibles déjà prospectées ou connues est "
            "<b>forcé</b> (les verdicts terrain et l'inventaire sont préservés, "
            "comme à une re-préparation normale).<br><br>"
            "<b>Comment l'utiliser :</b><br>"
            "• <b>Dossier de l'étude</b> — le dossier de sortie de la "
            "préparation d'origine (celui qui contient le .gpkg).<br>"
            "• <b>Régénérer le MNT</b> — à cocher <b>si le traitement du MNT a "
            "changé</b> (supprime <i>lidar_work/mnt.tif</i> ; plus long). Sinon la "
            "détection repart du MNT en cache (rapide).<br>"
            "• <b>Re-télécharger le LiDAR</b> (avancé) — seulement si de nouvelles "
            "dalles IGN sont disponibles.<br><br>"
            "<b>⚠ À faire d'abord :</b> <b>synchronise le retour terrain</b> "
            "(export CSV) avant de refaire. <b>Bloquent</b> l'opération : des "
            "cavités saisies non exportées (couche <i>cavites</i>), ou des "
            "cibles/gouffres à intérêt (indice/cavité) non synchronisés — la "
            "re-préparation les piégerait sinon dans « cibles visitées » sans "
            "jamais les envoyer au CSV Karst Entry."
        )

    def _add_advanced(self, param):
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        folder = getattr(QgsProcessingParameterFile, "Folder", None)
        if folder is None:  # QGIS 4 : enum scopé
            folder = QgsProcessingParameterFile.Behavior.Folder
        self.addParameter(QgsProcessingParameterFile(
            self.ETUDE,
            "Dossier de l'étude à refaire (contient le .gpkg et "
            "karstpro_etude.json / le log de préparation)",
            behavior=folder))
        # Libellés courts : les cases à cocher (QCheckBox) ne justifient pas le
        # texte comme les QLabel des autres paramètres — le détail complet
        # (pourquoi, quand cocher) vit dans l'aide (shortHelpString) ci-dessus.
        self.addParameter(QgsProcessingParameterBoolean(
            self.REGEN_MNT,
            "Régénérer le MNT (⚠ plus long)",
            defaultValue=False))
        self._add_advanced(QgsProcessingParameterBoolean(
            self.REDOWNLOAD_LIDAR,
            "Re-télécharger le LiDAR IGN (avancé)",
            defaultValue=False))
        # Sortie déclarée (pas un paramètre saisi par l'utilisateur — le dossier
        # est implicite, celui de l'étude relue) : QGIS rend alors le chemin
        # cliquable dans le panneau de résultats, comme pour « Préparer une
        # sortie ». Sans addOutput(), le dict brut retourné s'affiche en texte.
        self.addOutput(QgsProcessingOutputFolder(
            self.OUTPUT_DIR, "Dossier de l'étude refaite"))

    def processAlgorithm(self, parameters, context, feedback):
        from karstpro.core.etude import (
            read_etude_params, count_layer_features, count_pending_findings)

        etude_dir = self.parameterAsFile(parameters, self.ETUDE, context)
        regen_mnt = self.parameterAsBool(parameters, self.REGEN_MNT, context)
        redownload = self.parameterAsBool(parameters, self.REDOWNLOAD_LIDAR, context)

        params, gpkg, source = read_etude_params(etude_dir)
        if not params:
            raise QgsProcessingException(
                "Aucun « karstpro_etude.json » ni log « karstpro_prep_*.log » "
                f"trouvé dans {etude_dir}. Ce dossier a-t-il été produit par une "
                "préparation KarstPro ?")
        feedback.pushInfo(f"Paramètres relus depuis : {source}")

        # ── Garde-fou : ne pas écraser des saisies terrain non synchronisées ──
        if gpkg is not None and Path(gpkg).exists():
            n_cav = count_layer_features(gpkg, "cavites")
            if n_cav > 0:
                raise QgsProcessingException(
                    f"{n_cav} cavité(s) dans la couche « cavites » du gpkg "
                    "(saisies terrain non exportées). Refaire l'étude réécrirait "
                    "le gpkg et les perdrait. → Lance d'abord « Synchroniser le "
                    "retour terrain » (export CSV Karst Entry), puis recommence.")

            # ── Garde-fou : cibles/gouffres à intérêt non synchronisés ────────
            # Sans synchro préalable, le carryover de la re-préparation capture
            # TOUT interet != -1 (0, 1 ou 2 indistinctement) vers l'archive
            # « cibles visitées » — un indice/une cavité (≥1) s'y retrouverait
            # piégé, sans jamais rejoindre le CSV Karst Entry (qui ne lit que
            # P1/P2/P3, jamais l'archive). On refuse plutôt que de piéger la donnée.
            secteur = params.get("SECTEUR_NAME") or Path(gpkg).stem
            pending = count_pending_findings(gpkg, secteur, (1, 2))
            if pending:
                detail = ", ".join(f"{p['count']} dans « {p['layer']} »"
                                   for p in pending)
                raise QgsProcessingException(
                    f"Cibles ou gouffres à intérêt (indice/cavité) non exportés : "
                    f"{detail}. Refaire l'étude les piégerait dans l'archive "
                    "« cibles visitées » sans les envoyer au CSV Karst Entry. → "
                    "Lance d'abord « Synchroniser le retour terrain », puis "
                    "recommence.")

        # ── Gestion du cache lidar_work/ selon ce qui a changé ────────────────
        out_dir = Path(params.get("OUTPUT_DIR") or etude_dir)
        lidar_work = out_dir / "lidar_work"
        if regen_mnt:
            mnt = lidar_work / "mnt.tif"
            if mnt.exists():
                try:
                    mnt.unlink()
                    feedback.pushInfo("MNT en cache supprimé → régénération.")
                except Exception as exc:
                    feedback.pushWarning(f"Suppression du MNT impossible : {exc}")
        if redownload:
            laz = lidar_work / "laz"
            if laz.exists():
                import shutil
                try:
                    shutil.rmtree(laz)
                    feedback.pushInfo("Dalles LAZ supprimées → re-téléchargement.")
                except Exception as exc:
                    feedback.pushWarning(f"Suppression des LAZ impossible : {exc}")

        # ── Chemins d'entrée disparus → on avertit et on neutralise ───────────
        for k in ("CAVITES_CONNUES", "TRACAGES", "TOPO_FILE", "SCORING_CONFIG",
                  "GEO_LOCAL"):
            v = params.get(k)
            if v and not Path(str(v)).exists():
                feedback.pushWarning(f"{k} introuvable ({v}) — ignoré.")
                params[k] = None
        mnt_files = params.get("MNT_FILES")
        if isinstance(mnt_files, (list, tuple)):
            kept = [m for m in mnt_files if m and Path(str(m)).exists()]
            params["MNT_FILES"] = kept or None

        # ── Report des cibles forcé (comme une re-préparation) ────────────────
        params["KEEP_VISITED"] = True

        feedback.pushInfo("Relance de « Préparer une sortie » avec ces paramètres…")
        from qgis import processing
        res = processing.run("karstpro:karst_prep", params,
                             context=context, feedback=feedback,
                             is_child_algorithm=True)
        # Clé de sortie propre à CET algorithme (découplée de celle de karst_prep,
        # même si elles coïncident aujourd'hui) : nécessaire pour que le dossier
        # soit affiché comme un lien cliquable (cf. addOutput ci-dessus).
        out_str = res.get("OUTPUT_DIR") or str(out_dir)
        return {self.OUTPUT_DIR: out_str}
