# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterDefinition,
    QgsProcessingOutputFolder,
    QgsProcessingException,
)
from karstpro.core.i18n import t

# NOTE: imports lourds différés dans processAlgorithm (cf. autres algorithmes).


class KarstRefaireEtudeAlgorithm(QgsProcessingAlgorithm):
    """Rejoue une préparation existante avec **les mêmes paramètres**, sans
    re-saisie : relit ``karstpro_etude.json`` (ou, pour une ancienne étude, le
    dernier log de préparation), et relance « Préparer une étude ».

    Utile quand un traitement a changé (MNT, détection, scoring) et qu'on veut
    re-détecter une zone. Le report des cibles déjà prospectées/connues est
    **forcé** (comme à la préparation) ; les cavités saisies non synchronisées
    bloquent l'opération (garde-fou anti-perte).
    """

    ETUDE = "ETUDE"
    REGEN_MNT = "REGEN_MNT"
    REDOWNLOAD_LIDAR = "REDOWNLOAD_LIDAR"
    FORCE_MODEL = "FORCE_MODEL"
    SCAN25_APIKEY = "SCAN25_APIKEY"
    OUTPUT_DIR = "OUTPUT_DIR"

    def name(self):
        return "karst_refaire_etude"

    def displayName(self):
        return t("KarstPro — Refaire une étude")

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstRefaireEtudeAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        from karstpro.core.i18n import aide
        # Corps du panneau dans i18n/aide/<module>.<langue>.html — le nom du
        # module vient de __name__, il ne peut pas diverger du fichier.
        return help_html(aide(__name__.rsplit(".", 1)[-1]))

    def _add_advanced(self, param):
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        folder = getattr(QgsProcessingParameterFile, "Folder", None)
        if folder is None:  # QGIS 4 : enum scopé
            folder = QgsProcessingParameterFile.Behavior.Folder
        self.addParameter(QgsProcessingParameterFile(
            self.ETUDE,
            t("Dossier de l'étude à refaire (contient le .gpkg et "
            "karstpro_etude.json / le log de préparation)"),
            behavior=folder))
        # Libellés courts : les cases à cocher (QCheckBox) ne justifient pas le
        # texte comme les QLabel des autres paramètres — le détail complet
        # (pourquoi, quand cocher) vit dans l'aide (shortHelpString) ci-dessus.
        self.addParameter(QgsProcessingParameterBoolean(
            self.REGEN_MNT,
            t("Régénérer le MNT (⚠ plus long)"),
            defaultValue=False))
        self._add_advanced(QgsProcessingParameterBoolean(
            self.REDOWNLOAD_LIDAR,
            t("Re-télécharger le LiDAR IGN (avancé)"),
            defaultValue=False))
        # Meme construction dynamique que le menu Priorisation de "Préparer une
        # sortie" (karst_prep_algorithm.py) : options[0] = ne pas changer (garde
        # le reglage d'origine relu depuis karstpro_etude.json), puis les memes
        # choix que la prep (decale de 1 -> l'index prep = index ici - 1).
        force_options = [
            "Ne pas changer (garder le réglage d'origine)",
            "Automatique — modèle appris selon le domaine (recommandé)",
            "Poids manuels (exploratoire)",
        ]
        try:
            from karstpro.core.model_score import list_models
            optin_models = sorted(
                (m for m in list_models() if not m.get("auto_select", True)),
                key=lambda m: m.get("model_id", ""))
        except Exception:
            optin_models = []
        for m in optin_models:
            force_options.append(
                f"Forcer « {m.get('model_id', '?')} » — {m.get('domain_name', '')} "
                f"(OPT-IN : uniquement si le terrain est confirmé de ce type)")
        self._add_advanced(QgsProcessingParameterEnum(
            self.FORCE_MODEL,
            t("Forcer un modèle différent (avancé — voir l'aide)"),
            options=force_options,
            defaultValue=0))
        self._add_advanced(QgsProcessingParameterString(
            self.SCAN25_APIKEY,
            t("Clé API SCAN25 personnelle (optionnel — voir l'aide ; laisser vide "
            "= garder le réglage d'origine)"),
            defaultValue="",
            optional=True,
        ))
        # Sortie déclarée (pas un paramètre saisi par l'utilisateur — le dossier
        # est implicite, celui de l'étude relue) : QGIS rend alors le chemin
        # cliquable dans le panneau de résultats, comme pour « Préparer une
        # sortie ». Sans addOutput(), le dict brut retourné s'affiche en texte.
        self.addOutput(QgsProcessingOutputFolder(
            self.OUTPUT_DIR, "Dossier de l'étude refaite"))

    def processAlgorithm(self, parameters, context, feedback):
        from karstpro.core.etude import (
            read_etude_params, count_layer_features, count_pending_findings)

        etude_dir = self.parameterAsFile(parameters, self.ETUDE, context)
        regen_mnt = self.parameterAsBool(parameters, self.REGEN_MNT, context)
        redownload = self.parameterAsBool(parameters, self.REDOWNLOAD_LIDAR, context)
        scan25_apikey = self.parameterAsString(parameters, self.SCAN25_APIKEY, context).strip()

        params, gpkg, source = read_etude_params(etude_dir)
        if not params:
            raise QgsProcessingException(
                "Aucun « karstpro_etude.json » ni log « karstpro_prep_*.log » "
                f"trouvé dans {etude_dir}. Ce dossier a-t-il été produit par une "
                "préparation KarstPro ?")
        # `origine` et non `source` : t(source, **params) prend déjà `source`
        # en premier paramètre positionnel, et `t("…", source=…)` levait donc
        # un TypeError à chaque « Refaire une étude ».
        feedback.pushInfo(t("Paramètres relus depuis : {origine}", origine=source))

        # ── Garde-fou : ne pas écraser des saisies terrain non synchronisées ──
        if gpkg is not None and Path(gpkg).exists():
            n_cav = count_layer_features(gpkg, "cavites")
            if n_cav > 0:
                raise QgsProcessingException(
                    f"{n_cav} cavité(s) dans la couche « cavites » du gpkg "
                    "(saisies terrain non exportées). Refaire l'étude réécrirait "
                    "le gpkg et les perdrait. → Lance d'abord « Synchroniser le "
                    "retour terrain » (export CSV Karst Entry), puis recommence.")

            # ── Garde-fou : cibles/gouffres à intérêt non synchronisés ────────
            # Sans synchro préalable, le carryover de la re-préparation capture
            # TOUT interet != -1 (0, 1 ou 2 indistinctement) vers l'archive
            # « cibles visitées » — un indice/une cavité (≥1) s'y retrouverait
            # piégé, sans jamais rejoindre le CSV Karst Entry (qui ne lit que
            # P1/P2/P3, jamais l'archive). On refuse plutôt que de piéger la donnée.
            secteur = params.get("SECTEUR_NAME") or Path(gpkg).stem
            pending = count_pending_findings(gpkg, secteur, (1, 2))
            if pending:
                detail = ", ".join(f"{p['count']} dans « {p['layer']} »"
                                   for p in pending)
                raise QgsProcessingException(
                    f"Cibles ou gouffres à intérêt (indice/cavité) non exportés : "
                    f"{detail}. Refaire l'étude les piégerait dans l'archive "
                    "« cibles visitées » sans les envoyer au CSV Karst Entry. → "
                    "Lance d'abord « Synchroniser le retour terrain », puis "
                    "recommence.")

        # ── Gestion du cache lidar_work/ selon ce qui a changé ────────────────
        out_dir = Path(params.get("OUTPUT_DIR") or etude_dir)
        lidar_work = out_dir / "lidar_work"
        if regen_mnt:
            mnt = lidar_work / "mnt.tif"
            if mnt.exists():
                try:
                    mnt.unlink()
                    feedback.pushInfo(t("MNT en cache supprimé → régénération."))
                except Exception as exc:
                    feedback.pushWarning(t("Suppression du MNT impossible : {exc}", exc=exc))
        if redownload:
            laz = lidar_work / "laz"
            if laz.exists():
                import shutil
                try:
                    shutil.rmtree(laz)
                    feedback.pushInfo(t("Dalles LAZ supprimées → re-téléchargement."))
                except Exception as exc:
                    feedback.pushWarning(t("Suppression des LAZ impossible : {exc}", exc=exc))

        # ── Chemins d'entrée disparus → on avertit et on neutralise ───────────
        for k in ("CAVITES_CONNUES", "TRACAGES", "TOPO_FILE", "SCORING_CONFIG",
                  "GEO_LOCAL"):
            v = params.get(k)
            if v and not Path(str(v)).exists():
                feedback.pushWarning(t("{k} introuvable ({v}) — ignoré.", k=k, v=v))
                params[k] = None
        mnt_files = params.get("MNT_FILES")
        if isinstance(mnt_files, (list, tuple)):
            kept = [m for m in mnt_files if m and Path(str(m)).exists()]
            params["MNT_FILES"] = kept or None

        # ── Report des cibles forcé (comme une re-préparation) ────────────────
        params["KEEP_VISITED"] = True

        # ── Forcer un modèle différent (avancé) ───────────────────────────────
        # index 0 = ne pas changer ; index N>=1 correspond a l'index N-1 du menu
        # Priorisation de "Preparer une etude" (meme construction dynamique).
        force_idx = self.parameterAsEnum(parameters, self.FORCE_MODEL, context)
        old_priorites = {}
        if force_idx != 0:
            old_model_idx = params.get("USE_LEARNED_MODEL")
            new_model_idx = force_idx - 1
            feedback.pushInfo(
                t("Modèle forcé pour cette relance : index {new_model_idx} (était index {old_model_idx} à l'origine).", new_model_idx=new_model_idx, old_model_idx=old_model_idx))
            params["USE_LEARNED_MODEL"] = new_model_idx
            # Composition avant/après — signale ce qui change de palier de
            # priorité plutôt que de laisser le changement silencieux.
            # Logique de capture testée en pytest (karstpro.core.etude,
            # sans QGIS) : cf. sa docstring pour le piège "name" vs "__fid__".
            from karstpro.core.etude import capture_priorites
            old_priorites = capture_priorites(gpkg)
            if not old_priorites:
                feedback.pushWarning(
                    t("Comparaison avant/après impossible (gpkg absent, couche "
                    "« dolines » vide, ou ancien format sans __fid__)."))

        # ── Clé API SCAN25 (avancé) : n'écrase le réglage d'origine que si ────
        # renseignée ici — laisser vide préserve exactement ce qui était dans
        # karstpro_etude.json (y compris l'absence de clé).
        if scan25_apikey:
            feedback.pushInfo(
                t("Clé API SCAN25 fournie pour cette relance — la carte IGN "
                "1/25 000 sera ajoutée (ou remplacée) dans le projet régénéré."))
            params["SCAN25_APIKEY"] = scan25_apikey

        feedback.pushInfo(t("Relance de « Préparer une étude » avec ces paramètres…"))
        from qgis import processing
        res = processing.run("karstpro:karst_prep", params,
                             context=context, feedback=feedback,
                             is_child_algorithm=True)
        # Clé de sortie propre à CET algorithme (découplée de celle de karst_prep,
        # même si elles coïncident aujourd'hui) : nécessaire pour que le dossier
        # soit affiché comme un lien cliquable (cf. addOutput ci-dessus).
        out_str = res.get("OUTPUT_DIR") or str(out_dir)

        if old_priorites:
            from karstpro.core.etude import compare_priorites, format_priorite_changes
            new_gpkg = gpkg if gpkg is not None else next(
                Path(out_str).glob("*.gpkg"), None)
            new_priorites = capture_priorites(new_gpkg)
            if new_priorites:
                changes = compare_priorites(
                    old_priorites, new_priorites.keys(), new_priorites.values())
                detail = format_priorite_changes(changes)
                if detail:
                    feedback.pushInfo(
                        t("Changement de palier de priorité (nouveau modèle) : {detail}", detail=detail))
                else:
                    feedback.pushInfo(
                        t("Aucun changement de palier de priorité malgré le "
                        "modèle forcé (les deux modèles s'accordent ici)."))
            else:
                feedback.pushWarning(
                    t("Comparaison avant/après impossible : nouvelle couche "
                    "« dolines » introuvable ou vide."))

        return {self.OUTPUT_DIR: out_str}
