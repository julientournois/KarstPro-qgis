# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from typing import Optional
import geopandas as gpd
import sqlite3


def package_qfield_project(secteur_name: str,
                            dolines: gpd.GeoDataFrame,
                            cavites: gpd.GeoDataFrame,
                            output_dir: Path,
                            reseau: Optional[gpd.GeoDataFrame] = None,
                            geology: Optional[gpd.GeoDataFrame] = None,
                            topo: Optional[gpd.GeoDataFrame] = None,
                            cavites_georisques: Optional[gpd.GeoDataFrame] = None,
                            contours: Optional[gpd.GeoDataFrame] = None,
                            gouffres: Optional[gpd.GeoDataFrame] = None,
                            points_eau: Optional[gpd.GeoDataFrame] = None,
                            couches_contexte: Optional[list] = None,
                            external_layers: Optional[list] = None,
                            zoom_extent: Optional[tuple] = None,
                            scan25_apikey: Optional[str] = None,
                            target_crs: str = "EPSG:2154",
                            fonds_carte=None) -> dict:
    """``external_layers`` : couches inventaire référencées (NON copiées) dans le
    projet, en lecture seule QField. Liste de dicts ``{"gpkg", "layer", "name"}``
    (cavités connues, traçages). Permet de garder l'inventaire dans son fichier
    partagé sans le dupliquer dans le package.

    ``scan25_apikey`` : clé API SCAN25 **personnelle** de l'utilisateur (produit
    payant IGN, jamais fournie par KarstPro). Si renseignée, ajoute la carte
    SCAN25 au projet ; sinon aucun effet (couche non ajoutée).

    ``target_crs`` : CRS du projet et de toutes ses couches (EPSG:2154 =
    Lambert-93, par défaut — France). Pour l'Espagne (routeur pays), un
    EPSG:258XX (UTM ETRS89) est attendu. Le correctif GDAL ``_fix_gpkg_crs``
    reste spécifique à la France (cf. sa docstring) ; les fonds de carte, eux,
    sont entièrement pilotés par ``fonds_carte`` (capacité déclarée par le
    territoire, cf. ``karstpro/core/territoires/``) — plus aucune branche par
    CRS écrite à la main.

    ``fonds_carte`` : capacité ``Chaine``/``Absente`` du territoire (cf.
    ``territoire.capacite("fonds_carte")``). Chaque maillon décrit un fond WMS
    ou WMTS ; ``None`` ou ``Absente`` = aucun fond de carte ajouté."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    gpkg_path = output_dir / f"{secteur_name}.gpkg"

    from karstpro.core.gpkg import _make_empty_layer, CIBLES_SCHEMA, ARCHIVE_SCHEMA

    p1_name = f"{secteur_name} — cibles P1"
    p2_name = f"{secteur_name} — cibles P2"
    p3_name = f"{secteur_name} — cibles P3"
    visitees_name = f"{secteur_name} — cibles visitées"
    # NB : l'ordre de cette liste = l'ordre de haut en bas dans le panneau
    # Couches (le 1er élément est au-dessus). `dolines` n'y figure PAS ici :
    # c'est une couche de POLYGONES, elle doit passer SOUS les points de
    # prospection (cibles, gouffres) pour ne pas les masquer, mais AU-DESSUS
    # des couches de contexte (Géorisques, bdtopo_eau, hydro, géologie…).
    # Elle est donc insérée plus bas, juste après `gouffres`.
    layers = ["cavites", p1_name, p2_name, p3_name, visitees_name]
    dolines.to_file(gpkg_path, layer="dolines", driver="GPKG")
    cavites.to_file(gpkg_path, layer="cavites", driver="GPKG")
    # Couches cibles vides — peuplées immédiatement depuis les dolines scorées,
    # puis éventuellement remplacées par l'export MLL (ordre de visite optimal)
    empty_cibles = _make_empty_layer(CIBLES_SCHEMA, crs=target_crs, geom_type="Point")
    empty_cibles.to_file(gpkg_path, layer=p1_name, driver="GPKG")
    empty_cibles.to_file(gpkg_path, layer=p2_name, driver="GPKG")
    empty_cibles.to_file(gpkg_path, layer=p3_name, driver="GPKG")
    # Archive des cibles déjà prospectées (vide à la création). SANS index
    # spatial : les triggers rtree de GDAL appellent des fonctions ST absentes du
    # sqlite3 pur, ce qui ferait échouer les INSERT du report de cibles
    # (core/cibles_carryover.py). Couche petite — l'index est superflu.
    _make_empty_layer(ARCHIVE_SCHEMA, crs=target_crs, geom_type="Point").to_file(
        gpkg_path, layer=visitees_name, driver="GPKG", SPATIAL_INDEX="NO")
    # Couches de prospection, groupées juste sous les cibles, dans l'ordre
    # demandé : … P3 → Gouffres → Dolines → Géorisques → bdtopo_eau.
    if gouffres is not None and not gouffres.empty:
        # Trouées de canopée auto-déclassées : 117 267 des 118 060 candidats de
        # Poligny, 41 188 des 42 220 des Eyzies. Les livrer rendait le projet
        # QGIS et la synchro QField inexploitables sur tout secteur boisé. Ils
        # restent INTÉGRALEMENT dans `lidar_work/gouffres.gpkg` — écrit avant
        # cette étape — donc rien n'est perdu et le filtre est réversible.
        # `veg_dense` (et non `interet == 0`) : le 0 est aussi un verdict de
        # terrain, cf. core/shafts.py::flag_vegetation.
        gouffres = gouffres.copy()
        if "veg_dense" in gouffres.columns:
            gouffres = gouffres[~gouffres["veg_dense"].fillna(False).astype(bool)]
            gouffres = gouffres.drop(columns=["veg_dense"])
    if gouffres is not None and not gouffres.empty:
        # `interet` + `comment` + `photos` : bookkeeping terrain (cocher l'état
        # d'un gouffre visité, prendre une photo), éditables au formulaire QField
        # comme les cibles. Les gouffres SONT des cibles de terrain qu'on visite
        # — d'où la photo. PAS de boucle ML ici — pas de modèle gouffre à
        # réentraîner (cf. dolines).
        if "interet" not in gouffres.columns:
            gouffres["interet"] = -1
        if "comment" not in gouffres.columns:
            gouffres["comment"] = ""
        if "photos" not in gouffres.columns:
            gouffres["photos"] = ""    # photo terrain (widget ExternalResource)
        gouffres.to_file(gpkg_path, layer="gouffres", driver="GPKG")
        layers.append("gouffres")
    # Dolines (polygones) : sous les points de prospection, au-dessus du
    # contexte. Écrite plus haut dans le gpkg, seule sa POSITION dans l'arbre
    # des couches se joue ici.
    layers.append("dolines")
    # cavites_connues / tracages ne sont plus copiés ici : ils sont référencés
    # depuis leur gpkg inventaire externe via external_layers (read-only QField).
    if cavites_georisques is not None and not cavites_georisques.empty:
        cavites_georisques.to_file(gpkg_path, layer="cavites_georisques", driver="GPKG")
        layers.append("cavites_georisques")
    if points_eau is not None and not points_eau.empty:
        # Renommée « bdtopo_eau » : signale qu'il s'agit de référencement
        # BD Topo (donnée déjà cartographiée), pas de détection.
        points_eau.to_file(gpkg_path, layer="bdtopo_eau", driver="GPKG")
        layers.append("bdtopo_eau")
    # Couches de contexte déclarées par le TERRITOIRE (Atlas du Karst Wallon
    # côté wallon ; rien en France ni en Espagne). Écrites DANS le GeoPackage,
    # et non référencées depuis un fichier externe comme l'inventaire français :
    # elles viennent du réseau, elles doivent rester lisibles hors ligne sur le
    # terrain. Le nom de table porte le préfixe du secteur, ce qui le fait
    # afficher tel quel — le territoire nomme sa couche, le pipeline ignore ce
    # qu'elle contient et n'a donc pas de libellé à lui donner.
    for couche in (couches_contexte or []):
        donnees = couche.get("donnees")
        if donnees is None or donnees.empty:
            continue
        nom_table = f"{secteur_name} — {couche['titre']}"
        donnees.to_file(gpkg_path, layer=nom_table, driver="GPKG")
        layers.append(nom_table)
    # Couches de contexte (sous la prospection dans la légende).
    if reseau is not None and not reseau.empty:
        reseau.to_file(gpkg_path, layer="hydrologie", driver="GPKG")
        layers.append("hydrologie")
    if geology is not None and not geology.empty:
        geology.to_file(gpkg_path, layer="geologie", driver="GPKG")
        layers.append("geologie")
    if topo is not None and not topo.empty:
        topo.to_file(gpkg_path, layer="topo_reseau", driver="GPKG")
        layers.append("topo_reseau")
    if contours is not None and not contours.empty:
        contours.to_file(gpkg_path, layer="courbes_niveau", driver="GPKG")
        layers.append("courbes_niveau")

    # Force le type géométrie déclaré des couches éditables vides : pyogrio
    # écrit « GEOMETRY » (générique) sur une couche sans entité, ce qui empêche
    # QField de capturer la position GPS (entités sans géométrie). cf. gpkg.py.
    from karstpro.core.gpkg import _force_gpkg_geom_types
    # Les cibles P1/P2/P3 y sont AUSSI : creees vides, leur GeoSeries est non
    # typee, donc pyogrio ecrit une geometrie generique et le .qgs les declare
    # « No geometry ». Consequences constatees le 2026-08-09 : aucune etiquette
    # ne pouvait etre serialisee sur ces couches (on n'etiquette pas une couche
    # sans geometrie), et le meme defaut empeche QField de reconnaitre une
    # couche de points — cf. le docstring de _force_gpkg_geom_types.
    _force_gpkg_geom_types(gpkg_path, {
        "cavites": "POINT", visitees_name: "POINT",
        p1_name: "POINT", p2_name: "POINT", p3_name: "POINT",
    })

    # Embed QGIS layer styles in GeoPackage (layer_styles table)
    # QGIS reads these automatically when the .gpkg is opened
    _embed_styles(gpkg_path)
    # _fix_gpkg_crs corrige un bug GDAL/Fiona SPÉCIFIQUE à EPSG:2154 (srs_id
    # écrit à 99999/organization=NONE) avec des WKT codés en dur pour
    # Lambert-93 uniquement — ne pas l'appeler pour un autre target_crs (pas
    # de WKT équivalent sourcé/vérifié pour les UTM ETRS89 espagnols, et rien
    # ne dit que le même bug GDAL s'y reproduit).
    if target_crs == "EPSG:2154":
        _fix_gpkg_crs(gpkg_path)

    qgs_path = output_dir / f"{secteur_name}.qgs"
    try:
        _write_qgs_project(secteur_name, gpkg_path, layers, qgs_path,
                           zoom_extent=zoom_extent,
                           external_layers=external_layers,
                           scan25_apikey=scan25_apikey,
                           target_crs=target_crs,
                           fonds_carte=fonds_carte)
    except ImportError:
        # Hors contexte QGIS (tests, CLI) — on génère le QGS sans l'API QGIS.
        qgs_path.write_text(
            _generate_qgs(secteur_name, gpkg_path, layers, target_crs=target_crs),
            encoding="utf-8"
        )

    return {"gpkg": gpkg_path, "qgs": qgs_path}


def _build_cibles_gdf(subset: gpd.GeoDataFrame,
                      target_crs: str = "EPSG:2154") -> gpd.GeoDataFrame | None:
    """Convertit un sous-ensemble de dolines en couche de cibles (points).

    Centroïde + attributs résumés (name, score, priorite…), au schéma
    CIBLES_SCHEMA attendu par QField.

    Fonction de module et non closure de ``write_cibles_from_scored_dolines``
    : la règle de nommage des cibles est ce qui relie le rapport MLL, le GPX
    et les notes de terrain. Elle mérite d'être vérifiable sans écrire un
    GeoPackage complet.
    """
    from shapely.geometry import Point

    rows = []
    for _, row in subset.iterrows():
        centroid = row.geometry.centroid if row.geometry else None
        if centroid is None:
            continue
        rows.append({
            # Identifiant stable (cf. core/doline_identity.py), et non le rang
            # de ligne : c'est ce nom qui part au rapport MLL, au GPX et sur la
            # carte QField, et qui doit survivre à une re-détection.
            "doline_id": int(row["doline_id"]),
            "name": f"doline_{int(row['doline_id'])}",
            "priorite": row.get("priorite", ""),
            "score": row.get("score"),
            "score_morpho": row.get("score_morpho"),
            "surface_m2": row.get("surface_m2"),
            "profondeur_m": row.get("profondeur_m"),
            "ratio_ps": row.get("ratio_ps"),
            "pente_max_bord": row.get("pente_max_bord"),
            "lisere": bool(row.get("lisere", False)),
            # Features de label portées par la cible : elles seules restent
            # lisibles quand la doline d'origine a disparu d'une re-détection
            # (repli de sync.py::extract_terrain_labels).
            "bassin_versant_m2": row.get("bassin_versant_m2"),
            "comp_geologie_dist_m": row.get("comp_geologie_dist_m"),
            "circularite": row.get("circularite"),
            "type": "",
            "developpement_estime": None,
            "topographiable": 0,
            "lien_topo": "",
            "comment": "",
            "photos": "",    # photo terrain (widget ExternalResource QField)
            "interet": -1,   # non visité (saisi sur le terrain : 0/1/2)
            "geometry": Point(centroid.x, centroid.y),
        })
    return gpd.GeoDataFrame(rows, crs=target_crs) if rows else None


def write_cibles_from_scored_dolines(
    gpkg_path: Path,
    secteur_name: str,
    scored_dolines: gpd.GeoDataFrame,
    target_crs: str = "EPSG:2154",
) -> tuple[int, int, int]:
    """
    Écrit les couches ``{secteur} — cibles P1`` (rouge), ``P2`` (orange)
    et ``P3`` (jaune) dans le GeoPackage à partir des dolines scorées.

    Appelé directement depuis karst_prep_algorithm après le calcul des scores,
    sans passer par l'export MLL.  L'export MLL peut ensuite remplacer
    ces couches avec un ordre de visite optimisé.

    Returns
    -------
    (n_p1, n_p2, n_p3) : nombre de cibles écrites dans chaque couche.
    """
    p1_name = f"{secteur_name} — cibles P1"
    p2_name = f"{secteur_name} — cibles P2"
    p3_name = f"{secteur_name} — cibles P3"

    if "priorite" not in scored_dolines.columns:
        return (0, 0, 0)
    rouges  = scored_dolines[scored_dolines["priorite"] == "rouge"]
    oranges = scored_dolines[scored_dolines["priorite"] == "orange"]
    jaunes  = scored_dolines[scored_dolines["priorite"] == "jaune"]

    gdf_p1 = _build_cibles_gdf(rouges, target_crs)
    gdf_p2 = _build_cibles_gdf(oranges, target_crs)
    gdf_p3 = _build_cibles_gdf(jaunes, target_crs)

    if gdf_p1 is not None:
        gdf_p1.to_file(str(gpkg_path), layer=p1_name, driver="GPKG",
                       layer_options={"OVERWRITE": "YES"})
    if gdf_p2 is not None:
        gdf_p2.to_file(str(gpkg_path), layer=p2_name, driver="GPKG",
                       layer_options={"OVERWRITE": "YES"})
    if gdf_p3 is not None:
        gdf_p3.to_file(str(gpkg_path), layer=p3_name, driver="GPKG",
                       layer_options={"OVERWRITE": "YES"})

    # cf. package_qfield_project : correctif GDAL spécifique EPSG:2154, ne
    # s'applique pas aux autres CRS (pas de WKT équivalent sourcé/vérifié).
    if target_crs == "EPSG:2154":
        _fix_gpkg_crs(gpkg_path)
    return (len(rouges), len(oranges), len(jaunes))


# WKT EPSG:2154 codés en dur (au lieu de pyproj.CRS.from_epsg, qui appelle
# proj_create — NON thread-safe dans QGIS 4.0.2 : access violation au 2e
# lancement d'un algorithme dans le même processus). Le CRS du plugin est
# toujours Lambert-93 ; ces chaînes sont fixes.
_WKT2_2154 = ('PROJCRS["RGF93 v1 / Lambert-93",BASEGEOGCRS["RGF93 v1",DATUM["Reseau Geodesique Francais 1993 v1",ELLIPSOID["GRS 1980",6378137,298.257222101,LENGTHUNIT["metre",1]]],PRIMEM["Greenwich",0,ANGLEUNIT["degree",0.0174532925199433]],ID["EPSG",4171]],CONVERSION["Lambert-93",METHOD["Lambert Conic Conformal (2SP)",ID["EPSG",9802]],PARAMETER["Latitude of false origin",46.5,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8821]],PARAMETER["Longitude of false origin",3,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8822]],PARAMETER["Latitude of 1st standard parallel",49,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8823]],PARAMETER["Latitude of 2nd standard parallel",44,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8824]],PARAMETER["Easting at false origin",700000,LENGTHUNIT["metre",1],ID["EPSG",8826]],PARAMETER["Northing at false origin",6600000,LENGTHUNIT["metre",1],ID["EPSG",8827]]],CS[Cartesian,2],AXIS["easting (X)",east,ORDER[1],LENGTHUNIT["metre",1]],AXIS["northing (Y)",north,ORDER[2],LENGTHUNIT["metre",1]],USAGE[SCOPE["Engineering survey, topographic mapping."],AREA["France - onshore and offshore, mainland and Corsica (France métropolitaine including Corsica)."],BBOX[41.15,-9.86,51.56,10.38]],ID["EPSG",2154]]')
_WKT1_2154 = ('PROJCS["RGF93 v1 / Lambert-93",GEOGCS["RGF93 v1",DATUM["Reseau_Geodesique_Francais_1993_v1",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],AUTHORITY["EPSG","6171"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4171"]],PROJECTION["Lambert_Conformal_Conic_2SP"],PARAMETER["latitude_of_origin",46.5],PARAMETER["central_meridian",3],PARAMETER["standard_parallel_1",49],PARAMETER["standard_parallel_2",44],PARAMETER["false_easting",700000],PARAMETER["false_northing",6600000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],AUTHORITY["EPSG","2154"]]')


def _fix_gpkg_crs(gpkg_path: Path) -> None:
    """Force l'entrée EPSG:2154 correcte dans gpkg_spatial_ref_sys.

    Fiona/GDAL écrit parfois srs_id=99999 organization=NONE pour EPSG:2154,
    ce que QGIS 4 ne reconnaît pas. On insère/remplace l'entrée standard
    avec les WKT codés en dur (pas pyproj — voir _WKT2_2154).
    """
    wkt2 = _WKT2_2154
    wkt1 = _WKT1_2154

    with sqlite3.connect(gpkg_path) as con:
        cur = con.cursor()
        # Vérifier si la colonne definition_12_063 existe (GPKG >= 1.2.1)
        cols = {row[1] for row in cur.execute("PRAGMA table_info(gpkg_spatial_ref_sys)")}
        if "definition_12_063" in cols:
            cur.execute("""
                INSERT OR REPLACE INTO gpkg_spatial_ref_sys
                    (srs_name, srs_id, organization, organization_coordsys_id,
                     definition, definition_12_063)
                VALUES (?, ?, ?, ?, ?, ?)
            """, ("RGF93 v1 / Lambert-93", 2154, "EPSG", 2154, wkt1, wkt2))
        else:
            cur.execute("""
                INSERT OR REPLACE INTO gpkg_spatial_ref_sys
                    (srs_name, srs_id, organization, organization_coordsys_id, definition)
                VALUES (?, ?, ?, ?, ?)
            """, ("RGF93 v1 / Lambert-93", 2154, "EPSG", 2154, wkt1))

        cur.execute("UPDATE gpkg_geometry_columns SET srs_id=2154 WHERE srs_id=99999")
        cur.execute("UPDATE gpkg_contents SET srs_id=2154 WHERE srs_id=99999")
        con.commit()


def _embed_styles(gpkg_path: Path) -> None:
    """Writes QGIS layer styles into the GeoPackage layer_styles table.

    ``f_geometry_column`` DOIT correspondre exactement au nom de colonne
    géométrie réel de chaque table (lu dans ``gpkg_geometry_columns``), pas
    codé en dur : QGIS n'associe un style « useAsDefault » à une couche que
    si ce nom correspond. Bug réel trouvé en vérifiant pourquoi
    ``vl.loadDefaultStyle()`` échouait silencieusement (retour ``('', False)``)
    — pyogrio/GDAL nomme la colonne géométrie ``geom`` par défaut pour un
    GeoPackage, alors que le code écrivait ``"geometry"`` : aucune ligne ne
    correspondait jamais, donc ce style n'a jamais été chargeable ni par
    ``_write_qgs_project`` ni par un utilisateur ouvrant le gpkg brut hors
    projet — malgré le commentaire ci-dessous qui l'affirmait à tort
    (session du 2026-07-25).
    """
    with sqlite3.connect(gpkg_path) as con:
        cur = con.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS layer_styles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                f_table_catalog TEXT, f_table_schema TEXT, f_table_name TEXT,
                f_geometry_column TEXT, styleName TEXT, styleQML TEXT,
                styleSLD TEXT, useAsDefault INTEGER, description TEXT,
                owner TEXT, ui TEXT, update_time DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

        def _geom_col(table: str) -> str:
            row = cur.execute(
                "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
                (table,)).fetchone()
            return row[0] if row else "geom"

        cur.execute("DELETE FROM layer_styles WHERE f_table_name = 'dolines'")
        cur.execute(
            "INSERT INTO layer_styles "
            "(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, "
            " styleName, styleQML, useAsDefault) VALUES (?,?,?,?,?,?,?)",
            ("", "", "dolines", _geom_col("dolines"), "priorite", _DOLINES_QML, 1),
        )
        cur.execute("DELETE FROM layer_styles WHERE f_table_name = 'gouffres'")
        cur.execute(
            "INSERT INTO layer_styles "
            "(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, "
            " styleName, styleQML, useAsDefault) VALUES (?,?,?,?,?,?,?)",
            ("", "", "gouffres", _geom_col("gouffres"), "interet", _GOUFFRES_QML, 1),
        )
        con.commit()


# QML categorized renderer for dolines — colours by priorite field
_DOLINES_QML = """<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" styleCategories="Symbology">
  <renderer-v2 type="categorizedSymbol" attr="priorite" forceraster="0" symbollevels="0" enableorderby="0">
    <categories>
      <category value="rouge" label="Rouge — très fort intérêt" render="true">
        <symbol type="fill" name="rouge" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="214,47,39,217"/>
              <Option name="outline_color" type="QString" value="100,0,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="orange" label="Orange — bon intérêt" render="true">
        <symbol type="fill" name="orange" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="255,127,0,217"/>
              <Option name="outline_color" type="QString" value="150,70,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="jaune" label="Jaune — intérêt modéré" render="true">
        <symbol type="fill" name="jaune" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="255,215,0,217"/>
              <Option name="outline_color" type="QString" value="150,120,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="gris" label="Gris — faible intérêt" render="true">
        <symbol type="fill" name="gris" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="150,150,150,180"/>
              <Option name="outline_color" type="QString" value="80,80,80,255"/>
              <Option name="outline_width" type="QString" value="0.3"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
    </categories>
    <symbols/>
  </renderer-v2>
</qgis>"""


# QML categorized renderer for gouffres — colours by interet field.
# -1 (non visité) reste bien visible (magenta, le rendu par défaut avant ce
# style) ; 0 (sans intérêt — inclut les faux positifs de canopée marqués par
# flag_vegetation) passe en gris atténué, pour désencombrer visuellement les
# secteurs boisés sans jamais supprimer le point (réversible sur le terrain).
_GOUFFRES_QML = """<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" styleCategories="Symbology">
  <renderer-v2 type="categorizedSymbol" attr="interet" forceraster="0" symbollevels="0" enableorderby="0">
    <categories>
      <category value="-1" label="Non visité" render="true">
        <symbol type="marker" name="non_visite" clip_to_extent="1" alpha="0.9" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="197,27,138,255"/>
              <Option name="outline_color" type="QString" value="100,0,60,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="size" type="QString" value="3"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="0" label="Sans intérêt (dont canopée)" render="true">
        <symbol type="marker" name="sans_interet" clip_to_extent="1" alpha="0.5" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="150,150,150,150"/>
              <Option name="outline_color" type="QString" value="90,90,90,180"/>
              <Option name="outline_width" type="QString" value="0.3"/>
              <Option name="size" type="QString" value="2"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="1" label="Indice à creuser" render="true">
        <symbol type="marker" name="indice" clip_to_extent="1" alpha="0.95" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="255,127,0,255"/>
              <Option name="outline_color" type="QString" value="150,70,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="size" type="QString" value="3.5"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="2" label="Cavité confirmée" render="true">
        <symbol type="marker" name="cavite" clip_to_extent="1" alpha="0.95" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="214,47,39,255"/>
              <Option name="outline_color" type="QString" value="100,0,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="size" type="QString" value="4"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
    </categories>
    <symbols/>
  </renderer-v2>
</qgis>"""


def _is_cibles(layer_name: str) -> bool:
    """True pour les couches de cibles terrain « … — cibles P1/P2/P3 »."""
    return "cibles P" in layer_name


def _is_gouffres(layer_name: str) -> bool:
    """True pour la couche gouffres — éditable form-only (bookkeeping terrain)."""
    return layer_name == "gouffres"


def _is_cibles_visitees(layer_name: str) -> bool:
    """True pour l'archive « … — cibles visitées » — éditable form-only
    (corriger un verdict mal saisi sur une cible déjà prospectée)."""
    return layer_name.endswith("cibles visitées")


# Saisie `interet` : libellé → valeur stockée (la boucle de labels P3).
_INTERET_MAP = [
    {"Non visité": "-1"},
    {"Visité — rien": "0"},
    {"Indice à creuser": "1"},
    {"Cavité": "2"},
]
# Champs que l'opérateur peut modifier sur le terrain ; tout le reste (score,
# priorité, morphométrie…) est verrouillé pour ne pas être altéré. Commun aux
# cibles (boucle de labels) et aux gouffres (bookkeeping de visite).
_INTERET_EDITABLE_FIELDS = {"interet", "comment", "photos"}

# Champs RETIRÉS du formulaire de terrain. Ils restent dans la table, dans le
# GeoPackage et dans le CSV de labels — seul l'affichage change. Sur un écran de
# téléphone, chaque ligne compte.
#
#   fid       — numéro de ligne de la couche CIBLES : il ne désigne rien, et
#               affiché au-dessus de « Identifiant » il invite à croire qu'on
#               regarde la doline n° 1 alors qu'on lit la doline 1247.
#   doline_id — redondant avec `name`, qui affiche déjà « doline_1247 ».
#   les trois autres — features transportées pour que le label d'entraînement
#               reste exploitable quand la doline d'origine a disparu d'une
#               re-détection (cf. core/sync.py::_LABEL_FEATURES). Du transport
#               de données, jamais quelque chose qu'on lit sur le terrain.
_CHAMPS_MASQUES_TERRAIN = {
    "fid", "doline_id",
    "bassin_versant_m2", "comp_geologie_dist_m", "circularite",
}


def _configure_photo_widget(vl) -> None:
    """Active la prise de photo QField sur le champ ``photos`` (v1 : une photo).

    Widget **ExternalResource** : QField affiche un bouton appareil photo, prend
    la photo, l'enregistre comme fichier et stocke son **chemin relatif** au
    projet dans le champ. Au retour QFieldCloud, le fichier revient avec le
    projet (mécanisme de pièces jointes). Le rapport PDF intègre ensuite l'image.

    ⚠️ L'emplacement exact de stockage côté QField (DCIM/…) peut nécessiter un
    ajustement après test réel ; on pose ici une config relative robuste.
    Best-effort, jamais bloquant.
    """
    try:
        from qgis.core import QgsEditorWidgetSetup
        idx = vl.fields().indexOf("photos")
        if idx < 0:
            return
        cfg = {
            "StorageMode": 0,        # 0 = fichier
            "RelativeStorage": 1,    # 1 = chemin relatif au projet (portable)
            "DocumentViewer": 1,     # 1 = image (miniature dans la fiche)
            "DocumentViewerHeight": 0,
            "DocumentViewerWidth": 0,
            "FileWidget": True,
            "FileWidgetButton": True,
            "FileWidgetFilter": "",
        }
        vl.setEditorWidgetSetup(idx, QgsEditorWidgetSetup("ExternalResource", cfg))
    except Exception:
        return


def _configure_interet_form(vl) -> None:
    """Rend une couche éditable en **formulaire seul** : tous les champs en
    lecture seule sauf `interet`/`comment`, et widget liste pour `interet`. La
    géométrie n'est pas recapturée (pas de geomSource=gps). Utilisé par les
    cibles (labels terrain) et la couche gouffres (bookkeeping de visite)."""
    from qgis.core import QgsEditorWidgetSetup

    fields = vl.fields()
    efc = vl.editFormConfig()
    for i in range(fields.count()):
        efc.setReadOnly(i, fields.at(i).name() not in _INTERET_EDITABLE_FIELDS)
    vl.setEditFormConfig(efc)

    # Masquage : widget « Hidden ». La colonne reste dans la table attributaire
    # et dans le gpkg, elle disparaît seulement du formulaire de saisie. Les
    # noms absents de la couche sont simplement ignorés (la couche gouffres ne
    # porte pas doline_id, par exemple).
    for nom in _CHAMPS_MASQUES_TERRAIN:
        i = fields.indexOf(nom)
        if i >= 0:
            vl.setEditorWidgetSetup(i, QgsEditorWidgetSetup("Hidden", {}))

    idx = fields.indexOf("interet")
    if idx >= 0:
        vl.setEditorWidgetSetup(idx, QgsEditorWidgetSetup(
            "ValueMap", {"map": _INTERET_MAP}))


def _appliquer_libelles(vl) -> None:
    """Alias de champs et value maps, dans la langue courante.

    N'écrit QUE de la présentation : les noms de colonnes et les valeurs
    stockées restent inchangés en base. `type_doline` continue de valoir
    « doline-perte » dans la table — c'est une donnée relue par l'export MLL
    et le scoring — mais s'affiche « sinking sinkhole » en anglais grâce à la
    value map.

    Best-effort : une API absente ou un champ inconnu ne doit jamais empêcher
    d'écrire le projet.
    """
    from karstpro.core.i18n import alias_champ, valeurs_champ
    try:
        from qgis.core import QgsEditorWidgetSetup
    except Exception:
        return
    try:
        champs = vl.fields()
    except Exception:
        return
    for idx, champ in enumerate(champs):
        nom = champ.name()
        alias = alias_champ(nom)
        if alias != nom:
            try:
                vl.setFieldAlias(idx, alias)
            except Exception:
                pass
        carte = valeurs_champ(nom)
        if carte:
            try:
                vl.setEditorWidgetSetup(idx, QgsEditorWidgetSetup(
                    "ValueMap",
                    {"map": [{libelle: valeur} for valeur, libelle in carte.items()]}))
            except Exception:
                pass


def _write_qgs_project(name: str, gpkg_path: Path, layers: list,
                        qgs_path: Path, zoom_extent=None,
                        external_layers: list = None,
                        scan25_apikey: str = None,
                        target_crs: str = "EPSG:2154",
                        fonds_carte=None) -> None:
    """Écrit le projet QGIS via l'API QgsProject — garantit un CRS correct.

    Couches éditables (cavites) : QFieldSync action=offline + geomSource=gps.
    Couches consultation : action=offline (uniforme, sinon QFieldSync refuse le
    paquet pour « conflicting sync actions » sur un même gpkg) + setReadOnly.
    Couches masquées par défaut : dolines, hydrologie, geologie, cibles P3.
    """
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem,
        QgsRectangle, QgsFieldConstraints,
    )

    EDITABLE = {"cavites"}
    # `dolines` était masquée par défaut tant qu'elle n'avait aucune symbologie
    # exploitable (son style catégorisé n'était en fait jamais chargé, cf.
    # _style_dolines). Depuis qu'elle porte la couleur de priorité ET l'anneau
    # du signal ponctuel, la masquer revenait à cacher ces deux informations à
    # l'ouverture du projet. Elle est désormais visible, sous les points de
    # prospection (cf. ordre de `layers`).
    HIDDEN_BY_DEFAULT = {"dolines", "hydrologie", "geologie"}
    # `dolines` : 6 437 polygones contre 65 cibles P1 sur Rochefort — cochée,
    # la couche noie la carte à l'ouverture. Elle était masquée jusqu'en
    # v1.11.0, où elle a été décochée de cette liste sans que la docstring
    # suive ; rétablie le 2026-08-10. Reste visible dans la carte
    # morphologique imprimée, qui ne lit pas l'état coché.

    gpkg_str = str(gpkg_path)
    crs = QgsCoordinateReferenceSystem(target_crs)

    proj = QgsProject()
    proj.setCrs(crs)
    proj.setTitle(f"{name} — KarstPro")
    # Chemins relatifs → le .qgs et le .gpkg restent portables sur toute machine.
    # writeEntry("Paths","/Absolute",False) est l'API stable QGIS 3.x/4.x.
    proj.writeEntry("Paths", "/Absolute", False)

    root = proj.layerTreeRoot()
    # Vider l'arbre par défaut
    root.removeAllChildren()

    extent_dolines = None  # repli si zoom_extent absent

    from karstpro.core.i18n import libelle_couche

    for layer_name in layers:
        # Nom AFFICHÉ seulement : la table du GeoPackage garde son nom
        # (`gouffres`, `dolines`…), référencé par son littéral dans les 5
        # algorithmes et dans les projets QField déjà déployés. Traduire
        # l'identifiant casserait toutes les études existantes.
        display_name = (layer_name if layer_name.startswith(name)
                        else f"{name} — {libelle_couche(layer_name)}")
        uri = f"{gpkg_str}|layername={layer_name}"
        vl = QgsVectorLayer(uri, display_name, "ogr")
        if not vl.isValid():
            continue
        vl.setCrs(crs)
        _appliquer_libelles(vl)

        # Propriétés QFieldSync
        if layer_name in EDITABLE:
            vl.setCustomProperty("QFieldSync/action", "offline")
            vl.setCustomProperty("QFieldSync/geomSource", "gps")
            # Contrainte dure : interdit d'enregistrer une entité sans
            # géométrie. Sans ça, QField laisse valider le formulaire même si
            # le GPS est coupé ou sans fix (couvert forestier en karst) → des
            # points fantômes (attributs OK, position NULL) qu'on ne voit qu'au
            # bureau. QField applique les contraintes de champ dures (blocage
            # du commit). On la pose sur le champ "name" (sinon le 1er champ).
            fields = vl.fields()
            idx = fields.indexOf("name")
            if idx < 0 and fields.count() > 0:
                idx = 0
            if idx >= 0:
                vl.setConstraintExpression(
                    idx, "$geometry IS NOT NULL",
                    "Position GPS obligatoire : activez la localisation "
                    "avant d'enregistrer",
                )
                vl.setFieldConstraint(
                    idx, QgsFieldConstraints.ConstraintExpression,
                    QgsFieldConstraints.ConstraintStrengthHard,
                )
            # Prise de photo QField sur le champ `photos` (v1 : une photo).
            _configure_photo_widget(vl)
        elif (_is_cibles(layer_name) or _is_gouffres(layer_name)
              or _is_cibles_visitees(layer_name)):
            # Cibles P1/P2/P3 (boucle de labels terrain), gouffres (bookkeeping)
            # ET cibles visitées (corriger un verdict) : éditables en **formulaire
            # seul** (saisie `interet` / `comment`). PAS de geomSource=gps : la
            # géométrie est déjà posée
            # (centroïde de doline / point de gouffre), on ne la recapture pas.
            # Action offline uniforme (pas de conflit), PAS de setReadOnly : la
            # couche reste éditable. Tous les autres champs (score, priorité,
            # morphométrie du vide) sont verrouillés. Widget liste pour `interet`.
            vl.setCustomProperty("QFieldSync/action", "offline")
            _configure_interet_form(vl)
            # Photo terrain sur les cibles (sans effet sur gouffres, sans champ).
            _configure_photo_widget(vl)
        else:
            # Consultation seule. **Même action de sync que cavites** (offline) :
            # toutes les couches partagent le fichier Marnaval.gpkg, et QFieldSync
            # refuse de créer le paquet si des couches d'un même fichier ont des
            # actions différentes (« conflicting sync actions »). On garde donc
            # une action uniforme et on rend la couche non éditable via le drapeau
            # natif QGIS setReadOnly — l'éditabilité ≠ l'action de sync.
            vl.setCustomProperty("QFieldSync/action", "offline")
            vl.setReadOnly(True)

        # Etiquetage des cibles P1/P2 par leur identifiant stable. C'est ce
        # qui rend la carte imprimee utilisable : on lit « 1247 » sur le
        # papier et on retrouve doline_1247 dans QField et dans le rapport
        # MLL. Le NUMERO seul, pas « doline_1247 » : le prefixe est compris,
        # et une etiquette longue se chevauche des que deux cibles se
        # touchent. P3 non etiquetees — elles sont 987 sur Rochefort.
        # _is_cibles_layer plutot qu'une comparaison construite avec `name` :
        # la premiere tentative testait f"{name} — cibles P1" et ne matchait
        # jamais. Ce helper existe deja et ne depend d'aucune variable de
        # portee. « cibles visitees » n'y entre pas (il cherche « cibles P »).
        if _is_cibles(layer_name) and not layer_name.endswith("P3"):
            _label_points(vl, "doline_id", autour=True)
        if layer_name.endswith("cibles P1"):
            _style_cibles(vl, "P1")
        if layer_name.endswith("cibles P2"):
            _style_cibles(vl, "P2")
        if _is_cibles_visitees(layer_name):
            _style_cibles(vl, "visitees")

        if layer_name == "courbes_niveau":
            _style_contours(vl)
        if layer_name == "bdtopo_eau":
            _label_points(vl, "toponyme")
        if layer_name == "geologie":
            _style_geology_brgm(vl)
        if layer_name == "dolines":
            _style_dolines(vl)
        if layer_name == "gouffres":
            _style_gouffres(vl)

        # Repli pour le zoom initial si zoom_extent n'est pas fourni
        if layer_name == "dolines" and vl.featureCount() > 0:
            extent_dolines = vl.extent()

        proj.addMapLayer(vl, addToLegend=False)
        node = root.addLayer(vl)
        if layer_name in HIDDEN_BY_DEFAULT or layer_name.endswith("cibles P3"):
            node.setItemVisibilityChecked(False)

    # ── Couches inventaire externes (cavités connues, traçages) ────────────
    # Référencées depuis leur gpkg partagé (NON copiées), lecture seule QField.
    # QFieldSync en fera un snapshot dans le paquet cloud ; au bureau elles
    # pointent l'inventaire vivant.
    for ext in (external_layers or []):
        ext_path = ext.get("gpkg")
        ext_layer = ext.get("layer")
        if not ext_path or not ext_layer:
            continue
        uri = f"{ext_path}|layername={ext_layer}"
        disp = ext.get("name") or ext_layer
        vl = QgsVectorLayer(uri, disp, "ogr")
        if not vl.isValid():
            continue
        # Conserve la symbologie de l'inventaire : style embarqué dans le gpkg
        # (table layer_styles) ou .qml voisin. Sans ça, QField applique un style
        # par défaut et la symbologie soignée de l'inventaire / des traçages est
        # perdue. loadDefaultStyle() la fige dans le .qgs, qui voyage ensuite.
        try:
            vl.loadDefaultStyle()
        except Exception:
            pass
        vl.setCustomProperty("QFieldSync/action", "readonly")
        vl.setReadOnly(True)   # consultation seule (chaque inventaire = fichier
                               # distinct, donc pas de conflit d'action partagée)
        proj.addMapLayer(vl, addToLegend=False)
        root.addLayer(vl)

    # ── MNT en ombrage (relief gris pour reperer dolines/depressions) ──────
    # Reference relative lidar_work/mnt.tif ; place sous les couches vecteur.
    # Toujours ajouté. Pour un paquet QFieldCloud léger (qui ignore le flag
    # QFieldSync/cloud_action=remove), l'utilisateur retire la couche MNT du
    # projet avant le packaging.
    _add_mnt_hillshade(proj, root, gpkg_path.parent, crs)

    # Fonds de carte : entièrement déclarés par le territoire. Plus aucune
    # branche par CRS écrite à la main (cf. bug EPSG:2582 du 2026-08-02).
    # `fonds_carte` peut être une capacité `Absente` (territoire sans fond
    # configuré) — dans ce cas pas de fond ajouté, comportement identique.
    if fonds_carte is not None and not getattr(fonds_carte, "absente", False):
        plan_visible = not scan25_apikey
        for decl in fonds_carte.maillons:
            d = decl
            if d.params.get("couche") == "GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2":
                d = type(decl)(decl.type, {**decl.params, "visible": plan_visible})
            _add_fond_carte(proj, root, crs, d, scan25_apikey=scan25_apikey)

    # ── Vue initiale : zoom sur les cibles P1 (sinon emprise des dolines) ──
    # Évite d'ouvrir le projet sur une zone vide. zoom_extent = (minx,miny,maxx,maxy)
    # en L93, fourni par la préparation (les couches P1 sont vides à ce stade).
    initial = None
    if zoom_extent is not None:
        try:
            initial = QgsRectangle(*[float(v) for v in zoom_extent])
        except Exception:
            initial = None
    if (initial is None or initial.isEmpty()) and extent_dolines is not None:
        initial = extent_dolines
    if initial is not None and not initial.isEmpty():
        try:
            from qgis.core import QgsReferencedRectangle
            ext = QgsRectangle(initial)
            margin = max(ext.width(), ext.height()) * 0.15
            ext.grow(margin if margin > 0 else 250.0)
            proj.viewSettings().setDefaultViewExtent(
                QgsReferencedRectangle(ext, crs))
        except Exception:
            pass

    # ── Mises en page imprimables ─────────────────────────────────────────
    # APRÈS les couches et les fonds : le module les retrouve PAR NOM dans le
    # projet, il ne peut donc pas tourner plus tôt. Non bloquant — une mise en
    # page ratée ne doit jamais empêcher d'écrire le projet, qui reste
    # utilisable dans QGIS et sur QField sans elle.
    try:
        from datetime import date as _date
        from karstpro.core.etude import plugin_version
        from karstpro.core.mise_en_page import ajouter_mises_en_page
        # Le TERRITOIRE decide quels fonds partent a l'impression (cle
        # « impression » de sa declaration) : l'orthophoto est dans le projet
        # mais masquerait le fond topographique sur une feuille.
        _fonds_impr = None
        _credits = []
        if fonds_carte is not None and not getattr(fonds_carte, "absente", False):
            # `cle_requise` sans clé = fond JAMAIS ajouté au projet
            # (cf. `_add_fond`) : le créditer citerait une source absente de la
            # feuille. Sur-attribuer est moins grave que sous-attribuer, mais
            # c'est faux quand même.
            _imprimes = [d.params for d in fonds_carte.maillons
                         if d.params.get("impression", True)
                         and (scan25_apikey or not d.params.get("cle_requise"))]
            _fonds_impr = [p.get("titre") for p in _imprimes]
            _credits += [p.get("credit") for p in _imprimes]
        # Les couches de contexte sont sur la feuille elles aussi (sites et
        # galeries AKWA sont dans la légende de la carte de décision) : leur
        # producteur doit être cité. L'AKWA est en CC-BY 4.0.
        _credits += [c.get("credit") for c in (couches_contexte or [])]
        _pages = ajouter_mises_en_page(
            proj, name, zoom_extent, plugin_version(), _date.today().isoformat(),
            fonds_impression=_fonds_impr, credits=_credits)
        print(f"KarstPro/mise_en_page : {', '.join(_pages)}")
    except Exception as exc:            # noqa: BLE001
        print(f"KarstPro/mise_en_page ignoree : {exc}")

    proj.write(str(qgs_path))

    # QgsProject.write() crée des fichiers auxiliaires parasites — on les supprime.
    for pattern in ("*_styles.db", "*_attachments.zip"):
        for f in qgs_path.parent.glob(pattern):
            f.unlink(missing_ok=True)


def _style_geology_brgm(vl) -> None:
    """Symbologie BD Charm-50 : remplissage catégorisé par NOTATION aux couleurs
    officielles BRGM (colonnes CMJN C_FOND/M_FOND/J_FOND/N_FOND, échelle 0-100).

    Reproduit la carte géologique de référence. Repli sur une rampe HSV distincte
    par NOTATION si les colonnes couleur sont absentes (cas du WFS BRGM 1/1 000 000).
    Best-effort, jamais bloquant.
    """
    try:
        import colorsys
        from qgis.core import (
            QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFillSymbol,
        )
        from qgis.PyQt.QtGui import QColor

        fields = [f.name() for f in vl.fields()]
        attr = next((c for c in ("NOTATION", "notation") if c in fields), None)
        if attr is None:
            return
        has_cmyk = all(c in fields for c in ("C_FOND", "M_FOND", "J_FOND", "N_FOND"))

        # NOTATION → couleur (première occurrence rencontrée).
        nota_color: dict = {}
        for feat in vl.getFeatures():
            n = feat[attr]
            if n in nota_color:
                continue
            col = None
            if has_cmyk:
                try:
                    c = float(feat["C_FOND"] or 0); m = float(feat["M_FOND"] or 0)
                    j = float(feat["J_FOND"] or 0); k = float(feat["N_FOND"] or 0)
                    col = QColor(
                        int(round(255 * (1 - c / 100) * (1 - k / 100))),
                        int(round(255 * (1 - m / 100) * (1 - k / 100))),
                        int(round(255 * (1 - j / 100) * (1 - k / 100))))
                except Exception:
                    col = None
            nota_color[n] = col

        keys = list(nota_color)
        cats = []
        for i, n in enumerate(keys):
            col = nota_color[n]
            if col is None:  # repli rampe HSV distincte (sans CMJN)
                rr, gg, bb = colorsys.hsv_to_rgb(i / max(len(keys), 1), 0.45, 0.95)
                col = QColor(int(rr * 255), int(gg * 255), int(bb * 255))
            sym = QgsFillSymbol.createSimple({
                "color": f"{col.red()},{col.green()},{col.blue()},255",
                "outline_color": "90,90,90,200", "outline_width": "0.08"})
            cats.append(QgsRendererCategory(n, sym, str(n)))
        if cats:
            vl.setRenderer(QgsCategorizedSymbolRenderer(attr, cats))
            try:
                vl.setOpacity(0.55)  # semi-transparent : laisse voir relief + cibles
            except Exception:
                pass
    except Exception:
        return


def _style_dolines(vl) -> None:
    """Style la couche dolines : catégorisée par ``priorite`` (couleurs
    identiques à ``_DOLINES_QML``), construite via l'API QGIS plutôt que
    chargée depuis le gpkg.

    Bug réel trouvé en vérifiant pourquoi l'anneau ci-dessous ne
    s'appliquait à aucune catégorie (session du 2026-07-25) :
    ``_DOLINES_QML`` définit les symboles EN LIGNE dans chaque
    ``<category>`` au lieu de les référencer depuis le bloc ``<symbols>``
    (format non standard) — QGIS charge bien le type de renderer et
    l'attribut (« priorite »), mais ``categories()`` reste vide, donc
    aucune couleur de priorité ne s'est jamais appliquée quand le gpkg est
    ouvert seul, ni (avant ce correctif) dans le `.qgs`. Reconstruit ici
    entièrement par l'API — même mécanisme fiable que
    ``_style_geology_brgm``/``_style_contours``, pas de QML à la main.

    Anneaux intégrés DANS le symbole de chaque catégorie
    (``QgsCentroidFillSymbolLayer`` — marqueur posé au centroïde du
    polygone, empilé sur le `SimpleFill` de couleur) plutôt qu'une couche
    point séparée à garder alignée : chacun actif via une propriété
    data-defined (`PropertyLayerEnabled`) sur son symbol layer.

    - Anneau noir (2 mm, trait 1 mm) : signal ponctuel de puits (``pc_plongee_m``
      renseigné, cf. core/pc_anomaly.py) — purement informatif, n'affecte
      jamais le score.
    - Liseré CYAN sur le CONTOUR (blanc 1 mm doublé de cyan 0,5 mm) :
      signal RGE ALTI / affaissement historique (``rge_eligible`` et
      ``rge_contrast_m < -0.3``, cf. core/rgealti.py) — CONTRIBUE au score
      (feature du modèle appris), contrairement au noir. Sur le contour et
      non au centroïde : ce canal-là était saturé par le point de cible et
      l'anneau pc_, illisible sur un aplat de priorité.

    Best-effort.
    """
    try:
        from qgis.core import (
            QgsCategorizedSymbolRenderer, QgsCentroidFillSymbolLayer,
            QgsFillSymbol, QgsMarkerSymbol, QgsProperty, QgsRendererCategory,
            QgsSimpleLineSymbolLayer, QgsSymbolLayer, QgsUnitTypes,
        )
        from qgis.PyQt.QtGui import QColor
        colors = {
            "rouge":  ("214,47,39,217",  "100,0,0,255",   "0.4", "Rouge — très fort intérêt"),
            "orange": ("255,127,0,217",  "150,70,0,255",  "0.4", "Orange — bon intérêt"),
            "jaune":  ("255,215,0,217",  "150,120,0,255", "0.4", "Jaune — intérêt modéré"),
            "gris":   ("150,150,150,180", "80,80,80,255", "0.3", "Gris — faible intérêt"),
        }
        categories = []
        for value, (color, outline, width, label) in colors.items():
            sym = QgsFillSymbol.createSimple({
                "color": color, "outline_color": outline, "outline_width": width,
            })
            # 2 mm de diamètre, trait de 1 mm (unités explicites : ne pas
            # dépendre du défaut QGIS). Seul le TRAIT a été épaissi le
            # 2026-08-09 (0,4 -> 1 mm) : l'anneau était trop discret sur un
            # aplat de priorité, mais l'élargir à 3,5 mm le faisait déborder.
            #
            # Le diamètre reste contraint : le signal ponctuel ne concerne que
            # les dolines SOUS le seuil de surface, souvent quelques m². Un
            # anneau plus large déborderait des petites dolines qu'il signale
            # justement, et ne pointerait plus rien de précis. Épaissir le
            # trait gagne en visibilité sans toucher à ce compromis.
            ring = QgsMarkerSymbol.createSimple({
                "name": "circle", "color": "0,0,0,0",
                "outline_color": "0,0,0,255", "outline_width": "1.0",
                "size": "2", "size_unit": "MM",
            })
            centroid_layer = QgsCentroidFillSymbolLayer()
            centroid_layer.setSubSymbol(ring)
            centroid_layer.setDataDefinedProperty(
                QgsSymbolLayer.PropertyLayerEnabled,
                QgsProperty.fromExpression('"pc_plongee_m" IS NOT NULL'))
            sym.appendSymbolLayer(centroid_layer)

            # Signal RGE ALTI (affaissement historique) : LISERÉ CYAN SUR LE
            # CONTOUR de la doline, pas un anneau au centroïde.
            #
            # C'était un 3e anneau concentrique jusqu'au 2026-08-09, empilé au
            # centroïde avec l'anneau pc_ (2 mm) ET le point de cible P1. Trois
            # marques ponctuelles au même endroit sur un aplat de priorité
            # saturé : aucun jeu de taille ou de couleur ne les rendait
            # lisibles — le canal « marque au centroïde » était sature.
            #
            # Le contour est le seul canal encore libre, et il suit la forme :
            # il reste lisible a tous les zooms, y compris quand la doline
            # remplit l'ecran. La distinction devient STRUCTURELLE et non
            # graduelle : contour = affaissement historique (CONTRIBUE au
            # score), marque au centre = signal ponctuel (informatif). Plus
            # besoin de comparer deux diamètres pour savoir lequel compte.
            #
            # Double trait blanc puis cyan : le liseré doit tenir sur les
            # quatre remplissages de priorité (rouge, orange, jaune, gris), or
            # le cyan seul se noie sur le jaune et le gris clair.
            for couleur, largeur in (("255,255,255,255", "1.0"),
                                     ("0,180,180,255", "0.5")):
                rge_contour = QgsSimpleLineSymbolLayer()
                rge_contour.setColor(QColor(*[int(v) for v in couleur.split(",")]))
                rge_contour.setWidth(float(largeur))
                rge_contour.setWidthUnit(QgsUnitTypes.RenderMillimeters)
                rge_contour.setDataDefinedProperty(
                    QgsSymbolLayer.PropertyLayerEnabled,
                    QgsProperty.fromExpression(
                        '"rge_eligible" AND "rge_contrast_m" < -0.3'))
                sym.appendSymbolLayer(rge_contour)

            categories.append(QgsRendererCategory(value, sym, label))
        vl.setRenderer(QgsCategorizedSymbolRenderer("priorite", categories))
    except Exception:
        pass


def _style_cibles(vl, priorite: str) -> None:
    """Symbole d'une couche de cibles : un CERCLE, coloré par priorité.

    Des formes distinctes (triangle / carré / croix) avaient été posées pour
    rester lisibles en noir et blanc ; l'auteur les a écartées le 2026-08-10 —
    la carte s'imprime en couleur, et qui veut d'autres symboles les changera
    lui-même dans QGIS.

    Le style reste posé pour la COULEUR : sans lui, QGIS attribue une teinte
    aléatoire à chaque couche, et P1 pouvait sortir en vert pâle. Rouge,
    orange et gris reprennent la sémantique des priorités de la couche
    `dolines`.

    Best-effort : ne fait jamais échouer la préparation.
    """
    # 2 mm pour les trois : la taille par defaut de QGIS, celle d'avant ce
    # chantier. Les tailles differenciees (3,2 / 2,8 / 2,6) ont ete ecartees
    # par l'auteur le 2026-08-10 en meme temps que les formes.
    formes = {
        "P1":       ("circle", "227,26,28,255",   "2"),
        "P2":       ("circle", "255,127,0,255",   "2"),
        "visitees": ("circle", "110,110,110,255", "2"),
    }
    if priorite not in formes:
        return
    forme, couleur, taille = formes[priorite]
    try:
        from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
        sym = QgsMarkerSymbol.createSimple({
            "name": forme,
            "color": couleur,
            "outline_color": "0,0,0,255",
            "outline_width": "0.3",
            "size": taille,
        })
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
    except Exception:
        pass


def _style_gouffres(vl) -> None:
    """Style la couche gouffres : catégorisée par ``interet`` (couleurs
    identiques à l'ancien ``_GOUFFRES_QML``), construite via l'API QGIS —
    même correctif que ``_style_dolines`` : le QML embarqué dans le gpkg
    définissait les symboles en ligne dans chaque ``<category>`` au lieu de
    les référencer depuis ``<symbols>`` (format non standard, catégories
    jamais résolues par QGIS), en plus du nom de colonne géométrie
    ``"geometry"`` codé en dur alors que pyogrio écrit ``"geom"`` — la
    coloration par intérêt n'a donc jamais fonctionné en pratique, ni via le
    `.qgs` ni en ouvrant le gpkg seul. -1 (non visité) reste bien visible
    (magenta) ; 0 (sans intérêt — inclut les faux positifs de canopée,
    cf. core/shafts.py) passe en gris atténué pour désencombrer les secteurs
    boisés sans jamais supprimer le point. Best-effort.
    """
    try:
        from qgis.core import QgsCategorizedSymbolRenderer, QgsMarkerSymbol, QgsRendererCategory
        # Tailles plafonnées à 2 mm (unité explicite : ne pas dépendre du
        # défaut QGIS), écarts relatifs conservés — au-delà, les points se
        # chevauchent en secteur boisé dense (des dizaines de milliers de
        # gouffres détectés sur un grand secteur, cf. core/shafts.py).
        categories_def = [
            (-1, "197,27,138,255", "100,0,60,255", "0.4", "1.5", 0.9, "Non visité"),
            (0,  "150,150,150,150", "90,90,90,180", "0.3", "1",  0.5, "Sans intérêt (dont canopée)"),
            (1,  "255,127,0,255",  "150,70,0,255",  "0.4", "1.75", 0.95, "Indice à creuser"),
            (2,  "214,47,39,255",  "100,0,0,255",   "0.4", "2",  0.95, "Cavité confirmée"),
        ]
        categories = []
        for value, color, outline, width, size, alpha, label in categories_def:
            sym = QgsMarkerSymbol.createSimple({
                "name": "circle", "color": color,
                "outline_color": outline, "outline_width": width,
                "size": size, "size_unit": "MM",
            })
            sym.setOpacity(alpha)
            categories.append(QgsRendererCategory(value, sym, label))
        vl.setRenderer(QgsCategorizedSymbolRenderer("interet", categories))
    except Exception:
        pass


def _style_contours(vl) -> None:
    """Style la couche courbes_niveau : lignes fines, maîtresses (maitresse=1)
    en gras avec étiquette de cote « NNN m ». Best-effort, jamais bloquant.
    """
    # ── Rendu : règle fine (intermédiaires) + règle épaisse (maîtresses) ──
    try:
        from qgis.core import QgsLineSymbol, QgsRuleBasedRenderer
        root_rule = QgsRuleBasedRenderer.Rule(None)
        inter = QgsLineSymbol.createSimple(
            {"line_color": "166,124,82,180", "line_width": "0.12"})
        maitr = QgsLineSymbol.createSimple(
            {"line_color": "120,80,40,255", "line_width": "0.45"})
        r1 = QgsRuleBasedRenderer.Rule(inter, filterExp='"maitresse" = 0',
                                       label="intermédiaire")
        r2 = QgsRuleBasedRenderer.Rule(maitr, filterExp='"maitresse" = 1',
                                       label="maîtresse")
        root_rule.appendChild(r1)
        root_rule.appendChild(r2)
        vl.setRenderer(QgsRuleBasedRenderer(root_rule))
    except Exception:
        pass

    # ── Étiquettes de cote, uniquement sur les courbes maîtresses ─────────
    try:
        from qgis.core import (
            QgsPalLayerSettings, QgsTextFormat, QgsRuleBasedLabeling,
        )
        pal = QgsPalLayerSettings()
        pal.fieldName = "format_number(\"ELEV\", 0) || ' m'"
        pal.isExpression = True
        # Placement le long de la ligne — l'enum a bougé entre QGIS 3 et 4.
        try:
            from qgis.core import Qgis
            pal.placement = Qgis.LabelPlacement.Line
        except Exception:
            try:
                pal.placement = QgsPalLayerSettings.Line
            except Exception:
                pass
        try:
            fmt = QgsTextFormat()
            fmt.setSize(8)
            pal.setFormat(fmt)
        except Exception:
            pass

        root_lbl = QgsRuleBasedLabeling.Rule(None)
        rule = QgsRuleBasedLabeling.Rule(pal)
        rule.setFilterExpression('"maitresse" = 1')
        root_lbl.appendChild(rule)
        vl.setLabeling(QgsRuleBasedLabeling(root_lbl))
        vl.setLabelsEnabled(True)
    except Exception:
        pass
    # NB : le style des courbes n'est PAS persiste dans le .gpkg
    # (saveStyleToDatabase ouvre le GeoPackage en mode WAL et laisse des
    # fichiers .gpkg-wal/.gpkg-shm). Le rendu vit donc uniquement dans le .qgs.


def _label_points(vl, field: str, autour: bool = False,
                  distance_mm: float = 2.5) -> None:
    """Étiquette une couche de points avec le contenu de ``field`` (ex. le
    toponyme d'une source). Halo blanc pour la lisibilité sur fond d'ombrage.
    Best-effort : ne fait jamais échouer la préparation.

    ``autour`` : placement AUTOUR du point plutôt qu'au-dessus. QGIS choisit
    alors la position libre la plus proche à ``distance_mm``, ce qui dégage le
    symbole. Nécessaire sur les cibles, où le décalage fixe de 2 mm laissait
    l'étiquette sur le point (constaté à l'impression le 2026-08-10). Les
    toponymes des points d'eau gardent le placement d'origine, qui convient.
    """
    try:
        from qgis.core import (
            QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
            QgsVectorLayerSimpleLabeling,
        )
        pal = QgsPalLayerSettings()
        pal.fieldName = field
        pal.isExpression = False
        try:
            from qgis.core import Qgis
            if autour:
                pal.placement = Qgis.LabelPlacement.AroundPoint
                pal.dist = distance_mm
            else:
                # Décale l'étiquette à côté du point (sinon elle se
                # superpose au symbole).
                pal.placement = Qgis.LabelPlacement.OverPoint
                pal.xOffset = 2.0
                pal.yOffset = -2.0
        except Exception:
            pass
        fmt = QgsTextFormat()
        fmt.setSize(8)
        try:
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(0.8)
            fmt.setBuffer(buf)
        except Exception:
            pass
        pal.setFormat(fmt)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
    except Exception:
        pass


def _add_fond_carte(proj, root, crs, decl, scan25_apikey=None) -> None:
    """Ajoute UN fond de carte décrit par déclaration (WMS ou WMTS).

    Remplace les quatre anciennes fonctions dédiées par fond de carte (ortho
    IGN, SCAN25, Plan IGN, ortho PNOA Espagne), qui ne différaient que par
    URL, couche, format et CRS. Le bug du 2026-08-02 (branche par préfixe de
    CRS écrite à la main) devient inexprimable ici : le CRS vient de la
    déclaration ou du projet.
    """
    try:
        from urllib.parse import quote
        from qgis.core import QgsRasterLayer

        p = decl.params
        if p.get("cle_requise") and not scan25_apikey:
            return                                   # produit payant sans clé

        # « auto » = le CRS de travail du projet. crs est un
        # QgsCoordinateReferenceSystem : authid() donne « EPSG:xxxx », alors que
        # str() donnerait « <QgsCoordinateReferenceSystem: EPSG:xxxx> » —
        # exactement le bug du 2026-08-02.
        code_crs = p["crs"] if p.get("crs") and p["crs"] != "auto" else crs.authid()

        if decl.type == "wmts":
            # L'`apikey` n'est PAS universelle : elle appartient au SCAN25 IGN,
            # produit payant. Un service ouvert comme CartoWeb (NGI belge)
            # recevrait « apikey=None » et refuserait ses capacités. Le service
            # publie par ailleurs son style — « normal » côté IGN, « default »
            # côté NGI —, donc il se déclare aussi.
            imbriquee = f"{p['url']}?SERVICE=WMTS&VERSION=1.0.0&REQUEST=GetCapabilities"
            if p.get("cle_requise"):
                imbriquee += f"&apikey={scan25_apikey}"
            uri = (
                "IgnoreGetFeatureInfoUrl=1&IgnoreGetMapUrl=1&"
                f"crs={code_crs}&dpiMode=0&featureCount=10&"
                f"format={p['format']}&layers={p['couche']}&"
                f"styles={p.get('style', 'normal')}&"
                f"tileMatrixSet={p['tile_matrix_set']}&tilePixelRatio=2&"
                f"url={quote(imbriquee, safe='')}"
            )
        else:
            # Un fond WMS peut demander PLUSIEURS sous-couches empilées (le PICC
            # wallon n'a pas de couche de fond unique). Le fournisseur WMS de
            # QGIS attend alors `layers=` RÉPÉTÉ, avec autant de `styles=` vides
            # — une liste séparée par des virgules donne une couche invalide,
            # « Cannot calculate extent », sans autre explication.
            couches = [c.strip() for c in str(p["couche"]).split(",") if c.strip()]
            empilement = "".join(f"&layers={c}&styles=" for c in couches)
            uri = (
                f"crs={code_crs}&dpiMode=7&format={p['format']}"
                f"{empilement}"
                f"&url={p['url']}"
            )

        rl = QgsRasterLayer(uri, p["titre"], "wms")
        if not rl.isValid():
            from qgis.core import Qgis, QgsMessageLog
            QgsMessageLog.logMessage(
                f"Fond « {p['titre']} » non chargé (couche invalide) : "
                f"{rl.error().summary()}", "KarstPro", level=Qgis.Warning)
            return
        rl.setCustomProperty("QFieldSync/action", "remove")
        proj.addMapLayer(rl, addToLegend=False)
        node = root.addLayer(rl)
        visible = p.get("visible", False)
        if p.get("cle_requise"):
            visible = True          # l'utilisateur a fourni sa clé : il veut la voir
        node.setItemVisibilityChecked(bool(visible))
    except Exception as exc:
        from qgis.core import Qgis, QgsMessageLog
        QgsMessageLog.logMessage(
            f"Fond de carte : exception à l'ajout ({exc}).",
            "KarstPro", level=Qgis.Warning)
        return


def _add_mnt_hillshade(proj, root, output_dir: Path, crs) -> None:
    """Ajoute le MNT (lidar_work/mnt.tif) en ombrage multidirectionnel au projet.

    - chemin relatif (portable),
    - rendu Hillshade multidirectionnel + reechantillonnage bilineaire au zoom,
    - opacite 70 % (laisse transparaitre le Plan IGN dessous),
    - place en bas de l'arbre (sous les vecteurs),
    - exclu du packaging QFieldSync (raster volumineux).
    Sans effet si le MNT est absent.
    """
    mnt_path = output_dir / "lidar_work" / "mnt.tif"
    if not mnt_path.exists():
        return
    try:
        from qgis.core import QgsRasterLayer, QgsHillshadeRenderer
        rl = QgsRasterLayer(str(mnt_path), "MNT (ombrage)", "gdal")
        if not rl.isValid():
            return
        rl.setCrs(crs)

        renderer = QgsHillshadeRenderer(rl.dataProvider(), 1, 315.0, 45.0)
        try:
            renderer.setMultiDirectional(True)
        except Exception:
            pass
        rl.setRenderer(renderer)

        # Reechantillonnage bilineaire au zoom avant (supprime l'effet pixelise)
        try:
            from qgis.core import QgsBilinearRasterResampler, Qgis
            rf = rl.resampleFilter()
            if rf is not None:
                rf.setZoomedInResampler(QgsBilinearRasterResampler())
            rl.setResamplingStage(Qgis.RasterResamplingStage.Provider)
        except Exception:
            pass

        # Opacite reduite : laisse transparaitre le Plan IGN (fond de carte)
        # sous l'ombrage, tout en gardant le relief lisible.
        try:
            rl.renderer().setOpacity(0.70)
        except Exception:
            pass

        # Exclut le raster du packaging QField *câble* (USB/cartouche).
        # NB : QFieldCloud ignore ce flag (cloud_converter copie tous les
        # rasters) — pour un paquet cloud léger, retirer la couche MNT du projet
        # avant le packaging.
        rl.setCustomProperty("QFieldSync/action", "remove")

        proj.addMapLayer(rl, addToLegend=False)
        # addLayer ajoute en fin de fratrie => bas de l'arbre => sous les vecteurs
        root.addLayer(rl)
    except Exception:
        # L'ombrage est un confort : ne jamais faire echouer la preparation pour ca
        return


# Conservé pour les tests unitaires hors QGIS
def _generate_qgs(name: str, gpkg_path: Path, layers: list,
                   target_crs: str = "EPSG:2154") -> str:
    """Génère un QGS minimal hors contexte QGIS (tests uniquement).

    Repli utilisé UNIQUEMENT quand ``qgis.core`` n'est pas importable
    (pytest/CLI hors QGIS) — jamais atteint en production dans le plugin, où
    ``_write_qgs_project`` (API QGIS) fait foi. Pour EPSG:2154, le WKT complet
    est codé en dur (cf. ``_WKT2_2154`` — pas de pyproj, non thread-safe dans
    QGIS). Pour un autre ``target_crs`` (ex. Espagne, EPSG:258XX), pas de WKT
    équivalent sourcé ici : on écrit un bloc ``<spatialrefsys>`` minimal basé
    sur l'``authid`` seul — QGIS résout un CRS EPSG standard depuis sa propre
    base ``proj`` à l'ouverture même sans WKT explicite dans le fichier.
    """
    if target_crs == "EPSG:2154":
        wkt = _WKT2_2154
        srs_xml = f"""    <spatialrefsys nativeFormat="Wkt">
      <wkt>{wkt}</wkt>
      <srid>2154</srid>
      <authid>EPSG:2154</authid>
      <description>RGF93 v1 / Lambert-93</description>
      <projectionacronym>lcc</projectionacronym>
      <ellipsoidacronym>EPSG:7019</ellipsoidacronym>
      <geographicflag>false</geographicflag>
    </spatialrefsys>"""
    else:
        srid = target_crs.split(":")[-1]
        srs_xml = f"""    <spatialrefsys>
      <srid>{srid}</srid>
      <authid>{target_crs}</authid>
      <description>{target_crs}</description>
      <geographicflag>false</geographicflag>
    </spatialrefsys>"""

    import re
    from xml.sax.saxutils import escape as _xesc

    def _xattr_esc(s):
        # Contexte attribut (entre guillemets doubles littéraux du template) :
        # échappe AUSSI le guillemet, sinon il termine l'attribut prématurément.
        return _xesc(s, {'"': "&quot;"})

    EDITABLE = {"cavites"}
    # Doit rester synchronisé avec _write_qgs_project (repli hors contexte
    # QGIS) : `dolines` visible depuis qu'elle porte la couleur de priorité et
    # l'anneau du signal ponctuel.
    HIDDEN_BY_DEFAULT = {"dolines", "hydrologie", "geologie"}
    # `dolines` : 6 437 polygones contre 65 cibles P1 sur Rochefort — cochée,
    # la couche noie la carte à l'ouverture. Elle était masquée jusqu'en
    # v1.11.0, où elle a été décochée de cette liste sans que la docstring
    # suive ; rétablie le 2026-08-10. Reste visible dans la carte
    # morphologique imprimée, qui ne lit pas l'état coché.

    def _slug(s):
        return re.sub(r"[^a-zA-Z0-9]", "_", s)

    # Chemin relatif : le .qgs et le .gpkg sont dans le même dossier.
    gpkg_posix = Path(gpkg_path).name
    layer_parts, tree_parts = [], []
    # Secteur/nom : texte libre (saisi ou géocodé), jamais garanti bien formé
    # en XML — un '&', '<', '>' ou '"' non échappé produirait un .qgs corrompu
    # que QGIS ouvre mal ou pas du tout.
    name_esc = _xesc(name)
    gpkg_posix_esc = _xesc(gpkg_posix)

    for layer in layers:
        # ID stable (pas d'UUID) — les noms de couches sont uniques dans un projet.
        lid = _slug(layer)
        display_name = layer if layer.startswith(name) else f"{name} — {layer}"
        display_name_esc = _xesc(display_name)
        display_name_attr = _xattr_esc(display_name)
        layer_esc = _xesc(layer)
        # Action de sync UNIFORME (offline) sur toutes les couches du gpkg :
        # une action mixte (offline/readonly) dans un même fichier fait échouer
        # la création du paquet QFieldSync (« conflicting sync actions »). La
        # consultation seule passe par le drapeau natif readOnly, pas l'action.
        # cibles + gouffres = éditables form-only (saisie interet) mais SANS
        # capture GPS ; cavites = éditables avec GPS ; reste = consultation (RO).
        gps_capture = layer in EDITABLE
        editable = (gps_capture or _is_cibles(layer) or _is_gouffres(layer)
                    or _is_cibles_visitees(layer))
        gps = '\n        <property key="QFieldSync/geomSource" value="gps"/>' if gps_capture else ""
        ro_attr = "" if editable else ' readOnly="1"'
        checked = "Qt::Unchecked" if (layer in HIDDEN_BY_DEFAULT or layer.endswith("cibles P3")) else "Qt::Checked"

        layer_parts.append(f"""    <maplayer type="vector"{ro_attr}>
      <id>{lid}</id>
      <layername>{display_name_esc}</layername>
      <datasource>{gpkg_posix_esc}|layername={layer_esc}</datasource>
      <provider>ogr</provider>
      <srs>{srs_xml}</srs>
      <customproperties>
        <property key="QFieldSync/action" value="offline"/>{gps}
      </customproperties>
    </maplayer>""")
        tree_parts.append(
            f'    <layer-tree-layer checked="{checked}" id="{lid}" name="{display_name_attr}" expanded="1"/>'
        )

    return f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34">
  <title>{name_esc} — KarstPro</title>
  <projectCrs>{srs_xml}</projectCrs>
  <layer-tree-group name="" checked="Qt::Checked" expanded="1">
    <custom-order enabled="0"/>
{chr(10).join(tree_parts)}
  </layer-tree-group>
  <projectlayers>
{chr(10).join(layer_parts)}
  </projectlayers>
</qgis>"""


