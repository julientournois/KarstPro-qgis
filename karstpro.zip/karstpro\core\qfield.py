# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from typing import Optional
import geopandas as gpd
import sqlite3


def package_qfield_project(secteur_name: str,
                            dolines: gpd.GeoDataFrame,
                            cavites: gpd.GeoDataFrame,
                            output_dir: Path,
                            reseau: Optional[gpd.GeoDataFrame] = None,
                            geology: Optional[gpd.GeoDataFrame] = None,
                            topo: Optional[gpd.GeoDataFrame] = None,
                            cavites_georisques: Optional[gpd.GeoDataFrame] = None,
                            contours: Optional[gpd.GeoDataFrame] = None,
                            gouffres: Optional[gpd.GeoDataFrame] = None,
                            points_eau: Optional[gpd.GeoDataFrame] = None,
                            external_layers: Optional[list] = None,
                            zoom_extent: Optional[tuple] = None,
                            scan25_apikey: Optional[str] = None) -> dict:
    """``external_layers`` : couches inventaire référencées (NON copiées) dans le
    projet, en lecture seule QField. Liste de dicts ``{"gpkg", "layer", "name"}``
    (cavités connues, traçages). Permet de garder l'inventaire dans son fichier
    partagé sans le dupliquer dans le package.

    ``scan25_apikey`` : clé API SCAN25 **personnelle** de l'utilisateur (produit
    payant IGN, jamais fournie par KarstPro). Si renseignée, ajoute la carte
    SCAN25 au projet ; sinon aucun effet (couche non ajoutée)."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    gpkg_path = output_dir / f"{secteur_name}.gpkg"

    from karstpro.core.gpkg import _make_empty_layer, CIBLES_SCHEMA, ARCHIVE_SCHEMA

    p1_name = f"{secteur_name} — cibles P1"
    p2_name = f"{secteur_name} — cibles P2"
    p3_name = f"{secteur_name} — cibles P3"
    visitees_name = f"{secteur_name} — cibles visitées"
    layers = ["dolines", "cavites", p1_name, p2_name, p3_name, visitees_name]
    dolines.to_file(gpkg_path, layer="dolines", driver="GPKG")
    cavites.to_file(gpkg_path, layer="cavites", driver="GPKG")
    # Couches cibles vides — peuplées immédiatement depuis les dolines scorées,
    # puis éventuellement remplacées par l'export MLL (ordre de visite optimal)
    empty_cibles = _make_empty_layer(CIBLES_SCHEMA, crs="EPSG:2154", geom_type="Point")
    empty_cibles.to_file(gpkg_path, layer=p1_name, driver="GPKG")
    empty_cibles.to_file(gpkg_path, layer=p2_name, driver="GPKG")
    empty_cibles.to_file(gpkg_path, layer=p3_name, driver="GPKG")
    # Archive des cibles déjà prospectées (vide à la création). SANS index
    # spatial : les triggers rtree de GDAL appellent des fonctions ST absentes du
    # sqlite3 pur, ce qui ferait échouer les INSERT du report de cibles
    # (core/cibles_carryover.py). Couche petite — l'index est superflu.
    _make_empty_layer(ARCHIVE_SCHEMA, crs="EPSG:2154", geom_type="Point").to_file(
        gpkg_path, layer=visitees_name, driver="GPKG", SPATIAL_INDEX="NO")
    # Couches de prospection, groupées juste sous les cibles, dans l'ordre
    # demandé : … P3 → Gouffres → Géorisques → bdtopo_eau.
    if gouffres is not None and not gouffres.empty:
        # `interet` + `comment` + `photos` : bookkeeping terrain (cocher l'état
        # d'un gouffre visité, prendre une photo), éditables au formulaire QField
        # comme les cibles. Les gouffres SONT des cibles de terrain qu'on visite
        # — d'où la photo. PAS de boucle ML ici — pas de modèle gouffre à
        # réentraîner (cf. dolines).
        gouffres = gouffres.copy()
        if "interet" not in gouffres.columns:
            gouffres["interet"] = -1
        if "comment" not in gouffres.columns:
            gouffres["comment"] = ""
        if "photos" not in gouffres.columns:
            gouffres["photos"] = ""    # photo terrain (widget ExternalResource)
        gouffres.to_file(gpkg_path, layer="gouffres", driver="GPKG")
        layers.append("gouffres")
    # cavites_connues / tracages ne sont plus copiés ici : ils sont référencés
    # depuis leur gpkg inventaire externe via external_layers (read-only QField).
    if cavites_georisques is not None and not cavites_georisques.empty:
        cavites_georisques.to_file(gpkg_path, layer="cavites_georisques", driver="GPKG")
        layers.append("cavites_georisques")
    if points_eau is not None and not points_eau.empty:
        # Renommée « bdtopo_eau » : signale qu'il s'agit de référencement
        # BD Topo (donnée déjà cartographiée), pas de détection.
        points_eau.to_file(gpkg_path, layer="bdtopo_eau", driver="GPKG")
        layers.append("bdtopo_eau")
    # Couches de contexte (sous la prospection dans la légende).
    if reseau is not None and not reseau.empty:
        reseau.to_file(gpkg_path, layer="hydrologie", driver="GPKG")
        layers.append("hydrologie")
    if geology is not None and not geology.empty:
        geology.to_file(gpkg_path, layer="geologie", driver="GPKG")
        layers.append("geologie")
    if topo is not None and not topo.empty:
        topo.to_file(gpkg_path, layer="topo_reseau", driver="GPKG")
        layers.append("topo_reseau")
    if contours is not None and not contours.empty:
        contours.to_file(gpkg_path, layer="courbes_niveau", driver="GPKG")
        layers.append("courbes_niveau")

    # Force le type géométrie déclaré des couches éditables vides : pyogrio
    # écrit « GEOMETRY » (générique) sur une couche sans entité, ce qui empêche
    # QField de capturer la position GPS (entités sans géométrie). cf. gpkg.py.
    from karstpro.core.gpkg import _force_gpkg_geom_types
    _force_gpkg_geom_types(gpkg_path, {"cavites": "POINT", visitees_name: "POINT"})

    # Embed QGIS layer styles in GeoPackage (layer_styles table)
    # QGIS reads these automatically when the .gpkg is opened
    _embed_styles(gpkg_path)
    _fix_gpkg_crs(gpkg_path)

    qgs_path = output_dir / f"{secteur_name}.qgs"
    try:
        _write_qgs_project(secteur_name, gpkg_path, layers, qgs_path,
                           zoom_extent=zoom_extent,
                           external_layers=external_layers,
                           scan25_apikey=scan25_apikey)
    except ImportError:
        # Hors contexte QGIS (tests, CLI) — on génère le QGS sans l'API QGIS.
        qgs_path.write_text(
            _generate_qgs(secteur_name, gpkg_path, layers), encoding="utf-8"
        )

    return {"gpkg": gpkg_path, "qgs": qgs_path}


def write_cibles_from_scored_dolines(
    gpkg_path: Path,
    secteur_name: str,
    scored_dolines: gpd.GeoDataFrame,
) -> tuple[int, int, int]:
    """
    Écrit les couches ``{secteur} — cibles P1`` (rouge), ``P2`` (orange)
    et ``P3`` (jaune) dans le GeoPackage à partir des dolines scorées.

    Appelé directement depuis karst_prep_algorithm après le calcul des scores,
    sans passer par l'export MLL.  L'export MLL peut ensuite remplacer
    ces couches avec un ordre de visite optimisé.

    Returns
    -------
    (n_p1, n_p2, n_p3) : nombre de cibles écrites dans chaque couche.
    """
    from shapely.geometry import Point

    p1_name = f"{secteur_name} — cibles P1"
    p2_name = f"{secteur_name} — cibles P2"
    p3_name = f"{secteur_name} — cibles P3"

    def _build_cibles_gdf(subset: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        """Convertit un sous-ensemble de dolines en couche de cibles (points).

        Centroïde + attributs résumés (name=doline_fid, score, priorite…),
        au schéma CIBLES_SCHEMA attendu par QField.
        """
        rows = []
        for _, row in subset.iterrows():
            centroid = row.geometry.centroid if row.geometry else None
            if centroid is None:
                continue
            rows.append({
                # row.name = index 0-based ; +1 pour coller au fid GPKG (1-based)
                # de la couche dolines et a l'export MLL. ID unique partout.
                "name": f"doline_{row.name + 1}",
                "priorite": row.get("priorite", ""),
                "score": row.get("score"),
                "score_morpho": row.get("score_morpho"),
                "score_positionnel": row.get("score_positionnel"),
                "surface_m2": row.get("surface_m2"),
                "profondeur_m": row.get("profondeur_m"),
                "ratio_ps": row.get("ratio_ps"),
                "pente_max_bord": row.get("pente_max_bord"),
                "lisere": bool(row.get("lisere", False)),
                "type": "",
                "developpement_estime": None,
                "topographiable": 0,
                "lien_topo": "",
                "comment": "",
                "photos": "",    # photo terrain (widget ExternalResource QField)
                "interet": -1,   # non visité (saisi sur le terrain : 0/1/2)
                "geometry": Point(centroid.x, centroid.y),
            })
        return gpd.GeoDataFrame(rows, crs="EPSG:2154") if rows else None

    if "priorite" not in scored_dolines.columns:
        return (0, 0, 0)
    rouges  = scored_dolines[scored_dolines["priorite"] == "rouge"]
    oranges = scored_dolines[scored_dolines["priorite"] == "orange"]
    jaunes  = scored_dolines[scored_dolines["priorite"] == "jaune"]

    gdf_p1 = _build_cibles_gdf(rouges)
    gdf_p2 = _build_cibles_gdf(oranges)
    gdf_p3 = _build_cibles_gdf(jaunes)

    if gdf_p1 is not None:
        gdf_p1.to_file(str(gpkg_path), layer=p1_name, driver="GPKG",
                       layer_options={"OVERWRITE": "YES"})
    if gdf_p2 is not None:
        gdf_p2.to_file(str(gpkg_path), layer=p2_name, driver="GPKG",
                       layer_options={"OVERWRITE": "YES"})
    if gdf_p3 is not None:
        gdf_p3.to_file(str(gpkg_path), layer=p3_name, driver="GPKG",
                       layer_options={"OVERWRITE": "YES"})

    _fix_gpkg_crs(gpkg_path)
    return (len(rouges), len(oranges), len(jaunes))


# WKT EPSG:2154 codés en dur (au lieu de pyproj.CRS.from_epsg, qui appelle
# proj_create — NON thread-safe dans QGIS 4.0.2 : access violation au 2e
# lancement d'un algorithme dans le même processus). Le CRS du plugin est
# toujours Lambert-93 ; ces chaînes sont fixes.
_WKT2_2154 = ('PROJCRS["RGF93 v1 / Lambert-93",BASEGEOGCRS["RGF93 v1",DATUM["Reseau Geodesique Francais 1993 v1",ELLIPSOID["GRS 1980",6378137,298.257222101,LENGTHUNIT["metre",1]]],PRIMEM["Greenwich",0,ANGLEUNIT["degree",0.0174532925199433]],ID["EPSG",4171]],CONVERSION["Lambert-93",METHOD["Lambert Conic Conformal (2SP)",ID["EPSG",9802]],PARAMETER["Latitude of false origin",46.5,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8821]],PARAMETER["Longitude of false origin",3,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8822]],PARAMETER["Latitude of 1st standard parallel",49,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8823]],PARAMETER["Latitude of 2nd standard parallel",44,ANGLEUNIT["degree",0.0174532925199433],ID["EPSG",8824]],PARAMETER["Easting at false origin",700000,LENGTHUNIT["metre",1],ID["EPSG",8826]],PARAMETER["Northing at false origin",6600000,LENGTHUNIT["metre",1],ID["EPSG",8827]]],CS[Cartesian,2],AXIS["easting (X)",east,ORDER[1],LENGTHUNIT["metre",1]],AXIS["northing (Y)",north,ORDER[2],LENGTHUNIT["metre",1]],USAGE[SCOPE["Engineering survey, topographic mapping."],AREA["France - onshore and offshore, mainland and Corsica (France métropolitaine including Corsica)."],BBOX[41.15,-9.86,51.56,10.38]],ID["EPSG",2154]]')
_WKT1_2154 = ('PROJCS["RGF93 v1 / Lambert-93",GEOGCS["RGF93 v1",DATUM["Reseau_Geodesique_Francais_1993_v1",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],AUTHORITY["EPSG","6171"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4171"]],PROJECTION["Lambert_Conformal_Conic_2SP"],PARAMETER["latitude_of_origin",46.5],PARAMETER["central_meridian",3],PARAMETER["standard_parallel_1",49],PARAMETER["standard_parallel_2",44],PARAMETER["false_easting",700000],PARAMETER["false_northing",6600000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],AUTHORITY["EPSG","2154"]]')


def _fix_gpkg_crs(gpkg_path: Path) -> None:
    """Force l'entrée EPSG:2154 correcte dans gpkg_spatial_ref_sys.

    Fiona/GDAL écrit parfois srs_id=99999 organization=NONE pour EPSG:2154,
    ce que QGIS 4 ne reconnaît pas. On insère/remplace l'entrée standard
    avec les WKT codés en dur (pas pyproj — voir _WKT2_2154).
    """
    wkt2 = _WKT2_2154
    wkt1 = _WKT1_2154

    with sqlite3.connect(gpkg_path) as con:
        cur = con.cursor()
        # Vérifier si la colonne definition_12_063 existe (GPKG >= 1.2.1)
        cols = {row[1] for row in cur.execute("PRAGMA table_info(gpkg_spatial_ref_sys)")}
        if "definition_12_063" in cols:
            cur.execute("""
                INSERT OR REPLACE INTO gpkg_spatial_ref_sys
                    (srs_name, srs_id, organization, organization_coordsys_id,
                     definition, definition_12_063)
                VALUES (?, ?, ?, ?, ?, ?)
            """, ("RGF93 v1 / Lambert-93", 2154, "EPSG", 2154, wkt1, wkt2))
        else:
            cur.execute("""
                INSERT OR REPLACE INTO gpkg_spatial_ref_sys
                    (srs_name, srs_id, organization, organization_coordsys_id, definition)
                VALUES (?, ?, ?, ?, ?)
            """, ("RGF93 v1 / Lambert-93", 2154, "EPSG", 2154, wkt1))

        cur.execute("UPDATE gpkg_geometry_columns SET srs_id=2154 WHERE srs_id=99999")
        cur.execute("UPDATE gpkg_contents SET srs_id=2154 WHERE srs_id=99999")
        con.commit()


def _embed_styles(gpkg_path: Path) -> None:
    """Writes QGIS layer styles into the GeoPackage layer_styles table."""
    with sqlite3.connect(gpkg_path) as con:
        cur = con.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS layer_styles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                f_table_catalog TEXT, f_table_schema TEXT, f_table_name TEXT,
                f_geometry_column TEXT, styleName TEXT, styleQML TEXT,
                styleSLD TEXT, useAsDefault INTEGER, description TEXT,
                owner TEXT, ui TEXT, update_time DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("DELETE FROM layer_styles WHERE f_table_name = 'dolines'")
        cur.execute(
            "INSERT INTO layer_styles "
            "(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, "
            " styleName, styleQML, useAsDefault) VALUES (?,?,?,?,?,?,?)",
            ("", "", "dolines", "geometry", "priorite", _DOLINES_QML, 1),
        )
        cur.execute("DELETE FROM layer_styles WHERE f_table_name = 'gouffres'")
        cur.execute(
            "INSERT INTO layer_styles "
            "(f_table_catalog, f_table_schema, f_table_name, f_geometry_column, "
            " styleName, styleQML, useAsDefault) VALUES (?,?,?,?,?,?,?)",
            ("", "", "gouffres", "geometry", "interet", _GOUFFRES_QML, 1),
        )
        con.commit()


# QML categorized renderer for dolines — colours by priorite field
_DOLINES_QML = """<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" styleCategories="Symbology">
  <renderer-v2 type="categorizedSymbol" attr="priorite" forceraster="0" symbollevels="0" enableorderby="0">
    <categories>
      <category value="rouge" label="Rouge — très fort intérêt" render="true">
        <symbol type="fill" name="rouge" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="214,47,39,217"/>
              <Option name="outline_color" type="QString" value="100,0,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="orange" label="Orange — bon intérêt" render="true">
        <symbol type="fill" name="orange" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="255,127,0,217"/>
              <Option name="outline_color" type="QString" value="150,70,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="jaune" label="Jaune — intérêt modéré" render="true">
        <symbol type="fill" name="jaune" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="255,215,0,217"/>
              <Option name="outline_color" type="QString" value="150,120,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="gris" label="Gris — faible intérêt" render="true">
        <symbol type="fill" name="gris" clip_to_extent="1" alpha="0.85" force_rhr="0">
          <data_defined_properties><Option type="Map"><Option name="name" type="QString" value=""/><Option name="properties"/><Option name="type" type="QString" value="collection"/></Option></data_defined_properties>
          <layer class="SimpleFill" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="150,150,150,180"/>
              <Option name="outline_color" type="QString" value="80,80,80,255"/>
              <Option name="outline_width" type="QString" value="0.3"/>
              <Option name="style" type="QString" value="solid"/>
            </Option>
          </layer>
        </symbol>
      </category>
    </categories>
    <symbols/>
  </renderer-v2>
</qgis>"""


# QML categorized renderer for gouffres — colours by interet field.
# -1 (non visité) reste bien visible (magenta, le rendu par défaut avant ce
# style) ; 0 (sans intérêt — inclut les faux positifs de canopée marqués par
# flag_vegetation) passe en gris atténué, pour désencombrer visuellement les
# secteurs boisés sans jamais supprimer le point (réversible sur le terrain).
_GOUFFRES_QML = """<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34" styleCategories="Symbology">
  <renderer-v2 type="categorizedSymbol" attr="interet" forceraster="0" symbollevels="0" enableorderby="0">
    <categories>
      <category value="-1" label="Non visité" render="true">
        <symbol type="marker" name="non_visite" clip_to_extent="1" alpha="0.9" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="197,27,138,255"/>
              <Option name="outline_color" type="QString" value="100,0,60,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="size" type="QString" value="3"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="0" label="Sans intérêt (dont canopée)" render="true">
        <symbol type="marker" name="sans_interet" clip_to_extent="1" alpha="0.5" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="150,150,150,150"/>
              <Option name="outline_color" type="QString" value="90,90,90,180"/>
              <Option name="outline_width" type="QString" value="0.3"/>
              <Option name="size" type="QString" value="2"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="1" label="Indice à creuser" render="true">
        <symbol type="marker" name="indice" clip_to_extent="1" alpha="0.95" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="255,127,0,255"/>
              <Option name="outline_color" type="QString" value="150,70,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="size" type="QString" value="3.5"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
      <category value="2" label="Cavité confirmée" render="true">
        <symbol type="marker" name="cavite" clip_to_extent="1" alpha="0.95" force_rhr="0">
          <layer class="SimpleMarker" enabled="1" pass="0" locked="0">
            <Option type="Map">
              <Option name="color" type="QString" value="214,47,39,255"/>
              <Option name="outline_color" type="QString" value="100,0,0,255"/>
              <Option name="outline_width" type="QString" value="0.4"/>
              <Option name="size" type="QString" value="4"/>
              <Option name="name" type="QString" value="circle"/>
            </Option>
          </layer>
        </symbol>
      </category>
    </categories>
    <symbols/>
  </renderer-v2>
</qgis>"""


def _is_cibles(layer_name: str) -> bool:
    """True pour les couches de cibles terrain « … — cibles P1/P2/P3 »."""
    return "cibles P" in layer_name


def _is_gouffres(layer_name: str) -> bool:
    """True pour la couche gouffres — éditable form-only (bookkeeping terrain)."""
    return layer_name == "gouffres"


def _is_cibles_visitees(layer_name: str) -> bool:
    """True pour l'archive « … — cibles visitées » — éditable form-only
    (corriger un verdict mal saisi sur une cible déjà prospectée)."""
    return layer_name.endswith("cibles visitées")


# Saisie `interet` : libellé → valeur stockée (la boucle de labels P3).
_INTERET_MAP = [
    {"Non visité": "-1"},
    {"Visité — rien": "0"},
    {"Indice à creuser": "1"},
    {"Cavité": "2"},
]
# Champs que l'opérateur peut modifier sur le terrain ; tout le reste (score,
# priorité, morphométrie…) est verrouillé pour ne pas être altéré. Commun aux
# cibles (boucle de labels) et aux gouffres (bookkeeping de visite).
_INTERET_EDITABLE_FIELDS = {"interet", "comment", "photos"}


def _configure_photo_widget(vl) -> None:
    """Active la prise de photo QField sur le champ ``photos`` (v1 : une photo).

    Widget **ExternalResource** : QField affiche un bouton appareil photo, prend
    la photo, l'enregistre comme fichier et stocke son **chemin relatif** au
    projet dans le champ. Au retour QFieldCloud, le fichier revient avec le
    projet (mécanisme de pièces jointes). Le rapport PDF intègre ensuite l'image.

    ⚠️ L'emplacement exact de stockage côté QField (DCIM/…) peut nécessiter un
    ajustement après test réel ; on pose ici une config relative robuste.
    Best-effort, jamais bloquant.
    """
    try:
        from qgis.core import QgsEditorWidgetSetup
        idx = vl.fields().indexOf("photos")
        if idx < 0:
            return
        cfg = {
            "StorageMode": 0,        # 0 = fichier
            "RelativeStorage": 1,    # 1 = chemin relatif au projet (portable)
            "DocumentViewer": 1,     # 1 = image (miniature dans la fiche)
            "DocumentViewerHeight": 0,
            "DocumentViewerWidth": 0,
            "FileWidget": True,
            "FileWidgetButton": True,
            "FileWidgetFilter": "",
        }
        vl.setEditorWidgetSetup(idx, QgsEditorWidgetSetup("ExternalResource", cfg))
    except Exception:
        return


def _configure_interet_form(vl) -> None:
    """Rend une couche éditable en **formulaire seul** : tous les champs en
    lecture seule sauf `interet`/`comment`, et widget liste pour `interet`. La
    géométrie n'est pas recapturée (pas de geomSource=gps). Utilisé par les
    cibles (labels terrain) et la couche gouffres (bookkeeping de visite)."""
    from qgis.core import QgsEditorWidgetSetup

    fields = vl.fields()
    efc = vl.editFormConfig()
    for i in range(fields.count()):
        efc.setReadOnly(i, fields.at(i).name() not in _INTERET_EDITABLE_FIELDS)
    vl.setEditFormConfig(efc)

    idx = fields.indexOf("interet")
    if idx >= 0:
        vl.setEditorWidgetSetup(idx, QgsEditorWidgetSetup(
            "ValueMap", {"map": _INTERET_MAP}))


def _write_qgs_project(name: str, gpkg_path: Path, layers: list,
                        qgs_path: Path, zoom_extent=None,
                        external_layers: list = None,
                        scan25_apikey: str = None) -> None:
    """Écrit le projet QGIS via l'API QgsProject — garantit un CRS correct.

    Couches éditables (cavites) : QFieldSync action=offline + geomSource=gps.
    Couches consultation : action=offline (uniforme, sinon QFieldSync refuse le
    paquet pour « conflicting sync actions » sur un même gpkg) + setReadOnly.
    Couches masquées par défaut : dolines, hydrologie, geologie, cibles P3.
    """
    from qgis.core import (
        QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem,
        QgsRectangle, QgsFieldConstraints,
    )

    EDITABLE = {"cavites"}
    HIDDEN_BY_DEFAULT = {"dolines", "hydrologie", "geologie"}

    gpkg_str = str(gpkg_path)
    crs = QgsCoordinateReferenceSystem("EPSG:2154")

    proj = QgsProject()
    proj.setCrs(crs)
    proj.setTitle(f"{name} — KarstPro")
    # Chemins relatifs → le .qgs et le .gpkg restent portables sur toute machine.
    # writeEntry("Paths","/Absolute",False) est l'API stable QGIS 3.x/4.x.
    proj.writeEntry("Paths", "/Absolute", False)

    root = proj.layerTreeRoot()
    # Vider l'arbre par défaut
    root.removeAllChildren()

    extent_dolines = None  # repli si zoom_extent absent

    for layer_name in layers:
        display_name = layer_name if layer_name.startswith(name) else f"{name} — {layer_name}"
        uri = f"{gpkg_str}|layername={layer_name}"
        vl = QgsVectorLayer(uri, display_name, "ogr")
        if not vl.isValid():
            continue
        vl.setCrs(crs)

        # Propriétés QFieldSync
        if layer_name in EDITABLE:
            vl.setCustomProperty("QFieldSync/action", "offline")
            vl.setCustomProperty("QFieldSync/geomSource", "gps")
            # Contrainte dure : interdit d'enregistrer une entité sans
            # géométrie. Sans ça, QField laisse valider le formulaire même si
            # le GPS est coupé ou sans fix (couvert forestier en karst) → des
            # points fantômes (attributs OK, position NULL) qu'on ne voit qu'au
            # bureau. QField applique les contraintes de champ dures (blocage
            # du commit). On la pose sur le champ "name" (sinon le 1er champ).
            fields = vl.fields()
            idx = fields.indexOf("name")
            if idx < 0 and fields.count() > 0:
                idx = 0
            if idx >= 0:
                vl.setConstraintExpression(
                    idx, "$geometry IS NOT NULL",
                    "Position GPS obligatoire : activez la localisation "
                    "avant d'enregistrer",
                )
                vl.setFieldConstraint(
                    idx, QgsFieldConstraints.ConstraintExpression,
                    QgsFieldConstraints.ConstraintStrengthHard,
                )
            # Prise de photo QField sur le champ `photos` (v1 : une photo).
            _configure_photo_widget(vl)
        elif (_is_cibles(layer_name) or _is_gouffres(layer_name)
              or _is_cibles_visitees(layer_name)):
            # Cibles P1/P2/P3 (boucle de labels terrain), gouffres (bookkeeping)
            # ET cibles visitées (corriger un verdict) : éditables en **formulaire
            # seul** (saisie `interet` / `comment`). PAS de geomSource=gps : la
            # géométrie est déjà posée
            # (centroïde de doline / point de gouffre), on ne la recapture pas.
            # Action offline uniforme (pas de conflit), PAS de setReadOnly : la
            # couche reste éditable. Tous les autres champs (score, priorité,
            # morphométrie du vide) sont verrouillés. Widget liste pour `interet`.
            vl.setCustomProperty("QFieldSync/action", "offline")
            _configure_interet_form(vl)
            # Photo terrain sur les cibles (sans effet sur gouffres, sans champ).
            _configure_photo_widget(vl)
        else:
            # Consultation seule. **Même action de sync que cavites** (offline) :
            # toutes les couches partagent le fichier Marnaval.gpkg, et QFieldSync
            # refuse de créer le paquet si des couches d'un même fichier ont des
            # actions différentes (« conflicting sync actions »). On garde donc
            # une action uniforme et on rend la couche non éditable via le drapeau
            # natif QGIS setReadOnly — l'éditabilité ≠ l'action de sync.
            vl.setCustomProperty("QFieldSync/action", "offline")
            vl.setReadOnly(True)

        if layer_name == "courbes_niveau":
            _style_contours(vl)
        if layer_name == "bdtopo_eau":
            _label_points(vl, "toponyme")
        if layer_name == "geologie":
            _style_geology_brgm(vl)

        # Repli pour le zoom initial si zoom_extent n'est pas fourni
        if layer_name == "dolines" and vl.featureCount() > 0:
            extent_dolines = vl.extent()

        proj.addMapLayer(vl, addToLegend=False)
        node = root.addLayer(vl)
        if layer_name in HIDDEN_BY_DEFAULT or layer_name.endswith("cibles P3"):
            node.setItemVisibilityChecked(False)

    # ── Couches inventaire externes (cavités connues, traçages) ────────────
    # Référencées depuis leur gpkg partagé (NON copiées), lecture seule QField.
    # QFieldSync en fera un snapshot dans le paquet cloud ; au bureau elles
    # pointent l'inventaire vivant.
    for ext in (external_layers or []):
        ext_path = ext.get("gpkg")
        ext_layer = ext.get("layer")
        if not ext_path or not ext_layer:
            continue
        uri = f"{ext_path}|layername={ext_layer}"
        disp = ext.get("name") or ext_layer
        vl = QgsVectorLayer(uri, disp, "ogr")
        if not vl.isValid():
            continue
        # Conserve la symbologie de l'inventaire : style embarqué dans le gpkg
        # (table layer_styles) ou .qml voisin. Sans ça, QField applique un style
        # par défaut et la symbologie soignée de l'inventaire / des traçages est
        # perdue. loadDefaultStyle() la fige dans le .qgs, qui voyage ensuite.
        try:
            vl.loadDefaultStyle()
        except Exception:
            pass
        vl.setCustomProperty("QFieldSync/action", "readonly")
        vl.setReadOnly(True)   # consultation seule (chaque inventaire = fichier
                               # distinct, donc pas de conflit d'action partagée)
        proj.addMapLayer(vl, addToLegend=False)
        root.addLayer(vl)

    # ── MNT en ombrage (relief gris pour reperer dolines/depressions) ──────
    # Reference relative lidar_work/mnt.tif ; place sous les couches vecteur.
    # Toujours ajouté. Pour un paquet QFieldCloud léger (qui ignore le flag
    # QFieldSync/cloud_action=remove), l'utilisateur retire la couche MNT du
    # projet avant le packaging.
    _add_mnt_hillshade(proj, root, gpkg_path.parent, crs)

    # ── Fond ortho IGN (satellite) entre l'ombrage et le Plan IGN ──────────
    # Décoché par défaut : présent dans l'arbre, l'utilisateur l'active à la
    # demande. Placé sous l'ombrage MNT (70 %) → vue « satellite + relief »
    # une fois coché, et au-dessus du Plan IGN qu'il masque alors.
    _add_ortho_ign(proj, root, crs)

    # ── Fond SCAN25 (carte IGN classique 1/25 000) — SI clé fournie ─────────
    # Produit payant IGN : n'ajoute la couche que si l'utilisateur a fourni sa
    # propre clé (aucune clé n'est embarquée dans KarstPro). Cochée par défaut
    # (l'utilisateur qui renseigne sa clé veut la voir) ; le Plan IGN gratuit
    # est alors décoché en correspondance pour éviter deux fonds de carte
    # actifs par défaut.
    if scan25_apikey:
        _add_scan25_ign(proj, root, crs, scan25_apikey)

    # ── Fond de plan IGN (WMS) tout en bas, sous l'ombrage MNT ─────────────
    _add_plan_ign(proj, root, crs, visible=not scan25_apikey)

    # ── Vue initiale : zoom sur les cibles P1 (sinon emprise des dolines) ──
    # Évite d'ouvrir le projet sur une zone vide. zoom_extent = (minx,miny,maxx,maxy)
    # en L93, fourni par la préparation (les couches P1 sont vides à ce stade).
    initial = None
    if zoom_extent is not None:
        try:
            initial = QgsRectangle(*[float(v) for v in zoom_extent])
        except Exception:
            initial = None
    if (initial is None or initial.isEmpty()) and extent_dolines is not None:
        initial = extent_dolines
    if initial is not None and not initial.isEmpty():
        try:
            from qgis.core import QgsReferencedRectangle
            ext = QgsRectangle(initial)
            margin = max(ext.width(), ext.height()) * 0.15
            ext.grow(margin if margin > 0 else 250.0)
            proj.viewSettings().setDefaultViewExtent(
                QgsReferencedRectangle(ext, crs))
        except Exception:
            pass

    proj.write(str(qgs_path))

    # QgsProject.write() crée des fichiers auxiliaires parasites — on les supprime.
    for pattern in ("*_styles.db", "*_attachments.zip"):
        for f in qgs_path.parent.glob(pattern):
            f.unlink(missing_ok=True)


def _style_geology_brgm(vl) -> None:
    """Symbologie BD Charm-50 : remplissage catégorisé par NOTATION aux couleurs
    officielles BRGM (colonnes CMJN C_FOND/M_FOND/J_FOND/N_FOND, échelle 0-100).

    Reproduit la carte géologique de référence. Repli sur une rampe HSV distincte
    par NOTATION si les colonnes couleur sont absentes (cas du WFS BRGM 1/1 000 000).
    Best-effort, jamais bloquant.
    """
    try:
        import colorsys
        from qgis.core import (
            QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFillSymbol,
        )
        from qgis.PyQt.QtGui import QColor

        fields = [f.name() for f in vl.fields()]
        attr = next((c for c in ("NOTATION", "notation") if c in fields), None)
        if attr is None:
            return
        has_cmyk = all(c in fields for c in ("C_FOND", "M_FOND", "J_FOND", "N_FOND"))

        # NOTATION → couleur (première occurrence rencontrée).
        nota_color: dict = {}
        for feat in vl.getFeatures():
            n = feat[attr]
            if n in nota_color:
                continue
            col = None
            if has_cmyk:
                try:
                    c = float(feat["C_FOND"] or 0); m = float(feat["M_FOND"] or 0)
                    j = float(feat["J_FOND"] or 0); k = float(feat["N_FOND"] or 0)
                    col = QColor(
                        int(round(255 * (1 - c / 100) * (1 - k / 100))),
                        int(round(255 * (1 - m / 100) * (1 - k / 100))),
                        int(round(255 * (1 - j / 100) * (1 - k / 100))))
                except Exception:
                    col = None
            nota_color[n] = col

        keys = list(nota_color)
        cats = []
        for i, n in enumerate(keys):
            col = nota_color[n]
            if col is None:  # repli rampe HSV distincte (sans CMJN)
                rr, gg, bb = colorsys.hsv_to_rgb(i / max(len(keys), 1), 0.45, 0.95)
                col = QColor(int(rr * 255), int(gg * 255), int(bb * 255))
            sym = QgsFillSymbol.createSimple({
                "color": f"{col.red()},{col.green()},{col.blue()},255",
                "outline_color": "90,90,90,200", "outline_width": "0.08"})
            cats.append(QgsRendererCategory(n, sym, str(n)))
        if cats:
            vl.setRenderer(QgsCategorizedSymbolRenderer(attr, cats))
            try:
                vl.setOpacity(0.55)  # semi-transparent : laisse voir relief + cibles
            except Exception:
                pass
    except Exception:
        return


def _style_contours(vl) -> None:
    """Style la couche courbes_niveau : lignes fines, maîtresses (maitresse=1)
    en gras avec étiquette de cote « NNN m ». Best-effort, jamais bloquant.
    """
    # ── Rendu : règle fine (intermédiaires) + règle épaisse (maîtresses) ──
    try:
        from qgis.core import QgsLineSymbol, QgsRuleBasedRenderer
        root_rule = QgsRuleBasedRenderer.Rule(None)
        inter = QgsLineSymbol.createSimple(
            {"line_color": "166,124,82,180", "line_width": "0.12"})
        maitr = QgsLineSymbol.createSimple(
            {"line_color": "120,80,40,255", "line_width": "0.45"})
        r1 = QgsRuleBasedRenderer.Rule(inter, filterExp='"maitresse" = 0',
                                       label="intermédiaire")
        r2 = QgsRuleBasedRenderer.Rule(maitr, filterExp='"maitresse" = 1',
                                       label="maîtresse")
        root_rule.appendChild(r1)
        root_rule.appendChild(r2)
        vl.setRenderer(QgsRuleBasedRenderer(root_rule))
    except Exception:
        pass

    # ── Étiquettes de cote, uniquement sur les courbes maîtresses ─────────
    try:
        from qgis.core import (
            QgsPalLayerSettings, QgsTextFormat, QgsRuleBasedLabeling,
        )
        pal = QgsPalLayerSettings()
        pal.fieldName = "format_number(\"ELEV\", 0) || ' m'"
        pal.isExpression = True
        # Placement le long de la ligne — l'enum a bougé entre QGIS 3 et 4.
        try:
            from qgis.core import Qgis
            pal.placement = Qgis.LabelPlacement.Line
        except Exception:
            try:
                pal.placement = QgsPalLayerSettings.Line
            except Exception:
                pass
        try:
            fmt = QgsTextFormat()
            fmt.setSize(8)
            pal.setFormat(fmt)
        except Exception:
            pass

        root_lbl = QgsRuleBasedLabeling.Rule(None)
        rule = QgsRuleBasedLabeling.Rule(pal)
        rule.setFilterExpression('"maitresse" = 1')
        root_lbl.appendChild(rule)
        vl.setLabeling(QgsRuleBasedLabeling(root_lbl))
        vl.setLabelsEnabled(True)
    except Exception:
        pass
    # NB : le style des courbes n'est PAS persiste dans le .gpkg
    # (saveStyleToDatabase ouvre le GeoPackage en mode WAL et laisse des
    # fichiers .gpkg-wal/.gpkg-shm). Le rendu vit donc uniquement dans le .qgs.


def _label_points(vl, field: str) -> None:
    """Étiquette une couche de points avec le contenu de ``field`` (ex. le
    toponyme d'une source). Halo blanc pour la lisibilité sur fond d'ombrage.
    Best-effort : ne fait jamais échouer la préparation.
    """
    try:
        from qgis.core import (
            QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
            QgsVectorLayerSimpleLabeling,
        )
        pal = QgsPalLayerSettings()
        pal.fieldName = field
        pal.isExpression = False
        # Décale l'étiquette à côté du point (sinon elle se superpose au symbole).
        try:
            from qgis.core import Qgis
            pal.placement = Qgis.LabelPlacement.OverPoint
            pal.xOffset = 2.0
            pal.yOffset = -2.0
        except Exception:
            pass
        fmt = QgsTextFormat()
        fmt.setSize(8)
        try:
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(0.8)
            fmt.setBuffer(buf)
        except Exception:
            pass
        pal.setFormat(fmt)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
    except Exception:
        pass


def _add_ortho_ign(proj, root, crs) -> None:
    """Ajoute l'ortho IGN (WMS Geoplateforme) au projet, DECOCHEE par defaut.

    Fond satellite optionnel (ORTHOIMAGERY.ORTHOPHOTOS, 20 cm France). Ajoutee
    a l'arbre mais NON visible : l'utilisateur l'active a la demande. Gratuit et
    legal (source officielle IGN, meme origine que le LiDAR) — a l'inverse des
    tuiles Google XYZ qui violent les CGU. Exclue du packaging QField.
    Sans effet si la couche WMS est invalide (hors-ligne au moment de la prep).
    """
    try:
        from qgis.core import QgsRasterLayer
        uri = (
            "crs=EPSG:2154&dpiMode=7&format=image/jpeg"
            "&layers=ORTHOIMAGERY.ORTHOPHOTOS&styles="
            "&url=https://data.geopf.fr/wms-r/wms"
        )
        rl = QgsRasterLayer(uri, "Ortho IGN (satellite)", "wms")
        if not rl.isValid():
            return
        rl.setCustomProperty("QFieldSync/action", "remove")
        proj.addMapLayer(rl, addToLegend=False)
        node = root.addLayer(rl)              # ajoute en fin => sous l'ombrage
        node.setItemVisibilityChecked(False)   # decoche par defaut
    except Exception:
        return


def _add_scan25_ign(proj, root, crs, apikey: str) -> None:
    """Ajoute la carte IGN classique SCAN25 (WMTS Geoplateforme, endpoint PRIVE),
    DECOCHEE par defaut — SEULEMENT si ``apikey`` est fournie.

    SCAN25 est un produit PAYANT de l'IGN (GEOGRAPHICALGRIDSYSTEMS.MAPS.SCAN25TOUR,
    endpoint ``private/wmts``) : necessite une cle personnelle obtenue via
    cartes.gouv.fr (inscription avec un SIRET — associations incluses, ex. un
    club de speleo ou la FFS). KarstPro n'embarque JAMAIS de cle — chaque
    utilisateur fournit la sienne, ou laisse le champ vide (aucun effet).
    Exclue du packaging QField. Sans effet si la couche WMTS est invalide
    (cle invalide/expiree, ou hors-ligne au moment de la prep).

    Historique : la V1 utilisait l'endpoint WMS non-tuile (``private/wms-r``,
    layer ``SCAN25TOUR_PYR-JPEG_WLD_WM``) — silencieusement CASSEE : QGIS
    déclarait la couche valide (isValid() == True) mais chaque tuile
    renvoyée était vide (0 octet non-nul sur 262144, vérifié en conditions
    réelles). Confirmé cassé sur le terrain (Marnaval) ; la config WMTS
    ci-dessous est celle effectivement utilisée par un projet manuel qui
    fonctionne (Inventaire.qgz), reprise à l'identique.
    """
    try:
        from urllib.parse import quote
        from qgis.core import QgsRasterLayer
        # Le paramètre "url=" imbrique lui-même une query string à plusieurs
        # clés (SERVICE, VERSION, REQUEST, apikey) — ses propres "?"/"="/"&"
        # DOIVENT être percent-encodés, sinon QGIS les interprète comme des
        # clés supplémentaires du "wms:" URI externe au lieu de faire partie
        # de la valeur "url=" (contrairement au cas à un seul paramètre —
        # ex. l'ancien endpoint WMS ``?apikey=...`` — où laisser "?"/"="
        # littéraux ne posait pas ce problème d'ambiguïté).
        nested_url = (
            "https://data.geopf.fr/private/wmts?SERVICE=WMTS&VERSION=1.0.0"
            f"&REQUEST=GetCapabilities&apikey={apikey}"
        )
        uri = (
            "IgnoreGetFeatureInfoUrl=1&IgnoreGetMapUrl=1&crs=EPSG:3857&dpiMode=0"
            "&featureCount=10&format=image/jpeg"
            "&layers=GEOGRAPHICALGRIDSYSTEMS.MAPS.SCAN25TOUR&styles=normal"
            "&tileMatrixSet=PM_6_16&tilePixelRatio=2"
            f"&url={quote(nested_url, safe='')}"
        )
        rl = QgsRasterLayer(uri, "SCAN25 IGN (clé personnelle)", "wms")
        if not rl.isValid():
            return
        rl.setCustomProperty("QFieldSync/action", "remove")
        proj.addMapLayer(rl, addToLegend=False)
        node = root.addLayer(rl)              # ajoute en fin => sous l'ombrage
        # Cochée par défaut : cette couche n'est créée QUE si l'utilisateur a
        # fourni sa propre clé (produit payant) — s'il l'a renseignée, c'est
        # qu'il veut la voir. Le Plan IGN (gratuit) est alors décoché en
        # correspondance (cf. call site dans package_qfield_project).
        node.setItemVisibilityChecked(True)
    except Exception:
        return


def _add_plan_ign(proj, root, crs, visible: bool = True) -> None:
    """Ajoute le Plan IGN (WMS Geoplateforme) tout en bas du projet.

    Couche raster WMS (GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2). Visible par defaut
    (fond de carte) ; placee tout en bas, sous l'ombrage MNT. Necessite une
    connexion internet. Exclue du packaging QField.
    Sans effet si la couche WMS est invalide (hors-ligne au moment de la prep).

    ``visible`` : decoche a l'appel si SCAN25 (produit payant, plus detaille)
    a ete active a la place — evite les deux fonds de carte actifs en meme
    temps par defaut.
    """
    try:
        from qgis.core import QgsRasterLayer
        uri = (
            "crs=EPSG:2154&dpiMode=7&format=image/png"
            "&layers=GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2&styles="
            "&url=https://data.geopf.fr/wms-r/wms"
        )
        rl = QgsRasterLayer(uri, "Plan IGN", "wms")
        if not rl.isValid():
            return
        rl.setCustomProperty("QFieldSync/action", "remove")
        proj.addMapLayer(rl, addToLegend=False)
        node = root.addLayer(rl)            # ajoute en fin => tout en bas
        node.setItemVisibilityChecked(visible)
    except Exception:
        return


def _add_mnt_hillshade(proj, root, output_dir: Path, crs) -> None:
    """Ajoute le MNT (lidar_work/mnt.tif) en ombrage multidirectionnel au projet.

    - chemin relatif (portable),
    - rendu Hillshade multidirectionnel + reechantillonnage bilineaire au zoom,
    - opacite 70 % (laisse transparaitre le Plan IGN dessous),
    - place en bas de l'arbre (sous les vecteurs),
    - exclu du packaging QFieldSync (raster volumineux).
    Sans effet si le MNT est absent.
    """
    mnt_path = output_dir / "lidar_work" / "mnt.tif"
    if not mnt_path.exists():
        return
    try:
        from qgis.core import QgsRasterLayer, QgsHillshadeRenderer
        rl = QgsRasterLayer(str(mnt_path), "MNT (ombrage)", "gdal")
        if not rl.isValid():
            return
        rl.setCrs(crs)

        renderer = QgsHillshadeRenderer(rl.dataProvider(), 1, 315.0, 45.0)
        try:
            renderer.setMultiDirectional(True)
        except Exception:
            pass
        rl.setRenderer(renderer)

        # Reechantillonnage bilineaire au zoom avant (supprime l'effet pixelise)
        try:
            from qgis.core import QgsBilinearRasterResampler, Qgis
            rf = rl.resampleFilter()
            if rf is not None:
                rf.setZoomedInResampler(QgsBilinearRasterResampler())
            rl.setResamplingStage(Qgis.RasterResamplingStage.Provider)
        except Exception:
            pass

        # Opacite reduite : laisse transparaitre le Plan IGN (fond de carte)
        # sous l'ombrage, tout en gardant le relief lisible.
        try:
            rl.renderer().setOpacity(0.70)
        except Exception:
            pass

        # Exclut le raster du packaging QField *câble* (USB/cartouche).
        # NB : QFieldCloud ignore ce flag (cloud_converter copie tous les
        # rasters) — pour un paquet cloud léger, retirer la couche MNT du projet
        # avant le packaging.
        rl.setCustomProperty("QFieldSync/action", "remove")

        proj.addMapLayer(rl, addToLegend=False)
        # addLayer ajoute en fin de fratrie => bas de l'arbre => sous les vecteurs
        root.addLayer(rl)
    except Exception:
        # L'ombrage est un confort : ne jamais faire echouer la preparation pour ca
        return


# Conservé pour les tests unitaires hors QGIS
def _generate_qgs(name: str, gpkg_path: Path, layers: list) -> str:
    """Génère un QGS minimal hors contexte QGIS (tests uniquement)."""
    wkt = _WKT2_2154
    srs_xml = f"""    <spatialrefsys nativeFormat="Wkt">
      <wkt>{wkt}</wkt>
      <srid>2154</srid>
      <authid>EPSG:2154</authid>
      <description>RGF93 v1 / Lambert-93</description>
      <projectionacronym>lcc</projectionacronym>
      <ellipsoidacronym>EPSG:7019</ellipsoidacronym>
      <geographicflag>false</geographicflag>
    </spatialrefsys>"""

    import re
    from xml.sax.saxutils import escape as _xesc

    def _xattr_esc(s):
        # Contexte attribut (entre guillemets doubles littéraux du template) :
        # échappe AUSSI le guillemet, sinon il termine l'attribut prématurément.
        return _xesc(s, {'"': "&quot;"})

    EDITABLE = {"cavites"}
    HIDDEN_BY_DEFAULT = {"dolines", "hydrologie", "geologie"}

    def _slug(s):
        return re.sub(r"[^a-zA-Z0-9]", "_", s)

    # Chemin relatif : le .qgs et le .gpkg sont dans le même dossier.
    gpkg_posix = Path(gpkg_path).name
    layer_parts, tree_parts = [], []
    # Secteur/nom : texte libre (saisi ou géocodé), jamais garanti bien formé
    # en XML — un '&', '<', '>' ou '"' non échappé produirait un .qgs corrompu
    # que QGIS ouvre mal ou pas du tout.
    name_esc = _xesc(name)
    gpkg_posix_esc = _xesc(gpkg_posix)

    for layer in layers:
        # ID stable (pas d'UUID) — les noms de couches sont uniques dans un projet.
        lid = _slug(layer)
        display_name = layer if layer.startswith(name) else f"{name} — {layer}"
        display_name_esc = _xesc(display_name)
        display_name_attr = _xattr_esc(display_name)
        layer_esc = _xesc(layer)
        # Action de sync UNIFORME (offline) sur toutes les couches du gpkg :
        # une action mixte (offline/readonly) dans un même fichier fait échouer
        # la création du paquet QFieldSync (« conflicting sync actions »). La
        # consultation seule passe par le drapeau natif readOnly, pas l'action.
        # cibles + gouffres = éditables form-only (saisie interet) mais SANS
        # capture GPS ; cavites = éditables avec GPS ; reste = consultation (RO).
        gps_capture = layer in EDITABLE
        editable = (gps_capture or _is_cibles(layer) or _is_gouffres(layer)
                    or _is_cibles_visitees(layer))
        gps = '\n        <property key="QFieldSync/geomSource" value="gps"/>' if gps_capture else ""
        ro_attr = "" if editable else ' readOnly="1"'
        checked = "Qt::Unchecked" if (layer in HIDDEN_BY_DEFAULT or layer.endswith("cibles P3")) else "Qt::Checked"

        layer_parts.append(f"""    <maplayer type="vector"{ro_attr}>
      <id>{lid}</id>
      <layername>{display_name_esc}</layername>
      <datasource>{gpkg_posix_esc}|layername={layer_esc}</datasource>
      <provider>ogr</provider>
      <srs>{srs_xml}</srs>
      <customproperties>
        <property key="QFieldSync/action" value="offline"/>{gps}
      </customproperties>
    </maplayer>""")
        tree_parts.append(
            f'    <layer-tree-layer checked="{checked}" id="{lid}" name="{display_name_attr}" expanded="1"/>'
        )

    return f"""<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.34">
  <title>{name_esc} — KarstPro</title>
  <projectCrs>{srs_xml}</projectCrs>
  <layer-tree-group name="" checked="Qt::Checked" expanded="1">
    <custom-order enabled="0"/>
{chr(10).join(tree_parts)}
  </layer-tree-group>
  <projectlayers>
{chr(10).join(layer_parts)}
  </projectlayers>
</qgis>"""


