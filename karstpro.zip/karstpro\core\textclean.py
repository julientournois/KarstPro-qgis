# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Assainissement des champs texte saisis à la main avant injection dans le
prompt MLL — sans dépendance QGIS, donc testable hors plugin."""
import re

# Détecte un résidu de presse-papier Microsoft Office (commentaires conditionnels
# « [if gte mso 9] », balises Word/HTML) collé dans un champ texte d'inventaire.
_HTML_COMMENT = re.compile(r"<!--.*?-->", re.DOTALL)
_HTML_TAG = re.compile(r"<[^>]+>", re.DOTALL)
_WS = re.compile(r"\s+")


def clean_text(v):
    """Assainit une valeur texte saisie à la main (commentaire d'inventaire,
    toponyme…) : retire les commentaires HTML (dont le boilerplate Office
    « mso ») et les balises, puis compacte les blancs.

    Best-effort : renvoie la valeur telle quelle si ce n'est pas une chaîne, et
    ne touche pas au texte propre (aucune balise → inchangé hors espaces).
    """
    if not isinstance(v, str):
        return v
    s = _HTML_COMMENT.sub(" ", v)
    s = _HTML_TAG.sub(" ", s)
    s = _WS.sub(" ", s).strip()
    return s
