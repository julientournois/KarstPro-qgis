# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterString,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterDefinition,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
import csv
import math
from pathlib import Path

from karstpro.core.textclean import clean_text as _clean_text


class KarstExportMllAlgorithm(QgsProcessingAlgorithm):
    """Algorithme « Exporter pour analyse MLL ».

    Lit la couche ``dolines`` d'un GeoPackage préparé par KarstPro et produit
    le paquet d'analyse destiné à un LLM : prompt structuré (contexte géologie /
    hydro / traçages + table des cibles), GPX des waypoints P1/P2, fiches
    terrain et journal d'export. Recalcule les priorités depuis ``score`` —
    le rapport porte donc sur toutes les dolines scorées, pas seulement les
    couches cibles.
    """

    GPKG = "GPKG"
    SECTEUR = "SECTEUR"
    OUTPUT_DIR = "OUTPUT_DIR"
    CONTEXT = "CONTEXT"
    INVENTORY_GPKG = "INVENTORY_GPKG"
    TRACAGES_GPKG = "TRACAGES_GPKG"

    def name(self):
        return "karst_export_mll"

    def displayName(self):
        return "KarstPro — Exporter pour analyse MLL"

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstExportMllAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        return help_html(
            "<b>Exporter pour analyse MLL (IA).</b><br><br>"
            "<b>But :</b> produire un prompt structuré (rapport complet du secteur "
            "+ contexte géologique, hydrologique et inventaire) à coller dans un "
            "modèle de langage pour une analyse spéléologique approfondie.<br><br>"
            "<b>Ce que ça fait :</b> écrit jusqu'à 6 fichiers dans le dossier de "
            "sortie.<br><br>"
            "<b>➊ À fournir au chat IA :</b><br>"
            "• <i>mll_prompt_&lt;secteur&gt;_&lt;date&gt;.txt</i> — <b>à coller</b> "
            "dans la conversation (contexte, règles, mission) ;<br>"
            "• <i>mll_data_&lt;secteur&gt;_&lt;date&gt;.csv</i> <b>ou</b> "
            "<i>.json</i> — <b>à joindre</b> : les valeurs par doline (mêmes "
            "données, deux formats — joins celui que ton IA lit le mieux, les "
            "deux ne servent à rien). Le prompt ne les embarque plus (évitait "
            "un rapport de plusieurs milliers de lignes pour des données déjà "
            "tabulaires) ;<br>"
            "• <i>mll_gouffres_&lt;secteur&gt;_&lt;date&gt;.csv</i> — <b>à "
            "joindre</b> s'il existe : les puits verticaux <b>jamais visités</b>, "
            "à prospecter au même titre que les dolines (fichier séparé, "
            "colonnes propres aux puits) ;<br>"
            "• <i>carte_&lt;secteur&gt;_&lt;date&gt;.png</i> — <b>à joindre "
            "seulement si ton IA accepte les images</b> (modèle multimodal) : "
            "relief (ombrage MNT exagéré) + cibles rouges/oranges (P1/P2 "
            "uniquement — jaune/gris non tracées, non détaillées dans le "
            "rapport), anneau noir sur celles à signal ponctuel, réseau "
            "karstique connu et géologie BRGM semi-transparente (légende, "
            "échelle et nord intégrés à l'image).<br><br>"
            "<b>➋ À NE PAS fournir au chat IA :</b><br>"
            "• <i>cibles_&lt;secteur&gt;_&lt;date&gt;.gpx</i> — waypoints GPS "
            "rouges + oranges, coordonnées exactes, prêt pour Garmin/OruxMaps/"
            "QGIS. <b>Pour le terrain uniquement</b> : inutile à l'analyse, et "
            "l'IA ne doit jamais le régénérer (elle ne donne qu'un ordre de "
            "visite, cf. ci-dessous).<br><br>"
            "<b>Comment l'utiliser :</b><br>"
            "• <b>GeoPackage du secteur</b> — le .gpkg préparé.<br>"
            "• <b>Contexte terrain</b> (avancé) — texte libre (historique, indices).<br>"
            "• <b>Direction du pendage</b> (avancé) — laisser vide pour une "
            "estimation auto depuis la géologie + le MNT.<br><br>"
            "<b>En retour, MLL fournit :</b> analyse priorisée + ordre de visite "
            "optimal (liste d'IDs, pas un GPX régénéré), CSV pour QGIS, et un "
            "script python-docx pour le rapport DOCX complet."
        )

    PENDAGE      = "PENDAGE"
    ZONES_EXCLUES = "ZONES_EXCLUES"

    def _add_advanced(self, param):
        """Place le paramètre dans la section repliable « Paramètres avancés »."""
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        # ── Paramètres requis (toujours visibles) ──────────────────────────
        self.addParameter(QgsProcessingParameterFile(
            self.GPKG,
            "GeoPackage KarstPro (.gpkg)",
            extension="gpkg",
        ))
        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR,
            "Dossier de sortie (optionnel — par défaut, dossier du GeoPackage)",
            optional=True, createByDefault=False,
        ))

        # GeoPackages inventaire (cavités connues / traçages) — désormais
        # référencés et non copiés dans le package : le MLL les relit ici.
        self._add_advanced(QgsProcessingParameterFile(
            self.INVENTORY_GPKG,
            "GeoPackage inventaire cavités (.gpkg — cavités connues pour le MLL)",
            optional=True, extension="gpkg",
        ))
        self._add_advanced(QgsProcessingParameterFile(
            self.TRACAGES_GPKG,
            "GeoPackage traçages (.gpkg — traçages pour le MLL)",
            optional=True, extension="gpkg",
        ))

        # ── Paramètres optionnels (section « avancés », repliée par défaut) ─
        self._add_advanced(QgsProcessingParameterString(
            self.SECTEUR,
            "Nom du secteur (auto-détecté si vide)",
            defaultValue="",
            optional=True,
        ))
        self._add_advanced(QgsProcessingParameterString(
            self.CONTEXT,
            "Contexte terrain (géologie locale, historique explorations…)",
            defaultValue="",
            optional=True,
            multiLine=True,
        ))
        self._add_advanced(QgsProcessingParameterString(
            self.PENDAGE,
            "Direction du pendage / sens de drainage "
            "(laisser vide = estimation auto depuis géologie + MNT)",
            defaultValue="",
            optional=True,
        ))
        self._add_advanced(QgsProcessingParameterString(
            self.ZONES_EXCLUES,
            "Zones à exclure de la prospection (ex: quadrant sud — falaises, propriété privée…)",
            defaultValue="",
            optional=True,
        ))

    def processAlgorithm(self, parameters, context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        import traceback

        try:
            return self._run(parameters, context, feedback)
        except Exception:
            feedback.reportError(
                f"ERREUR dans KarstExportMLL :\n{traceback.format_exc()}",
                fatalError=True,
            )
            raise

    def _read_dolines_sqlite(self, gpkg_path: Path, feedback) -> list:
        """Lit la couche dolines via sqlite3 + shapely, sans passer par pyproj.

        pyogrio→pyproj→proj_create n'est pas thread-safe dans QGIS 4.0.2.
        On parse directement le WKB GPKG pour extraire le centroïde de chaque polygone.
        """
        import sqlite3
        import struct

        FLOAT64 = struct.Struct("<d")  # little-endian double

        def _centroid_from_gpkg_geom(blob):
            """Extrait le centroïde (x, y) depuis un blob de géométrie GPKG.

            Format GPKG : 2 octets magic 'GP' + 1 version + 1 flags + 4 SRS_ID
            + envelope optionnelle + WKB ISO.

            Stratégie : si une envelope XY est présente (flag bits 1-3 = 1),
            on lit directement min/max XY (8 doubles = midpoint exact pour bbox).
            Sinon on parse le WKB avec shapely.
            """
            if not blob or len(blob) < 8:
                return None, None
            flags = blob[3]
            env_indicator = (flags >> 1) & 0x07

            # Tailles d'envelope : 0=none, 1=XY(32), 2=XYZ(48), 3=XYM(48), 4=XYZM(64)
            env_sizes = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
            env_size = env_sizes.get(env_indicator, 0)

            wkb_offset = 8 + env_size

            if env_indicator >= 1:
                # Utiliser l'envelope : minX, maxX, minY, maxY (doubles LE à partir de byte 8)
                try:
                    minX = FLOAT64.unpack_from(blob, 8)[0]
                    maxX = FLOAT64.unpack_from(blob, 16)[0]
                    minY = FLOAT64.unpack_from(blob, 24)[0]
                    maxY = FLOAT64.unpack_from(blob, 32)[0]
                    return (minX + maxX) / 2.0, (minY + maxY) / 2.0
                except struct.error:
                    pass

            # Fallback : parser le WKB complet avec shapely
            try:
                from shapely import wkb as swkb
                geom = swkb.loads(bytes(blob[wkb_offset:]))
                c = geom.centroid
                return c.x, c.y
            except Exception:
                return None, None

        def _safe_float(val):
            if val is None:
                return None
            try:
                f = float(val)
                return None if math.isnan(f) else f
            except (TypeError, ValueError):
                return None

        con = sqlite3.connect(str(gpkg_path))
        con.row_factory = sqlite3.Row
        cur = con.cursor()

        # Trouver le nom de la colonne géométrie
        try:
            cur.execute(
                "SELECT column_name FROM gpkg_geometry_columns WHERE table_name='dolines'"
            )
            row = cur.fetchone()
            geom_col = row[0] if row else "geom"
        except Exception:
            geom_col = "geom"

        # Trouver la table dolines (nom exact dans le GPKG)
        cur.execute(
            "SELECT table_name FROM gpkg_contents WHERE data_type='features'"
        )
        available = [r[0] for r in cur.fetchall()]
        # Cherche "dolines" en priorité, puis toute table contenant "doline"
        dolines_table = None
        if "dolines" in available:
            dolines_table = "dolines"
        else:
            for t in available:
                if "doline" in t.lower():
                    dolines_table = t
                    break
        if dolines_table is None:
            con.close()
            raise ValueError(
                f"Aucune couche 'dolines' trouvée dans {gpkg_path.name}. "
                f"Couches disponibles : {available}. "
                f"Sélectionnez le GeoPackage généré par 'Préparer une sortie'."
            )

        # Lister toutes les colonnes attributaires
        cur.execute(f'SELECT * FROM "{dolines_table}" LIMIT 0')
        all_cols = [d[0] for d in cur.description]
        attr_cols = [c for c in all_cols if c != geom_col]

        col_sql = ", ".join(f'"{c}"' for c in attr_cols) + f', "{geom_col}"'
        cur.execute(f'SELECT {col_sql} FROM "{dolines_table}"')

        rows_out = []
        for row in cur.fetchall():
            d = {}
            for c in attr_cols:
                d[c] = _clean_text(row[c])

            # ID = fid GPKG (1-based). La preparation nomme desormais les cibles
            # "doline_{fid}" (cf. qfield.write_cibles + reset_index a la prep),
            # donc l'export utilise le fid tel quel : "doline_N" du rapport ==
            # "doline_N" sur la carte == fid N dans la table attributaire.
            if d.get("fid") is not None:
                try:
                    d["fid"] = int(d["fid"])
                except (TypeError, ValueError):
                    pass

            x, y = _centroid_from_gpkg_geom(row[geom_col])
            d["x_l93"] = round(x, 0) if x is not None else None
            d["y_l93"] = round(y, 0) if y is not None else None
            # WGS84 précalculé (conversion exacte côté plugin) : le LLM ne doit
            # JAMAIS convertir lui-même — une erreur de projection enverrait
            # l'opérateur au mauvais endroit sur le terrain.
            if x is not None and y is not None:
                lon, lat = _l93_to_wgs84(x, y)
                d["lat_wgs84"] = round(lat, 7)
                d["lon_wgs84"] = round(lon, 7)
                # UTM WGS84 (m) précalculé — grille des GPS de terrain. Fuseau
                # déduit de la longitude (France : 30/31/32) et exposé, sinon une
                # zone à cheval donnerait un E/N faux. Le LLM ne recalcule JAMAIS.
                from karstpro.core.geology import _l93_to_utm
                e_utm, n_utm, zone = _l93_to_utm(x, y)
                d["x_utm"] = round(e_utm, 0)
                d["y_utm"] = round(n_utm, 0)
                d["utm_zone"] = zone
            else:
                d["lat_wgs84"] = None
                d["lon_wgs84"] = None
                d["x_utm"] = None
                d["y_utm"] = None
                d["utm_zone"] = None

            # Normalisation des champs numériques
            for field, decimals in [
                ("surface_m2", 1), ("profondeur_m", 2),
                ("score_morpho", 1), ("score", 1),
                ("ratio_ps", 3), ("pente_max_bord", 1),
                ("comp_geologie_dist_m", 0), ("cavite_distance_m", 0),
            ]:
                if field in d and d[field] is not None:
                    f = _safe_float(d[field])
                    d[field] = round(f, decimals) if f is not None else None

            for field in ("lisere", "cavite_connue_proche"):
                if field in d:
                    d[field] = bool(d[field])

            rows_out.append(d)

        con.close()
        return sorted(rows_out, key=lambda r: (r.get("score") or 0), reverse=True)

    def _read_tracages_gpkg(self, cur, feedback, table: str = "tracages") -> list:
        """Lit la couche traçages (``table``) du gpkg (LineString) via sqlite.

        Renvoie une liste de dicts : attributs (point_injection, point_sortie,
        colorant, resultat, temps_transit, distance_m…) + coordonnées L93 des
        extrémités (x_inj/y_inj = 1er sommet, x_res/y_res = dernier sommet).
        On suppose le gpkg inventaire en EPSG:2154 (contrat de schéma) : les
        coordonnées sont lues telles quelles, sans pyproj (thread-safe).
        """
        from shapely import wkb as swkb

        # Nom de la colonne géométrie
        try:
            cur.execute(
                "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
                (table,),
            )
            r = cur.fetchone()
            geom_col = r[0] if r else "geom"
        except Exception:
            geom_col = "geom"

        # Attributs disponibles
        cur.execute(f'PRAGMA table_info("{table}")')
        cols = [c[1] for c in cur.fetchall()]
        wanted = [c for c in (
            "point_injection", "point_sortie", "colorant", "resultat",
            "date_injection", "date_detection", "temps_transit",
            "distance_m", "operateurs") if c in cols]
        attr_sql = ", ".join([geom_col] + wanted)

        def _endpoints(blob):
            """Extrait (x_inj,y_inj,x_res,y_res) en L93 depuis un blob GPKG."""
            if not blob or len(blob) < 8:
                return None
            flags = blob[3]
            env_indicator = (flags >> 1) & 0x07
            env_sizes = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
            wkb_offset = 8 + env_sizes.get(env_indicator, 0)
            try:
                geom = swkb.loads(bytes(blob[wkb_offset:]))
                coords = list(geom.coords) if geom.geom_type == "LineString" \
                    else list(geom.geoms[0].coords)
                if len(coords) < 2:
                    return None
                (xi, yi), (xr, yr) = coords[0][:2], coords[-1][:2]
                return round(xi, 0), round(yi, 0), round(xr, 0), round(yr, 0)
            except Exception:
                return None

        rows = []
        for row in cur.execute(f'SELECT {attr_sql} FROM "{table}"'):
            ep = _endpoints(row[0])
            if ep is None:
                continue
            d = {wanted[i]: _clean_text(row[i + 1]) for i in range(len(wanted))}
            d.update({"x_inj": ep[0], "y_inj": ep[1],
                      "x_res": ep[2], "y_res": ep[3]})
            rows.append(d)
        feedback.pushInfo(f"  {len(rows)} traçage(s) chargé(s) depuis le gpkg.")
        return rows

    def _read_external_tracages(self, gpkg_path, feedback) -> list:
        """Lit les traçages depuis un gpkg externe (couche détectée par schéma)."""
        import sqlite3
        from karstpro.core.sync import find_tracages_layer
        table = find_tracages_layer(gpkg_path)
        if not table:
            feedback.pushWarning(
                f"Aucune couche traçages valide dans {gpkg_path.name}.")
            return []
        con = sqlite3.connect(str(gpkg_path))
        try:
            return self._read_tracages_gpkg(con.cursor(), feedback, table=table)
        except Exception as e:
            feedback.pushWarning(f"Traçages externes ignorés : {e}")
            return []
        finally:
            con.close()

    def _read_external_cavites_connues(self, gpkg_path, feedback, bbox=None) -> list:
        """Lit les cavités connues depuis un gpkg inventaire externe.

        Si ``bbox`` = (xmin, ymin, xmax, ymax) en L93 est fourni, ne garde que
        les cavités DANS la box d'étude : un inventaire couvre souvent un
        département entier, et injecter des cavités d'autres communes dans le
        prompt MLL n'a aucun sens (bruit, tokens, fausses associations)."""
        import sqlite3
        from shapely import wkb as swkb
        from karstpro.core.sync import find_inventory_layer
        table = find_inventory_layer(gpkg_path)
        if not table:
            feedback.pushWarning(
                f"Aucune couche inventaire valide dans {gpkg_path.name}.")
            return []
        con = sqlite3.connect(str(gpkg_path))
        try:
            cur = con.cursor()
            avail = {c[1] for c in cur.execute(f'PRAGMA table_info("{table}")')}
            cols = [c for c in ("name", "type", "date_disc", "date_expl",
                                "explorers", "comment", "reference") if c in avail]
            if not cols:
                return []
            geom_col = None
            try:
                cur.execute(
                    "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
                    (table,))
                r = cur.fetchone()
                geom_col = r[0] if r else None
            except Exception:
                geom_col = None

            def _pt(blob):
                if not blob or len(blob) < 8:
                    return None
                env = (blob[3] >> 1) & 0x07
                off = 8 + {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}.get(env, 0)
                try:
                    g = swkb.loads(bytes(blob[off:]))
                    c = g if g.geom_type == "Point" else g.centroid
                    return c.x, c.y
                except Exception:
                    return None

            # Box d'étude exprimée dans le CRS de l'inventaire (souvent WGS84).
            srs_id = None
            try:
                r = cur.execute(
                    "SELECT srs_id FROM gpkg_geometry_columns WHERE table_name=?",
                    (table,)).fetchone()
                srs_id = r[0] if r else None
            except Exception:
                srs_id = None
            cmp_bbox = (self._bbox_for_srs(bbox, srs_id, feedback)
                        if (bbox is not None and geom_col is not None) else None)
            filtering = cmp_bbox is not None
            if bbox is not None and geom_col is None:
                feedback.pushWarning(
                    f"  Inventaire {gpkg_path.name} sans géométrie : filtre "
                    "spatial impossible, toutes les cavités sont incluses.")
            sel = ", ".join([f'"{c}"' for c in cols]
                            + ([f'"{geom_col}"'] if filtering else []))
            rows, n_total = [], 0
            for r in cur.execute(f'SELECT {sel} FROM "{table}" ORDER BY name'):
                n_total += 1
                if filtering:
                    xy = _pt(r[len(cols)])
                    # Pas de géométrie exploitable → impossible à localiser → exclu
                    if xy is None:
                        continue
                    x, y = xy
                    if not (cmp_bbox[0] <= x <= cmp_bbox[2]
                            and cmp_bbox[1] <= y <= cmp_bbox[3]):
                        continue
                rows.append({cols[i]: _clean_text(r[i]) for i in range(len(cols))})
            if filtering:
                feedback.pushInfo(
                    f"  {len(rows)}/{n_total} cavité(s) connue(s) dans la box "
                    f"d'étude ({gpkg_path.name}).")
            else:
                feedback.pushInfo(
                    f"  {len(rows)} cavité(s) connue(s) lue(s) depuis {gpkg_path.name}.")
            return rows
        except Exception as e:
            feedback.pushWarning(f"Cavités connues externes ignorées : {e}")
            return []
        finally:
            con.close()

    def _table_srs_id(self, gpkg_path, table):
        """srs_id (code EPSG) déclaré pour la couche, ou None."""
        import sqlite3
        try:
            con = sqlite3.connect(str(gpkg_path))
            try:
                r = con.execute(
                    "SELECT srs_id FROM gpkg_geometry_columns WHERE table_name=?",
                    (table,)).fetchone()
                return r[0] if r else None
            finally:
                con.close()
        except Exception:
            return None

    def _bbox_for_srs(self, bbox_l93, srs_id, feedback):
        """Exprime la box d'étude (L93) dans le repère de la couche cible, pour
        comparer directement avec ses coordonnées brutes (un inventaire peut être
        stocké en WGS84 — cf. Karst Entry — et non en L93 comme le veut le schéma).

        Renvoie la box dans le bon CRS, ou None si le CRS n'est pas géré (→ pas
        de filtre spatial, toutes les entités conservées)."""
        if bbox_l93 is None:
            return None
        # 2154 (ou non déclaré) : on suppose du L93, comparaison directe.
        if srs_id in (2154, 0, None):
            return bbox_l93
        # 4326 : on convertit les 4 coins L93→WGS84 et on prend l'enveloppe.
        if srs_id == 4326:
            xmin, ymin, xmax, ymax = bbox_l93
            lons, lats = [], []
            for x, y in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
                lon, lat = _l93_to_wgs84(x, y)
                lons.append(lon)
                lats.append(lat)
            return (min(lons), min(lats), max(lons), max(lats))
        feedback.pushWarning(
            f"  CRS EPSG:{srs_id} non géré pour le filtre spatial — toutes les "
            "entités sont incluses.")
        return None

    def _read_point_layer(self, cur, table: str, attr_cols: list, feedback) -> list:
        """Lit une couche de points du gpkg courant (ex. gouffres, bdtopo_eau)
        via sqlite + shapely, sans pyproj. Renvoie une liste de dicts : attributs
        demandés présents dans la table + coordonnées L93 ``x``/``y`` (centroïde).
        gpkg supposé en EPSG:2154 (contrat de schéma)."""
        from shapely import wkb as swkb

        try:
            cur.execute(
                "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
                (table,))
            r = cur.fetchone()
            geom_col = r[0] if r else "geom"
        except Exception:
            geom_col = "geom"

        cur.execute(f'PRAGMA table_info("{table}")')
        cols = [c[1] for c in cur.fetchall()]
        wanted = [c for c in attr_cols if c in cols]
        sel = ", ".join([f'"{geom_col}"'] + [f'"{c}"' for c in wanted])

        def _pt(blob):
            if not blob or len(blob) < 8:
                return None
            env_indicator = (blob[3] >> 1) & 0x07
            env_sizes = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
            off = 8 + env_sizes.get(env_indicator, 0)
            try:
                g = swkb.loads(bytes(blob[off:]))
                c = g if g.geom_type == "Point" else g.centroid
                return round(c.x, 0), round(c.y, 0)
            except Exception:
                return None

        rows = []
        for row in cur.execute(f'SELECT {sel} FROM "{table}"'):
            xy = _pt(row[0])
            if xy is None:
                continue
            d = {wanted[i]: _clean_text(row[i + 1]) for i in range(len(wanted))}
            d["x"], d["y"] = xy
            rows.append(d)
        return rows

    @staticmethod
    def _gouffres_a_prospecter(gouffres_rows: list) -> list:
        """Gouffres restant à prospecter = ceux jamais visités (`interet == -1`).

        Filtrer sur `interet` plutôt que sur la distance à une cible : les faux
        positifs de canopée sont déjà auto-déclassés à `interet = 0` par
        `core/shafts.py` (c'est le gros du bruit), et `1`/`2` sont des verdicts
        terrain déjà exploités ailleurs. Reste `-1` : les candidats propres,
        jamais vérifiés — exactement la to-do de prospection.
        """
        return [g for g in gouffres_rows if g.get("interet") in (-1, None)]

    def _build_gouffres_section(self, gouffres_rows: list, nearest_cible,
                                 csv_filename: str = "") -> str:
        """Section MLL des gouffres/puits détectés.

        ⚠️ Historique : cette section ne listait QUE les gouffres à ≤ 100 m
        d'une cible rouge/orange (plafond 40 lignes), pour éviter de noyer le
        rapport sous des centaines de faux positifs de canopée. Mesuré le
        2026-07-26, ce filtre faisait perdre **~90 % des gouffres jamais
        visités** (Marnaval 111/124, Beurey 22/23, Sommelonne 2/2) — or ce sont
        de vrais puits verticaux ouverts (Ø 2,8-18 m) qui constituent la to-do
        de prospection. Le tri se fait donc désormais sur `interet` (cf.
        `_gouffres_a_prospecter`), pas sur la distance : la canopée est déjà
        écartée en amont. La distance à la cible la plus proche reste affichée,
        comme **information** et non comme filtre.
        """
        if not gouffres_rows:
            return ""
        a_faire = self._gouffres_a_prospecter(gouffres_rows)
        n_ecartes = len(gouffres_rows) - len(a_faire)

        rows = []
        for g in a_faire:
            c, dist = nearest_cible(g["x"], g["y"])
            rows.append((g, c, dist if dist is not None else float("inf")))
        rows.sort(key=lambda t: -(t[0].get("diametre_m") or 0))

        CAP = 60
        tbl = ""
        if rows:
            tbl = ("\n| Gouffre L93 | Ø (m) | Compacité | Cible la plus proche | Dist. (m) |\n"
                   "|---|---|---|---|---|\n")
            for g, c, dist in rows[:CAP]:
                diam = g.get("diametre_m")
                comp = g.get("compacite")
                cible = f"doline_{c['fid']}" if c is not None else "—"
                dtxt = f"{dist:.0f}" if dist != float("inf") else "—"
                tbl += (f"| {g['x']:.0f},{g['y']:.0f} | "
                        f"{diam if diam is not None else '—'} | "
                        f"{comp if comp is not None else '—'} | "
                        f"{cible} | {dtxt} |\n")
            if len(rows) > CAP:
                tbl += (f"\n… et {len(rows)-CAP} autre(s) gouffre(s) à prospecter — "
                        f"**liste complète dans `{csv_filename}`**.\n"
                        if csv_filename else
                        f"\n… et {len(rows)-CAP} autre(s) gouffre(s) à prospecter.\n")

        return f"""
## Gouffres / puits verticaux à prospecter ({len(a_faire)} jamais visités)

Vides LiDAR compacts à bord de sol valide = **signature d'un puits vertical
ouvert** (le laser plonge dans le vide, aucun écho sol → trou de NODATA, et NON
une cuvette). C'est de la **détection** (vs les cavités connues qui sont du
référencement).

Cette liste ne contient que les gouffres **jamais visités** — triés par
diamètre décroissant. {n_ecartes} autre(s) candidat(s) sont écartés d'office :
faux positifs de canopée dense auto-déclassés, ou déjà tranchés sur le terrain.
⚠️ Faux positifs résiduels possibles (canopée non cartographiée, bâti) —
**à confirmer sur le terrain**, ne raisonne pas dessus comme sur une donnée sûre.
{tbl}
Ce sont des **cibles à part entière**, au même titre que les dolines : un puits
ouvert de plusieurs mètres de diamètre jamais vérifié mérite une visite, même
loin de toute doline scorée. La colonne « cible la plus proche » est
**informative** (regroupement de journée), pas un critère de tri.

Exploite-les aussi comme **renfort d'hypothèse** : une doline avec un puits
détecté à proximité voit son hypothèse « gouffre vertical / accès pénétrable »
renforcée. L'absence de gouffre détecté n'infirme rien (puits noyé, comblé ou
sous canopée).
"""

    def _build_points_eau_section(self, points_eau_rows: list, nearest_cible) -> str:
        """Section MLL des points d'eau karstiques référencés (BD Topo)."""
        if not points_eau_rows:
            return ""
        tbl = ("\n| Type | Toponyme | L93 | Cible proche | Dist. (m) |\n"
               "|---|---|---|---|---|\n")
        for p in points_eau_rows:
            c, dist = nearest_cible(p["x"], p["y"])
            cible = f"doline_{c['fid']}" if c is not None else "—"
            dist_s = f"{dist:.0f}" if dist is not None else "—"
            tbl += (f"| {p.get('type') or '—'} | {p.get('toponyme') or '—'} | "
                    f"{p['x']:.0f},{p['y']:.0f} | {cible} | {dist_s} |\n")
        return f"""
## Points d'eau karstiques référencés ({len(points_eau_rows)})

Sources, pertes, inversacs, résurgences, exutoires **déjà cartographiés** (BD
Topo) — du **référencement**, pas de la détection. Indispensable pour les
entrées noyées (inversac), invisibles au MNT car le laser se réfléchit sur l'eau.
{tbl}
Exploite-les pour l'interprétation hydrologique :
- Une **source / résurgence** est un exutoire potentiel : une cible en amont peut
  alimenter ce système (relie-la au sens de drainage / pendage).
- Une **perte** est un point d'absorption connu : une cible proche peut être une
  perte secondaire du même bassin.
- Croise avec les traçages : un point d'eau sur un axe injection→résurgence
  confirme un drain actif.
"""

    def _build_pc_anomaly_section(self, dolines: list) -> str:
        """Section MLL des anomalies ponctuelles détectées (nuage de
        points brut vs MNT lissé). Même ton que les gouffres : renfort
        d'hypothèse, jamais une preuve."""
        def _has_pc(d):
            v = d.get("pc_plongee_m")
            return v is not None and not (isinstance(v, float) and math.isnan(v))
        candidats = [d for d in dolines if _has_pc(d)]
        if not candidats:
            return ""
        candidats.sort(key=lambda d: -(d.get("pc_plongee_m") or 0))
        tbl = "\n| ID | Plongée (m) | Dist. centroïde (m) | Derniers retours |\n"
        tbl += "|---|---|---|---|\n"
        for d in candidats[:40]:
            tbl += (f"| doline_{d['fid']} | {d['pc_plongee_m']:.2f} | "
                    f"{d['pc_dist_m']:.1f} | {int(d['pc_n_points'])} |\n")
        return f"""
## Anomalies ponctuelles détectées 🔻 ({len(candidats)})

Comparaison, sous chaque doline testée, de l'altitude minimale des **derniers
retours LiDAR bruts** (pas seulement les points classés sol) à une référence
de voisinage local. Une cellule qui plonge nettement sous ses voisines
immédiates est un candidat "puits" — signature invisible à la détection de
dolines (cuvette) et de gouffres (trou NODATA) : ni l'une ni l'autre ne voit
un puits où seule une poignée de retours a atteint le fond.
{tbl}
⚠️ **Signal informatif, jamais un facteur de score.** Validé contre des
inventaires de cavités connues sur 8 secteurs et 2 régions géologiques : une
doline avec signal a 2 à 6 fois plus de chances d'avoir une cavité connue à
moins de 20 m qu'une doline sans. C'est un **renfort d'hypothèse**, jamais une
preuve : cette validation mesure une corrélation avec du **déjà découvert**,
pas la présence réelle d'une cavité. À vérifier systématiquement sur le
terrain.

🌳 **L'absence de signal n'infirme RIEN.** La méthode exige que des derniers
retours atteignent le fond ; sous **canopée fermée** il y en a bien moins
(mesuré : 7,4 % de dolines avec signal sous forêt contre 11,4 % à découvert,
et deux fois moins de points par cellule). En secteur boisé, l'absence
d'anomalie traduit donc surtout la limite du LiDAR, pas l'absence de puits —
ne raisonne jamais a contrario sur les dolines sans 🔻.
"""

    def _build_rgealti_section(self, dolines: list) -> str:
        """Section MLL du signal RGE ALTI (différence LiDAR historique /
        LiDAR HD). Contrairement à `_build_pc_anomaly_section`, ce signal
        CONTRIBUE au score (feature du modèle appris) — le ton doit le
        dire explicitement, pas seulement "renfort d'hypothèse".
        Si le secteur n'est pas éligible (RGE ALTI = corrélation
        photogrammétrique, pas LiDAR), retourne un message explicite plutôt
        qu'une section vide silencieuse."""
        if not dolines:
            return ""
        eligible = bool(dolines[0].get("rge_eligible"))
        if not eligible:
            return """
## Signal RGE ALTI — affaissement historique 🔵

⚠️ **Non exploitable pour ce secteur.** Le relevé RGE ALTI local n'est pas
d'origine LiDAR (corrélation photogrammétrique, trop imprécise pour ce
signal) ou hors couverture historique — aucune donnée fiable disponible ici.
"""

        def _has_rge(d):
            v = d.get("rge_contrast_m")
            return v is not None and not (isinstance(v, float) and math.isnan(v))
        candidats = [d for d in dolines if _has_rge(d)]
        if not candidats:
            return ""
        candidats.sort(key=lambda d: (d.get("rge_contrast_m") or 0))  # plus negatif d'abord
        tbl = "\n| ID | Contraste (m) |\n|---|---|\n"
        for d in candidats[:40]:
            tbl += f"| doline_{d['fid']} | {d['rge_contrast_m']:.2f} |\n"
        return f"""
## Signal RGE ALTI — affaissement historique 🔵 ({len(candidats)})

Différence entre le MNT LiDAR HD actuel et un relevé LiDAR ancien de l'IGN
(RGE ALTI, souvent 2009-2016, campagnes "Directive Inondation" sur les
vallées), biais systématique entre les deux époques retiré. Une valeur
**négative** signale un affaissement relatif localisé depuis l'ancien
relevé — signature possible d'un soutirage karstique actif.
{tbl}
⚠️ **Contrairement au signal ponctuel ci-dessus, celui-ci CONTRIBUE au score
— mais uniquement là où c'est validé.** `rge_contrast_m` est une feature du
modèle appris **Barrois uniquement** aujourd'hui (testé et rejeté sur le Lot
et le Jura plateau — pas de gain mesuré, karst à nu sans affaissement de
surface comparable). Si ce secteur utilise le modèle Barrois, une doline peut
déjà être rouge en partie à cause de ce facteur, avant même de consulter
cette section ; sinon, la colonne reste purement informative, comme le signal
ponctuel. Validé sur 4 secteurs contre les inventaires de cavités
connues (AUC 0,62 à 0,81 selon le secteur et le rayon de matching) — un vrai
signal, mais mesuré par corrélation avec du **déjà découvert**, pas une
preuve de cavité active. À vérifier sur le terrain comme les autres indices.
"""

    def _run(self, parameters, context: QgsProcessingContext,
             feedback: QgsProcessingFeedback):
        """Corps réel de l'export (séparé de processAlgorithm pour le proxy log).

        Étapes : lecture gpkg (dolines + couches contexte via SQL direct),
        recalcul des priorités depuis ``score``, estimation auto du pendage,
        génération du prompt MLL, du GPX, des fiches terrain et du journal.
        """
        import sqlite3
        import json
        from datetime import date

        gpkg_path = Path(self.parameterAsFile(parameters, self.GPKG, context))
        secteur = self.parameterAsString(parameters, self.SECTEUR, context).strip()
        # Champs libres saisis dans la boîte de dialogue : nettoyés au cas où
        # l'utilisateur y colle du texte mis en forme depuis Word/Outlook.
        extra_context = _clean_text(self.parameterAsString(parameters, self.CONTEXT, context))
        pendage = _clean_text(self.parameterAsString(parameters, self.PENDAGE, context))
        zones_exclues = _clean_text(self.parameterAsString(parameters, self.ZONES_EXCLUES, context))
        output_str = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        # Par défaut (champ vide) : le dossier du GeoPackage d'entrée.
        output_dir = Path(output_str) if output_str else gpkg_path.parent
        output_dir.mkdir(parents=True, exist_ok=True)
        inv_gpkg_str = self.parameterAsFile(parameters, self.INVENTORY_GPKG, context)
        tr_gpkg_str = self.parameterAsFile(parameters, self.TRACAGES_GPKG, context)
        inventory_gpkg = Path(inv_gpkg_str) if inv_gpkg_str else None
        tracages_gpkg = Path(tr_gpkg_str) if tr_gpkg_str else None

        if not secteur:
            secteur = gpkg_path.stem

        # ── Dossier d'export + fichier log (capture tout le journal) ───────
        # Log dans logs/ (pas dans export_dir) : cohérent avec les autres
        # outils, export_dir ne garde que les livrables (prompt, GPX...).
        from datetime import datetime
        today = date.today()
        export_dir = output_dir / f"mll_export_{secteur}_{today}"
        export_dir.mkdir(parents=True, exist_ok=True)
        logs_dir = output_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / f"mll_export_{secteur}_{today}.log"

        from karstpro.core.log_feedback import write_log_header, wrap_feedback
        write_log_header(log_file, f"KarstPro — Exporter pour analyse MLL ({secteur})", parameters)
        feedback = wrap_feedback(feedback, log_file)
        _t0 = datetime.now()

        feedback.pushInfo(f"Lecture de {gpkg_path.name}...")

        # Lecture via sqlite3 + shapely — évite pyproj qui n'est pas thread-safe
        # dans QGIS 4.0.2 (proj_create → DatabaseContext → access violation).
        dolines = self._read_dolines_sqlite(gpkg_path, feedback)

        # ── Box d'étude : emprise des dolines (+ marge) pour filtrer
        # spatialement l'inventaire (souvent départemental) ───────────────
        STUDY_MARGIN_M = 1000.0
        _xs = [d["x_l93"] for d in dolines if d.get("x_l93") is not None]
        _ys = [d["y_l93"] for d in dolines if d.get("y_l93") is not None]
        study_bbox = None
        if _xs and _ys:
            study_bbox = (min(_xs) - STUDY_MARGIN_M, min(_ys) - STUDY_MARGIN_M,
                          max(_xs) + STUDY_MARGIN_M, max(_ys) + STUDY_MARGIN_M)

        # ── Pendage : auto-estimé si le champ est laissé vide ─────────────
        if not pendage:
            try:
                mnt_path = gpkg_path.parent / "lidar_work" / "mnt.tif"
                auto = _estimate_dip(gpkg_path, mnt_path)
                if auto:
                    pendage = auto["texte"]
                    feedback.pushInfo(
                        f"Pendage auto-estimé : {pendage} "
                        f"(contact {auto['contact']}, R²={auto['r2']:.2f})"
                    )
                else:
                    feedback.pushInfo(
                        "Pendage non estimé (pas de contact conformable exploitable "
                        "ou MNT absent) — champ laissé vide."
                    )
            except Exception as e:
                feedback.pushWarning(f"Estimation pendage échouée : {e}")

        # ── Flags découverte : profonde + hors réseau connu ──────────────
        # Heuristique : profondeur > 5m ET (pas de topo OU dist réseau > 500m)
        # Ces dolines ont un fort signal morphologique mais aucune association
        # au réseau connu — zones sous-explorées à prioriser pour la découverte.
        DECOUVERTE_PROF_MIN = 5.0
        DECOUVERTE_DIST_MIN = 500.0
        for d in dolines:
            prof      = d.get("profondeur_m") or 0.0
            dist_r    = d.get("comp_dist_reseau_m")
            loin_reseau = (dist_r is None or math.isnan(float(dist_r))
                           or float(dist_r) >= DECOUVERTE_DIST_MIN)
            d["decouverte"] = (prof >= DECOUVERTE_PROF_MIN and loin_reseau)

        cibles_decouverte = [d for d in dolines if d["decouverte"]]
        n_bonus_hors_couloir = len(cibles_decouverte)

        con = sqlite3.connect(gpkg_path)
        try:
            cur = con.cursor()

            feedback.pushInfo(f"  {len(dolines)} dolines chargées.")
            feedback.pushInfo(
                f"  {n_bonus_hors_couloir} cibles de découverte "
                f"(prof >= {DECOUVERTE_PROF_MIN}m, dist reseau > {DECOUVERTE_DIST_MIN}m ou sans topo)"
            )

            # ── Stats par priorité ────────────────────────────────────────────
            cur.execute("""
                SELECT priorite, COUNT(*),
                       ROUND(AVG(surface_m2),0), ROUND(MAX(surface_m2),0),
                       ROUND(AVG(profondeur_m),2), ROUND(MAX(profondeur_m),2),
                       ROUND(AVG(score),1), ROUND(MAX(score),1)
                FROM dolines GROUP BY priorite ORDER BY MAX(score) DESC
            """)
            stats = {}
            for row in cur.fetchall():
                stats[row[0]] = {
                    "n": row[1], "surf_moy": row[2], "surf_max": row[3],
                    "prof_moy": row[4], "prof_max": row[5],
                    "score_moy": row[6], "score_max": row[7],
                }

            # ── Cavités, topo ─────────────────────────────────────────────────
            def count_table(table):
                try:
                    cur.execute(f"SELECT COUNT(*) FROM {table}")
                    return cur.fetchone()[0]
                except Exception:
                    return 0

            n_cavites = count_table("cavites")
            n_topo = count_table("topo_reseau")
            n_hydro = count_table("hydrologie")
            n_cav_georisques = count_table("cavites_georisques")

            from karstpro.core.sync import (
                find_inventory_layer, find_tracages_layer,
            )

            # Traçages : gpkg traçages externe si fourni, sinon la couche
            # traçages présente dans le gpkg courant (détectée par schéma).
            tracages_rows = []
            tr_src = None   # (gpkg_path, table) pour détecter le CRS
            if tracages_gpkg is not None and tracages_gpkg.exists():
                tracages_rows = self._read_external_tracages(tracages_gpkg, feedback)
                tr_src = (tracages_gpkg, find_tracages_layer(tracages_gpkg))
            else:
                tbl = find_tracages_layer(gpkg_path)
                if tbl:
                    try:
                        tracages_rows = self._read_tracages_gpkg(
                            cur, feedback, table=tbl)
                        tr_src = (gpkg_path, tbl)
                    except Exception as e:
                        feedback.pushWarning(f"Traçages (gpkg courant) ignorés : {e}")

            # Filtre spatial des traçages sur la box d'étude : on garde un tracé
            # si son injection OU sa résurgence tombe dans la box (un axe qui
            # traverse le secteur est pertinent). Les extrémités sont arrondies
            # au mètre dans la lecture → on ne filtre que pour un source L93
            # (en WGS84 l'arrondi degré détruit la coordonnée) ; sinon on garde
            # tout, comme avant.
            if study_bbox and tracages_rows and tr_src is not None:
                tr_srs = self._table_srs_id(tr_src[0], tr_src[1])
                if tr_srs in (2154, 0, None):
                    bx0, by0, bx1, by1 = study_bbox

                    def _in_box(x, y):
                        return bx0 <= x <= bx1 and by0 <= y <= by1
                    before = len(tracages_rows)
                    tracages_rows = [
                        t for t in tracages_rows
                        if _in_box(t["x_inj"], t["y_inj"]) or _in_box(t["x_res"], t["y_res"])]
                    if len(tracages_rows) < before:
                        feedback.pushInfo(
                            f"  Traçages : {len(tracages_rows)}/{before} dans la box d'étude.")
                else:
                    feedback.pushInfo(
                        f"  Traçages en EPSG:{tr_srs} (non L93) : filtre spatial "
                        "non appliqué, tous conservés.")

            # Cavités connues : gpkg inventaire externe si fourni, sinon la couche
            # inventaire présente dans le gpkg courant (cavites_connues /
            # « Inventaire Cavités », hors tampon cavites). Filtrées sur la box
            # d'étude (l'inventaire peut couvrir un département entier).
            cavites_connues_rows = []
            if inventory_gpkg is not None and inventory_gpkg.exists():
                cavites_connues_rows = self._read_external_cavites_connues(
                    inventory_gpkg, feedback, bbox=study_bbox)
            elif find_inventory_layer(gpkg_path):
                cavites_connues_rows = self._read_external_cavites_connues(
                    gpkg_path, feedback, bbox=study_bbox)

            n_cav_connues = len(cavites_connues_rows)
            n_tracages = len(tracages_rows)

            # Charger les cavités Géorisques BRGM si présentes
            cavites_georisques_rows = []
            if n_cav_georisques > 0:
                try:
                    cur.execute("""
                        SELECT nom_cavite, type_cavite, identifiant,
                               date_validite, reperage_geographique
                        FROM cavites_georisques
                        ORDER BY nom_cavite
                    """)
                    cols_geo = ["nom_cavite", "type_cavite", "identifiant",
                                "date_validite", "reperage_geographique"]
                    for r in cur.fetchall():
                        cavites_georisques_rows.append(
                            {c: _clean_text(v) for c, v in zip(cols_geo, r)})
                except Exception:
                    pass

            # Gouffres / puits détectés (vides LiDAR) et points d'eau référencés
            # (sources/pertes BD Topo). Couches écrites par la préparation v1.2+.
            gouffres_rows = []
            if count_table("gouffres") > 0:
                try:
                    gouffres_rows = self._read_point_layer(
                        cur, "gouffres",
                        ["surface_m2", "compacite", "couronne_sol", "diametre_m",
                         "interet", "comment"],
                        feedback)
                except Exception as e:
                    feedback.pushWarning(f"Gouffres ignorés : {e}")
            points_eau_rows = []
            if count_table("bdtopo_eau") > 0:
                try:
                    points_eau_rows = self._read_point_layer(
                        cur, "bdtopo_eau", ["type", "toponyme", "code"], feedback)
                except Exception as e:
                    feedback.pushWarning(f"Points d'eau ignorés : {e}")

        finally:
            con.close()

        feedback.pushInfo(
            f"  {n_topo} segments topo, {n_cavites} cavites, "
            f"{n_cav_connues} cavité(s) connue(s), {n_tracages} traçage(s), "
            f"{len(gouffres_rows)} gouffre(s), {len(points_eau_rows)} point(s) d'eau."
        )
        feedback.setProgress(30)

        # ── Séparation par priorité ───────────────────────────────────────
        rouges  = [d for d in dolines if d["priorite"] == "rouge"]
        oranges = [d for d in dolines if d["priorite"] == "orange"]
        jaunes  = [d for d in dolines if d["priorite"] == "jaune"]
        gris    = [d for d in dolines if d["priorite"] == "gris"]

        # ── Carte de contexte (PNG) — hillshade MNT + dolines par priorite ──
        # Calculee tot pour pouvoir la mentionner dans le prompt lui-meme.
        # Utile pour un LLM MULTIMODAL (vision) : donne un vrai visuel des
        # alignements/clusters, chose que les tableaux de coordonnees ne
        # permettent pas de "voir". Rendu 100% QGIS natif (aucune nouvelle
        # dependance : pas de matplotlib/Pillow). Best-effort : un echec ici
        # n'empeche pas le reste de l'export.
        map_path = _export_context_map(gpkg_path, dolines, export_dir, secteur,
                                        today, feedback)

        # ── GPX (rouges + oranges) — écrit une seule fois par script, coordonnées
        # exactes. Ne JAMAIS redemander au LLM de le régénérer/réordonner en
        # sortie : on aurait déjà le fichier en main, lui en redemander une copie
        # est redondant et, sur des centaines de points, un vrai risque de
        # dégradation (troncature/doublon silencieux dans une sortie longue et
        # répétitive). La mission §5 se limite à demander l'ORDRE de visite
        # (liste d'IDs, quelques lignes) — le GPX lui-même reste tel quel.
        # Best-effort : un échec ici n'empêche pas le reste.
        cibles = rouges + oranges
        gpx_path = export_dir / f"cibles_{secteur}_{today}.gpx"
        gpx_written = False
        try:
            _write_gpx(cibles, gpx_path, secteur)
            gpx_written = True
        except Exception as e:
            feedback.pushWarning(f"GPX non genere : {e}")

        # Moteur de scoring effectif : si score_ml est renseigné, c'est le
        # modèle appris (régression logistique par domaine) qui a piloté
        # score/priorite ; sinon, les poids manuels (barème Bloc A). Le rapport
        # DOIT décrire le bon moteur, sinon le LLM raisonne sur une fausse
        # prémisse (score = proba×100 vs somme de barèmes).
        def _has_ml(d):
            v = d.get("score_ml")
            try:
                return v is not None and not math.isnan(float(v))
            except (TypeError, ValueError):
                return False
        model_applied = any(_has_ml(d) for d in dolines)

        # ── Clustering spatial rouges + oranges (radius 400 m) ───────────
        cibles_top = rouges + oranges
        clusters = _compute_clusters(cibles_top, radius_m=400.0)

        # Résumé des clusters pour le rapport
        cluster_summary: dict = {}   # label → liste de fids
        for d in cibles_top:
            lbl = clusters.get(d.get("fid"), "·")
            if lbl != "·":
                cluster_summary.setdefault(lbl, []).append(d)

        # ── Gouffres & points d'eau : section MLL ─────────────────────────
        # On relie chaque feature à la cible (rouge/orange) la plus proche : un
        # gouffre détecté à 40 m d'une P1 est un signal de verticalité concret ;
        # une source/perte BD Topo proche oriente l'hypothèse hydrologique.
        def _nearest_cible(x, y):
            best, bd = None, None
            for d in cibles_top:
                dx, dy = d.get("x_l93"), d.get("y_l93")
                if dx is None or dy is None:
                    continue
                dist = math.hypot(x - dx, y - dy)
                if bd is None or dist < bd:
                    best, bd = d, dist
            return best, bd

        # ── CSV des gouffres à prospecter ────────────────────────────────
        # Fichier SÉPARÉ du CSV des dolines : les deux n'ont aucune colonne
        # métier en commun (diametre_m/compacite/couronne_sol contre
        # surface_m2/profondeur_m/score/priorite). Les fusionner donnerait un
        # tableau à moitié vide, pénible à lire pour un LLM et inexploitable
        # tel quel à l'import QGIS. Écrit AVANT la section pour que celle-ci
        # puisse renvoyer vers le fichier quand la liste dépasse le plafond.
        gouffres_a_faire = self._gouffres_a_prospecter(gouffres_rows)
        gouffres_csv_filename = f"mll_gouffres_{secteur}_{today}.csv"
        gouffres_csv_written = False
        if gouffres_a_faire:
            try:
                _write_gouffres_csv(gouffres_a_faire, _nearest_cible,
                                    export_dir / gouffres_csv_filename)
                gouffres_csv_written = True
            except Exception as e:
                feedback.pushWarning(f"CSV gouffres non genere : {e}")

        gouffres_section = self._build_gouffres_section(
            gouffres_rows, _nearest_cible,
            gouffres_csv_filename if gouffres_csv_written else "")
        points_eau_section = self._build_points_eau_section(points_eau_rows, _nearest_cible)
        pc_anomaly_section = self._build_pc_anomaly_section(dolines)
        rgealti_section = self._build_rgealti_section(dolines)

        # ── Rapport Markdown ──────────────────────────────────────────────
        def _table_row(d, rank):
            ratio  = f"{d['ratio_ps']:.3f}" if d.get("ratio_ps") is not None else "—"
            pente  = f"{d['pente_max_bord']:.0f}°" if d.get("pente_max_bord") is not None else "—"
            lisere = "✓" if d.get("lisere") else "—"
            alt    = d.get("altitude_m")
            alt_str = f"{alt:.0f}" if alt is not None else "—"
            coords = f"{int(d['x_l93'])},{int(d['y_l93'])}" if d.get("x_l93") else "—"
            absorb = "✓" if d.get("comp_absorption") else "—"
            geo    = "✓" if d.get("comp_geologie") else "—"
            dist_r = d.get("comp_dist_reseau_m")
            dist_str = f"{int(dist_r)}" if dist_r is not None and not math.isnan(float(dist_r)) else "—"
            clust  = clusters.get(d.get("fid"), "·")
            flag   = " 🔍" if d.get("decouverte") else ""
            flag  += " 🏛️" if d.get("cavite_connue_proche") else ""
            _pc    = d.get("pc_plongee_m")
            flag  += " 🔻" if (_pc is not None and not (isinstance(_pc, float) and math.isnan(_pc))) else ""
            _rge   = d.get("rge_contrast_m")
            flag  += " 🔵" if (_rge is not None and not (isinstance(_rge, float) and math.isnan(_rge))) else ""
            typ    = d.get("type_doline") or "—"
            tpi    = d.get("tpi_500m")
            tpi_str = f"{tpi:+.1f}" if isinstance(tpi, (int, float)) and not math.isnan(float(tpi)) else "—"
            return (f"| {clust} | {rank} | doline_{d['fid']}{flag} | {typ} | {alt_str} | "
                    f"{d['surface_m2']} | {d['profondeur_m']} | {ratio} | {pente} | "
                    f"{lisere} | {absorb} | {geo} | {tpi_str} | "
                    f"{d['score_morpho']} | **{d['score']}** | "
                    f"{dist_str} | {coords} |")

        lines = []
        def w(s=""): lines.append(s)

        w(f"# KarstPro — Analyse secteur « {secteur} »")
        w(f"Date export : {date.today()}  |  Source : {gpkg_path.name}")
        if extra_context:
            w()
            w("## Contexte terrain")
            w()
            w(extra_context)
        w()
        w("---")
        w()
        w("## Résumé")
        w()
        w(f"- **{len(dolines)} dépressions** détectées par LiDAR HD IGN (résolution 1m)")
        w(f"- Réseau karstique connu : **{n_topo} segment(s)** de galeries")
        w(f"- Réseau hydrologique D8 : **{n_hydro} entités**")
        w(f"- Cavités relevées sur le terrain : **{n_cavites}**")
        w(f"- **Cibles de découverte** (prof ≥ 5m, hors réseau connu) : **{n_bonus_hors_couloir}**"
          f" — signalées 🔍 dans les tableaux")
        n_total_cav_ref = n_cav_connues + n_cav_georisques
        if n_total_cav_ref > 0:
            n_proches = sum(1 for d in dolines if d.get("cavite_connue_proche"))
            w(f"- **Cavités référencées dans le secteur** : **{n_total_cav_ref}**"
              f" ({n_cav_connues} utilisateur + {n_cav_georisques} Géorisques BRGM)"
              f" | {n_proches} doline(s) à moins de 20 m — signalées 🏛️")
        w()
        w("## Répartition par priorité")
        w()
        w("| Priorité | Nb | Surf. moy. (m²) | Surf. max (m²) | Prof. moy. (m) | Prof. max (m) | Score moy. | Score max |")
        w("|----------|----|-----------------|----------------|----------------|---------------|------------|-----------|")
        for prio, label in [("rouge","Rouge"), ("orange","Orange"),
                             ("jaune","Jaune"), ("gris","Gris")]:
            s = stats.get(prio)
            if s:
                w(f"| {label} | {s['n']} | {s['surf_moy']} | {s['surf_max']} | "
                  f"{s['prof_moy']} | {s['prof_max']} | {s['score_moy']} | {s['score_max']} |")
        w()
        _geo_md = _geology_context_md(gpkg_path)
        if _geo_md:
            w(_geo_md)
            w()
        w("## Critères de scoring")
        w()
        if model_applied:
            w("**Moteur effectif : MODÈLE APPRIS par domaine géologique (régression logistique).**")
            w("`score` = probabilité du modèle ×100 (= colonne `score_ml`) ; les priorités "
              "rouge/orange/jaune sont issues des seuils de probabilité propres au modèle, "
              "PAS des seuils 55/35/25 du barème manuel.")
            w("`score_morpho` (barème manuel ci-dessous) reste fourni pour comparaison. "
              "Validation hors-échantillon (inventaire indépendant), selon le domaine "
              "géologique retenu par le routeur pour ce secteur : AUC 0,65–0,72 (Barrois) "
              "ou 0,60–0,64 (Lot/Dordogne/Ardèche) vs 0,57 pour le barème manuel — le modèle "
              "précis appliqué ici n'est pas re-identifiable depuis ce rapport, voir le log "
              "de préparation du secteur. Le score CLASSE les cibles, il ne prédit pas une "
              "cavité : la précision au sommet reste à confirmer terrain.")
        else:
            w("**Moteur effectif : barème manuel Bloc A (morphologie uniquement) — 0 à 100 pts [v2.0]. "
              "Priorisation EXPLORATOIRE** (hors-échantillon ≈ hasard, AUC 0,57) — "
              "à traiter comme un filtre visuel, pas une prédiction.")
            w("Seuils de priorité v2 : P1 ≥ 55 | P2 ≥ 35 | P3 ≥ 25 | Hors seuil < 25")
        w("Le score est indépendant du réseau topo connu : un massif vierge score autant qu'un massif exploré.")
        w()
        w("**Composantes du barème morphologique (= colonne `score_morpho`) :**")
        w()
        w("| Composante | Colonne | Poids max | Remarque |")
        w("|------------|---------|-----------|----------|")
        w("| Profondeur | profondeur_m | **30 pts** | Seuils 0.3/1.0/3.0/8.0 m — continu +0.4pt/m > 8m |")
        w("| Surface | surface_m2 | 10 pts | Seuils 50/300/1500 m² |")
        w("| Ratio P/√S | ratio_ps | 8 pts | Potentiel vertical — seuils 0.1/0.2/0.4 |")
        w("| Pente bord | pente_max_bord | 20 pts | p90 anneau 5m — seuils 20/45/70° |")
        w("| Liseré | lisere | 10 pts | Alignement 100m/20° — karst de contact |")
        w("| Absorption | bassin_versant_m2 | 18 pts | Bassin versant D8 — seuils 1k/5k/20k m² |")
        w("| Contact géol. | comp_geologie | 25 pts | Gradient exponentiel τ=250m × facteur karstifiabilité |")
        w("| TPI 500m | tpi_500m | 8 pts | Alt. vs terrain (MNT) 500m — doline sommitale vs fond vallon |")
        w()
        w("**Colonnes calculées mais hors score (informatives)**")
        w("- `circularite` : 4π·S/P² — pénalisait les dolines structurales allongées (supprimé du score v2)")
        w("- `comp_densite_500m` : nb voisines dans 500m — non-discriminant en Barrois dense (supprimé du score v2)")
        w("- `comp_dist_reseau_m` : distance au passage topo le plus proche (NaN si pas de topo)")
        w("- `comp_in_couloir` : booléen — doline dans un buffer 500m autour des galeries connues")
        w("- **Absorb.** ✓ = bassin versant ≥ 5 000 m²  |  **Géol.** ✓ = centroïde sur formation karstifiable")
        w("- **Dist. réseau** : distance en mètres au passage topo le plus proche (— si pas de topo)")
        w()
        _TABLE_HEADER = ("| Cluster | # | ID | Type | Alt. (m) | Surface (m²) | Prof. (m) | P/√S | "
                         "Pente bord | Liseré | Absorb. | Géol. | TPI (m) | "
                         "Score morpho | Score | Dist. réseau (m) | X_L93,Y_L93 |")
        _TABLE_SEP    = ("|---------|---|----|------|----------|-------------|-----------|------|"
                         "------------|--------|---------|-------|---------|"
                         "--------------|-------|------------------|-------------|")

        w("## Clusters géographiques (cibles rouges + oranges, rayon 400 m)")
        w()
        if cluster_summary:
            w("| Cluster | Nb dolines | IDs | Alt. min–max (m) | Centroïde approx. X_L93,Y_L93 |")
            w("|---------|------------|-----|-----------------|-------------------------------|")
            for lbl in sorted(cluster_summary):
                members = cluster_summary[lbl]
                ids = ", ".join(f"doline_{d['fid']}" for d in
                                sorted(members, key=lambda x: x.get("score") or 0, reverse=True))
                xs = [d["x_l93"] for d in members if d.get("x_l93")]
                ys = [d["y_l93"] for d in members if d.get("y_l93")]
                cx = f"{int(sum(xs)/len(xs))}" if xs else "—"
                cy = f"{int(sum(ys)/len(ys))}" if ys else "—"
                alts = [d["altitude_m"] for d in members if d.get("altitude_m") is not None]
                alt_range = f"{min(alts):.0f}–{max(alts):.0f}" if alts else "—"
                w(f"| {lbl} | {len(members)} | {ids} | {alt_range} | {cx},{cy} |")
            n_isolees = sum(1 for d in cibles_top if clusters.get(d.get("fid")) == "·")
            if n_isolees:
                w(f"| · | {n_isolees} | (dolines isolées — > 400 m de toute autre cible) | — | — |")
        else:
            w("Aucun cluster détecté (toutes les cibles rouges/oranges sont à > 400 m les unes des autres).")
        w()
        w("## Cibles prioritaires")
        w()
        w(f"- **P1 (rouges)** : {len(rouges)} dolines.")
        w(f"- **P2 (oranges)** : {len(oranges)} dolines.")
        w(f"- **P3 (jaunes)** : {len(jaunes)} dolines.")
        w(f"- **Grises (hors seuil)** : {len(gris)} dolines — non détaillées "
          "(sous le seuil de prospection, exclues du CSV/JSON).")
        w()
        w("Toutes les caractéristiques par doline (P1 entières + meilleures "
          "P2/P3, cf. plafond ci-dessous) sont dans les fichiers CSV/JSON "
          "joints, pas dans ce texte — évite un rapport de plusieurs milliers "
          "de lignes pour des données déjà disponibles sous forme tabulaire.")
        w()
        w("## Cibles de découverte 🔍")
        w()
        w("> Dolines avec **profondeur ≥ 5m ET distance au réseau topo > 500m** (ou sans topo renseignée).")
        w("> Fort signal morphologique dans une zone non documentée — potentiel de réseau nouveau.")
        w("> Le score reflète uniquement la morphologie : ces dolines ne sont PAS pénalisées")
        w("> par leur éloignement du réseau connu (le Bloc B positionnel a été supprimé).")
        w()
        if cibles_decouverte:
            w(_TABLE_HEADER)
            w(_TABLE_SEP)
            for i, d in enumerate(sorted(cibles_decouverte,
                                         key=lambda x: x.get("profondeur_m") or 0,
                                         reverse=True), 1):
                w(_table_row(d, i))
        else:
            w("Aucune doline répondant aux critères de découverte (prof ≥ 5m, hors réseau).")
        w()
        if cavites_connues_rows:
            w("## Cavités connues dans le secteur 🏛️")
            w()
            w("> Ces cavités sont déjà répertoriées et (partiellement) explorées.")
            w("> Les dolines marquées 🏛️ dans les tableaux ci-dessus sont à moins de 20 m")
            w("> d'une de ces cavités — elles peuvent être une entrée alternative,")
            w("> un prolongement non exploré, ou un doublon à déprioritiser.")
            w()
            w("| Nom | Type | Découverte | Dernière explo | Explorateurs | Commentaire | Référence |")
            w("|-----|------|------------|----------------|--------------|-------------|-----------|")
            for c in cavites_connues_rows:
                w(f"| {c.get('name','')} | {c.get('type','')} | {c.get('date_disc','')} | "
                  f"{c.get('date_expl','')} | {c.get('explorers','')} | "
                  f"{c.get('comment','')} | {c.get('reference','')} |")

        w()
        w("## Données brutes (fichier séparé)")
        w()
        # Dump borné pour ne pas dépasser la fenêtre de contexte du LLM :
        #  - toutes les P1 (rouges) — les cibles prioritaires, jamais tronquées ;
        #  - les 300 meilleures P2+P3 (oranges+jaunes) par score ;
        #  - grises (hors seuil) exclues (~70 % du volume, sous le seuil).
        # Le score n'étant pas validé, on garde les jaunes dans le vivier P2/P3.
        P2P3_CAP = 300
        p2p3 = sorted(
            [d for d in dolines if d.get("priorite") in ("orange", "jaune")],
            key=lambda d: (d.get("score") or 0), reverse=True)
        p2p3_kept = p2p3[:P2P3_CAP]
        dolines_json = rouges + p2p3_kept
        n_p2p3_exclus = len(p2p3) - len(p2p3_kept)
        # JSON écrit dans un fichier à part (mll_data_<secteur>_<date>.json),
        # plutôt qu'embarqué dans le .txt : un rapport de 400k+ caractères
        # mêlant prose et JSON brut est illisible à l'œil humain, et rien
        # n'empêche de joindre les deux fichiers au même message LLM.
        data_filename = f"mll_data_{secteur}_{today}.json"
        data_path = export_dir / data_filename
        data_path.write_text(
            json.dumps(dolines_json, ensure_ascii=False, indent=2),
            encoding="utf-8")

        # CSV : mêmes lignes que le JSON, format tabulaire (Excel/QGIS direct)
        # — remplace les tableaux markdown auparavant embarqués dans ce
        # rapport (P1 entières + P2 plafonnées à 30), qui dupliquaient déjà
        # les mêmes valeurs que le JSON. Best-effort : un échec ici n'empêche
        # pas le reste de l'export (le JSON reste la source de vérité).
        csv_filename = f"mll_data_{secteur}_{today}.csv"
        csv_written = False
        try:
            _write_data_csv(dolines_json, export_dir / csv_filename)
            csv_written = True
        except Exception as e:
            feedback.pushWarning(f"CSV de donnees non genere : {e}")

        w(f"Toutes les valeurs par doline (coordonnées L93/WGS84/UTM "
          f"précalculées, tous les attributs) sont dans les fichiers joints "
          f"**`{csv_filename}`** (tableau, à ouvrir directement dans "
          f"Excel/QGIS) et **`{data_filename}`** (JSON, mêmes données) : "
          f"{len(rouges)} P1 (toutes) + {len(p2p3_kept)} meilleures P2/P3 "
          f"(plafond {P2P3_CAP}). Exclues : {n_p2p3_exclus} autres P2/P3 + "
          f"{len(gris)} grises hors-seuil.")
        w()
        w("Joins ces fichiers à ce message — toute valeur chiffrée que tu "
          "cites doit en provenir, jamais d'une estimation.")

        if gouffres_csv_written:
            w()
            w(f"Les {len(gouffres_a_faire)} gouffres à prospecter (jamais "
              f"visités) sont dans **`{gouffres_csv_filename}`** — fichier "
              f"séparé, colonnes propres aux puits verticaux.")

        report = "\n".join(lines)

        # ── Prompt MLL ───────────────────────────────────────────────────
        has_topo = n_topo > 0
        topo_line = (f"- Réseau karstique connu : {n_topo} segments de galeries (informatif — hors score)"
                     if has_topo else
                     "- Pas de réseau karstique connu dans ce secteur")

        context_parts = []
        if extra_context:
            context_parts.append(extra_context)
        if pendage:
            context_parts.append(f"Direction du pendage / sens de drainage : {pendage}")
        if zones_exclues:
            context_parts.append(f"Zones à exclure de la prospection : {zones_exclues}")
        context_section = ("\n## Contexte terrain spécifique\n\n"
                           + "\n\n".join(context_parts) + "\n") if context_parts else ""

        cavites_connues_section = ""
        n_proches_prompt = sum(1 for d in dolines if d.get("cavite_connue_proche"))

        if cavites_connues_rows or cavites_georisques_rows:
            # Tableau cavités utilisateur
            tableau_utilisateur = ""
            if cavites_connues_rows:
                tableau_utilisateur = "\n### Cavités fournies par l'utilisateur\n\n"
                tableau_utilisateur += "| Nom | Type | Date découv. | Explorateurs | Référence |\n"
                tableau_utilisateur += "|-----|------|--------------|--------------|----------|\n"
                for c in cavites_connues_rows:
                    tableau_utilisateur += (
                        f"| {c.get('name','') or '—'} | {c.get('type','') or '—'} | "
                        f"{c.get('date_disc','') or '—'} | {c.get('explorers','') or '—'} | "
                        f"{c.get('reference','') or '—'} |\n"
                    )

            # Tableau Géorisques
            tableau_georisques = ""
            if cavites_georisques_rows:
                tableau_georisques = "\n### Cavités BRGM Géorisques (inventaire national)\n\n"
                tableau_georisques += "| Nom | Type | Identifiant BRGM | Date validité | Repérage |\n"
                tableau_georisques += "|-----|------|------------------|---------------|----------|\n"
                for c in cavites_georisques_rows:
                    tableau_georisques += (
                        f"| {c.get('nom_cavite','') or '—'} | {c.get('type_cavite','') or '—'} | "
                        f"{c.get('identifiant','') or '—'} | {c.get('date_validite','') or '—'} | "
                        f"{c.get('reperage_geographique','') or '—'} |\n"
                    )

            cavites_connues_section = f"""
## Cavités référencées dans le secteur ({n_total_cav_ref} au total)

{tableau_utilisateur}{tableau_georisques}
Les dolines marquées 🏛️ dans les tableaux sont à moins de 20 m de l'une de ces cavités ({n_proches_prompt} au total).

Pour chaque doline 🏛️ :
- Évalue si c'est un doublon (même phénomène, entrée différente) ou un prolongement potentiel non exploré
- Indique explicitement dans ton analyse quelle cavité connue est concernée et ce que ça implique pour la prospection
- Une cavité "connue" peut être peu ou anciennement explorée — ne l'exclure que si elle est clairement exhaustivement topographiée
- Les cavités Géorisques sont souvent des points d'inventaire administratif peu documentés : traite-les avec plus de recul qu'une cavité fournie par l'utilisateur
"""

        # ── Traçages hydrologiques (réseau perte→résurgence connu) ─────────
        tracages_section = ""
        if tracages_rows:
            tbl = "| Injection (perte) | Résurgence | Colorant | Résultat | Transit | Distance (m) | Inj. L93 | Rés. L93 |\n"
            tbl += "|---|---|---|---|---|---|---|---|\n"
            for t in tracages_rows:
                dist = t.get("distance_m")
                dist_s = f"{dist:.0f}" if isinstance(dist, (int, float)) else "—"
                tbl += (
                    f"| {t.get('point_injection') or '—'} | {t.get('point_sortie') or '—'} | "
                    f"{t.get('colorant') or '—'} | {t.get('resultat') or '—'} | "
                    f"{t.get('temps_transit') or '—'} | {dist_s} | "
                    f"{t['x_inj']:.0f},{t['y_inj']:.0f} | {t['x_res']:.0f},{t['y_res']:.0f} |\n"
                )
            tracages_section = f"""
## Traçages hydrologiques connus ({len(tracages_rows)} tracé(s))

Connexions perte→résurgence établies par traçage colorimétrique. Les coordonnées L93
des points d'injection et de résurgence te permettent de situer ces axes par rapport aux dolines/cibles.

{tbl}
Exploite ce réseau pour l'interprétation :
- Une cible **entre** un point d'injection et une résurgence (sur l'axe de drainage) est probablement sur un drain actif → intérêt accru.
- Une cible **en amont** d'une perte tracée peut alimenter le même système.
- Une zone à fort signal morphologique **sans résurgence connue en aval** peut signaler une résurgence potentielle non identifiée.
- Un résultat **négatif** signifie une absence de connexion démontrée — n'en déduis pas une connexion inverse.
- Le temps de transit renseigne sur le type d'écoulement (rapide = conduit ouvert, lent = réseau noyé/diffus).
"""

        decouverte_section = ""
        if cibles_decouverte:
            ids = ", ".join(f"doline_{d['fid']}" for d in
                            sorted(cibles_decouverte,
                                   key=lambda x: x.get("profondeur_m") or 0,
                                   reverse=True)[:10])
            decouverte_section = f"""
## Cibles de découverte ({n_bonus_hors_couloir} dolines)

**{n_bonus_hors_couloir} dolines** : profondeur ≥ 5m et distantes du réseau topo connu (> 500m ou sans topo).
Ces dolines ont un fort signal morphologique dans une zone non documentée — potentiel de réseau nouveau.
Leur score est identique aux autres : le scoring est purement morphologique, sans pénalité d'éloignement.
Top par profondeur : {ids}
Ces dolines portent le marqueur 🔍 dans les tableaux et ont leur propre section "Cibles de découverte".
Traite-les comme des cibles de prospection autonomes — potentiellement les plus intéressantes pour la découverte.
"""

        # Résumé clusters pour le prompt
        cluster_prompt_lines = []
        for lbl in sorted(cluster_summary):
            members = cluster_summary[lbl]
            ids = ", ".join(f"doline_{d['fid']}" for d in
                            sorted(members, key=lambda x: x.get("score") or 0, reverse=True))
            xs = [d["x_l93"] for d in members if d.get("x_l93")]
            ys = [d["y_l93"] for d in members if d.get("y_l93")]
            cx = f"{int(sum(xs)/len(xs))}" if xs else "?"
            cy = f"{int(sum(ys)/len(ys))}" if ys else "?"
            cluster_prompt_lines.append(f"  - Cluster {lbl} ({len(members)} dolines) : {ids} — centroïde L93 {cx},{cy}")
        clusters_section = ""
        if cluster_prompt_lines:
            clusters_section = (
                "\n## Clusters géographiques pré-calculés (rayon 400 m)\n\n"
                "Ces clusters sont calculés automatiquement — utilise-les comme base pour l'organisation par journée :\n"
                + "\n".join(cluster_prompt_lines) + "\n"
            )

        scoring_engine_line = (
            "**Priorisation par MODÈLE APPRIS (régression logistique par domaine "
            "géologique)** : `score` = probabilité ×100 ; `score_morpho` = barème "
            "morphologique manuel, fourni pour comparaison. AUC hors-échantillon "
            "0,60–0,72 selon le domaine (vs 0,57 manuel) — le score CLASSE, il ne "
            "prédit pas une cavité"
            if model_applied else
            "**Score = barème morphologique Bloc A v2.0 (poids manuels, EXPLORATOIRE)** : "
            "profondeur, surface, ratio P/√S, pente bord, liseré, absorption, contact "
            "géologique, TPI 500m — hors-échantillon ce barème ≈ hasard (AUC 0,57), "
            "à traiter comme filtre visuel"
        )

        attachments_note = (
            "\n## Fichiers à joindre à ce message\n\n"
            + (
                f"- **`{csv_filename}`** (CSV) — toutes les valeurs par doline "
                "en tableau, ouvrable directement dans Excel/QGIS.\n"
                if csv_written else ""
            )
            + f"- **`{data_filename}`** (JSON) — mêmes données que le CSV, "
            "format structuré. Source unique de vérité pour toute valeur "
            "chiffrée que tu cites : ne l'estime jamais depuis le texte ou "
            "l'image.\n"
            + (
                f"- **`{gouffres_csv_filename}`** (CSV) — les gouffres / puits "
                "verticaux **jamais visités**, à prospecter au même titre que "
                "les dolines. Fichier séparé : colonnes propres aux puits "
                "(diamètre, compacité), sans rapport avec celles des dolines.\n"
                if gouffres_csv_written else ""
            )
            + (
                f"- **`{map_path.name}`** (PNG, si tu es multimodal) — "
                "relief (ombrage MNT, exagération verticale x2,5 pour rester "
                "lisible même sous la géologie et en zone boisée) avec les "
                "cibles rouges et oranges (P1/P2 uniquement — jaunes/grises "
                "non tracées, non détaillées dans ce rapport), un anneau noir "
                "sur les cibles avec signal ponctuel (nuage LiDAR brut, cf. "
                "section dédiée ci-dessus), le réseau karstique déjà "
                "topographié (traits bleu foncé) si disponible, et les "
                "formations géologiques BRGM en semi-transparence (légende, "
                "échelle, flèche du nord intégrées à l'image). Sert "
                "uniquement à juger visuellement "
                "des alignements structuraux, de l'orientation et de la "
                "répartition spatiale (sans présumer qu'une formation "
                "non-calcaire exclut toute karstification locale) — n'en "
                "déduis AUCUNE coordonnée ni distance précise par estimation "
                "en pixels, utilise toujours le JSON pour les valeurs "
                "chiffrées.\n"
                if map_path else ""
            )
        )

        # Mission GPX : le fichier existe déjà (écrit une seule fois par script,
        # coordonnées exactes), mais il n'est PAS joint au message MLL — le LLM
        # n'en a pas besoin, l'ordre de visite se calcule depuis les coordonnées
        # déjà présentes dans le JSON. Le GPX ne sert qu'au terrain (Garmin/
        # OruxMaps/QGIS), indépendamment de cette conversation ; on ne lui
        # redemande JAMAIS de le régénérer (sortie longue et répétitive =
        # risque de troncature/doublon silencieux, et de toute façon redondant
        # avec un fichier déjà correct). Sa mission se limite à l'ORDRE de
        # visite (liste d'IDs, quelques lignes) — un simple ordre de lecture
        # humain, pas une donnée à réinjecter dans un fichier.
        gpx_section = (
            f"""**5. Ordre de visite — à produire obligatoirement**
Donne uniquement la liste ordonnée des IDs de cibles (rouges et oranges),
dans l'ordre de visite optimal que tu as déterminé (regroupement
géographique / clusters, pas le score brut), répartie par journée de
prospection (2-3 journées). Exemple de format :

```
Journée 1 : doline_2333_R, doline_76_R, doline_1950_R, ...
Journée 2 : doline_2076_R, doline_2485_R, ...
```

Ne recopie ni ne régénère aucune coordonnée ni aucun fichier GPX — cette
liste d'IDs est juste une feuille de route à lire, pas une donnée à
réencoder dans un fichier."""
            if gpx_written else
            f"""**5. Ordre de visite — à produire obligatoirement**
Le GPX n'a pas pu être généré automatiquement. Donne la liste ordonnée des
IDs de cibles (rouges et oranges), dans l'ordre de visite optimal que tu as
déterminé (regroupement géographique, pas par score brut), répartie par
journée de prospection (2-3 journées) — ne recopie aucune coordonnée, elles
sont dans le fichier JSON joint (champs `lat_wgs84` / `lon_wgs84`)."""
        )

        prompt = f"""Tu es un expert en spéléologie et en analyse de terrain karstique.
Je te fournis les données d'analyse LiDAR HD d'un secteur karstique français pour la prospection spéléologique.
{attachments_note}
## Contexte du secteur « {secteur} »

- Zone analysée par LiDAR HD IGN (résolution 1m, classification sol/végétation automatique)
- {len(dolines)} dépressions karstiques (dolines) détectées automatiquement
{topo_line}
- {scoring_engine_line}{context_section}{cavites_connues_section}{gouffres_section}{points_eau_section}{pc_anomaly_section}{rgealti_section}{tracages_section}{decouverte_section}{clusters_section}

## Données d'analyse complètes

{report}

---

## Règles d'analyse (à respecter strictement)

- **N'invente AUCUNE valeur.** Chaque affirmation chiffrée doit citer l'ID de
  doline et la valeur EXACTE fournie dans le CSV ou le fichier JSON joints
  (mêmes données, deux formats). Si une donnée manque, écris « non renseigné »
  — ne l'estime pas.
- **N'effectue AUCUNE conversion de coordonnées.** Les champs `lat_wgs84` /
  `lon_wgs84` et `x_utm` / `y_utm` / `utm_zone` sont précalculés pour chaque
  doline dans le CSV/JSON joints : utilise-les tels quels. Une coordonnée
  recalculée de tête est une erreur de terrain.
- **Si tu regardes l'image jointe : n'en déduis AUCUNE coordonnée ni distance
  par estimation visuelle/en pixels** — l'échelle et le nord servent
  uniquement à juger des ordres de grandeur et de l'orientation à l'œil
  (alignements, espacement relatif des clusters). Toute valeur chiffrée
  (coordonnée, distance, surface) doit venir du CSV/JSON joints, jamais d'une
  lecture de l'image.
- **Calibre ta confiance** : le score CLASSE les cibles entre elles, il ne
  prédit pas une cavité. La majorité des P1 ne donneront probablement rien —
  ton rôle est d'optimiser l'ordre et la lecture de terrain, pas de promettre.
- Les dolines jaunes figurent dans le CSV/JSON joints (plafonné aux
  meilleures, cf. section « Cibles prioritaires » ci-dessus) : fouille-les pour
  les missions qui les concernent. **Les dolines grises sont hors seuil et
  ne figurent NULLE PART dans ce rapport** (ni texte, ni CSV, ni JSON) : n'en
  parle pas comme si tu avais des données sur elles.

## Ta mission

**0. Synthèse exécutive (à produire EN PREMIER)**
Un tableau des 10 cibles les plus prometteuses, toutes priorités confondues :
ID, type probable, confiance (haute/moyenne/faible), justification en 1 phrase
citant les valeurs (profondeur, P/√S, type_doline, TPI, contexte géol/hydro).

**1. Liste priorisée des cibles terrain**
Pour chaque doline rouge et orange (dans l'ordre de score décroissant) :
- Analyse individuelle : pourquoi ce score ? Quel type de phénomène probable (gouffre vertical / perte active / résurgence / galerie fossile) ? Appuie-toi sur type_doline, ratio P/√S, pente, bassin versant, TPI et le contexte géologique.
- **Confiance (haute/moyenne/faible) + test de terrain falsifiable** : qu'est-ce qui, sur place, confirmerait ou éliminerait la cible en moins de 10 minutes (courant d'air, ponor visible, remplissage, roche en place…) ?
- Regroupement géographique : identifie les clusters de dolines proches à visiter dans la même journée
- Ordre de visite optimal sur 2-3 journées de prospection

**2. Analyse structurale et hydrologique du secteur**
- Alignements de dolines (colonne liseré, clusters) : directions dominantes, cohérence avec l'azimut du pendage fourni{" et, si tu as l'image jointe, avec le tracé visible des contacts entre formations géologiques (couleurs BRGM) — c'est le SEUL endroit où ce tracé est visible, il n'existe dans aucun tableau ni JSON" if map_path else " (le tracé du contact lui-même n'est pas fourni dans ce rapport texte, seul l'azimut l'est)"} ?
- Croise les `type_doline` (perte / doline-perte) avec les traçages connus : quelles pertes alimentent probablement quel axe de drainage ? Où chercher des regards sur ce drainage ?
- TPI et altitude : les cibles se répartissent-elles en position sommitale (absorption directe) ou de fond de vallon (concentration) ? Qu'est-ce que cela implique pour le type de cavité attendu ?
- Quelles dolines jaunes (JSON) méritent quand même une vérification rapide ? Critère : morphologie atypique (P/√S élevé, profondeur > 3 m, type perte) malgré un score modeste — cite les IDs.

**3. Recommandations terrain pratiques**
- Signes à rechercher sur place pour chaque type de cible (courant d'air, dépôts, morphologie de l'entrée)
- Conditions optimales (saison, météo récente) pour ce type de karst
- Matériel spécifique à prévoir selon les profondeurs détectées

**4. Limites et incertitudes**
- Quelles dolines pourraient être des faux positifs ? Indices dans les données : surface très faible + profondeur faible (artefact), forme très allongée (circularite basse = fossé/ravin), proximité de zones anthropiques, absence de contexte karstifiable (Géol. = —).
- Facteurs non capturés par l'analyse automatique à vérifier sur le terrain
- Termine par un paragraphe d'honnêteté : ce que cette analyse NE permet PAS de conclure.

{gpx_section}

**6. Export CSV QGIS — à produire obligatoirement**
Génère un tableau CSV (séparateur `;`) de toutes les cibles, dans le même ordre de visite que la liste d'IDs du §5, avec les colonnes suivantes :

```
name;type;comment;score;priorite;surface_m2;profondeur_m;ratio_ps;x_l93;y_l93;latitude_wgs84;longitude_wgs84;x_utm;y_utm;utm_zone
```

- `type` : ta meilleure hypothèse parmi `gouffre/grotte/perte/résurgence/inconnu`
- `comment` : synthèse terrain en 1 phrase (indice principal, signe à rechercher)
- `latitude_wgs84`/`longitude_wgs84` : recopier `lat_wgs84`/`lon_wgs84` du CSV/JSON joints — aucun recalcul
- `x_utm`/`y_utm`/`utm_zone` : recopier `x_utm`/`y_utm`/`utm_zone` du CSV/JSON joints (coordonnées UTM WGS84 en mètres, grille des GPS de terrain) — aucun recalcul
- Les autres champs : valeurs numériques issues des données fournies

Ce CSV sera importé dans QGIS via Couche → Ajouter une couche de texte délimité, avec X=`x_l93`, Y=`y_l93`, SCR EPSG:2154.

**7. Rapport de prospection DOCX — à produire obligatoirement**
Génère un script Python complet et autonome utilisant `python-docx` (pip install python-docx).
Ce script, une fois exécuté, crée le fichier `rapport_{secteur}_<date>.docx` dans le dossier courant.

Le rapport DOCX doit contenir :
- **Page de titre** : secteur, date, nb cibles rouges / oranges
- **Résumé exécutif** (bullet points) : contexte, potentiel estimé, points clés de l'analyse
- **Tableau des cibles prioritaires** (toutes les rouges puis top 20 oranges) : colonnes ID, Coordonnées GPS WGS84, Profondeur (m), Surface (m²), Score, Type probable, Indice terrain
- **Organisation de la prospection** : planning par journées avec l'ordre de visite optimal que tu as déterminé
- **Analyse structurale** : alignements, direction de drainage, zones de prolongement probable
- **Recommandations terrain** : matériel, conditions, signes à rechercher
- **Fiche terrain vierge par cible rouge** : une mini-fiche par page (ID, coords, type supposé, case "observation", case "résultat")

Contraintes du script :
- Toutes les données (cibles, coordonnées WGS84 converties, scores, types supposés) doivent être **écrites en dur dans le script** à partir de ton analyse — pas de lecture de fichier externe
- Le script doit être **autonome** : `python rapport_<secteur>.py` suffit
- Utilise des styles Word lisibles : titre H1/H2, tableau avec en-tête coloré, police Arial
- Commence le bloc de code par ```python et termine par ```

Sois concis, pratique, et calibre tes réponses pour un spéléologue expérimenté qui connaît déjà le secteur."""

        feedback.setProgress(70)

        # export_dir / today déjà créés en début de _run (avec le fichier log)
        # Le prompt .txt embarque deja l'integralite du rapport (variable `report`
        # inseree dans `prompt`), donc on n'ecrit plus de .md redondant.
        prompt_path = export_dir / f"mll_prompt_{secteur}_{today}.txt"
        prompt_path.write_text(prompt, encoding="utf-8")

        feedback.setProgress(80)

        # GPX déjà écrit plus tôt (cf. gpx_written) — juste le signaler ici
        # pour garder l'ordre de log habituel.
        if gpx_written:
            feedback.pushInfo(f"GPX        : {gpx_path}")

        if map_path:
            feedback.pushInfo(f"Carte      : {map_path}")
        if csv_written:
            feedback.pushInfo(f"Données CSV: {export_dir / csv_filename}")
        feedback.pushInfo(f"Données JSON: {data_path}")
        if gouffres_csv_written:
            feedback.pushInfo(
                f"Gouffres   : {export_dir / gouffres_csv_filename} "
                f"({len(gouffres_a_faire)} à prospecter)")

        feedback.setProgress(90)

        # Les couches cibles P1/P2/P3 sont creees et peuplees par la PREPARATION
        # (qfield.write_cibles_from_scored_dolines). L'export MLL ne les reecrit
        # plus : elles seraient identiques et un secteur saisi different creerait
        # des doublons. L'export ne produit que le rapport, le prompt et le GPX.

        feedback.setProgress(100)
        feedback.pushInfo(f"Prompt     : {prompt_path}")
        feedback.pushInfo(
            f"Taille du prompt : {len(prompt):,} caracteres — "
            "ouvrir le .txt et joindre le .csv (ou .json) dans MLL. "
            "MLL produira : analyse + ordre de visite (liste d'IDs) + CSV QGIS + script Python pour le DOCX."
        )
        if map_path:
            feedback.pushInfo(
                "Si MLL accepte les images (modele multimodal) : joins aussi "
                f"{map_path.name} au message — carte de contexte (relief + "
                "cibles rouge/orange + geologie) utile pour juger visuellement "
                "des alignements structuraux."
            )
        feedback.pushInfo(f"Log        : {log_file}")
        _elapsed = (datetime.now() - _t0).total_seconds()
        feedback.pushInfo(f"Exécution terminée en {_elapsed:.0f} s")

        return {self.OUTPUT_DIR: str(output_dir)}


# ── Helpers module-level ──────────────────────────────────────────────────────

def _compute_clusters(dolines: list, radius_m: float = 400.0) -> dict:
    """Regroupe les dolines en clusters spatiaux par connexité (distance ≤ radius_m).

    Retourne {fid: label} où label est une lettre (A, B, C…) pour les clusters
    de ≥ 2 dolines, ou "·" pour les dolines isolées.
    """
    import math

    n = len(dolines)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(x, y):
        px, py = find(x), find(y)
        if px != py:
            parent[px] = py

    coords = [(d.get("x_l93") or 0.0, d.get("y_l93") or 0.0) for d in dolines]
    for i in range(n):
        xi, yi = coords[i]
        for j in range(i + 1, n):
            dx = xi - coords[j][0]
            dy = yi - coords[j][1]
            if math.sqrt(dx * dx + dy * dy) <= radius_m:
                union(i, j)

    # Compter les membres par racine
    root_count: dict = {}
    for i in range(n):
        r = find(i)
        root_count[r] = root_count.get(r, 0) + 1

    # Attribuer les lettres uniquement aux clusters de ≥ 2 dolines
    root_label: dict = {}
    letter_idx = 0
    for r in sorted(root_count):
        if root_count[r] >= 2:
            if letter_idx < 26:
                root_label[r] = chr(ord("A") + letter_idx)
            else:
                root_label[r] = f"C{letter_idx - 25}"
            letter_idx += 1

    result = {}
    for i, d in enumerate(dolines):
        r = find(i)
        result[d.get("fid", i)] = root_label.get(r, "·")
    return result


def _l93_to_wgs84(x: float, y: float) -> tuple:
    """Lambert-93 (EPSG:2154) → WGS84 (lon, lat), pur Python sans pyproj.

    Formule LCC 2SP inverse (EPSG méthode 9802) sur ellipsoïde GRS80.
    RGF93 ≡ WGS84 à < 1 m — aucune transformation de datum nécessaire.
    Évite proj_create qui n'est pas thread-safe dans QGIS 4.0.2.
    """
    import math

    a   = 6_378_137.0
    f   = 1 / 298.257_222_101
    e2  = 2*f - f*f
    e   = math.sqrt(e2)

    lam0 = math.radians(3.0)
    phi0 = math.radians(46.5)
    phi1 = math.radians(44.0)
    phi2 = math.radians(49.0)
    E_F  = 700_000.0
    N_F  = 6_600_000.0

    def _m(phi):
        sp = math.sin(phi)
        return math.cos(phi) / math.sqrt(1 - e2 * sp * sp)

    def _t(phi):
        sp = math.sin(phi)
        return math.tan(math.pi/4 - phi/2) / ((1 - e*sp) / (1 + e*sp))**(e/2)

    m1 = _m(phi1); m2 = _m(phi2)
    t1 = _t(phi1); t2 = _t(phi2); t0 = _t(phi0)

    n  = (math.log(m1) - math.log(m2)) / (math.log(t1) - math.log(t2))
    F  = m1 / (n * t1**n)
    r0 = a * F * t0**n

    dE = x - E_F
    dN = r0 - (y - N_F)
    r_prime = math.copysign(math.hypot(dE, dN), n)
    t_prime = (r_prime / (a * F)) ** (1.0 / n)
    theta   = math.atan2(dE, dN)

    lam = theta / n + lam0

    phi = math.pi/2 - 2*math.atan(t_prime)
    for _ in range(10):
        sp = math.sin(phi)
        phi_new = math.pi/2 - 2*math.atan(
            t_prime * ((1 - e*sp) / (1 + e*sp))**(e/2)
        )
        if abs(phi_new - phi) < 1e-12:
            phi = phi_new
            break
        phi = phi_new

    return math.degrees(lam), math.degrees(phi)


def _export_context_map(gpkg_path, dolines: list, export_dir, secteur: str,
                         today, feedback) -> "Path | None":
    """Rend une image PNG (hillshade MNT + dolines colorees par priorite)
    pour donner un contexte visuel a un LLM multimodal (vision).

    Rendu 100% QGIS natif (QgsMapRendererParallelJob), meme recette de
    hillshade que core/qfield.py::_add_mnt_hillshade (315deg/45deg,
    multidirectionnel) — aucune nouvelle dependance (pas de matplotlib ni
    Pillow), coherent avec le reste du plugin qui evite les dependances
    lourdes evitables.

    Une couche memoire par priorite (plutot qu'une seule couche avec un
    champ + renderer categorise) : evite tout usage de QgsField/QVariant,
    terrain jamais teste ailleurs dans ce projet — plus sur.

    Best-effort : renvoie None (avec un warning) si le rendu echoue, sans
    faire planter le reste de l'export.
    """
    try:
        from qgis.core import (
            QgsRasterLayer, QgsHillshadeRenderer, QgsVectorLayer,
            QgsFeature, QgsGeometry, QgsPointXY, QgsMarkerSymbol, QgsLineSymbol,
            QgsSingleSymbolRenderer, QgsMapSettings, QgsMapRendererParallelJob,
            QgsRectangle, QgsCoordinateReferenceSystem,
        )
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtGui import QColor

        crs = QgsCoordinateReferenceSystem("EPSG:2154")
        # QgsMapSettings.setLayers() : le PREMIER element de la liste est rendu
        # AU-DESSUS (verifie empiriquement — deux polygones opaques, celui en
        # position 0 gagne). Les points doivent donc venir AVANT le hillshade
        # dans `layers`, sinon le relief les recouvre entierement.
        point_layers = []
        hillshade_layer = None

        mnt_path = Path(gpkg_path).parent / "lidar_work" / "mnt.tif"
        if mnt_path.exists():
            rl = QgsRasterLayer(str(mnt_path), "MNT", "gdal")
            if rl.isValid():
                rl.setCrs(crs)
                renderer = QgsHillshadeRenderer(rl.dataProvider(), 1, 315.0, 45.0)
                try:
                    renderer.setMultiDirectional(True)
                except Exception:
                    pass
                # Exagération verticale : sur un massif boisé/peu accidenté,
                # le relief brut (zFactor=1) produit des nuances trop fines
                # pour rester lisibles sous une géologie superposée, même en
                # mode Multiply — un LLM vision perd cette information. Testé
                # empiriquement sur Marnaval (zFactor=1 : relief quasi plat
                # sous la géologie en zone boisée ; zFactor=2.5 : nettement
                # visible, sans excès de bruit).
                try:
                    renderer.setZFactor(2.5)
                except Exception:
                    pass
                rl.setRenderer(renderer)
                hillshade_layer = rl

        # Géologie complète (couleurs officielles BRGM), drapée sur le
        # hillshade en mode Multiply — cf. essai avec un masque binaire
        # karstifiable/non-karstifiable (calcaire/dolomie dans DESCR) :
        # abandonné après vérification sur données réelles (Marnaval, 64 %
        # de la zone d'étude est en réalité une roche non-calcaire mais
        # porte quand même des dolines — le critère lexical DESCR ne
        # distingue pas "urbain/non pertinent" comme espéré, il aurait
        # induit le LLM en erreur en grisant à tort des zones naturelles
        # boisées). La géologie complète reste informative (un
        # spéléologue sait la lire) sans affirmer une pertinence qu'on ne
        # peut pas garantir.
        geology_layer = None
        geology_uri = f"{gpkg_path}|layername=geologie"
        gl = QgsVectorLayer(geology_uri, "geologie", "ogr")
        if gl.isValid() and gl.featureCount() > 0:
            from qgis.PyQt.QtGui import QPainter as _QPainter
            from karstpro.core.qfield import _style_geology_brgm
            _style_geology_brgm(gl)
            comp_ns = getattr(_QPainter, "CompositionMode", _QPainter)
            multiply = getattr(comp_ns, "CompositionMode_Multiply",
                                getattr(comp_ns, "Multiply", None))
            if multiply is not None:
                gl.setBlendMode(multiply)
            gl.setOpacity(0.85)
            geology_layer = gl

        # Réseau karstique connu (topo) : trait fin bien contrasté sur le
        # hillshade + la géologie, pour situer les cibles par rapport aux
        # galeries déjà topographiées.
        topo_layer = None
        topo_uri = f"{gpkg_path}|layername=topo_reseau"
        tl = QgsVectorLayer(topo_uri, "topo_reseau", "ogr")
        if tl.isValid() and tl.featureCount() > 0:
            tsym = QgsLineSymbol.createSimple({
                "line_color": "#1e3a8a", "line_width": "0.7",
            })
            tl.setRenderer(QgsSingleSymbolRenderer(tsym))
            topo_layer = tl

        colors = {"rouge": "#dc2626", "orange": "#ea580c"}
        sizes = {"rouge": "3.2", "orange": "3.2"}

        # Emprise calculee sur TOUTES les dolines (contexte visuel complet du
        # secteur prepare), independamment de ce qui est effectivement trace.
        xs_all = [d["x_l93"] for d in dolines if d.get("x_l93") is not None]
        ys_all = [d["y_l93"] for d in dolines if d.get("y_l93") is not None]
        if not xs_all:
            return None

        # Seules rouge/orange sont dessinees : jaune (620 sur Marnaval) et
        # gris (2191, 68% du total) sont exclues du JSON detaille du prompt
        # (cf. P2P3_CAP et le dump json qui ne garde que rouges + meilleures
        # P2/P3) — les tracer sur la carte ajoute zero information (le LLM
        # ne peut de toute facon rien en lire dans le texte) tout en noyant
        # le hillshade sous des centaines de points superflus. rouge/orange
        # sont aussi le seul perimetre deja utilise pour le clustering
        # structural (`cibles_top`) : la carte montre exactement ce que le
        # texte detaille et analyse, ni plus ni moins.
        # Ordre d'empilement (haut -> bas dans point_layers) : rouge au-dessus.
        for prio in ("rouge", "orange"):
            pts = [(d["x_l93"], d["y_l93"]) for d in dolines
                   if d.get("priorite") == prio
                   and d.get("x_l93") is not None and d.get("y_l93") is not None]
            if not pts:
                continue
            vl = QgsVectorLayer("Point?crs=EPSG:2154", prio, "memory")
            pr = vl.dataProvider()
            feats = []
            for x, y in pts:
                f = QgsFeature()
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                feats.append(f)
            pr.addFeatures(feats)
            vl.updateExtents()
            sym = QgsMarkerSymbol.createSimple({
                "name": "circle", "color": colors[prio],
                "outline_color": "#1f2937", "outline_width": "0.3",
                "size": sizes[prio],
            })
            vl.setRenderer(QgsSingleSymbolRenderer(sym))
            point_layers.append(vl)

        # Repère « signal ponctuel » : anneau noir sans remplissage par-dessus
        # les points rouge/orange déjà tracés — même restriction P1/P2 que le
        # reste de la carte (jaune/gris jamais dessinés ici, cf. commentaire
        # ci-dessus). Validé empiriquement sur 8 secteurs réels avant d'être
        # ajouté (ratio 2,2x-6x, session du 2026-07-25).
        signal_layer = None
        signal_pts = [(d["x_l93"], d["y_l93"]) for d in dolines
                      if d.get("priorite") in ("rouge", "orange")
                      and d.get("x_l93") is not None and d.get("y_l93") is not None
                      and d.get("pc_plongee_m") is not None
                      and not (isinstance(d.get("pc_plongee_m"), float)
                               and math.isnan(d["pc_plongee_m"]))]
        if signal_pts:
            vl = QgsVectorLayer("Point?crs=EPSG:2154", "signal_ponctuel", "memory")
            pr = vl.dataProvider()
            feats = []
            for x, y in signal_pts:
                f = QgsFeature()
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                feats.append(f)
            pr.addFeatures(feats)
            vl.updateExtents()
            sym = QgsMarkerSymbol.createSimple({
                "name": "circle", "color": "0,0,0,0",
                "outline_color": "#000000", "outline_width": "0.6",
                "size": "5.5",
            })
            vl.setRenderer(QgsSingleSymbolRenderer(sym))
            signal_layer = vl

        # Repère « signal RGE ALTI » (affaissement historique) : anneau cyan,
        # même principe que le signal ponctuel ci-dessus mais couleur/taille
        # distinctes (cf. core/qfield.py::_style_dolines). Contrairement au
        # signal ponctuel, celui-ci contribue au score -- affiché quand même
        # séparément ici pour rester visible sur la carte statique.
        rge_layer = None
        rge_pts = [(d["x_l93"], d["y_l93"]) for d in dolines
                   if d.get("priorite") in ("rouge", "orange")
                   and d.get("x_l93") is not None and d.get("y_l93") is not None
                   and d.get("rge_contrast_m") is not None
                   and not (isinstance(d.get("rge_contrast_m"), float)
                            and math.isnan(d["rge_contrast_m"]))]
        if rge_pts:
            vl = QgsVectorLayer("Point?crs=EPSG:2154", "signal_rgealti", "memory")
            pr = vl.dataProvider()
            feats = []
            for x, y in rge_pts:
                f = QgsFeature()
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                feats.append(f)
            pr.addFeatures(feats)
            vl.updateExtents()
            sym = QgsMarkerSymbol.createSimple({
                "name": "circle", "color": "0,0,0,0",
                "outline_color": "#00b4b4", "outline_width": "0.6",
                "size": "7",
            })
            vl.setRenderer(QgsSingleSymbolRenderer(sym))
            rge_layer = vl

        # Ordre d'empilement (haut -> bas) : signal RGE ALTI > signal ponctuel
        # > cibles > topo connue > géologie > hillshade. Rappel empirique : le
        # PREMIER élément de la liste est rendu AU-DESSUS (cf. test_layer_order).
        layers = (([rge_layer] if rge_layer else [])
                  + ([signal_layer] if signal_layer else [])
                  + point_layers
                  + ([topo_layer] if topo_layer else [])
                  + ([geology_layer] if geology_layer else [])
                  + ([hillshade_layer] if hillshade_layer else []))

        span = max(max(xs_all) - min(xs_all), max(ys_all) - min(ys_all))
        margin = span * 0.1 if span > 0 else 200.0
        extent = QgsRectangle(min(xs_all) - margin, min(ys_all) - margin,
                               max(xs_all) + margin, max(ys_all) + margin)

        ms = QgsMapSettings()
        ms.setLayers(layers)
        ms.setBackgroundColor(QColor(255, 255, 255))
        ms.setOutputSize(QSize(1600, 1200))
        ms.setExtent(extent)
        ms.setDestinationCrs(crs)

        job = QgsMapRendererParallelJob(ms)
        job.start()
        job.waitForFinished()
        img = job.renderedImage()
        _draw_legend(img, has_topo=topo_layer is not None,
                     has_geology=geology_layer is not None,
                     has_signal=signal_layer is not None,
                     has_rgealti=rge_layer is not None)
        # Échelle + nord : sans repère métrique, un LLM vision ne peut évaluer
        # les distances/l'orientation qu'en devinant depuis les pixels — un
        # cluster "resserré" pourrait couvrir 50m ou 500m sans indication.
        # Canvas non tourné (CRS projeté EPSG:2154, ms sans rotation) : le
        # nord est toujours vers le haut, la flèche est donc toujours exacte.
        meters_per_px = (extent.xMaximum() - extent.xMinimum()) / img.width()
        _draw_scale_and_north(img, meters_per_px)

        png_path = Path(export_dir) / f"carte_{secteur}_{today}.png"
        ok = img.save(str(png_path), "PNG")
        return png_path if ok else None
    except Exception as e:
        feedback.pushWarning(f"Carte de contexte non générée : {e}")
        return None


def _draw_legend(img, has_topo: bool, has_geology: bool, has_signal: bool = False,
                  has_rgealti: bool = False) -> None:
    """Dessine une légende directement dans l'image (coin bas-gauche).

    Sans ça, le sens des couleurs n'existe que dans le texte du prompt : si
    l'utilisateur détache l'image du .txt dans une conversation LLM (ou la
    ressort plus tard), elle devient illisible. Dessin fait au QPainter sur
    le QImage déjà rendu — pas de dépendance supplémentaire.
    """
    from qgis.PyQt.QtGui import QPainter, QColor, QFont, QPen, QBrush

    entries = [
        ("#dc2626", "Doline priorité rouge (P1)", True),
        ("#ea580c", "Doline priorité orange (P2)", True),
    ]
    if has_signal:
        entries.append(("#000000", "Signal ponctuel (nuage LiDAR brut)", False))
    if has_rgealti:
        entries.append(("#00b4b4", "Signal RGE ALTI (affaissement historique)", False))
    if has_topo:
        entries.append(("#1e3a8a", "Réseau karstique connu (topo)", True))
    if has_geology:
        entries.append(("#6b7280", "Formations géologiques (BRGM)", True))

    painter = QPainter(img)
    try:
        # PyQt5 : QPainter.Antialiasing — PyQt6 : QPainter.RenderHint.Antialiasing
        render_hint_ns = getattr(QPainter, "RenderHint", QPainter)
        painter.setRenderHint(getattr(render_hint_ns, "Antialiasing"))

        pad = 10
        line_h = 22
        font = QFont("Arial", 11)
        painter.setFont(font)
        fm = painter.fontMetrics()
        max_w = max(fm.horizontalAdvance(label) for _, label, _ in entries)
        box_w = max_w + 3 * pad + 18
        box_h = pad * 2 + line_h * len(entries)
        box_x, box_y = pad, img.height() - box_h - pad

        painter.setBrush(QBrush(QColor(255, 255, 255, 235)))
        painter.setPen(QPen(QColor(60, 60, 60), 1))
        painter.drawRect(box_x, box_y, box_w, box_h)

        for i, (color, label, filled) in enumerate(entries):
            cy = box_y + pad + i * line_h + line_h // 2
            painter.setBrush(QBrush(QColor(color)) if filled else QBrush())
            painter.setPen(QPen(QColor(30, 30, 30) if filled else QColor(color), 1 if filled else 2))
            painter.drawEllipse(box_x + pad, cy - 6, 12, 12)
            painter.setPen(QPen(QColor(20, 20, 20)))
            painter.drawText(box_x + pad + 18 + 6, cy + 5, label)
    finally:
        painter.end()


def _nice_scale_length(target_m: float) -> float:
    """Arrondit une longueur d'échelle au « nombre rond » (1/2/5 × 10^n) le
    plus proche en dessous de ``target_m`` — convention cartographique
    standard pour une barre d'échelle lisible (200 m, pas 187 m)."""
    import math
    if target_m <= 0:
        return 100.0
    exp = math.floor(math.log10(target_m))
    for mult in (5, 2, 1):
        candidate = mult * 10 ** exp
        if candidate <= target_m:
            return float(candidate)
    return float(10 ** exp)


def _draw_scale_and_north(img, meters_per_px: float) -> None:
    """Dessine une barre d'échelle + une flèche du nord (coin haut-droit).

    Sans repère métrique ni orientation, un LLM vision ne peut évaluer les
    distances ou l'orientation des alignements qu'en devinant — risque
    d'hallucination. Le canvas n'étant jamais tourné (CRS projeté, rendu
    sans rotation), le nord est toujours strictement vers le haut : la
    flèche est fiable à 100%, pas une approximation.
    """
    from qgis.PyQt.QtGui import QPainter, QColor, QFont, QPen, QBrush
    from qgis.PyQt.QtCore import QPoint

    painter = QPainter(img)
    try:
        render_hint_ns = getattr(QPainter, "RenderHint", QPainter)
        painter.setRenderHint(getattr(render_hint_ns, "Antialiasing"))

        pad = 12
        bar_len_m = _nice_scale_length(meters_per_px * 220)
        bar_len_px = bar_len_m / meters_per_px
        bar_x2 = img.width() - pad
        bar_x1 = bar_x2 - bar_len_px
        bar_y = pad + 40

        font = QFont("Arial", 10)
        painter.setFont(font)
        label = f"{bar_len_m:.0f} m" if bar_len_m < 1000 else f"{bar_len_m/1000:.1f} km"
        fm = painter.fontMetrics()
        label_w = fm.horizontalAdvance(label)

        # Fond blanc semi-opaque pour rester lisible sur fond sombre.
        pad_bg = 6
        bg_x = min(bar_x1, bar_x2 - label_w) - pad_bg
        bg_w = (bar_x2 - bg_x) + pad_bg
        painter.setBrush(QBrush(QColor(255, 255, 255, 235)))
        painter.setPen(QPen(QColor(60, 60, 60), 1))
        painter.drawRect(int(bg_x), int(bar_y - 22), int(bg_w), 34)

        painter.setPen(QPen(QColor(20, 20, 20), 2))
        painter.drawLine(int(bar_x1), int(bar_y), int(bar_x2), int(bar_y))
        for x in (bar_x1, bar_x2):
            painter.drawLine(int(x), int(bar_y - 5), int(x), int(bar_y + 5))
        painter.drawText(int(bar_x2 - label_w), int(bar_y - 8), label)

        # Flèche du nord, au-dessus de l'échelle.
        cx = bar_x2 - 10
        top_y, bot_y = pad + 4, pad + 26
        painter.setBrush(QBrush(QColor(30, 30, 30)))
        painter.drawPolygon([
            QPoint(int(cx), int(top_y)),
            QPoint(int(cx - 6), int(bot_y)),
            QPoint(int(cx + 6), int(bot_y)),
        ])
        painter.drawText(int(cx - 5), int(bot_y + 12), "N")
    finally:
        painter.end()


def _write_gouffres_csv(gouffres: list, nearest_cible, csv_path) -> None:
    """Écrit les gouffres à prospecter (jamais visités) en CSV.

    Fichier distinct du CSV des dolines : aucune colonne métier en commun
    (un puits se décrit par son diamètre et sa compacité, une doline par sa
    surface, sa profondeur et son score). ``cible_proche``/``cible_dist_m``
    sont **informatifs** (regroupement par journée de prospection), pas un
    critère de sélection — cf. `_build_gouffres_section`.
    """
    cols = ["x_l93", "y_l93", "diametre_m", "surface_m2", "compacite",
            "couronne_sol", "cible_proche", "cible_dist_m"]
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=cols, delimiter=";",
                                extrasaction="ignore")
        writer.writeheader()
        for g in sorted(gouffres, key=lambda x: -(x.get("diametre_m") or 0)):
            c, dist = nearest_cible(g["x"], g["y"])
            writer.writerow({
                "x_l93": round(g["x"], 2),
                "y_l93": round(g["y"], 2),
                "diametre_m": g.get("diametre_m"),
                "surface_m2": g.get("surface_m2"),
                "compacite": g.get("compacite"),
                "couronne_sol": g.get("couronne_sol"),
                "cible_proche": f"doline_{c['fid']}" if c is not None else "",
                "cible_dist_m": round(dist, 1) if dist is not None else "",
            })


def _write_data_csv(dolines_json: list, csv_path) -> None:
    """Écrit toutes les caractéristiques de `dolines_json` (P1 + meilleures
    P2/P3, cf. P2P3_CAP) en CSV — mêmes données que le JSON joint, format
    tabulaire ouvrable directement dans Excel/QGIS. Remplace les tableaux
    markdown auparavant dupliqués dans le prompt .txt (mêmes valeurs que le
    JSON, redondance pure) : le CSV est écrit une seule fois par script,
    jamais régénéré par le LLM.

    Colonnes = union des clés présentes sur l'ensemble des dolines (les
    champs varient selon le contexte du secteur : géologie, traçages,
    détection ponctuelle…) — évite une liste figée qui se désynchroniserait
    silencieusement d'un nouveau champ ajouté ailleurs dans le pipeline.
    """
    priority_cols = ["fid", "priorite", "type_doline", "score", "score_morpho",
                      "surface_m2", "profondeur_m"]
    all_keys = {}
    for d in dolines_json:
        for k in d.keys():
            all_keys[k] = True
    columns = [c for c in priority_cols if c in all_keys] + \
        sorted(k for k in all_keys if k not in priority_cols)

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, delimiter=";", extrasaction="ignore")
        writer.writeheader()
        for d in dolines_json:
            writer.writerow(d)


def _write_gpx(cibles: list, gpx_path, secteur: str) -> None:
    """Génère un fichier GPX avec un waypoint par cible (rouge puis orange)."""
    import xml.etree.ElementTree as ET

    root = ET.Element("gpx", {
        "version": "1.1",
        "creator": "KarstPro",
        "xmlns": "http://www.topografix.com/GPX/1/1",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:schemaLocation": (
            "http://www.topografix.com/GPX/1/1 "
            "http://www.topografix.com/GPX/1/1/gpx.xsd"
        ),
    })
    ET.SubElement(root, "metadata").append(
        _gpx_elem("name", f"KarstPro — {secteur}")
    )

    for d in cibles:
        x = d.get("x_l93")
        y = d.get("y_l93")
        if x is None or y is None:
            continue
        lon, lat = _l93_to_wgs84(float(x), float(y))
        prio = d.get("priorite", "?")
        fid  = d.get("fid", "?")
        score = d.get("score", "?")
        surf  = d.get("surface_m2", "?")
        prof  = d.get("profondeur_m", "?")
        ratio = f"{d['ratio_ps']:.3f}" if d.get("ratio_ps") is not None else "?"

        sym = "Flag, Red" if prio == "rouge" else "Flag, Orange"
        wpt = ET.SubElement(root, "wpt", {"lat": f"{lat:.7f}", "lon": f"{lon:.7f}"})
        wpt.append(_gpx_elem("name", f"doline_{fid}_{prio[0].upper()}"))
        wpt.append(_gpx_elem("desc",
            f"Score:{score} | {surf}m2 | prof:{prof}m | P/sqrtS:{ratio} | {prio}"))
        wpt.append(_gpx_elem("sym", sym))
        wpt.append(_gpx_elem("type", f"Prospection karstique — {prio}"))

    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")
    tree.write(str(gpx_path), encoding="utf-8", xml_declaration=True)


def _gpx_elem(tag: str, text: str):
    import xml.etree.ElementTree as ET
    el = ET.Element(tag)
    el.text = text
    return el


# ── Estimation du pendage régional (problème des trois points) ─────────────────

_COMPASS16 = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
              "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]


def _gpkg_blob_to_geom(blob):
    """Convertit un blob de géométrie GPKG en géométrie shapely (sans pyproj)."""
    if not blob or len(blob) < 8:
        return None
    flags = blob[3]
    env_indicator = (flags >> 1) & 0x07
    env_sizes = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
    off = 8 + env_sizes.get(env_indicator, 0)
    try:
        from shapely import wkb as swkb
        return swkb.loads(bytes(blob[off:]))
    except Exception:
        return None


def _sample_contact(line, step=10.0):
    """Points (x, y) régulièrement espacés le long d'une ligne/multiligne."""
    from shapely.geometry import LineString, MultiLineString
    if isinstance(line, LineString):
        geoms = [line]
    elif isinstance(line, MultiLineString):
        geoms = list(line.geoms)
    else:
        geoms = [g for g in getattr(line, "geoms", []) if g.geom_type == "LineString"]
    pts = []
    for g in geoms:
        n = max(2, int(g.length // step))
        for i in range(n + 1):
            p = g.interpolate(i / n, normalized=True)
            pts.append((p.x, p.y))
    return pts


def _geology_context_md(gpkg_path) -> str:
    """Section markdown : contexte géologique **complet** de la zone (BD Charm-50).

    Toutes les formations présentes (pas seulement le karstifiable), avec surface
    et part, le karstifiable signalé par ★. Donne au LLM le cadre lithologique du
    secteur (couverture argilo-sableuse vs calcaires support de karst). Lecture
    SQL pure (sans pyproj). Chaîne vide si pas de couche géologie.
    """
    import sqlite3
    from karstpro.core.gpkg import read_gpkg_layer
    try:
        con = sqlite3.connect(str(gpkg_path))
        has = con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='geologie'"
        ).fetchone()
        con.close()
        if not has:
            return ""
        g = read_gpkg_layer(gpkg_path, "geologie")
    except Exception:
        return ""
    if g is None or g.empty:
        return ""
    g = g[g.geometry.notna()].copy()
    if g.empty:
        return ""
    g["_km2"] = g.geometry.area / 1e6
    nota = "NOTATION" if "NOTATION" in g.columns else None
    descr = "DESCR" if "DESCR" in g.columns else None
    keys = [c for c in (nota, descr) if c]
    if not keys:
        return ""
    agg = (g.groupby(keys)["_km2"].sum().reset_index()
           .sort_values("_km2", ascending=False))
    total = float(g["_km2"].sum()) or 1.0
    kw = ("calcaire", "dolomie", "dolomit")
    out = [
        "## Contexte géologique de la zone (BD Charm-50, 1/50 000)",
        "",
        f"Couverture **complète** : {len(agg)} formation(s), {total:.1f} km². "
        "★ = karstifiable (calcaire / dolomie — support potentiel de karst).",
        "",
        "| ★ | NOTATION | km² | % | Formation |",
        "|---|----------|-----|---|-----------|",
    ]
    for _, r in agg.iterrows():
        d = str(r[descr]) if descr else ""
        star = "★" if any(k in d.lower() for k in kw) else ""
        n = str(r[nota]) if nota else "—"
        out.append(f"| {star} | {n} | {r['_km2']:.2f} | "
                   f"{100 * r['_km2'] / total:.0f}% | {d[:70]} |")
    out += [
        "",
        "> Lecture karst : les dolines se forment sur / à proximité des formations ★. "
        "Les formations non-karstifiables (argiles, sables, marnes) décrivent la "
        "**couverture** et le contexte de soutirage — utiles à l'interprétation, "
        "hors score.",
    ]
    return "\n".join(out)


def _estimate_dip(gpkg_path, mnt_path, step=10.0):
    """Estime l'azimut et l'angle de pendage régional depuis les contacts
    géologiques et le MNT. Retourne le meilleur contact (R² max) sous forme
    d'un dict {texte, contact, r2, dip, az, compass} ou None.

    Pure sqlite + shapely + rasterio (échantillonnage en coords natives L93,
    pas de reprojection) — compatible avec le thread Processing de QGIS 4.0.2.
    """
    import sqlite3
    import numpy as np
    from shapely.ops import unary_union

    if not Path(mnt_path).exists():
        return None

    con = sqlite3.connect(str(gpkg_path))
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='geologie'")
    if not cur.fetchone():
        con.close()
        return None
    try:
        cur.execute("SELECT column_name FROM gpkg_geometry_columns WHERE table_name='geologie'")
        r = cur.fetchone()
        gcol = r[0] if r else "geom"
    except Exception:
        gcol = "geom"
    cur.execute("SELECT * FROM geologie LIMIT 0")
    cols = [d[0] for d in cur.description]
    field = "NOTATION" if "NOTATION" in cols else ("CODE_LEG" if "CODE_LEG" in cols else None)
    if field is None:
        con.close()
        return None

    cur.execute(f'SELECT "{field}" AS f, "{gcol}" AS g FROM geologie')
    groups = {}
    for row in cur.fetchall():
        geom = _gpkg_blob_to_geom(row["g"])
        if geom is None:
            continue
        groups.setdefault(str(row["f"]), []).append(geom)
    con.close()
    if len(groups) < 2:
        return None

    forms = {k: unary_union(v) for k, v in groups.items()}
    keys = list(forms)

    import rasterio
    src = rasterio.open(str(mnt_path))
    nodata = src.nodata
    best = None
    try:
        for i in range(len(keys)):
            for j in range(i + 1, len(keys)):
                contact = forms[keys[i]].boundary.intersection(forms[keys[j]].boundary)
                if contact.is_empty:
                    continue
                pts = _sample_contact(contact, step)
                if len(pts) < 8:
                    continue
                z = np.array([v[0] for v in src.sample(pts)], dtype="float64")
                if nodata is not None:
                    z[z == nodata] = np.nan
                ok = np.isfinite(z)
                if ok.sum() < 8:
                    continue
                xy = np.array(pts)[ok]
                zz = z[ok]
                X = np.column_stack([xy[:, 0], xy[:, 1], np.ones(len(xy))])
                coef, *_ = np.linalg.lstsq(X, zz, rcond=None)
                a, b, _c = coef
                zhat = X @ coef
                ss_res = float(np.sum((zz - zhat) ** 2))
                ss_tot = float(np.sum((zz - zz.mean()) ** 2))
                r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
                dip = float(np.degrees(np.arctan(np.hypot(a, b))))
                az = float(np.degrees(np.arctan2(-a, -b)) % 360)
                denivele = float(np.nanmax(zz) - np.nanmin(zz))
                # Garde-fou : rejette les contacts plats/droits/bruités (discordances)
                if not (r2 > 0.4 and denivele > 3.0):
                    continue
                if best is None or r2 > best["r2"]:
                    best = {"r2": r2, "dip": dip, "az": az, "n_pts": int(ok.sum()),
                            "contact": f"{keys[i]}/{keys[j]}", "denivele": denivele}
    finally:
        src.close()

    if best is None:
        return None
    best["compass"] = _COMPASS16[int((best["az"] + 11.25) // 22.5) % 16]
    qual = ("pendage faible" if best["dip"] < 2
            else "pendage modéré" if best["dip"] < 6 else "pendage marqué")
    # Fiabilité explicite dans le TEXTE lui-même (pas seulement le feedback
    # QGIS) : le seuil de garde-fou n'est que R²>0.4, donc un contact à
    # peine mieux qu'aléatoire serait sinon présenté au LLM avec la même
    # autorité qu'un contact quasi parfait — un LLM ne peut pas deviner la
    # fiabilité d'une estimation qu'on ne lui donne pas.
    fiabilite = ("fiable" if best["r2"] >= 0.7
                 else "à confirmer" if best["r2"] >= 0.5 else "peu fiable")
    best["texte"] = (
        f"{best['compass']} (~{best['az']:.0f}°), "
        f"{qual} ~{best['dip']:.1f}° (estimé auto. depuis le contact "
        f"{best['contact']}, R²={best['r2']:.2f} sur {best['n_pts']} points "
        f"— fiabilité {fiabilite}, à recouper sur le terrain)"
    )
    return best
