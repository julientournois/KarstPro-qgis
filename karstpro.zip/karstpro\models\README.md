# Registre des modèles appris

Chaque `*.json` de ce dossier est un **modèle de priorisation par domaine de
karst**, auto-descriptif. Le routeur (`core/model_score.py::select_model`) les
découvre par simple `glob` — déposer un fichier valide suffit à l'enregistrer.

## Schéma d'un modèle

Champs **requis** (sans eux, le fichier est ignoré par `list_models`) :

| Champ | Rôle |
|---|---|
| `features` | liste ordonnée des colonnes d'entrée |
| `feature_modes` | `{feature: "log"|"lin"}` — transform appliqué avant standardisation |
| `coef` | coefficients logistiques, alignés sur `features` |
| `intercept` | biais |
| `scaler_mean`, `scaler_scale` | standardisation par feature |
| `median` | imputation des NaN, par feature |
| `prio_thresholds` | `{P1, P2, P3}` seuils de probabilité → rouge/orange/jaune |

Champs de **domaine** (servent au routeur ; sans eux le modèle n'est jamais
sélectionné automatiquement) :

| Champ | Rôle |
|---|---|
| `model_id` | identifiant court (défaut = nom de fichier) |
| `karst_type` | description lisible (ex. « couvert », « nu », « craie ») |
| `domain_name` | libellé géographique |
| `domain_notations` | préfixes NOTATION BD Charm-50 du faciès validé (ex. `["n4","n3","j7","j6"]`) |
| `domain_notation_min_frac` | fraction minimale de dolines sur ce faciès pour sélectionner le modèle (défaut 0.5) |
| `domain_centroid_l93`, `domain_radius_warn_m` | repli géographique quand la lithologie n'est pas calculable |

## Ajouter un nouveau domaine de karst

1. **Inventaire** indépendant de cavités dans le nouveau karst (triage :
   richesse ≥ ~30-40 cavités pénétrables/commune, géoréf fiable).
2. Traiter le LiDAR (`KarstPro – Préparation`) sur des communes du domaine.
3. Entraîner (`prototypes/train_model.py`) → exporter en JSON ici.
4. **Valider hors-échantillon** (`validation/inventaire/`) sur des communes
   NON vues à l'entraînement. Si l'AUC ne bat pas nettement les poids manuels,
   **ne pas livrer** le modèle (exploratoire seulement pour ce domaine).
5. Renseigner les champs de domaine (faciès `domain_notations` dérivé
   empiriquement des dolines validées, pas supposé) et déposer le `.json`.

> Le faciès se dérive des dolines RÉELLEMENT validées, pas d'une hypothèse
> géologique : pour le Barrois, les dolines sont à ~67 % sur la couverture
> crétacée (n3/n4), pas sur le calcaire jurassique — karst sous couverture.
