# Registre des modèles appris

Chaque `*.json` de ce dossier est un **modèle de priorisation par domaine de
karst**, auto-descriptif. Le routeur (`core/model_score.py::select_model`) les
découvre par simple `glob` — déposer un fichier valide suffit à l'enregistrer.

## Schéma d'un modèle

Champs **requis** (sans eux, le fichier est ignoré par `list_models`) :

| Champ | Rôle |
|---|---|
| `features` | liste ordonnée des colonnes d'entrée |
| `feature_modes` | `{feature: "log"|"lin"}` — transform appliqué avant standardisation |
| `coef` | coefficients logistiques, alignés sur `features` |
| `intercept` | biais |
| `scaler_mean`, `scaler_scale` | standardisation par feature |
| `median` | imputation des NaN, par feature |
| `prio_thresholds` | `{P1, P2, P3}` seuils de probabilité → rouge/orange/jaune |

Champs de **domaine** (servent au routeur ; sans eux le modèle n'est jamais
sélectionné automatiquement) :

| Champ | Rôle |
|---|---|
| `model_id` | identifiant court (défaut = nom de fichier) |
| `karst_type` | description lisible (ex. « couvert », « nu », « craie ») |
| `domain_name` | libellé géographique |
| `domain_notations` | préfixes NOTATION BD Charm-50 du faciès validé (ex. `["n4","n3","j7","j6"]`) |
| `domain_notation_min_frac` | fraction minimale de dolines sur ce faciès pour sélectionner le modèle (défaut 0.5) |
| `domain_centroid_l93`, `domain_radius_warn_m` | repli géographique quand la lithologie n'est pas calculable |
| `domain_radius_max_m` | **veto dur** : au-delà, le modèle est refusé même si la lithologie concorde (les préfixes NOTATION sont régionaux → une concordance à 200 km n'est pas le même karst) |

## Ajouter un nouveau domaine de karst

1. **Inventaire** indépendant de cavités dans le nouveau karst (triage :
   richesse ≥ ~30-40 cavités pénétrables/commune, géoréf fiable).
2. Traiter le LiDAR (`KarstPro – Préparation`) sur des communes du domaine.
3. Entraîner (`prototypes/train_model.py`) → exporter en JSON ici.
4. **Valider hors-échantillon** (`validation/inventaire/`) sur des communes
   NON vues à l'entraînement. Si l'AUC ne bat pas nettement les poids manuels,
   **ne pas livrer** le modèle (exploratoire seulement pour ce domaine).
5. Renseigner les champs de domaine (faciès `domain_notations` dérivé
   empiriquement des dolines validées, pas supposé) et déposer le `.json`.

> Le faciès se dérive des dolines RÉELLEMENT validées, pas d'une hypothèse
> géologique : pour le Barrois, les dolines sont à ~67 % sur la couverture
> crétacée (n3/n4), pas sur le calcaire jurassique — karst sous couverture.

## Réentraîner un domaine existant (labels terrain)

Une fois des labels terrain accumulés (`labels_terrain.csv`, écrit par chaque
synchro terrain — voir `karstpro/README.md`), `prototypes/retrain_model.py`
les fusionne aux communes d'inventaire existantes et ne remplace le modèle
déployé que si l'AUC hors-échantillon (LOCO) s'améliore strictement :

1. Éditer `prototypes/retrain_sources.json` : ajouter le dossier de projet du
   secteur synchronisé sous la clé du domaine (ex. `"barrois": [...]`).
2. `python prototypes/retrain_model.py --domain barrois --dry-run` — vérifie
   la décision sans rien écrire.
3. Si la décision de promotion te convient : relancer sans `--dry-run`. Le
   script écrase `karstpro/models/<domain>_model.json` **uniquement** si le
   candidat fait strictement mieux ; sinon il ne touche à rien.
4. Un rapport horodaté est toujours écrit dans
   `prototypes/retrain_reports/` (retenu ou non) — historique de chaque
   tentative.

Strictement manuel : ce script n'est jamais déclenché depuis QGIS ni depuis
la synchro terrain, et ne fait pas partie du plugin distribué
(`prototypes/` n'est jamais packagé — voir `build_release.ps1`).

> **Piège sur un `--domain` inédit (nouveau ou fautif) :** s'il n'existe pas
> encore de `karstpro/models/<domain>_model.json`, il n'y a pas d'AUC
> déployée à battre — le script traite « pas de modèle » comme « modèle
> infiniment mauvais » et **entraîne et écrit un modèle dès le premier run
> sans confirmation**, même si `<domain>` est une simple faute de frappe.
> Toujours passer par `--dry-run` d'abord pour vérifier le nom du domaine et
> la liste des secteurs avant le run réel.
