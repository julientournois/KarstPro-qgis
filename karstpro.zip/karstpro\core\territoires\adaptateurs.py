# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Adaptateurs en code — capacités que la config ne peut pas exprimer.

Frontière config/code : arrivent ici les sources dont la logique comporte
enchaînement, pagination, expression régulière ou pipeline PDAL. Mesuré :
`core/lidar_pnoa_auto.py` fait 442 lignes — inexprimable en JSON.

Chaque adaptateur est une FINE enveloppe : il ne réimplémente rien, il
uniformise seulement la signature pour que l'appelant ignore le territoire.
Les imports lourds sont différés dans `executer()`, convention du dépôt.
"""
from __future__ import annotations

from karstpro.core.territoires.types import ContexteEtude


class _AdaptateurBase:
    absente = False


class MntIgn(_AdaptateurBase):
    """MNT France : découverte des dalles par WFS, téléchargement COPC, PDAL."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.lidar import (
            bbox_to_ign_tiles, download_lidar_tiles, generate_mnt,
        )
        laz_dir = ctx.work_dir / "laz"
        laz_dir.mkdir(parents=True, exist_ok=True)
        # Messages repris à l'identique de l'ancien pipeline : c'est ici leur
        # place désormais, chaque source annonçant ce qu'elle fait. Les
        # supprimer aurait été un écart au « comportement identique », et
        # l'avertissement des 30 min est une information utile à l'opérateur.
        if ctx.feedback:
            ctx.feedback.pushInfo("Téléchargement des dalles LIDAR HD IGN...")
        tuiles = bbox_to_ign_tiles(ctx.bbox, target_crs=ctx.crs)
        if ctx.feedback:
            ctx.feedback.pushInfo(
                f"  {len(tuiles)} dalle(s) — téléchargement parallèle (3 threads)...")

        links_path = laz_dir / "dalles_a_telecharger.txt"
        with open(links_path, "w", encoding="utf-8") as f:
            f.write(f"# Dalles LiDAR HD IGN — {ctx.work_dir.parent.name}\n")
            f.write(f"# {len(tuiles)} dalle(s) — déposer les .copc.laz dans ce dossier\n")
            f.write(f"# Dossier : {laz_dir}\n\n")
            for tile in tuiles:
                f.write(f"{tile['url']}\n")

        if ctx.feedback:
            ctx.feedback.pushInfo(f"  Liens de téléchargement manuel : {links_path}")

        fichiers = download_lidar_tiles(tuiles, laz_dir, feedback=ctx.feedback)
        mnt = ctx.work_dir / "mnt.tif"
        if not (mnt.exists() and mnt.stat().st_size > 0):
            if ctx.feedback:
                ctx.feedback.pushInfo(
                    "Génération du MNT (cela peut prendre plus de 30 min selon "
                    "la surface et la puissance de calcul)...")
            generate_mnt(fichiers, mnt, target_crs=ctx.crs)
        return {"mnt": mnt, "laz": fichiers}


class MntPnoa(_AdaptateurBase):
    """MNT Espagne 1 m : portail CNIG (non documenté comme API)."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.lidar import generate_mnt
        from karstpro.core.lidar_pnoa_auto import download_pnoa_auto
        laz_dir = ctx.work_dir / "laz"
        laz_dir.mkdir(parents=True, exist_ok=True)
        fichiers = download_pnoa_auto(
            ctx.bbox, crs=ctx.crs, dest_dir=laz_dir, feedback=ctx.feedback)
        if not fichiers:
            return None                      # -> la Chaine passe au repli WCS
        mnt = ctx.work_dir / "mnt.tif"
        if not (mnt.exists() and mnt.stat().st_size > 0):
            generate_mnt(fichiers, mnt, target_crs=ctx.crs)
        return {"mnt": mnt, "laz": fichiers}


class GeologieBrgm(_AdaptateurBase):
    """Géologie France : BD Charm-50 en cache local, sinon WFS BRGM.

    Adaptateur et non config : combine un WFS et des GeoPackages embarqués,
    avec résolution de chemin (`geology._find_geo50k_root`).
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_geology_auto
        if ctx.feedback:
            ctx.feedback.pushInfo(
                "Import geologie — BD Charm-50 1/50 000 (cache auto)...")
        return fetch_geology_auto(
            ctx.bbox, feedback=ctx.feedback, target_crs=ctx.crs)


class ObstaclesBdTopo(_AdaptateurBase):
    """Bâti + eau (France) — faux positifs de gouffres quasi certains."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_bdtopo_obstacles
        return fetch_bdtopo_obstacles(
            ctx.bbox, feedback=ctx.feedback, target_crs=ctx.crs)


class VegetationBdTopo(_AdaptateurBase):
    """Végétation à canopée fermée (France) — signal PROBABILISTE."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_bdtopo_vegetation
        return fetch_bdtopo_vegetation(
            ctx.bbox, feedback=ctx.feedback, target_crs=ctx.crs)


class ObstaclesSiose(_AdaptateurBase):
    """Bâti + eau (Espagne) — faux positifs de gouffres quasi certains.

    Adaptateur et non config : le WFS SIOSE impose une pagination (~30 000
    polygones sur une emprise d'étude), son GML INSPIRE n'est pas du
    simple-feature, et le code de classe s'extrait par expression régulière.
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.landcover_siose import obstacles_siose
        return obstacles_siose(ctx.bbox, ctx.crs, feedback=ctx.feedback)


class VegetationSiose(_AdaptateurBase):
    """Végétation à canopée fermée (Espagne) — signal PROBABILISTE.

    Alimente `shafts.flag_vegetation`, qui marque `interet=0` sans jamais
    supprimer : une trouée de canopée a la même signature qu'un puits, la
    donnée d'occupation du sol ne tranche pas, elle déclasse.
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.landcover_siose import vegetation_siose
        return vegetation_siose(ctx.bbox, ctx.crs, feedback=ctx.feedback)


class PointsEauBdTopo(_AdaptateurBase):
    """Points d'eau karstiques référencés (France) : sources, pertes, exutoires.

    Ce N'EST PAS de la détection — on localise des entités déjà connues.
    Indispensable pour les gouffres noyés (inversac), invisibles au MNT.

    Quatrième appel BD Topo du pipeline, et le seul que la refonte
    territoires avait manqué : le balayage d'exhaustivité recensait les
    MARQUEURS (« bdtopo » -> 3 capacités) sans compter les SITES D'APPEL.
    Signalé indirectement par l'utilisateur le 2026-08-02.
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_points_eau
        if ctx.feedback:
            ctx.feedback.pushInfo(
                "Récupération des points d'eau karstiques (BD Topo)...")
        return fetch_points_eau(ctx.bbox, feedback=ctx.feedback,
                                target_crs=ctx.crs)


class RgeAlti(_AdaptateurBase):
    """Signal d'affaissement historique (France) : téléchargement + rééchantillonnage."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.rgealti import fetch_rgealti_for_secteur
        mnt = ctx.work_dir / "mnt.tif"
        cible = ctx.work_dir / "rgealti.tif"
        fetch_rgealti_for_secteur(mnt, cible)
        return cible


# Registre : la config référence un adaptateur par NOM, jamais par chemin de
# module — pas d'import arbitraire depuis un fichier de configuration, et le
# chargeur peut valider l'existence du nom.
ADAPTATEURS = {
    "mnt_ign": MntIgn,
    "mnt_pnoa": MntPnoa,
    "geologie_brgm": GeologieBrgm,
    "rgealti": RgeAlti,
    "points_eau_bdtopo": PointsEauBdTopo,
    "obstacles_bdtopo": ObstaclesBdTopo,
    "vegetation_bdtopo": VegetationBdTopo,
    "obstacles_siose": ObstaclesSiose,
    "vegetation_siose": VegetationSiose,
}
