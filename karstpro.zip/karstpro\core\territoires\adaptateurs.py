# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Adaptateurs en code — capacités que la config ne peut pas exprimer.

Frontière config/code : arrivent ici les sources dont la logique comporte
enchaînement, pagination, expression régulière ou pipeline PDAL. Mesuré :
`core/lidar_pnoa_auto.py` fait 442 lignes — inexprimable en JSON.

Chaque adaptateur est une FINE enveloppe : il ne réimplémente rien, il
uniformise seulement la signature pour que l'appelant ignore le territoire.
Les imports lourds sont différés dans `executer()`, convention du dépôt.
"""
from __future__ import annotations

from karstpro.core.territoires.types import ContexteEtude
from karstpro.core.i18n import t


def _purger_derives(work_dir, feedback=None) -> None:
    """Supprime ce qui descend du MNT, après l'avoir reconstruit.

    Remplissage, dolines, gouffres, hydrologie : tout cela a été calculé sur
    l'ANCIEN MNT. Les laisser en place ne fait pas que gaspiller — la
    préparation les reprend tels quels (`if mnt_filled.exists()` à l'étape 3),
    et livre donc une détection faite sur le relief 5 m alors que le MNT est
    désormais en 1 m. Défaut constaté le 2026-10-02 : les quatre dalles
    étaient reconnues, la reconstruction annoncée, et l'étude rendait
    toujours zéro gouffre.
    """
    from karstpro.core.mnt_cache import invalider_caches_derives
    supprimes = invalider_caches_derives(work_dir)
    if supprimes and feedback is not None:
        feedback.pushInfo(t(
            "  MNT reconstruit — {n} cache(s) dérivé(s) invalidé(s) : "
            "dolines et gouffres seront recalculés.", n=len(supprimes)))


def _mnt_a_refaire(mnt, dalles, feedback=None) -> bool:
    """Le MNT en cache doit-il être reconstruit à partir de `dalles` ?

    Absent ou vide : oui, évidemment. Mais aussi — et c'est le cas qui
    manquait — **plus ancien que la plus récente des dalles**.

    Pourquoi. Les deux territoires ont une procédure de dépôt manuel des
    dalles, et dans les deux cas le MNT peut déjà exister quand elles
    arrivent :

    - **Espagne** : le portail du CNIG exige une vérification anti-robot
      depuis le 2026-09-29, donc la première préparation retombe sur le
      relief WCS 5 m et écrit `mnt.tif`. L'utilisateur dépose ensuite ses
      dalles 1 m… que l'ancien test `if not mnt.exists()` faisait
      purement ignorer. L'étude restait en 5 m, les dalles sous le nez, et
      rien ne le signalait. C'est toute la marche à suivre documentée qui
      échouait en silence.
    - **France** : le CDN de l'IGN bride les téléchargements, d'où la
      procédure `dalles_a_telecharger.txt`. Un MNT bâti sur un lot
      **incomplet** ne se refaisait pas quand les dalles manquantes étaient
      ajoutées — mêmes conséquences, bords tronqués en plus.

    La date de modification suffit à distinguer les deux situations, sans
    rien stocker de plus : une dalle arrivée après le MNT le périme.
    """
    from pathlib import Path
    mnt = Path(mnt)
    if not (mnt.exists() and mnt.stat().st_size > 0):
        return True
    try:
        plus_recente = max(Path(d).stat().st_mtime for d in dalles)
    except (OSError, ValueError):
        return False                     # au doute, on garde le cache
    if plus_recente <= mnt.stat().st_mtime:
        return False
    if feedback is not None:
        feedback.pushInfo(t(
            "  Des dalles sont plus récentes que le MNT en cache — "
            "reconstruction du MNT à partir des dalles."))
    return True


class _AdaptateurBase:
    absente = False


class MntIgn(_AdaptateurBase):
    """MNT France : découverte des dalles par WFS, téléchargement COPC, PDAL."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.lidar import (
            bbox_to_ign_tiles, download_lidar_tiles, generate_mnt,
        )
        laz_dir = ctx.work_dir / "laz"
        laz_dir.mkdir(parents=True, exist_ok=True)
        # Messages repris à l'identique de l'ancien pipeline : c'est ici leur
        # place désormais, chaque source annonçant ce qu'elle fait. Les
        # supprimer aurait été un écart au « comportement identique », et
        # l'avertissement des 30 min est une information utile à l'opérateur.
        if ctx.feedback:
            ctx.feedback.pushInfo(t("Téléchargement des dalles LIDAR HD IGN..."))
        tuiles = bbox_to_ign_tiles(ctx.bbox, target_crs=ctx.crs)
        if ctx.feedback:
            ctx.feedback.pushInfo(
                t("  {n} dalle(s) — téléchargement parallèle (3 threads)...", n=len(tuiles)))

        links_path = laz_dir / "dalles_a_telecharger.txt"
        with open(links_path, "w", encoding="utf-8") as f:
            f.write(f"# Dalles LiDAR HD IGN — {ctx.work_dir.parent.name}\n")
            f.write(f"# {len(tuiles)} dalle(s) — déposer les .copc.laz dans ce dossier\n")
            f.write(f"# Dossier : {laz_dir}\n\n")
            for tile in tuiles:
                f.write(f"{tile['url']}\n")

        if ctx.feedback:
            ctx.feedback.pushInfo(t("  Liens de téléchargement manuel : {links_path}", links_path=links_path))

        fichiers = download_lidar_tiles(tuiles, laz_dir, feedback=ctx.feedback)
        mnt = ctx.work_dir / "mnt.tif"
        if _mnt_a_refaire(mnt, fichiers, feedback=ctx.feedback):
            # `forcer` : sinon `generate_mnt` rend la main sans rien faire dès
            # que le fichier existe. Et les dérivés (remplissage, dolines,
            # gouffres) descendent de l'ANCIEN MNT — les garder ferait
            # rejouer une détection faite sur le relief 5 m.
            generate_mnt(fichiers, mnt, target_crs=ctx.crs,
                         feedback=ctx.feedback, forcer=True)
            _purger_derives(ctx.work_dir, feedback=ctx.feedback)
        return {"mnt": mnt, "laz": fichiers}


class MntPnoa(_AdaptateurBase):
    """MNT Espagne 1 m : portail CNIG (non documenté comme API)."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.lidar import generate_mnt
        from karstpro.core.lidar_pnoa_auto import download_pnoa_auto
        laz_dir = ctx.work_dir / "laz"
        laz_dir.mkdir(parents=True, exist_ok=True)
        fichiers = download_pnoa_auto(
            ctx.bbox, crs=ctx.crs, dest_dir=laz_dir, feedback=ctx.feedback)
        if not fichiers:
            return None                      # -> la Chaine passe au repli WCS
        mnt = ctx.work_dir / "mnt.tif"
        if _mnt_a_refaire(mnt, fichiers, feedback=ctx.feedback):
            # `forcer` : sinon `generate_mnt` rend la main sans rien faire dès
            # que le fichier existe. Et les dérivés (remplissage, dolines,
            # gouffres) descendent de l'ANCIEN MNT — les garder ferait
            # rejouer une détection faite sur le relief 5 m.
            generate_mnt(fichiers, mnt, target_crs=ctx.crs,
                         feedback=ctx.feedback, forcer=True)
            _purger_derives(ctx.work_dir, feedback=ctx.feedback)
        return {"mnt": mnt, "laz": fichiers}


class GeologieBrgm(_AdaptateurBase):
    """Géologie France : BD Charm-50 en cache local, sinon WFS BRGM.

    Adaptateur et non config : combine un WFS et des GeoPackages embarqués,
    avec résolution de chemin (`geology._find_geo50k_root`).
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_geology_auto
        if ctx.feedback:
            ctx.feedback.pushInfo(
                t("Import geologie — BD Charm-50 1/50 000 (cache auto)..."))
        return fetch_geology_auto(
            ctx.bbox, feedback=ctx.feedback, target_crs=ctx.crs)


class ObstaclesBdTopo(_AdaptateurBase):
    """Bâti + eau (France) — faux positifs de gouffres quasi certains."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_bdtopo_obstacles
        return fetch_bdtopo_obstacles(
            ctx.bbox, feedback=ctx.feedback, target_crs=ctx.crs)


class VegetationBdTopo(_AdaptateurBase):
    """Végétation à canopée fermée (France) — signal PROBABILISTE."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_bdtopo_vegetation
        return fetch_bdtopo_vegetation(
            ctx.bbox, feedback=ctx.feedback, target_crs=ctx.crs)


class ObstaclesSiose(_AdaptateurBase):
    """Bâti + eau (Espagne) — faux positifs de gouffres quasi certains.

    Adaptateur et non config : le WFS SIOSE impose une pagination (~30 000
    polygones sur une emprise d'étude), son GML INSPIRE n'est pas du
    simple-feature, et le code de classe s'extrait par expression régulière.
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.landcover_siose import obstacles_siose
        return obstacles_siose(ctx.bbox, ctx.crs, feedback=ctx.feedback)


class VegetationSiose(_AdaptateurBase):
    """Végétation à canopée fermée (Espagne) — signal PROBABILISTE.

    Alimente `shafts.flag_vegetation`, qui marque `interet=0` sans jamais
    supprimer : une trouée de canopée a la même signature qu'un puits, la
    donnée d'occupation du sol ne tranche pas, elle déclasse.
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.landcover_siose import vegetation_siose
        return vegetation_siose(ctx.bbox, ctx.crs, feedback=ctx.feedback)


class PointsEauBdTopo(_AdaptateurBase):
    """Points d'eau karstiques référencés (France) : sources, pertes, exutoires.

    Ce N'EST PAS de la détection — on localise des entités déjà connues.
    Indispensable pour les gouffres noyés (inversac), invisibles au MNT.

    Quatrième appel BD Topo du pipeline, et le seul que la refonte
    territoires avait manqué : le balayage d'exhaustivité recensait les
    MARQUEURS (« bdtopo » -> 3 capacités) sans compter les SITES D'APPEL.
    Signalé indirectement par l'utilisateur le 2026-08-02.
    """

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.geology import fetch_points_eau
        if ctx.feedback:
            ctx.feedback.pushInfo(
                t("Récupération des points d'eau karstiques (BD Topo)..."))
        return fetch_points_eau(ctx.bbox, feedback=ctx.feedback,
                                target_crs=ctx.crs)


class RgeAlti(_AdaptateurBase):
    """Signal d'affaissement historique (France) : téléchargement + rééchantillonnage."""

    def executer(self, ctx: ContexteEtude):
        from karstpro.core.rgealti import fetch_rgealti_for_secteur
        mnt = ctx.work_dir / "mnt.tif"
        cible = ctx.work_dir / "rgealti.tif"
        fetch_rgealti_for_secteur(mnt, cible)
        return cible


# Registre : la config référence un adaptateur par NOM, jamais par chemin de
# module — pas d'import arbitraire depuis un fichier de configuration, et le
# chargeur peut valider l'existence du nom.
ADAPTATEURS = {
    "mnt_ign": MntIgn,
    "mnt_pnoa": MntPnoa,
    "geologie_brgm": GeologieBrgm,
    "rgealti": RgeAlti,
    "points_eau_bdtopo": PointsEauBdTopo,
    "obstacles_bdtopo": ObstaclesBdTopo,
    "vegetation_bdtopo": VegetationBdTopo,
    "obstacles_siose": ObstaclesSiose,
    "vegetation_siose": VegetationSiose,
}
