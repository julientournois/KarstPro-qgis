# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Fournisseurs de capacités pilotés par déclaration (config JSON).

Frontière config/code : ce module ne contient que des clients GÉNÉRIQUES,
paramétrés par des données. Tout ce qui a du contrôle de flux (enchaînement,
pagination, expression régulière, pipeline PDAL) vit dans `adaptateurs.py`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from karstpro.core.territoires.types import ConfigurationInvalide, ContexteEtude
from karstpro.core.i18n import t


# ── Résolveurs de CRS de travail ─────────────────────────────────────────────

@dataclass(frozen=True)
class CrsFixe:
    """CRS constant, ex. la France en Lambert-93."""
    code: str
    absente = False

    def resoudre(self, bbox_wgs84) -> str:
        return self.code

    def executer(self, ctx: ContexteEtude) -> str:
        return self.code


@dataclass(frozen=True)
class CrsUtmParLongitude:
    """Zone UTM déduite de la longitude du centre de la bbox, puis TABLE
    explicite zone -> code EPSG.

    ⚠️ Aucune fabrication de code EPSG par concaténation. Le bug du 2026-08-02
    venait exactement de là : `"EPSG:25830".startswith("EPSG:2582")` est faux,
    ce qui rendait la branche espagnole inatteignable pour les zones 30 et 31.
    Une table explicite supprime cette classe d'erreur.
    """
    zones: Mapping[str, str]
    absente = False

    def resoudre(self, bbox_wgs84) -> str:
        xmin, _, xmax, _ = bbox_wgs84
        lon = (xmin + xmax) / 2
        zone = int((lon + 180) // 6) + 1
        code = self.zones.get(str(zone))
        if code is None:
            raise ConfigurationInvalide(
                f"Zone UTM {zone} hors couverture déclarée pour ce territoire "
                f"(zones couvertes : {sorted(self.zones)}).")
        return code

    def executer(self, ctx: ContexteEtude) -> str:
        return self.resoudre(ctx.bbox)


# ── Source opérée par l'utilisateur ──────────────────────────────────────────

@dataclass(frozen=True)
class MntManuel:
    """MNT que seul l'utilisateur peut fournir (paramètre ``MNT_FILES``).

    Certains territoires ne servent leur MNT par AUCUNE API : la Wallonie
    publie un LiDAR 1 m sous CC-BY 4.0, mais son WCS INSPIRE expose zéro
    couverture et son service ArcGIS est un MapServer, pas un ImageServer.
    Reste le panier de téléchargement, livré par courriel sous 48 h.

    Ce n'est PAS une capacité absente : ``registre.py`` interdit à juste titre
    un territoire sans source de MNT. La source existe — c'est l'utilisateur.
    """
    message_source: str
    url: str
    absente = False

    def executer(self, ctx: ContexteEtude):
        """Explique où télécharger, puis renonce.

        Retourne ``None`` : arriver ici signifie que ``MNT_FILES`` n'a pas été
        fourni. Le chemin d'échec existant du pipeline (« Aucune source de MNT
        disponible … impossible de continuer ») prend le relais, ce qui évite
        de modifier karst_prep_algorithm.py.
        """
        # Traduit ICI, comme Absente.raison : le message vient d'un JSON de
        # configuration, donc le scan AST de test_i18n ne le verrait jamais
        # passer par t() au point d'appel.
        if ctx.feedback:
            ctx.feedback.pushWarning(t(self.message_source, url=self.url))
        return None


# ── Combinateur de repli ─────────────────────────────────────────────────────

@dataclass(frozen=True)
class Chaine:
    """Essaie chaque maillon dans l'ordre, renvoie le premier résultat non nul.

    Rend explicite le repli PNOA 1 m -> MDT WCS 5 m côté Espagne, au lieu de
    l'enfouir dans une branche de l'algorithme. L'avertissement de résolution
    dégradée est porté par le maillon de repli lui-même.
    """
    maillons: tuple
    absente = False

    def executer(self, ctx: ContexteEtude):
        for maillon in self.maillons:
            resultat = maillon.executer(ctx)
            if resultat:
                return resultat
        return None


@dataclass(frozen=True)
class Liste:
    """Exécute **tous** les maillons et rend la liste de leurs résultats.

    À ne pas confondre avec :class:`Chaine`, qui décrit un repli : elle s'arrête
    au premier maillon qui aboutit. Ici les maillons ne se remplacent pas, ils
    s'additionnent — les quatre couches de l'Atlas du Karst Wallon sont quatre
    couches, pas quatre façons d'obtenir la même.

    Un maillon qui échoue est signalé et ignoré : une couche de contexte
    indisponible ne doit pas faire perdre une préparation de plusieurs heures.
    """
    maillons: tuple
    absente = False

    def executer(self, ctx: ContexteEtude):
        resultats = []
        for maillon in self.maillons:
            try:
                resultat = maillon.executer(ctx)
            except Exception as exc:
                if ctx.feedback:
                    ctx.feedback.pushWarning(
                        t("Couche de contexte ignorée : {exc}", exc=exc))
                continue
            if resultat is not None:
                resultats.append(resultat)
        return resultats


# ── Fournisseur réseau générique, décrit en données ─────────────────────────

@dataclass(frozen=True)
class SourceDeclarative:
    """Fournisseur réseau décrit entièrement par des données (URL, couche,
    champs). L'instanciation ne fait AUCUN appel réseau : elle ne retient que
    les paramètres, ce qui rend le chargement de config testable hors ligne.

    L'exécution est branchée capacité par capacité lors de la migration du
    pipeline (tâches ultérieures) : chaque capacité a sa propre signature de
    retour, ce module se contente de porter la déclaration.
    """
    type: str
    params: Mapping[str, object]
    absente = False

    def executer(self, ctx: ContexteEtude):
        if self.type == "arcgis":
            # Discriminant porté par la DÉCLARATION : un territoire qui nomme
            # son champ de description veut le service générique ; sans lui, on
            # garde l'adaptateur IGME, qui connaît les deux échelles espagnoles
            # et leur repli. Le type « arcgis » n'a jamais été générique — son
            # docstring annonçait un branchement « capacité par capacité », et
            # la Wallonie est le premier territoire à en avoir besoin.
            champ = self.params.get("champ_descr")
            if champ:
                from karstpro.core.geology_arcgis import fetch_arcgis_polygones
                if ctx.feedback:
                    ctx.feedback.pushInfo(t(
                        "Import géologie — service ArcGIS du territoire..."))
                return fetch_arcgis_polygones(
                    str(self.params["url"]), ctx.bbox, ctx.crs, str(champ))
            from karstpro.core.geology_igme import fetch_igme_geology
            if ctx.feedback:
                ctx.feedback.pushInfo(
                    t("Import geologie — IGME (Espagne, 1/50 000 puis 1/1M)..."))
            return fetch_igme_geology(ctx.bbox, crs=ctx.crs)
        if self.type == "arcgis_vecteur":
            # Couche de contexte : rendue telle quelle, sans contrat de colonne
            # ni de géométrie (cf. core/arcgis_vecteur.py). Le titre voyage
            # avec les données — c'est le territoire qui nomme sa couche, pas
            # le pipeline, qui ne sait pas ce qu'elle contient.
            from karstpro.core.arcgis_vecteur import fetch_arcgis_features
            titre = str(self.params["titre"])
            if ctx.feedback:
                ctx.feedback.pushInfo(
                    t("Import couche de contexte « {titre} »...", titre=titre))
            donnees = fetch_arcgis_features(
                str(self.params["url"]), ctx.bbox, ctx.crs,
                champs=self.params.get("champs"))
            # `credit` voyage avec la couche : c'est le producteur cité au pied
            # des feuilles imprimées. L'AKWA est en CC-BY 4.0, qui EXIGE
            # l'attribution — la composer depuis les données évite de la coder
            # en dur, ce qui avait fait créditer l'IGN français sur une carte
            # wallonne.
            return {"titre": titre, "donnees": donnees,
                    "credit": self.params.get("credit")}
        if self.type == "wcs":
            from karstpro.core.mdt_wcs_es import fetch_mdt_wcs
            if ctx.feedback:
                ctx.feedback.pushWarning(
                    t("PNOA 1 m indisponible pour cette zone (hors couverture "
                    "ou service en panne) — repli sur le MDT automatique "
                    "WCS (5 m, moins précis). Résolution 5x plus grossière "
                    "que le LiDAR 1 m : les petites dolines seront "
                    "probablement invisibles.")
                )
            chemin = fetch_mdt_wcs(ctx.bbox, crs=ctx.crs, dest_dir=ctx.work_dir)
            return None if chemin is None else {"mnt": chemin, "laz": []}
        raise NotImplementedError(
            f"Le type déclaratif « {self.type} » n'est pas encore branché sur "
            f"une capacité du pipeline.")
