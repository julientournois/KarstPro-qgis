# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Fournisseurs de capacités pilotés par déclaration (config JSON).

Frontière config/code : ce module ne contient que des clients GÉNÉRIQUES,
paramétrés par des données. Tout ce qui a du contrôle de flux (enchaînement,
pagination, expression régulière, pipeline PDAL) vit dans `adaptateurs.py`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from karstpro.core.territoires.types import ConfigurationInvalide, ContexteEtude


# ── Résolveurs de CRS de travail ─────────────────────────────────────────────

@dataclass(frozen=True)
class CrsFixe:
    """CRS constant, ex. la France en Lambert-93."""
    code: str
    absente = False

    def resoudre(self, bbox_wgs84) -> str:
        return self.code

    def executer(self, ctx: ContexteEtude) -> str:
        return self.code


@dataclass(frozen=True)
class CrsUtmParLongitude:
    """Zone UTM déduite de la longitude du centre de la bbox, puis TABLE
    explicite zone -> code EPSG.

    ⚠️ Aucune fabrication de code EPSG par concaténation. Le bug du 2026-08-02
    venait exactement de là : `"EPSG:25830".startswith("EPSG:2582")` est faux,
    ce qui rendait la branche espagnole inatteignable pour les zones 30 et 31.
    Une table explicite supprime cette classe d'erreur.
    """
    zones: Mapping[str, str]
    absente = False

    def resoudre(self, bbox_wgs84) -> str:
        xmin, _, xmax, _ = bbox_wgs84
        lon = (xmin + xmax) / 2
        zone = int((lon + 180) // 6) + 1
        code = self.zones.get(str(zone))
        if code is None:
            raise ConfigurationInvalide(
                f"Zone UTM {zone} hors couverture déclarée pour ce territoire "
                f"(zones couvertes : {sorted(self.zones)}).")
        return code

    def executer(self, ctx: ContexteEtude) -> str:
        return self.resoudre(ctx.bbox)


# ── Combinateur de repli ─────────────────────────────────────────────────────

@dataclass(frozen=True)
class Chaine:
    """Essaie chaque maillon dans l'ordre, renvoie le premier résultat non nul.

    Rend explicite le repli PNOA 1 m -> MDT WCS 5 m côté Espagne, au lieu de
    l'enfouir dans une branche de l'algorithme. L'avertissement de résolution
    dégradée est porté par le maillon de repli lui-même.
    """
    maillons: tuple
    absente = False

    def executer(self, ctx: ContexteEtude):
        for maillon in self.maillons:
            resultat = maillon.executer(ctx)
            if resultat:
                return resultat
        return None


# ── Fournisseur réseau générique, décrit en données ─────────────────────────

@dataclass(frozen=True)
class SourceDeclarative:
    """Fournisseur réseau décrit entièrement par des données (URL, couche,
    champs). L'instanciation ne fait AUCUN appel réseau : elle ne retient que
    les paramètres, ce qui rend le chargement de config testable hors ligne.

    L'exécution est branchée capacité par capacité lors de la migration du
    pipeline (tâches ultérieures) : chaque capacité a sa propre signature de
    retour, ce module se contente de porter la déclaration.
    """
    type: str
    params: Mapping[str, object]
    absente = False

    def executer(self, ctx: ContexteEtude):
        if self.type == "arcgis":
            from karstpro.core.geology_igme import fetch_igme_geology
            if ctx.feedback:
                ctx.feedback.pushInfo(
                    "Import geologie — IGME (Espagne, 1/50 000 puis 1/1M)...")
            return fetch_igme_geology(ctx.bbox, crs=ctx.crs)
        if self.type == "wcs":
            from karstpro.core.mdt_wcs_es import fetch_mdt_wcs
            if ctx.feedback:
                ctx.feedback.pushWarning(
                    "PNOA 1 m indisponible pour cette zone (hors couverture "
                    "ou service en panne) — repli sur le MDT automatique "
                    "WCS (5 m, moins précis). Résolution 5x plus grossière "
                    "que le LiDAR 1 m : les petites dolines seront "
                    "probablement invisibles."
                )
            chemin = fetch_mdt_wcs(ctx.bbox, crs=ctx.crs, dest_dir=ctx.work_dir)
            return None if chemin is None else {"mnt": chemin, "laz": []}
        raise NotImplementedError(
            f"Le type déclaratif « {self.type} » n'est pas encore branché sur "
            f"une capacité du pipeline.")
