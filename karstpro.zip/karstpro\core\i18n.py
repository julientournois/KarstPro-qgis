# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Traduction de l'interface — catalogue Python, sans Qt ni outil externe.

Le français est la **langue source** : le texte français sert directement de
clé, il n'y a donc pas de `fr.json` identité à maintenir. Seules les autres
langues ont un catalogue.

    feedback.pushInfo(t("Gouffres : {n} candidat(s)", n=len(gouffres)))

Reformuler un message français casse volontairement la correspondance :
``test_i18n`` échoue alors en signalant une chaîne sans traduction. C'est le
but — il doit être impossible de reformuler un message sans que l'anglais
suive. Un catalogue Qt (.ts) retomberait silencieusement sur le français, donc
exactement sur la dérive qu'on cherche à empêcher.

**Aucun import Qt ici**, délibérément : `core/` reste importable sans QGIS (les
imports lourds y sont différés parce que QGIS met ``sys.stderr`` à ``None`` au
chargement des plugins, ce qui fait planter les extensions C qui émettent des
avertissements). La locale est donc *injectée* depuis la couche QGIS —
``definir_langue(QgsApplication.locale())`` au chargement du provider — au lieu
d'être lue ici.
"""
from __future__ import annotations

import json
from pathlib import Path

# Langue source. Toute autre langue doit avoir son catalogue dans i18n/.
SOURCE = "fr"

# Langues gérées. Le test de garde vérifie qu'un catalogue existe pour chacune
# et que toute chaîne traduisible y figure.
LANGUES = ("fr", "en")

# Langue servie quand la locale n'est ni le français ni l'anglais. Voir
# definir_langue() pour le raisonnement — ce n'est PAS la langue source.
REPLI = "en"

_DOSSIER = Path(__file__).resolve().parent.parent / "i18n"

_langue = SOURCE
_catalogues: dict = {}      # {langue: {source: traduction}} — chargé à la demande


def _charger(code: str) -> dict:
    """Catalogue d'une langue. Absent ou illisible → dict vide (repli français).

    Best-effort volontaire : un catalogue corrompu doit dégrader vers le
    français, jamais empêcher le plugin de démarrer.
    """
    if code in _catalogues:
        return _catalogues[code]
    donnees: dict = {}
    if code != SOURCE:
        try:
            donnees = json.loads(
                (_DOSSIER / f"{code}.json").read_text(encoding="utf-8"))
        except Exception:
            donnees = {}
    _catalogues[code] = donnees
    return donnees


def definir_langue(code) -> str:
    """Fixe la langue courante. Renvoie le code retenu.

    Accepte les formes rendues par QGIS et Qt (« fr », « fr_FR », « en_GB ») :
    seules les deux premières lettres comptent.

    Une langue sans catalogue retombe sur l'**anglais**, pas sur le français.
    Le réflexe initial était de replier sur la langue source, seule garantie
    complète par construction — mais ``test_i18n`` garantit désormais que
    l'anglais l'est aussi (toute chaîne passée à ``t()`` doit y figurer, sinon
    la suite échoue). L'anglais est donc un repli aussi sûr, et bien plus utile
    à qui ne parle ni l'une ni l'autre : un QGIS espagnol, allemand ou italien
    affichait jusqu'ici du français, ce qui était le contraire de l'intention.
    Les francophones de Belgique ou de Suisse ont une locale ``fr_BE`` /
    ``fr_CH``, donc déjà couverte par le préfixe.
    """
    global _langue
    court = (str(code or "")[:2]).lower()
    _langue = court if court in LANGUES else REPLI
    return _langue


def langue() -> str:
    return _langue


def t(source: str, **params) -> str:
    """Traduit ``source`` dans la langue courante, puis applique ``format``.

    Le formatage est protégé : si la traduction a perdu un marqueur (``{n}``
    absent ou renommé), on retombe sur le texte français formaté au lieu de
    lever un KeyError. Une préparation de dix minutes ne doit jamais échouer à
    cause d'une traduction. La correction des marqueurs est garantie en amont
    par ``test_i18n``, pas par un plantage à l'exécution.
    """
    texte = _charger(_langue).get(source, source) if _langue != SOURCE else source
    if not params:
        return texte
    try:
        return texte.format(**params)
    except (KeyError, IndexError, ValueError):
        try:
            return source.format(**params)
        except (KeyError, IndexError, ValueError):
            return source


def aide(module: str) -> str:
    """Corps HTML du panneau d'aide d'un algorithme, dans la langue courante.

    ``module`` est le nom du fichier de l'algorithme sans extension
    (``karst_prep_algorithm``) : les appelants le dérivent de ``__name__``, il
    ne peut donc pas diverger du nom de fichier.

    Ces panneaux vivent hors du catalogue : 1 200 à 4 500 caractères chacun,
    ils seraient illisibles en entrée JSON et impossibles à relire en diff.
    Les sortir du Python allège aussi les algorithmes de 14 187 caractères de
    texte qui n'ont rien à faire dans du code.

    Repli sur le français si la traduction manque — mieux vaut une aide
    française qu'un panneau vide.
    """
    for code in (_langue, SOURCE):
        chemin = _DOSSIER / "aide" / f"{module}.{code}.html"
        try:
            return chemin.read_text(encoding="utf-8")
        except OSError:
            continue
    return ""


_affichage: dict = {}


def _table_affichage() -> dict:
    """Libellés affichés des couches, champs et valeurs. {} si illisible."""
    global _affichage
    if not _affichage:
        try:
            _affichage = json.loads(
                (_DOSSIER / "affichage.json").read_text(encoding="utf-8"))
        except Exception:
            _affichage = {"couches": {}, "champs": {}, "valeurs": {}}
    return _affichage


def _libelle(famille: str, cle: str, defaut: str) -> str:
    entree = _table_affichage().get(famille, {}).get(cle)
    if not isinstance(entree, dict):
        return defaut
    return entree.get(_langue) or entree.get(SOURCE) or defaut


def libelle_couche(nom_table: str) -> str:
    """Nom AFFICHÉ d'une couche. La table garde son nom : `gouffres` reste
    `gouffres` dans le GeoPackage, seul l'arbre des couches change."""
    return _libelle("couches", nom_table, nom_table)


def alias_champ(nom_colonne: str) -> str:
    """Alias AFFICHÉ d'un champ. La colonne garde son nom en base."""
    return _libelle("champs", nom_colonne, nom_colonne)


def valeurs_champ(nom_colonne: str) -> dict:
    """{valeur stockée: libellé affiché} pour une value map QGIS.

    Les valeurs de `type_doline` (doline / doline-perte / perte) sont des
    **données** relues par l'export MLL et le scoring : elles restent
    françaises en base, seule leur présentation est traduite.
    """
    table = _table_affichage().get("valeurs", {}).get(nom_colonne, {})
    return {v: (lang.get(_langue) or lang.get(SOURCE) or v)
            for v, lang in table.items() if isinstance(lang, dict)}


def _reinitialiser() -> None:
    _affichage.clear()
    """Vide le cache de catalogues — réservé aux tests."""
    _catalogues.clear()
