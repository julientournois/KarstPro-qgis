# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Point d'entrée ENFANT : exécute « Préparer une étude » dans un processus neuf.

Pourquoi ce détour. Construire un CRS pyproj dans un **second** `QgsTask` tue
le processus QGIS (cf. `karstpro/core/crs_thread.py`) : relancer une
préparation dans la même session suffit à tout perdre. Ici l'algorithme est
toujours le **premier et unique** run de son processus.

**Le corps de `processAlgorithm` n'est pas découpé.** Le découper en « plomberie
QGIS » et « travail » était l'option envisagée — 950 lignes à ouvrir. Réexécuter
le même algorithme dans un processus neuf donne le même bénéfice sans y toucher,
donc sans le risque de régression que ce découpage porterait. Le découpage
reste possible plus tard, il n'est plus urgent.

La récursion est coupée par la variable d'environnement `KARSTPRO_ENFANT` :
l'algorithme ne délègue que si elle est absente.
"""
import json
import os
import sys
import traceback
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
if str(RACINE) not in sys.path:
    sys.path.insert(0, str(RACINE))


class _FeedbackEmetteur:
    """`QgsProcessingFeedback` dont chaque message part vers le parent.

    On hérite de la classe QGIS : la préparation appelle `processing.run()` en
    interne, qui exige un vrai feedback, pas un double.
    """

    def __new__(cls):
        from qgis.core import QgsProcessingFeedback

        class _Impl(QgsProcessingFeedback):
            def pushInfo(self, message):
                from karstpro.core.sous_processus import emettre
                emettre("info", message=message)

            def pushWarning(self, message):
                from karstpro.core.sous_processus import emettre
                emettre("warning", message=message)

            def reportError(self, message, fatalError=False):
                from karstpro.core.sous_processus import emettre
                emettre("warning", message=message)

            def setProgress(self, valeur):
                from karstpro.core.sous_processus import emettre
                emettre("progress", valeur=float(valeur))

        return _Impl()


def main() -> int:
    parametres = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))

    from qgis.core import (QgsApplication, QgsProcessingContext)

    QgsApplication.setPrefixPath(sys.exec_prefix, True)
    app = QgsApplication([], False)
    app.initQgis()
    try:
        plugins = Path(QgsApplication.prefixPath()) / "python" / "plugins"
        if plugins.is_dir():
            sys.path.append(str(plugins))
        from processing.core.Processing import Processing
        Processing.initialize()

        from karstpro.karstpro_provider import KarstProProvider
        fournisseur = KarstProProvider()      # référence conservée (GC)
        QgsApplication.processingRegistry().addProvider(fournisseur)

        algo = QgsApplication.processingRegistry().createAlgorithmById(
            "karstpro:karst_prep", {})
        if algo is None:
            raise RuntimeError("algorithme « karstpro:karst_prep » introuvable "
                               "dans le processus enfant")

        resultat, ok = algo.run(parametres, QgsProcessingContext(),
                                _FeedbackEmetteur())
        from karstpro.core.sous_processus import emettre
        if not ok:
            raise RuntimeError("la préparation a rendu un échec sans exception")
        emettre("resultat", **{k: str(v) for k, v in (resultat or {}).items()})
        return 0
    finally:
        try:
            app.exitQgis()
        except Exception:                                      # noqa: BLE001
            pass


if __name__ == "__main__":
    # `KARSTPRO_ENFANT` coupe la récursion : sans elle, l'algorithme relancerait
    # un sous-processus, qui en relancerait un autre.
    os.environ["KARSTPRO_ENFANT"] = "1"
    try:
        code = main()
    except Exception:                                          # noqa: BLE001
        traceback.print_exc()
        code = 1
    sys.stdout.flush()
    sys.stderr.flush()
    # `os._exit` : `exitQgis()` laisse vivre les threads de PDAL et de
    # WhiteboxTools, et le processus meurt pendant la destruction avec un code
    # sans rapport avec le résultat (127 constaté).
    os._exit(code)
