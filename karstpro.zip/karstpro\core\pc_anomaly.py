# karstpro/core/pc_anomaly.py
# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Détection ponctuelle de puits depuis le nuage de points brut (derniers
retours) — signal complémentaire aux dolines/gouffres dérivés du MNT lissé.

Compare, dans une petite fenêtre locale autour de chaque doline, l'altitude
minimale des derniers retours à une référence de voisinage : une cellule qui
plonge nettement sous ses voisines immédiates est un candidat "puits" —
signature invisible à la fois à la détection de dolines (cuvettes) et de
gouffres (trous NODATA compacts, cf. shafts.py).

Travaille sur les rasters déjà produits par ``core.lidar.generate_pc_rasters``
(bande min + bande count des derniers retours) et le MNT du secteur — aucune
I/O PDAL supplémentaire ici, juste du découpage/numpy en mémoire. numpy pur
(pas scipy, malgré sa disponibilité dans l'environnement QGIS) : convention
déjà établie dans ``core/shafts.py``, scipy n'est pas une dépendance gérée
(``core/dependencies.py``).

Purement informatif (Phase 1, cf. spec) : ne modifie jamais score/priorite.
"""
import math
import warnings

import numpy as np


def _window_bounds(transform, width, height, cx, cy, radius_m):
    """Bornes pixel (r0, r1, c0, c1) d'une fenêtre carrée de rayon
    ``radius_m`` autour de (cx, cy), tronquée à l'emprise du raster.
    ``None`` si le centre est entièrement hors emprise.
    """
    inv = ~transform
    col_f, row_f = inv * (cx, cy)
    col, row = int(round(col_f)), int(round(row_f))
    px = int(math.ceil(radius_m / abs(transform.a)))
    r0, r1 = row - px, row + px + 1
    c0, c1 = col - px, col + px + 1
    if r1 <= 0 or c1 <= 0 or r0 >= height or c0 >= width:
        return None
    return max(0, r0), min(height, r1), max(0, c0), min(width, c1)


def sample_doline_signal(pc_min, pc_count, mnt, transform, cx, cy,
                          search_radius_m=8.0, median_radius_px=4,
                          plunge_abs_m=1.0, plunge_rel_m=1.0):
    """Cherche une anomalie ponctuelle près du centroïde (cx, cy) d'une
    doline.

    Args:
        pc_min, pc_count, mnt: tableaux numpy 2D, même grille (résolution,
            emprise) — altitude min des derniers retours, nombre de derniers
            retours, MNT sol.
        transform: rasterio.Affine du raster (identique pour les 3
            tableaux).
        cx, cy: centroïde de la doline, mêmes coordonnées que le raster.
        search_radius_m: rayon où chercher la cellule anomalie autour du
            centroïde.
        median_radius_px: rayon (en cellules) de la fenêtre de référence
            locale (médiane) — défaut 4 -> fenêtre 9x9.
        plunge_abs_m: plongée minimale absolue sous le MNT pour candidater.
        plunge_rel_m: plongée minimale sous la référence locale (médiane du
            voisinage) pour candidater.

    Returns:
        dict {"pc_plongee_m", "pc_dist_m", "pc_n_points"} ou ``None`` si
        aucune anomalie trouvée dans le rayon de recherche.
    """
    height, width = pc_min.shape
    win_radius_m = search_radius_m + median_radius_px * abs(transform.a)
    bounds = _window_bounds(transform, width, height, cx, cy, win_radius_m)
    if bounds is None:
        return None
    r0, r1, c0, c1 = bounds

    min_win = pc_min[r0:r1, c0:c1]
    count_win = pc_count[r0:r1, c0:c1]
    mnt_win = mnt[r0:r1, c0:c1]
    if min_win.size == 0:
        return None

    hag = np.where(count_win > 0, min_win - mnt_win, np.nan)
    if np.all(np.isnan(hag)):
        return None

    win = 2 * median_radius_px + 1
    padded = np.pad(hag, median_radius_px, mode="edge")
    windows = np.lib.stride_tricks.sliding_window_view(padded, (win, win))
    # "All-NaN slice" est attendu (fenêtre sans aucun dernier retour, ex.
    # plan d'eau ou bord de dalle) — nanmedian renvoie NaN, géré plus bas
    # par la comparaison (NaN donne toujours False), pas une erreur.
    with np.errstate(all="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        local_ref = np.nanmedian(windows, axis=(-2, -1))

    anomaly = (hag < local_ref - plunge_rel_m) & (hag < -plunge_abs_m)
    if not anomaly.any():
        return None

    # Le sur-echantillonnage pour la mediane deborde volontairement plus
    # loin que le rayon de recherche reel : on filtre ici.
    rows, cols = np.indices(hag.shape)
    cell_x = transform.c + (c0 + cols + 0.5) * transform.a
    cell_y = transform.f + (r0 + rows + 0.5) * transform.e
    dist = np.hypot(cell_x - cx, cell_y - cy)
    anomaly &= dist <= search_radius_m
    if not anomaly.any():
        return None

    cand_rows, cand_cols = np.where(anomaly)
    best_i = np.argmin(hag[cand_rows, cand_cols])
    by, bx = cand_rows[best_i], cand_cols[best_i]
    return {
        "pc_plongee_m": round(float(-hag[by, bx]), 2),
        "pc_dist_m": round(float(dist[by, bx]), 1),
        "pc_n_points": int(count_win[by, bx]),
    }


def sample_dolines(dolines, pc_min, pc_count, mnt, transform,
                    surface_col="surface_m2", surface_threshold_m2=100_000.0,
                    **kwargs):
    """Calcule le signal ponctuel pour chaque doline sous le seuil de
    surface. Renvoie ``dolines`` avec 3 nouvelles colonnes
    (``pc_plongee_m``, ``pc_dist_m``, ``pc_n_points``), NaN si pas de signal
    ou surface >= seuil (jamais testée).

    Args:
        dolines: GeoDataFrame (colonnes ``geometry``, ``surface_col``).
        pc_min, pc_count, mnt, transform: cf. sample_doline_signal.
        surface_threshold_m2: dolines >= ce seuil ne sont pas testées.
            Défaut volontairement très haut = **toutes les dolines testées**.
        **kwargs: transmis à sample_doline_signal (search_radius_m, etc.)

    ⚠️ Le défaut valait 50 m² jusqu'au 2026-07-26, sur l'intuition (jamais
    vérifiée) que « le signal n'est fiable que sur les petites dolines ».
    Mesuré depuis sur 5 secteurs, contre les inventaires de cavités connues
    (rayon 20 m), le signal est **au moins aussi prédictif sur les dolines
    ≥ 50 m²** — ratio signal/sans-signal : Marnaval 7,2× (contre 2,6× sur les
    petites), Molain 12,8× (4,1×), Arc-sous-Cicon 7,1× (5,2×), Besain 4,0×
    (3,9×), Beurey 4,6× (4,9×). Le taux de détection reste par ailleurs stable
    (8,6-9,0 %) quel que soit le seuil : pas d'explosion de faux positifs.
    L'ancien seuil excluait donc la population où le signal marche le mieux,
    et qui contient 78 % des dolines rouges (57/73 sur Marnaval).
    """
    plongees, dists, n_points = [], [], []
    for _, row in dolines.iterrows():
        surf = row.get(surface_col)
        result = None
        if surf is not None and surf < surface_threshold_m2:
            c = row.geometry.centroid
            result = sample_doline_signal(pc_min, pc_count, mnt, transform,
                                           c.x, c.y, **kwargs)
        if result is None:
            plongees.append(np.nan)
            dists.append(np.nan)
            n_points.append(np.nan)
        else:
            plongees.append(result["pc_plongee_m"])
            dists.append(result["pc_dist_m"])
            n_points.append(result["pc_n_points"])

    out = dolines.copy()
    out["pc_plongee_m"] = plongees
    out["pc_dist_m"] = dists
    out["pc_n_points"] = n_points
    return out
