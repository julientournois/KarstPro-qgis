# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from datetime import date, datetime
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingContext,
    QgsProcessingFeedback,
)

# NOTE: geopandas and karstpro.core.* imports are deferred to inside
# processAlgorithm() to avoid the sys.stderr=None crash at QGIS plugin load.


class KarstSyncAlgorithm(QgsProcessingAlgorithm):
    """Intègre au bureau le retour d'une sortie terrain saisie dans QField.

    Produit, à partir des trouvailles terrain (cavités saisies + cibles et
    gouffres à intérêt) :
      - un **CSV importable par Karst Entry** (gestion d'inventaire) ;
      - un **rapport PDF** (une fiche par trouvaille, avec photo) ;
      - le CSV cumulatif des labels terrain (apprentissage).

    KarstPro = détection + terrain ; Karst Entry = inventaire. La sync ne touche
    plus à une couche inventaire : elle exporte un CSV que Karst Entry importe
    (et y dédoublonne).
    """

    QFIELD_GPKG = "QFIELD_GPKG"
    MNT_RASTER = "MNT_RASTER"
    DEDUP_THRESHOLD = "DEDUP_THRESHOLD"
    CLEAN_FIELD_LAYERS = "CLEAN_FIELD_LAYERS"
    OUTPUT_DIR = "OUTPUT_DIR"

    def name(self):
        return "karst_sync"

    def displayName(self):
        return "KarstPro — Synchroniser le retour terrain"

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstSyncAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        return help_html(
            "<b>Synchroniser le retour terrain.</b><br><br>"
            "<b>But :</b> intégrer au bureau ce qui a été saisi sur le téléphone "
            "après une sortie, et produire un <b>CSV pour Karst Entry</b> + un "
            "rapport PDF. KarstPro détecte et va sur le terrain ; Karst Entry "
            "gère l'inventaire.<br><br>"
            "<b>Ce que ça fait :</b><br>"
            "• Rassemble les <b>trouvailles terrain</b> : cavités saisies (couche "
            "<i>cavites</i>), cibles à intérêt (indice ou cavité) et gouffres "
            "visités à intérêt. Renseigne l'altitude (MNT), géocode la commune.<br>"
            "• Écrit <b>&lt;secteur&gt;_terrain_karstentry.csv</b> à côté du .gpkg "
            "(délimiteur « ; », WGS84, photos comprises). À <b>importer dans Karst "
            "Entry</b> (qui dédoublonne contre ton inventaire).<br>"
            "• Génère un <b>rapport PDF</b> (une fiche par trouvaille, avec photo). "
            "<i>Sans trouvaille, ni CSV ni PDF ni dossier de rapport ne sont créés</i> "
            "— seul un journal, à côté du .gpkg.<br>"
            "• Extrait les verdicts <i>interet</i> vers <i>labels_terrain.csv</i> "
            "(apprentissage).<br>"
            "• Option <b>Nettoyer les couches terrain</b> (⚠ destructif) : vide "
            "<i>cavites</i> et déplace TOUTES les cibles visitées (sans intérêt "
            "<b>et</b> à intérêt, déjà exportées) de P1/P2/P3 vers « cibles "
            "visitées » — jamais de suppression sèche, pour que la re-préparation "
            "ne re-propose pas un endroit déjà confirmé. Ces retraits redescendent "
            "au téléphone à la re-synchro QFieldCloud.<br><br>"
            "<b>Comment l'utiliser :</b><br>"
            "1. Au bureau, synchronise d'abord le projet QField (QFieldSync → "
            "rapatrier du cloud).<br>"
            "2. Lance cet outil sur le .gpkg QField rapatrié.<br>"
            "3. (Optionnel) Renseigne le <b>MNT</b> : il sert à <b>calculer "
            "l'altitude</b> des trouvailles. La plupart des projets QField ne "
            "l'embarquent pas (trop lourd pour le cloud sans abonnement) — fournis "
            "ici la couche raster ou le .tif du secteur. Sans MNT, l'altitude reste "
            "vide.<br>"
            "4. Importe le CSV produit dans Karst Entry (onglet « Import CSV »)."
        )

    def _add_advanced(self, param):
        """Place le paramètre dans la section repliable « Paramètres avancés »."""
        from qgis.core import QgsProcessingParameterDefinition
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProcessingParameterRasterLayer
        self.addParameter(QgsProcessingParameterFile(
            self.QFIELD_GPKG,
            "GeoPackage du projet QField (retour terrain rapatrié du cloud)",
            extension="gpkg"))
        # MNT optionnel : la plupart des projets QField n'embarquent PAS le MNT
        # (trop lourd pour QFieldCloud). Sans MNT, l'altitude des trouvailles
        # reste vide. Couche raster chargée OU fichier (.tif via « … »).
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.MNT_RASTER,
            "MNT pour l'altitude (optionnel — couche raster ou .tif). "
            "Sert à calculer l'altitude des trouvailles. Si vide, recherché à "
            "côté du .gpkg (lidar_work/mnt.tif) ; sinon altitude non renseignée.",
            optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.CLEAN_FIELD_LAYERS,
            "Nettoyer les couches terrain après export (⚠ destructif)",
            defaultValue=True))
        self._add_advanced(QgsProcessingParameterNumber(
            self.DEDUP_THRESHOLD,
            "Distance de regroupement GPS (m) — deux points plus proches sont "
            "considérés comme la même trouvaille (évite les doublons)",
            defaultValue=3.0, minValue=1.0, maxValue=100.0))
        self._add_advanced(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR,
            "Dossier du rapport PDF (optionnel — par défaut : dossier du projet "
            "QField, sous RapportSortie/JJ-MM-AAAA)",
            optional=True, createByDefault=False))

    def processAlgorithm(self, parameters, context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        from karstpro.core.sync import (
            deduplicate_by_proximity, fill_altitude_from_mnt,
            collect_field_findings, write_karstentry_csv,
        )
        from karstpro.core.report import generate_report
        from qgis.core import QgsProcessingException

        qfield_gpkg = Path(self.parameterAsFile(parameters, self.QFIELD_GPKG, context))
        threshold = self.parameterAsDouble(parameters, self.DEDUP_THRESHOLD, context)
        clean_layers = self.parameterAsBool(parameters, self.CLEAN_FIELD_LAYERS, context)
        output_str = self.parameterAsString(parameters, self.OUTPUT_DIR, context)

        if not qfield_gpkg.exists():
            raise QgsProcessingException(
                f"GeoPackage QField introuvable : {qfield_gpkg}.")

        secteur = qfield_gpkg.stem
        # Horodatage commun au CSV et au PDF : évite d'écraser les exports d'une
        # sortie précédente (plusieurs sorties le même jour).
        stamp = datetime.now().strftime("%Y-%m-%d_%Hh%M-%S")

        # ── 1. Rassembler TOUTES les trouvailles terrain (AVANT nettoyage ET
        # avant de créer quoi que ce soit sur disque) : permet de savoir s'il y
        # a réellement quelque chose à exporter avant de créer un dossier de
        # rapport vide. Cavités saisies + cibles interet≥1 + gouffres interet≥1.
        # Lecture en sqlite pur (pas de pyproj : crash proj_create au 2ᵉ run
        # Processing).
        feedback.pushInfo("Lecture des trouvailles terrain...")
        findings = collect_field_findings(qfield_gpkg, secteur)
        feedback.pushInfo(f"  {len(findings)} trouvaille(s) brute(s) "
                          "(cavités saisies + cibles/gouffres à intérêt).")

        # Altitude depuis le MNT (absent du téléphone). Priorité au MNT choisi
        # explicitement (couche/fichier) ; sinon recherché à côté du gpkg :
        # lidar_work/ (étude bureau) ou racine (QFieldCloud copie à plat).
        mnt_layer = self.parameterAsRasterLayer(parameters, self.MNT_RASTER, context)
        if mnt_layer is not None and mnt_layer.isValid():
            mnt_path = Path(mnt_layer.source().split("|")[0])
            feedback.pushInfo(f"MNT fourni : {mnt_path}")
        else:
            mnt_path = qfield_gpkg.parent / "lidar_work" / "mnt.tif"
            if not mnt_path.exists() and (qfield_gpkg.parent / "mnt.tif").exists():
                mnt_path = qfield_gpkg.parent / "mnt.tif"
        before = int(findings["altitude"].notna().sum()) if "altitude" in findings.columns else 0
        findings = fill_altitude_from_mnt(findings, mnt_path)
        after = int(findings["altitude"].notna().sum()) if "altitude" in findings.columns else 0
        if after > before:
            feedback.pushInfo(f"  Altitude MNT renseignée pour {after - before} trouvaille(s).")
        elif not mnt_path.exists():
            feedback.pushWarning(
                f"  MNT introuvable ({mnt_path}) — altitude non renseignée.")

        # Regroupement des doublons GPS (une même cavité saisie plusieurs fois,
        # ou une cible qui coïncide avec une saisie directe). Garde la 1re.
        findings = deduplicate_by_proximity(findings, threshold_m=threshold)
        feedback.pushInfo(f"  {len(findings)} trouvaille(s) après regroupement.")
        no_findings = len(findings) == 0

        # Dossier rapport : explicite, sinon dossier du projet QField. Créé —
        # avec le CSV et le PDF dedans — SEULEMENT s'il y a quelque chose à
        # exporter. Sans trouvaille, pas de dossier/CSV/PDF vides : le journal
        # va directement à côté du gpkg (comme « Mettre à jour les cibles »).
        if output_str:
            report_dir = Path(output_str)
        else:
            report_dir = (qfield_gpkg.parent / "RapportSortie"
                          / date.today().strftime("%d-%m-%Y"))
        # Journal toujours dans logs/ (à côté du gpkg), séparé du dossier de
        # rapport (CSV/PDF) — pas d'encombrement du dossier d'étude.
        logs_dir = qfield_gpkg.parent / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / f"karstpro_sync_{secteur}_{stamp}.log"
        if not no_findings:
            report_dir.mkdir(parents=True, exist_ok=True)

        # Journal persistant (comme la préparation / l'export MLL) : tout le
        # déroulé est recopié dans un .log, même si la fenêtre Processing se
        # ferme. Les messages ci-dessus (lecture/altitude/regroupement) n'y sont
        # pas recopiés (on ne connaissait pas encore l'emplacement du log) —
        # on en remet un résumé ci-dessous.
        from karstpro.core.log_feedback import write_log_header, wrap_feedback
        write_log_header(
            log_file, f"KarstPro — Synchroniser le retour terrain ({secteur})",
            parameters)
        feedback = wrap_feedback(feedback, log_file)
        feedback.pushInfo(f"{len(findings)} trouvaille(s) au total (après regroupement).")

        if no_findings:
            n_csv = 0
            feedback.pushInfo(
                "Aucune trouvaille terrain (cavité saisie, cible ou gouffre à "
                "intérêt) — rien à exporter. CSV et rapport PDF non générés.")
        else:
            # ── 2. CSV importable Karst Entry (dans le dossier du rapport) ────
            # Placé à côté du PDF, horodaté. Les photos (relatives au projet
            # QField) sont résolues en chemins ABSOLUS pour que le CSV reste
            # importable hors du dossier du gpkg (KarstEntry les recopie à côté
            # de sa couche).
            csv_path = report_dir / f"{secteur}_terrain_karstentry_{stamp}.csv"
            n_csv = write_karstentry_csv(
                findings, csv_path, photos_base_dir=qfield_gpkg.parent)
            feedback.pushInfo(
                f"CSV Karst Entry : {n_csv} trouvaille(s) → {csv_path}")
            feedback.pushInfo(
                "  → À importer dans Karst Entry (onglet « Import CSV »).")

            # ── 3. Rapport PDF (mêmes trouvailles, avec photos) ───────────────
            feedback.pushInfo("Génération du rapport PDF...")
            report_path = report_dir / f"rapport_{secteur}_{stamp}.pdf"
            generate_report(secteur, findings, report_path,
                            attachments_dir=qfield_gpkg.parent)
            feedback.pushInfo(f"Rapport : {report_path}")

        # ── 4. Boucle de labels terrain (P3) ─────────────────────────────────
        # Extrait les `interet` (y compris 0) vers un CSV cumulatif. AVANT le
        # nettoyage (qui retire les verdicts de P1/P2/P3).
        try:
            from karstpro.core.sync import extract_terrain_labels
            labels_csv = qfield_gpkg.parent / "labels_terrain.csv"
            n_lab = extract_terrain_labels(qfield_gpkg, secteur, labels_csv)
            if n_lab:
                feedback.pushInfo(
                    f"Labels terrain : {n_lab} cible(s) visitée(s) → {labels_csv}")
            else:
                feedback.pushInfo(
                    "Labels terrain : aucune cible avec 'interet' saisi "
                    "(rien à extraire).")
        except Exception as exc:
            feedback.pushWarning(f"Extraction des labels terrain ignorée : {exc}")

        # ── 5. Nettoyage des couches terrain (option, destructif) ─────────────
        # RÉUTILISE « Mettre à jour les cibles » (archive interet=0 + retire les
        # cibles à cavité trouvée), puis archive AUSSI les cibles à intérêt (≥1,
        # déjà exportées au CSV) — pas de suppression sèche : suppress_already_
        # visited (re-préparation) ne lit QUE l'archive « cibles visitées », donc
        # une cavité/indice confirmé mais supprimé sans archive reviendrait se
        # faire re-proposer comme cible neuve à la prochaine préparation. VIDE
        # ensuite la couche tampon « cavites ».
        # ⚠ À la re-synchro QFieldCloud, ces retraits descendent sur le téléphone.
        if clean_layers:
            try:
                from qgis import processing
                feedback.pushInfo("Mise à jour des cibles (réutilisation)...")
                processing.run("karstpro:karst_update_cibles", {
                    "GPKG_FILE": str(qfield_gpkg),
                    "GPS_BUFFER_M": threshold,
                }, context=context, feedback=feedback)
            except Exception as exc:
                feedback.pushWarning(f"Mise à jour des cibles ignorée : {exc}")
            try:
                from karstpro.core.cibles_carryover import move_visited_to_archive
                rm_detail = []
                n_rm = move_visited_to_archive(qfield_gpkg, secteur,
                                               only_interet={1, 2},
                                               detail_out=rm_detail)
                if n_rm:
                    feedback.pushInfo(
                        f"{n_rm} cible(s) à intérêt archivée(s) dans « cibles "
                        "visitées » (déjà exportées au CSV inventaire).")
                    for d in rm_detail:
                        feedback.pushInfo(
                            f"    {d['name']} : « {d['layer']} » → « {d['destination']} »")
            except Exception as exc:
                feedback.pushWarning(f"Archivage des cibles à intérêt ignoré : {exc}")
            try:
                from karstpro.core.sync import reset_gouffres_interet
                g_detail = []
                n_g = reset_gouffres_interet(qfield_gpkg, (1, 2), detail_out=g_detail)
                if n_g:
                    feedback.pushInfo(
                        f"{n_g} gouffre(s) à intérêt remis à « non visité » "
                        "(verdict exporté au CSV — la couche reste, gouffres connus).")
                    for d in g_detail:
                        feedback.pushInfo(
                            f"    {d['name']} : « {d['layer']} » → « {d['destination']} »")
            except Exception as exc:
                feedback.pushWarning(f"Réinitialisation des gouffres ignorée : {exc}")
            try:
                from karstpro.core.gpkg import read_gpkg_layer, delete_features_by_fid
                cav = read_gpkg_layer(qfield_gpkg, "cavites")
                all_cav_fids = (cav["__fid__"].tolist()
                                if "__fid__" in cav.columns else [])
                n_del = delete_features_by_fid(qfield_gpkg, "cavites", all_cav_fids)
                if n_del:
                    feedback.pushInfo(
                        f"Couche « cavites » vidée : {n_del} cavité(s) retirée(s) "
                        "(exportées au CSV inventaire).")
                    if "name" in cav.columns:
                        for name in cav["name"]:
                            feedback.pushInfo(
                                f"    {name or '?'} : « cavites » → « CSV Karst Entry »")
            except Exception as exc:
                feedback.pushWarning(f"Nettoyage de « cavites » ignoré : {exc}")

        feedback.pushInfo(
            f"Terminé : {n_csv} trouvaille(s) exportée(s) pour Karst Entry.")
        feedback.pushInfo(f"Journal : {log_file}")
        # Le dossier de rapport n'existe que s'il y avait quelque chose à
        # exporter ; sinon on pointe vers le dossier du gpkg (où vit le .log).
        out_dir = report_dir if not no_findings else qfield_gpkg.parent
        return {self.OUTPUT_DIR: str(out_dir)}
