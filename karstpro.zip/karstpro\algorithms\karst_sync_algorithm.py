# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from datetime import date, datetime
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from karstpro.core.i18n import t

# NOTE: geopandas and karstpro.core.* imports are deferred to inside
# processAlgorithm() to avoid the sys.stderr=None crash at QGIS plugin load.


class KarstSyncAlgorithm(QgsProcessingAlgorithm):
    """Intègre au bureau le retour d'une sortie terrain saisie dans QField.

    Produit, à partir des trouvailles terrain (cavités saisies + cibles et
    gouffres à intérêt) :
      - un **CSV importable par Karst Entry** (gestion d'inventaire) ;
      - un **rapport PDF** (une fiche par trouvaille, avec photo) ;
      - le CSV cumulatif des labels terrain (apprentissage).

    KarstPro = détection + terrain ; Karst Entry = inventaire. La sync ne touche
    plus à une couche inventaire : elle exporte un CSV que Karst Entry importe
    (et y dédoublonne).
    """

    QFIELD_GPKG = "QFIELD_GPKG"
    MNT_RASTER = "MNT_RASTER"
    DEDUP_THRESHOLD = "DEDUP_THRESHOLD"
    CLEAN_FIELD_LAYERS = "CLEAN_FIELD_LAYERS"
    OUTPUT_DIR = "OUTPUT_DIR"

    def name(self):
        return "karst_sync"

    def displayName(self):
        return t("KarstPro — Synchroniser le retour terrain")

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstSyncAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        from karstpro.core.i18n import aide
        # Corps du panneau dans i18n/aide/<module>.<langue>.html — le nom du
        # module vient de __name__, il ne peut pas diverger du fichier.
        return help_html(aide(__name__.rsplit(".", 1)[-1]))

    def _add_advanced(self, param):
        """Place le paramètre dans la section repliable « Paramètres avancés »."""
        from qgis.core import QgsProcessingParameterDefinition
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProcessingParameterRasterLayer
        self.addParameter(QgsProcessingParameterFile(
            self.QFIELD_GPKG,
            t("GeoPackage du projet QField (retour terrain rapatrié du cloud)"),
            extension="gpkg"))
        # MNT optionnel : la plupart des projets QField n'embarquent PAS le MNT
        # (trop lourd pour QFieldCloud). Sans MNT, l'altitude des trouvailles
        # reste vide. Couche raster chargée OU fichier (.tif via « … »).
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.MNT_RASTER,
            t("MNT pour l'altitude (optionnel — couche raster ou .tif). "
            "Sert à calculer l'altitude des trouvailles. Si vide, recherché à "
            "côté du .gpkg (lidar_work/mnt.tif) ; sinon altitude non renseignée."),
            optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.CLEAN_FIELD_LAYERS,
            t("Nettoyer les couches terrain après export (⚠ destructif)"),
            defaultValue=True))
        self._add_advanced(QgsProcessingParameterNumber(
            self.DEDUP_THRESHOLD,
            t("Distance de regroupement GPS (m) — deux points plus proches sont "
            "considérés comme la même trouvaille (évite les doublons)"),
            defaultValue=3.0, minValue=1.0, maxValue=100.0))
        self._add_advanced(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR,
            t("Dossier du rapport PDF (optionnel — par défaut : dossier du projet "
            "QField, sous RapportSortie/JJ-MM-AAAA)"),
            optional=True, createByDefault=False))

    def processAlgorithm(self, parameters, context: QgsProcessingContext,
                         feedback: QgsProcessingFeedback):
        from karstpro.core.sync import (
            deduplicate_by_proximity, fill_altitude_from_mnt,
            collect_field_findings, write_karstentry_csv,
        )
        from karstpro.core.report import generate_report
        from qgis.core import QgsProcessingException

        qfield_gpkg = Path(self.parameterAsFile(parameters, self.QFIELD_GPKG, context))
        threshold = self.parameterAsDouble(parameters, self.DEDUP_THRESHOLD, context)
        clean_layers = self.parameterAsBool(parameters, self.CLEAN_FIELD_LAYERS, context)
        output_str = self.parameterAsString(parameters, self.OUTPUT_DIR, context)

        if not qfield_gpkg.exists():
            raise QgsProcessingException(
                f"GeoPackage QField introuvable : {qfield_gpkg}.")

        secteur = qfield_gpkg.stem
        # Horodatage commun au CSV et au PDF : évite d'écraser les exports d'une
        # sortie précédente (plusieurs sorties le même jour).
        stamp = datetime.now().strftime("%Y-%m-%d_%Hh%M-%S")

        # ── 1. Rassembler TOUTES les trouvailles terrain (AVANT nettoyage ET
        # avant de créer quoi que ce soit sur disque) : permet de savoir s'il y
        # a réellement quelque chose à exporter avant de créer un dossier de
        # rapport vide. Cavités saisies + cibles interet≥1 + gouffres interet≥1.
        # Lecture en sqlite pur (pas de pyproj : crash proj_create au 2ᵉ run
        # Processing).
        feedback.pushInfo(t("Lecture des trouvailles terrain..."))
        findings = collect_field_findings(qfield_gpkg, secteur)
        feedback.pushInfo(t("  {n} trouvaille(s) brute(s) (cavités saisies + cibles/gouffres à intérêt).", n=len(findings)))

        # Altitude depuis le MNT (absent du téléphone). Priorité au MNT choisi
        # explicitement (couche/fichier) ; sinon recherché à côté du gpkg :
        # lidar_work/ (étude bureau) ou racine (QFieldCloud copie à plat).
        mnt_layer = self.parameterAsRasterLayer(parameters, self.MNT_RASTER, context)
        if mnt_layer is not None and mnt_layer.isValid():
            mnt_path = Path(mnt_layer.source().split("|")[0])
            feedback.pushInfo(t("MNT fourni : {mnt_path}", mnt_path=mnt_path))
        else:
            mnt_path = qfield_gpkg.parent / "lidar_work" / "mnt.tif"
            if not mnt_path.exists() and (qfield_gpkg.parent / "mnt.tif").exists():
                mnt_path = qfield_gpkg.parent / "mnt.tif"
        before = int(findings["altitude"].notna().sum()) if "altitude" in findings.columns else 0
        findings = fill_altitude_from_mnt(findings, mnt_path)
        after = int(findings["altitude"].notna().sum()) if "altitude" in findings.columns else 0
        if after > before:
            feedback.pushInfo(t("  Altitude MNT renseignée pour {v0} trouvaille(s).", v0=after - before))
        elif not mnt_path.exists():
            feedback.pushWarning(
                t("  MNT introuvable ({mnt_path}) — altitude non renseignée.", mnt_path=mnt_path))

        # Regroupement des doublons GPS (une même cavité saisie plusieurs fois,
        # ou une cible qui coïncide avec une saisie directe). Garde la 1re.
        findings = deduplicate_by_proximity(findings, threshold_m=threshold)
        feedback.pushInfo(t("  {n} trouvaille(s) après regroupement.", n=len(findings)))
        no_findings = len(findings) == 0

        # Dossier rapport : explicite, sinon dossier du projet QField. Créé —
        # avec le CSV et le PDF dedans — SEULEMENT s'il y a quelque chose à
        # exporter. Sans trouvaille, pas de dossier/CSV/PDF vides : le journal
        # va directement à côté du gpkg (comme « Mettre à jour les cibles »).
        if output_str:
            report_dir = Path(output_str)
        else:
            report_dir = (qfield_gpkg.parent / "RapportSortie"
                          / date.today().strftime("%d-%m-%Y"))
        # Journal toujours dans logs/ (à côté du gpkg), séparé du dossier de
        # rapport (CSV/PDF) — pas d'encombrement du dossier d'étude.
        logs_dir = qfield_gpkg.parent / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / f"karstpro_sync_{secteur}_{stamp}.log"
        if not no_findings:
            report_dir.mkdir(parents=True, exist_ok=True)

        # Journal persistant (comme la préparation / l'export MLL) : tout le
        # déroulé est recopié dans un .log, même si la fenêtre Processing se
        # ferme. Les messages ci-dessus (lecture/altitude/regroupement) n'y sont
        # pas recopiés (on ne connaissait pas encore l'emplacement du log) —
        # on en remet un résumé ci-dessous.
        from karstpro.core.log_feedback import write_log_header, wrap_feedback
        write_log_header(
            log_file, f"{t('KarstPro — Synchroniser le retour terrain')} ({secteur})",
            parameters)
        feedback = wrap_feedback(feedback, log_file)
        feedback.pushInfo(t("{n} trouvaille(s) au total (après regroupement).", n=len(findings)))

        if no_findings:
            n_csv = 0
            feedback.pushInfo(
                t("Aucune trouvaille terrain (cavité saisie, cible ou gouffre à "
                "intérêt) — rien à exporter. CSV et rapport PDF non générés."))
        else:
            # ── 2. CSV importable Karst Entry (dans le dossier du rapport) ────
            # Placé à côté du PDF, horodaté. Les photos (relatives au projet
            # QField) sont résolues en chemins ABSOLUS pour que le CSV reste
            # importable hors du dossier du gpkg (KarstEntry les recopie à côté
            # de sa couche).
            csv_path = report_dir / f"{secteur}_terrain_karstentry_{stamp}.csv"
            n_csv = write_karstentry_csv(
                findings, csv_path, photos_base_dir=qfield_gpkg.parent)
            feedback.pushInfo(
                t("CSV Karst Entry : {n_csv} trouvaille(s) → {csv_path}", n_csv=n_csv, csv_path=csv_path))
            feedback.pushInfo(
                t("  → À importer dans Karst Entry (onglet « Import CSV »)."))

            # ── 3. Rapport PDF (mêmes trouvailles, avec photos) ───────────────
            feedback.pushInfo(t("Génération du rapport PDF..."))
            report_path = report_dir / f"rapport_{secteur}_{stamp}.pdf"
            generate_report(secteur, findings, report_path,
                            attachments_dir=qfield_gpkg.parent)
            feedback.pushInfo(t("Rapport : {report_path}", report_path=report_path))

        # ── 4. Boucle de labels terrain (P3) ─────────────────────────────────
        # Extrait les `interet` (y compris 0) vers un CSV cumulatif. AVANT le
        # nettoyage (qui retire les verdicts de P1/P2/P3).
        try:
            from karstpro.core.sync import extract_terrain_labels
            labels_csv = qfield_gpkg.parent / "labels_terrain.csv"
            n_lab = extract_terrain_labels(qfield_gpkg, secteur, labels_csv)
            if n_lab:
                feedback.pushInfo(
                    t("Labels terrain : {n_lab} cible(s) visitée(s) → {labels_csv}", n_lab=n_lab, labels_csv=labels_csv))
            else:
                feedback.pushInfo(
                    t("Labels terrain : aucune cible avec 'interet' saisi "
                    "(rien à extraire)."))
        except Exception as exc:
            feedback.pushWarning(t("Extraction des labels terrain ignorée : {exc}", exc=exc))

        # ── 5. Nettoyage des couches terrain (option, destructif) ─────────────
        # RÉUTILISE « Mettre à jour les cibles » (archive interet=0 + retire les
        # cibles à cavité trouvée), puis archive AUSSI les cibles à intérêt (≥1,
        # déjà exportées au CSV) — pas de suppression sèche : suppress_already_
        # visited (re-préparation) ne lit QUE l'archive « cibles visitées », donc
        # une cavité/indice confirmé mais supprimé sans archive reviendrait se
        # faire re-proposer comme cible neuve à la prochaine préparation. VIDE
        # ensuite la couche tampon « cavites ».
        # ⚠ À la re-synchro QFieldCloud, ces retraits descendent sur le téléphone.
        if clean_layers:
            try:
                from qgis import processing
                feedback.pushInfo(t("Mise à jour des cibles (réutilisation)..."))
                processing.run("karstpro:karst_update_cibles", {
                    "GPKG_FILE": str(qfield_gpkg),
                    "GPS_BUFFER_M": threshold,
                }, context=context, feedback=feedback)
            except Exception as exc:
                feedback.pushWarning(t("Mise à jour des cibles ignorée : {exc}", exc=exc))
            try:
                from karstpro.core.cibles_carryover import move_visited_to_archive
                rm_detail = []
                n_rm = move_visited_to_archive(qfield_gpkg, secteur,
                                               only_interet={1, 2},
                                               detail_out=rm_detail)
                if n_rm:
                    feedback.pushInfo(
                        t("{n_rm} cible(s) à intérêt archivée(s) dans « cibles visitées » (déjà exportées au CSV inventaire).", n_rm=n_rm))
                    for d in rm_detail:
                        feedback.pushInfo(
                            t("    {v0} : « {v1} » → « {v2} »", v0=d['name'], v1=d['layer'], v2=d['destination']))
            except Exception as exc:
                feedback.pushWarning(t("Archivage des cibles à intérêt ignoré : {exc}", exc=exc))
            try:
                from karstpro.core.sync import reset_gouffres_interet
                g_detail = []
                n_g = reset_gouffres_interet(qfield_gpkg, (1, 2), detail_out=g_detail)
                if n_g:
                    feedback.pushInfo(
                        t("{n_g} gouffre(s) à intérêt remis à « non visité » (verdict exporté au CSV — la couche reste, gouffres connus).", n_g=n_g))
                    for d in g_detail:
                        feedback.pushInfo(
                            t("    {v0} : « {v1} » → « {v2} »", v0=d['name'], v1=d['layer'], v2=d['destination']))
            except Exception as exc:
                feedback.pushWarning(t("Réinitialisation des gouffres ignorée : {exc}", exc=exc))
            try:
                from karstpro.core.gpkg import read_gpkg_layer, delete_features_by_fid
                cav = read_gpkg_layer(qfield_gpkg, "cavites")
                all_cav_fids = (cav["__fid__"].tolist()
                                if "__fid__" in cav.columns else [])
                n_del = delete_features_by_fid(qfield_gpkg, "cavites", all_cav_fids)
                if n_del:
                    feedback.pushInfo(
                        t("Couche « cavites » vidée : {n_del} cavité(s) retirée(s) (exportées au CSV inventaire).", n_del=n_del))
                    if "name" in cav.columns:
                        for name in cav["name"]:
                            feedback.pushInfo(
                                t("    {v0} : « cavites » → « CSV Karst Entry »", v0=name or '?'))
            except Exception as exc:
                feedback.pushWarning(t("Nettoyage de « cavites » ignoré : {exc}", exc=exc))

        feedback.pushInfo(
            t("Terminé : {n_csv} trouvaille(s) exportée(s) pour Karst Entry.", n_csv=n_csv))
        feedback.pushInfo(t("Journal : {log_file}", log_file=log_file))
        # Le dossier de rapport n'existe que s'il y avait quelque chose à
        # exporter ; sinon on pointe vers le dossier du gpkg (où vit le .log).
        out_dir = report_dir if not no_findings else qfield_gpkg.parent
        return {self.OUTPUT_DIR: str(out_dir)}
