# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
import json
from pathlib import Path
import geopandas as gpd
import pandas as pd

# ── Schéma partagé chargé depuis config/karst_schema.json ───────────────────
# Source de vérité unique pour les couches échangées avec Karst Entry
# (cavites, cavites_connues, tracages). Copie locale par projet : les deux
# plugins restent indépendants mais doivent porter le même contrat.
_SCHEMA_PATH = Path(__file__).resolve().parent.parent / "config" / "karst_schema.json"

# Repli : KarstPro doit rester fonctionnel si le JSON est absent/illisible.
# NB : le schéma de l'inventaire (cavites_connues) n'est plus matérialisé en
# Python — KarstPro le détecte/lit mais ne le crée plus. Source de vérité :
# karst_schema.json (côté Karst Entry pour la création).
_FALLBACK_CAVITES = {
    "name": "str", "type": "str", "reference": "str", "comment": "str",
    "dim_entree_longueur": "float", "dim_entree_largeur": "float",
    "developpement_estime": "float", "altitude": "float",
    "topographiable": "int64", "lien_topo": "str",
    "date_disc": "str", "date_expl": "str", "explorers": "str", "photos": "str",
}


def _load_layer_fields(layer_key: str, fallback: dict) -> dict:
    """Champs {nom: type} d'une couche depuis karst_schema.json, ou repli."""
    try:
        data = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
        fields = data["layers"][layer_key]["fields"]
        return dict(fields) if fields else fallback
    except (OSError, KeyError, ValueError, TypeError):
        return fallback


# Noyau cavité partagé (cavites) — produit par KarstPro, édité par Karst Entry.
CAVITES_SCHEMA = _load_layer_fields("cavites", _FALLBACK_CAVITES)

DOLINES_SCHEMA = {
    # Identifiant stable entre préparations — cf. core/doline_identity.py.
    # NE PAS confondre avec le fid GPKG, qui reste un rang d'écriture : toute
    # re-détection le décale et périme les rapports MLL et les notes de terrain.
    "doline_id": "int64",
    "surface_m2": "float",
    "profondeur_m": "float",
    "altitude_m": "float",      # altitude du centroïde (MNT IGN 1 m)
    "score_morpho": "float",
    "score_ml": "float",        # proba modèle appris ×100 — NaN si modèle non activé (Barrois)
    "ratio_ps": "float",        # P/√S — indicateur de verticalité
    "pente_max_bord": "float",  # p90 de pente sur l'anneau périphérique 5 m (°) — v2
    "lisere": "bool",           # True = appartient à un liseré de dolines alignées
    "tpi_500m": "float",        # Topographic Position Index — alt. vs terrain (MNT) 500 m — v2
    "score": "float",
    "priorite": "str",          # rouge/orange/jaune/gris
    # ── Composantes du score et informatives (pour l'analyse MLL) ────
    "circularite": "float",            # 4π·S/P² ∈ [0,1] — 1=cercle, <0.4=allongé/fossé — INFORMATIF
    "bassin_versant_m2": "float",     # surface drainée vers la doline depuis l'amont (m²)
    "type_doline": "str",             # doline / doline-perte / perte (auto depuis flow acc)
    "comp_absorption": "bool",        # True si bassin_versant_m2 ≥ seuil doline-perte (5 000 m²)
    "comp_geologie": "bool",          # centroïde sur formation karstifiable
    "comp_geologie_dist_m": "float",  # distance au bord du polygone karstifiable (m)
    "comp_dist_reseau_m": "float",    # distance au passage topo le plus proche (m) — INFORMATIF
    "comp_in_couloir": "bool",        # dans le couloir de galeries (buffer 500 m) — INFORMATIF
    "comp_bonus_decouverte": "bool",  # bonus exceptionnel (prof > 5 m hors couloir)
    "comp_densite_500m": "int64",     # nb de dolines voisines dans 500 m — INFORMATIF
}

# Couche de cibles terrain — points à prospecter (alimentée par l'export MLL)
CIBLES_SCHEMA = {
    "doline_id": "int64",       # identifiant stable de la doline d'origine
    "name": "str",              # nom affiché (ex. doline_42) — jamais reparsé
    "priorite": "str",          # rouge / orange
    "score": "float",
    "score_morpho": "float",
    "surface_m2": "float",
    "profondeur_m": "float",
    "ratio_ps": "float",
    "pente_max_bord": "float",
    "lisere": "bool",
    "tpi_500m": "float",        # v2
    # Features de label portées par la cible : une cible archivée dont la
    # doline a disparu doit rester exploitable au ré-entraînement (le repli de
    # sync.py::extract_terrain_labels lit ces colonnes quand la doline
    # d'origine n'existe plus dans la couche re-détectée).
    "bassin_versant_m2": "float",
    "comp_geologie_dist_m": "float",
    "circularite": "float",
    # Rapprochement avec l'inventaire, RECOPIÉ DEPUIS LA DOLINE. Signalé par un
    # utilisateur le 2026-08-21 : le rapprochement fonctionnait, mais seule la
    # doline le savait — sur le terrain on marche vers la cible, pas vers le
    # polygone, et on allait vérifier une cavité déjà explorée sans le savoir.
    # Colonnes toujours présentes, même vides : un schéma qui varie selon les
    # données casserait le report de cibles d'une préparation à l'autre.
    "cavite_connue_proche": "bool",
    "cavite_nom": "str",
    "cavite_distance_m": "float",
    "cavite_type": "str",
    "cavite_ref": "str",
    "type": "str",
    "developpement_estime": "float",
    "topographiable": "int64",
    "lien_topo": "str",
    "comment": "str",
    "photos": "str",            # photo terrain (widget ExternalResource QField)
    # Saisie terrain (boucle de labels P3) : intérêt constaté sur place.
    # -1 = non visité (défaut), 0 = visité rien, 1 = indice à creuser, 2 = cavité.
    # Les négatifs (0) sont le signal que l'inventaire ne contient jamais.
    "interet": "int64",
}


# Couche d'archive « … — cibles visitées » : reçoit les cibles déjà prospectées
# (déplacées depuis P1/P2/P3 au retour terrain). Même schéma que les cibles, plus
# la priorité d'origine (d'où elle vient) et la date de visite. Permet de séparer
# la to-do des cibles faites, et de survivre à une re-préparation (cf.
# core/cibles_carryover.py).
ARCHIVE_SCHEMA = {
    **CIBLES_SCHEMA,
    "priorite_origine": "str",   # P1 / P2 / P3 d'où la cible a été déplacée
    "date_visite": "str",        # ISO (AAAA-MM-JJ), vide si inconnue
}


def _make_empty_layer(schema: dict, crs: str = "EPSG:2154",
                      geom_type: str = "Polygon") -> gpd.GeoDataFrame:
    data = {col: pd.Series(dtype=dtype) for col, dtype in schema.items()}
    gdf = gpd.GeoDataFrame(data)
    gdf = gdf.set_geometry(gpd.GeoSeries([], dtype="geometry"))
    gdf = gdf.set_crs(crs)
    # Mémorise le type voulu : une GeoSeries vide est non typée, donc pyogrio
    # écrit un GPKG en type générique « GEOMETRY ». Sur les couches éditables
    # (cavites), QField ne reconnaît alors pas une couche de
    # points et la capture GPS n'attache aucune géométrie (entités fantômes,
    # position NULL). _force_gpkg_geom_types() relit cet attribut pour corriger
    # gpkg_geometry_columns après écriture.
    gdf.attrs["geom_type"] = geom_type
    return gdf


def _force_gpkg_geom_types(path, layer_types: dict) -> None:
    """Force le type géométrie déclaré dans gpkg_geometry_columns.

    pyogrio écrit « GEOMETRY » pour une couche vide. QField/OGR lit le type
    déclaré ici comme source autoritaire : on le réécrit en POINT/POLYGON/…
    pour les couches concernées. Sans effet sur les données (couches vides).
    """
    import sqlite3
    with sqlite3.connect(str(path)) as con:
        cur = con.cursor()
        existing = {r[0] for r in cur.execute(
            "SELECT table_name FROM gpkg_geometry_columns")}
        for layer, gtype in layer_types.items():
            if layer in existing:
                cur.execute(
                    "UPDATE gpkg_geometry_columns SET geometry_type_name=? "
                    "WHERE table_name=?", (gtype.upper(), layer))
        con.commit()


def create_empty_gpkg(path: Path, crs: str = "EPSG:2154") -> None:
    """Crée un GeoPackage vide avec les couches de base.

    Les couches cibles P1/P2 sont créées dynamiquement par
    ``package_qfield_project`` avec le nom du secteur.
    """
    path = Path(path)
    cav = _make_empty_layer(CAVITES_SCHEMA, crs, "Point")
    dol = _make_empty_layer(DOLINES_SCHEMA, crs, "Polygon")
    cav.to_file(path, layer="cavites", driver="GPKG")
    dol.to_file(path, layer="dolines", driver="GPKG")
    _force_gpkg_geom_types(
        path, {"cavites": "POINT", "dolines": "POLYGON"})


def read_gpkg_layer(gpkg_path, layer):
    """Lit une couche d'un GeoPackage en GeoDataFrame **sans pyproj** (sqlite +
    shapely, ``crs=None``).

    Évite le crash ``pyproj``/``proj_create`` (DatabaseContext non thread-safe)
    au 2ᵉ lancement d'un algorithme Processing dans QGIS 4.0.2, déclenché par la
    construction du CRS dans ``geopandas.read_file``. Les coordonnées sont
    renvoyées telles quelles (repère natif de la couche). Une colonne
    ``__fid__`` (le ``rowid`` SQLite = ``fid`` du GeoPackage) est ajoutée pour
    permettre des écritures ciblées via :func:`delete_features_by_fid`.
    """
    import sqlite3
    from shapely import wkb as swkb

    def _geom(blob):
        if not blob or len(blob) < 8:
            return None
        env_indicator = (blob[3] >> 1) & 0x07
        off = 8 + {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}.get(env_indicator, 0)
        try:
            g = swkb.loads(bytes(blob[off:]))
            return None if g.is_empty else g
        except Exception:
            return None

    con = sqlite3.connect(str(gpkg_path))
    try:
        cur = con.cursor()
        r = cur.execute(
            "SELECT column_name FROM gpkg_geometry_columns WHERE table_name=?",
            (layer,)).fetchone()
        geom_col = r[0] if r else "geom"
        cols = [c[1] for c in cur.execute(f'PRAGMA table_info("{layer}")')]
        attr_cols = [c for c in cols if c != geom_col]
        sel = ", ".join(["rowid"] + [f'"{c}"' for c in attr_cols] + [f'"{geom_col}"'])
        recs, geoms = [], []
        for row in cur.execute(f'SELECT {sel} FROM "{layer}"'):
            d = {"__fid__": row[0]}
            for i, c in enumerate(attr_cols):
                d[c] = row[i + 1]
            recs.append(d)
            geoms.append(_geom(row[len(attr_cols) + 1]))
        return gpd.GeoDataFrame(recs, geometry=geoms, crs=None)
    finally:
        con.close()


def read_vlayer_geometries_2154(vlayer):
    """Lit une ``QgsVectorLayer`` en GeoDataFrame (``crs=None``), géométries
    reprojetées en EPSG:2154 via l'API QGIS (``QgsCoordinateTransform``,
    thread-safe) — **sans pyproj**, donc sans risque de crash ``proj_create``
    au 2ᵉ run Processing (même limite que :func:`read_gpkg_layer`). Seules les
    géométries sont nécessaires (filtrage spatial) ; pas les attributs."""
    from shapely import wkb as swkb
    from qgis.core import (QgsCoordinateReferenceSystem,
                           QgsCoordinateTransform, QgsProject)
    l93 = QgsCoordinateReferenceSystem("EPSG:2154")
    src_crs = vlayer.crs()
    tr = None
    if src_crs.isValid() and src_crs.authid() != "EPSG:2154":
        tr = QgsCoordinateTransform(src_crs, l93, QgsProject.instance())
    geoms = []
    for feat in vlayer.getFeatures():
        g = feat.geometry()
        if g is None or g.isEmpty():
            continue
        if tr is not None and g.transform(tr) != 0:
            continue
        try:
            shp = swkb.loads(bytes(g.asWkb()))
        except Exception:
            continue
        if shp is not None and not shp.is_empty:
            geoms.append(shp)
    return gpd.GeoDataFrame({"geometry": geoms}, crs=None)


def delete_features_by_fid(gpkg_path, layer, fids):
    """Supprime des entités d'une couche GeoPackage par leur ``fid`` (rowid),
    en SQL pur — **sans pyproj ni réécriture de couche** (préserve le CRS et le
    schéma). Retourne le nombre de lignes supprimées."""
    import sqlite3
    fids = [int(f) for f in fids]
    if not fids:
        return 0
    con = sqlite3.connect(str(gpkg_path))
    try:
        marks = ",".join("?" * len(fids))
        cur = con.execute(f'DELETE FROM "{layer}" WHERE rowid IN ({marks})', fids)
        con.commit()
        return cur.rowcount
    finally:
        con.close()


def gpkg_srs_id(gpkg_path, layer: str):
    """Code EPSG déclaré par le GeoPackage pour ``layer``, ou ``None``.

    Lu depuis ``gpkg_contents.srs_id`` en sqlite pur — pas de pyogrio/pyproj,
    dont ``proj_create`` n'est pas thread-safe dans QGIS 4.0.2 (access
    violation au 2ᵉ lancement d'un algorithme Processing).

    Sert de garde aux traitements qui supposent un repère précis : l'export
    MLL est entièrement bâti sur Lambert-93 (colonnes ``x_l93``/``y_l93``,
    ``_l93_to_wgs84``, canevas cartographique EPSG:2154). Sans ce contrôle, un
    projet espagnol produisait des coordonnées converties comme si elles
    étaient françaises — ~1500 km d'erreur, silencieusement (cf.
    JOURNAL_EXPERIENCES.md, 2026-08-02).

    Renvoie ``None`` si l'information est absente ou illisible : l'appelant
    laisse alors passer. C'est un garde-fou contre une erreur grossière, pas
    un validateur de conformité.
    """
    import sqlite3

    try:
        con = sqlite3.connect(str(gpkg_path))
    except Exception:
        return None
    # Deux tables portent l'information dans un GeoPackage valide, et elles
    # concordent (vérifié sur les projets réels Marnaval et Cangas de Onís).
    # On interroge les deux : gpkg_contents décrit la couche, mais un gpkg
    # écrit par un outil tiers peut n'avoir renseigné que la table géométrie.
    row = None
    try:
        for table in ("gpkg_contents", "gpkg_geometry_columns"):
            try:
                row = con.execute(
                    f"SELECT srs_id FROM {table} WHERE table_name=?", (layer,)
                ).fetchone()
            except Exception:
                row = None
            if row is not None and row[0] is not None:
                break
    finally:
        con.close()
    if row is None or row[0] is None:
        return None
    try:
        return int(row[0])
    except (TypeError, ValueError):
        return None
