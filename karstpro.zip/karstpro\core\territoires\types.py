# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Types de base du modèle territoires / capacités."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


class ConfigurationIncomplete(Exception):
    """Un territoire ne déclare pas toutes les capacités requises."""


class ConfigurationInconnue(Exception):
    """Un territoire déclare une capacité qui n'existe pas (faute de frappe)."""


class ConfigurationInvalide(Exception):
    """Déclaration présente mais inutilisable (capacité obligatoire absente,
    schéma de config incorrect, adaptateur inconnu)."""


@dataclass(frozen=True)
class ContexteEtude:
    """Contexte passé à toute capacité.

    Objet unique et non éclaté : ajouter un champ demain ne réécrit pas les
    onze signatures de capacités.
    """
    bbox: tuple           # (xmin, ymin, xmax, ymax) exprimée dans `crs`
    crs: str              # CRS de travail résolu, ex. "EPSG:2154"
    work_dir: Path        # dossier de travail (lidar_work)
    feedback: Any         # QgsProcessingFeedback, ou doublure en test

    def __post_init__(self):
        """`crs` est une CHAÎNE, et l'annotation ne suffisait pas à l'imposer.

        Un objet `pyproj.CRS` y est arrivé le 2026-08-20, par une conversion
        mécanique qui cherchait les `crs=` de geopandas et a attrapé ce
        constructeur au passage. L'objet a voyagé sans bruit jusqu'à la
        définition du pipeline PDAL, où il a fait échouer `json.dump` — trois
        couches plus bas, dans un message qui ne désignait pas la cause.

        Le contrat était déjà écrit dans l'annotation ci-dessus ; il n'était
        pas tenu. Il l'est maintenant, et l'erreur nomme le vrai coupable.
        """
        if not isinstance(self.crs, str):
            raise TypeError(
                "ContexteEtude.crs doit être une chaîne « EPSG:xxxx », pas "
                f"un {type(self.crs).__name__}. Les capacités le transmettent "
                "à des services web et à PDAL, qui attendent du texte.")


@dataclass(frozen=True)
class Absente:
    """Déclaration EXPLICITE d'absence d'une capacité sur un territoire.

    Porte le message montré à l'utilisateur : il est ainsi écrit une seule
    fois, à côté de la donnée qu'il décrit, au lieu d'être dupliqué dans
    l'algorithme.
    """
    raison_source: str

    @property
    def raison(self) -> str:
        """Message traduit dans la langue courante.

        La traduction se fait ICI, pas aux sept endroits qui l'affichent :
        elle vient d'un JSON de configuration, donc le scan AST du garde-fou
        ne peut pas la voir passer par t(). Verifie le 2026-08-09 par une
        preparation reelle en anglais — les six raisons sortaient en francais
        alors qu'elles figuraient bien au catalogue. Le test verifiait leur
        PRESENCE, jamais leur USAGE.
        """
        from karstpro.core.i18n import t
        return t(self.raison_source)

    @property
    def absente(self) -> bool:
        return True


@runtime_checkable
class Capacite(Protocol):
    """Fournisseur satisfaisant une capacité. Signature unique par capacité :
    l'appelant ne sait jamais dans quel territoire il se trouve."""

    @property
    def absente(self) -> bool: ...

    def executer(self, ctx: ContexteEtude) -> Any: ...
