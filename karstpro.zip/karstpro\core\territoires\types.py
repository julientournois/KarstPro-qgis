# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Types de base du modèle territoires / capacités."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


class ConfigurationIncomplete(Exception):
    """Un territoire ne déclare pas toutes les capacités requises."""


class ConfigurationInconnue(Exception):
    """Un territoire déclare une capacité qui n'existe pas (faute de frappe)."""


class ConfigurationInvalide(Exception):
    """Déclaration présente mais inutilisable (capacité obligatoire absente,
    schéma de config incorrect, adaptateur inconnu)."""


@dataclass(frozen=True)
class ContexteEtude:
    """Contexte passé à toute capacité.

    Objet unique et non éclaté : ajouter un champ demain ne réécrit pas les
    onze signatures de capacités.
    """
    bbox: tuple           # (xmin, ymin, xmax, ymax) exprimée dans `crs`
    crs: str              # CRS de travail résolu, ex. "EPSG:2154"
    work_dir: Path        # dossier de travail (lidar_work)
    feedback: Any         # QgsProcessingFeedback, ou doublure en test


@dataclass(frozen=True)
class Absente:
    """Déclaration EXPLICITE d'absence d'une capacité sur un territoire.

    Porte le message montré à l'utilisateur : il est ainsi écrit une seule
    fois, à côté de la donnée qu'il décrit, au lieu d'être dupliqué dans
    l'algorithme.
    """
    raison: str

    @property
    def absente(self) -> bool:
        return True


@runtime_checkable
class Capacite(Protocol):
    """Fournisseur satisfaisant une capacité. Signature unique par capacité :
    l'appelant ne sait jamais dans quel territoire il se trouve."""

    @property
    def absente(self) -> bool: ...

    def executer(self, ctx: ContexteEtude) -> Any: ...
