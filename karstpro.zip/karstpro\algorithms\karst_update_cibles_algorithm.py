# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterDefinition,
    QgsProcessing,
)
from pathlib import Path
import re

# NOTE: All heavy imports deferred to processAlgorithm() — see karst_prep_algorithm.py


class KarstUpdateCiblesAlgorithm(QgsProcessingAlgorithm):
    """Retire des couches cibles P1/P2/P3 toutes les dolines dont une cavité
    saisie sur le terrain (couche ``cavites`` du GeoPackage) tombe à l'intérieur
    du polygone de doline (couche ``dolines``) élargi d'un buffer GPS.

    Logique :
      1. Lire ``cavites`` (saisies terrain) et ``dolines`` (polygones).
      2. Pour chaque cavité saisie, buffer GPS → intersection avec les polygones
         de dolines → liste des dolines visitées.
      3. Pour chaque couche cibles P1/P2/P3 : supprimer les cibles dont le
         centroïde correspond à une doline visitée (tolérance 1 m).
      4. Réécrire les couches filtrées dans le GPKG.

    À lancer au retour d'une sortie terrain, après synchronisation QField.
    """

    GPKG_FILE    = "GPKG_FILE"
    SOURCE_LAYER = "SOURCE_LAYER"
    SECTEUR_NAME = "SECTEUR_NAME"
    GPS_BUFFER_M = "GPS_BUFFER_M"

    def name(self):
        return "karst_update_cibles"

    def displayName(self):
        return "KarstPro — Mettre à jour les cibles"

    def group(self):
        return "KarstPro"

    def groupId(self):
        return "karstpro"

    def createInstance(self):
        return KarstUpdateCiblesAlgorithm()

    def helpUrl(self):
        from karstpro.core.log_feedback import doc_url
        return doc_url()

    def icon(self):
        from karstpro.icons import karst_icon
        ic = karst_icon()
        return ic if ic is not None else super().icon()

    def shortHelpString(self):
        from karstpro.core.log_feedback import help_html
        return help_html(
            "<b>Mettre à jour les cibles après une sortie terrain.</b><br><br>"
            "<b>But :</b> retirer des cibles à prospecter (P1/P2/P3) celles que tu "
            "as résolues — là où tu as <b>trouvé une cavité</b>.<br><br>"
            "<b>Ce que ça fait :</b> déplace vers « cibles visitées » les cibles "
            "sans intérêt (<i>interet = 0</i>), puis supprime celles dont une "
            "cavité (couche source) tombe dans la doline, buffer GPS compris. Les "
            "cibles à intérêt (indice/cavité) partent à l'inventaire via la "
            "<i>synchro retour terrain</i>, pas ici.<br><br>"
            "<b>Comment l'utiliser :</b><br>"
            "• <b>GeoPackage du secteur</b> — le .gpkg synchronisé depuis QField.<br>"
            "• <b>Couche des cavités à retirer</b> — choisis <b><i>cavites</i></b> "
            "(tes trouvailles de la sortie). Vide = couche <i>cavites</i> du GPKG "
            "par défaut. <u>Ne choisis pas l'inventaire entier</u> : la "
            "confrontation à l'inventaire se fait à la préparation.<br>"
            "• <b>Buffer GPS</b> — rayon (m) autour du point pour l'imprécision "
            "GPS (défaut : 3 m).<br>"
            "• <b>Nom du secteur</b> (avancé) — auto-détecté ; à renseigner si "
            "plusieurs jeux de cibles coexistent.<br><br>"
            "<b>Résultat :</b> P1/P2/P3 mises à jour en place. Recharger les "
            "couches dans QGIS après exécution (clic droit → Actualiser)."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.GPKG_FILE,
            "GeoPackage du secteur (.gpkg)",
            extension="gpkg",
        ))
        source_param = QgsProcessingParameterVectorLayer(
            self.SOURCE_LAYER,
            "Couche des cavités à retirer "
            "(défaut : la couche « cavites » du GeoPackage)",
            types=[QgsProcessing.TypeVectorPoint],
            optional=True,
        )
        source_param.setFlags(
            source_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(source_param)
        buffer_param = QgsProcessingParameterNumber(
            self.GPS_BUFFER_M,
            "Buffer GPS — imprécision GPS (mètres)",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=3.0,
            minValue=1.0,
            maxValue=100.0,
        )
        buffer_param.setFlags(
            buffer_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(buffer_param)
        # Optionnel : le nom du secteur est auto-détecté depuis les couches du
        # GPKG. À renseigner seulement si plusieurs jeux de cibles coexistent.
        secteur_param = QgsProcessingParameterString(
            self.SECTEUR_NAME,
            "Nom du secteur (vide = auto-détecté depuis le GPKG)",
            defaultValue="",
            optional=True,
        )
        secteur_param.setFlags(
            secteur_param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(secteur_param)

    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        """Retire des couches cibles P1/P2/P3 les dolines déjà prospectées.

        Chaque point de cavité saisi est élargi d'un buffer GPS puis intersecté
        avec les POLYGONES de dolines (plus robuste que la distance au
        centroïde) ; toute doline touchée est retirée des couches cibles.
        Le gpkg est mis à jour en place (les dolines restent intactes).
        """
        import pyogrio
        from datetime import datetime
        from karstpro.core.gpkg import read_gpkg_layer, delete_features_by_fid

        gpkg_path   = Path(self.parameterAsFile(parameters, self.GPKG_FILE, context))
        secteur     = self.parameterAsString(parameters, self.SECTEUR_NAME, context).strip()
        source_vlayer = self.parameterAsVectorLayer(parameters, self.SOURCE_LAYER, context)
        gps_buffer  = self.parameterAsDouble(parameters, self.GPS_BUFFER_M, context)

        if not gpkg_path.exists():
            raise ValueError(f"GeoPackage introuvable : {gpkg_path}")

        # Journal persistant (comme la préparation / l'export MLL) : tout le
        # déroulé est recopié dans un .log, dans logs/ à côté du GeoPackage.
        logs_dir = gpkg_path.parent / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_file = logs_dir / (
            f"karstpro_maj_cibles_{gpkg_path.stem}_{datetime.now():%Y%m%d_%H%M%S}.log")
        from karstpro.core.log_feedback import write_log_header, wrap_feedback
        write_log_header(log_file, "KarstPro — Mettre à jour les cibles", parameters)
        feedback = wrap_feedback(feedback, log_file)

        # ── 1. Couches disponibles ────────────────────────────────────
        # pyogrio (geopandas l'utilise) — fiona n'est pas installe dans QGIS.
        available = [str(n) for n in pyogrio.list_layers(str(gpkg_path))[:, 0]]
        feedback.pushInfo(f"Couches dans le GPKG : {', '.join(available)}")

        # ── 1b. Auto-détection du secteur si non renseigné ────────────
        # Les couches cibles sont nommées "{secteur} — cibles P1/P2/P3".
        if not secteur:
            secteurs = set()
            for layer_name in available:
                m = re.match(r"^(.*) — cibles P[123]$", layer_name)
                if m:
                    secteurs.add(m.group(1))
            if len(secteurs) == 1:
                secteur = secteurs.pop()
                feedback.pushInfo(f"Secteur auto-détecté : « {secteur} »")
            elif len(secteurs) > 1:
                raise ValueError(
                    "Plusieurs jeux de cibles dans ce GPKG "
                    f"({', '.join(sorted(secteurs))}). Renseignez le « Nom du "
                    "secteur » (paramètre avancé) pour choisir lequel mettre à jour."
                )
            else:
                raise ValueError(
                    "Aucune couche « … — cibles P1/P2/P3 » trouvée dans le GPKG. "
                    "Ce fichier a-t-il bien été préparé par KarstPro ?"
                )

        # ── 1c. Déplacer les cibles SANS intérêt vers l'archive ───────
        # Seules les cibles « visité, rien » (interet = 0) partent dans
        # « cibles visitées ». Les cibles à intérêt (interet ≥ 1 : indice ou
        # cavité) vont à l'inventaire (CSV Karst Entry) via la synchro retour
        # terrain — elles ne sont PAS archivées ici. Fait AVANT la validation des
        # cavités (qui peut sortir l'algo). Sans effet si l'archive n'existe pas.
        try:
            from karstpro.core.cibles_carryover import move_visited_to_archive
            moved_detail = []
            n_moved = move_visited_to_archive(gpkg_path, secteur, only_interet={0},
                                              detail_out=moved_detail)
            if n_moved:
                feedback.pushInfo(
                    f"{n_moved} cible(s) sans intérêt déplacée(s) vers "
                    "« cibles visitées ».")
                for d in moved_detail:
                    feedback.pushInfo(
                        f"    {d['name']} : « {d['layer']} » → « {d['destination']} »")
        except Exception as exc:
            feedback.pushWarning(f"Déplacement vers l'archive ignoré : {exc}")

        # Garde-fou CRS : _read_vlayer_2154 ramène la couche source en
        # Lambert-93, puis les distances sont calculées contre les dolines et
        # cibles lues telles quelles du gpkg. Sur un projet non-français, ces
        # deux jeux sont dans des repères différents : les cibles seraient
        # retirées (ou conservées) sur des distances aberrantes, sans le
        # moindre signe — et cet algorithme ÉCRIT dans le gpkg. Même famille
        # que l'export MLL (cf. JOURNAL_EXPERIENCES.md, 2026-08-02).
        from karstpro.core.gpkg import gpkg_srs_id
        srs_id = gpkg_srs_id(gpkg_path, "dolines")
        if srs_id is not None and srs_id != 2154:
            # ValueError = convention d'erreur de ce module (cf. lignes
            # voisines) ; QgsProcessingException n'y est pas importé.
            raise ValueError(
                f"« Mettre à jour les cibles » ne gère que les projets français "
                f"(Lambert-93 / EPSG:2154) ; ce GeoPackage est en EPSG:{srs_id}. "
                f"Les distances seraient calculées entre deux repères différents "
                f"et des cibles seraient supprimées à tort. Traitement interrompu.")

        # ── 2. Couche source des cavités ──────────────────────────────
        # Soit la couche choisie dans la liste déroulante (couche du projet),
        # soit, par défaut, la couche "cavites" du GeoPackage.
        # Lecture SANS pyproj (crash proj_create au 2e run Processing) : couche
        # source via l'API QGIS (transform CRS thread-safe), couche gpkg en
        # sqlite pur. Toutes les géométries ramenées en EPSG:2154.
        if source_vlayer is not None:
            label = source_vlayer.name()
            try:
                cavites = self._read_vlayer_2154(source_vlayer)
            except Exception as e:
                raise ValueError(f"Lecture de la couche « {label} » échouée : {e}")
        else:
            if "cavites" not in available:
                raise ValueError(
                    "Aucune couche source indiquée et couche « cavites » absente "
                    "du GeoPackage. Sélectionnez une couche de cavités."
                )
            label = "cavites"
            cavites = read_gpkg_layer(gpkg_path, "cavites")

        if cavites.empty:
            # Aider : lister les couches de cavités peuplées du GPKG
            suggestions = []
            for l in available:
                if "cavite" in l.lower() and "georisque" not in l.lower():
                    try:
                        if not read_gpkg_layer(gpkg_path, l).empty:
                            suggestions.append(l)
                    except Exception:
                        pass
            msg = f"Couche « {label} » vide — aucune cavité à retirer."
            if suggestions:
                msg += (f" Couche(s) peuplée(s) dans le GPKG : "
                        f"{', '.join(sorted(set(suggestions)))}.")
            feedback.pushWarning(msg)
            return {}

        feedback.pushInfo(f"{len(cavites)} cavité(s) dans « {label} ».")

        # ── 3. Polygones de dolines ───────────────────────────────────
        if "dolines" not in available:
            feedback.pushWarning(
                "Couche 'dolines' absente — fallback sur distance au centroïde "
                f"(rayon {gps_buffer:.0f} m)."
            )
            dolines = None
        else:
            dolines = read_gpkg_layer(gpkg_path, "dolines")
            feedback.pushInfo(f"{len(dolines)} dolines chargées.")

        # ── 4. Préparer les géométries des dolines visitées ──────────
        #
        # Une cible est retirée si elle correspond à une doline « visitée ».
        # On considère une cible visitée si :
        #   (a) une cavité est à ≤ buffer GPS de la cible (cas direct, robuste), OU
        #   (b) la cible tombe dans le polygone d'une doline elle-même touchée par
        #       une cavité (utile pour les grandes dolines où la cavité est loin
        #       du centroïde).
        # On évite toute comparaison de centroïdes arrondis (fragile : un écart de
        # 1 m entre le centroïde stocké et recalculé faisait rater la suppression).
        cav_geoms = [g for g in cavites.geometry if _valid_geom(g)]
        feedback.pushInfo(f"{len(cav_geoms)} cavité(s) géolocalisée(s) utilisée(s).")

        dolines_visitees = None   # union des polygones de dolines touchés par une cavité
        if dolines is not None and not dolines.empty:
            from shapely.ops import unary_union
            dol_sindex = dolines.sindex
            touched = []
            for cav_pt in cav_geoms:
                cav_buf = cav_pt.buffer(gps_buffer)
                for j in dol_sindex.intersection(cav_buf.bounds):
                    dg = dolines.geometry.iloc[j]
                    if _valid_geom(dg) and dg.intersects(cav_buf):
                        touched.append(dg)
            if touched:
                dolines_visitees = unary_union(touched)
                feedback.pushInfo(
                    f"{len(touched)} doline(s) touchée(s) par une cavité "
                    f"(buffer {gps_buffer:.0f} m)."
                )

        # ── 5. Filtrer les couches cibles ─────────────────────────────
        cibles_layers = {
            "P1": f"{secteur} — cibles P1",
            "P2": f"{secteur} — cibles P2",
            "P3": f"{secteur} — cibles P3",
        }

        total_supprimees = 0

        for rang, layer_name in cibles_layers.items():
            if layer_name not in available:
                feedback.pushInfo(f"Couche '{layer_name}' absente — ignorée.")
                continue

            cibles = read_gpkg_layer(gpkg_path, layer_name)
            if cibles.empty:
                feedback.pushInfo(f"{rang} : couche vide — ignorée.")
                continue

            avant  = len(cibles)
            a_supprimer = []

            for idx, cible_row in cibles.iterrows():
                cible_pt = cible_row.geometry
                if not _valid_geom(cible_pt):
                    continue

                nom = cible_row.get("name", str(idx))

                # (a) cavité directement proche de la cible ?
                dmin = min((cav.distance(cible_pt) for cav in cav_geoms),
                           default=float("inf"))
                if dmin <= gps_buffer:
                    a_supprimer.append(idx)
                    feedback.pushInfo(
                        f"  {rang} — suppression : {nom} (cavité à {dmin:.1f} m)")
                    continue
                # (b) cible à l'intérieur d'une doline touchée par une cavité ?
                if dolines_visitees is not None and dolines_visitees.contains(cible_pt):
                    a_supprimer.append(idx)
                    feedback.pushInfo(
                        f"  {rang} — suppression : {nom} (doline sur cavité)")

            # Suppression ciblée par fid (rowid) en SQL, sans pyproj. Une cible
            # sur une cavité (connue ou trouvée) est résolue → retirée de la to-do.
            fids = (cibles.loc[a_supprimer, "__fid__"].tolist()
                    if a_supprimer else [])
            supprimees = delete_features_by_fid(gpkg_path, layer_name, fids)
            total_supprimees += supprimees
            feedback.pushInfo(
                f"{rang} ({layer_name}) : {avant} → {avant - supprimees} "
                f"({supprimees} cible(s) retirée(s))")

            if feedback.isCanceled():
                break

        # ── 6. Résumé ─────────────────────────────────────────────────
        feedback.pushInfo("=" * 50)
        feedback.pushInfo(
            f"Mise à jour terminée — {total_supprimees} cible(s) retirée(s) au total."
        )
        feedback.pushInfo(
            "Recharger les couches P1/P2/P3 dans QGIS pour voir les changements "
            "(clic droit → Actualiser)."
        )
        feedback.pushInfo(f"Journal : {log_file}")
        return {}

    def _read_vlayer_2154(self, vlayer):
        """Lit une QgsVectorLayer en GeoDataFrame (``crs=None``), géométries
        reprojetées en EPSG:2154 via l'API QGIS (``QgsCoordinateTransform``,
        thread-safe) — **sans pyproj**, donc sans risque de crash ``proj_create``
        au 2ᵉ run Processing. Seules les géométries sont nécessaires au filtre."""
        import geopandas as gpd
        from shapely import wkb as swkb
        from qgis.core import (QgsCoordinateReferenceSystem,
                               QgsCoordinateTransform, QgsProject)
        l93 = QgsCoordinateReferenceSystem("EPSG:2154")
        src_crs = vlayer.crs()
        tr = None
        if src_crs.isValid() and src_crs.authid() != "EPSG:2154":
            tr = QgsCoordinateTransform(src_crs, l93, QgsProject.instance())
        geoms = []
        for feat in vlayer.getFeatures():
            g = feat.geometry()
            if g is None or g.isEmpty():
                continue
            if tr is not None and g.transform(tr) != 0:
                continue
            try:
                shp = swkb.loads(bytes(g.asWkb()))
            except Exception:
                continue
            if shp is not None and not shp.is_empty:
                geoms.append(shp)
        return gpd.GeoDataFrame({"geometry": geoms}, crs=None)


# ── Utilitaires ────────────────────────────────────────────────────────────────

def _valid_geom(geom) -> bool:
    """True si geom est une géométrie shapely exploitable.

    Les couches peuvent contenir des entités sans géométrie : geopandas les
    renvoie tantôt en None, tantôt en float NaN selon le driver. On filtre les
    deux (et tout objet dépourvu de .buffer).
    """
    if geom is None:
        return False
    if not hasattr(geom, "buffer"):   # exclut float/NaN et autres non-géométries
        return False
    try:
        return not geom.is_empty
    except Exception:
        return False
