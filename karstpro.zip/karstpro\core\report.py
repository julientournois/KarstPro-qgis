# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
from pathlib import Path
from datetime import date
import geopandas as gpd
import pandas as pd
from karstpro.core.geology import _l93_to_utm, _l93_to_wgs84
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, Image as RLImage)
from reportlab.lib.utils import ImageReader
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import mm

# Libellés FR des champs (sinon le nom de colonne brut est utilisé).
_LABELS = {
    "name": "Nom", "type": "Type", "reference": "Référence", "origine": "Origine",
    "comment": "Commentaire", "dim_entree_longueur": "Entrée — longueur (m)",
    "dim_entree_largeur": "Entrée — largeur (m)",
    "developpement_estime": "Développement estimé (m)",
    "altitude": "Altitude (m)",
    "topographiable": "Topographiable", "lien_topo": "Lien topo",
    "date_disc": "Date découverte", "date_expl": "Date exploration",
    "prot_id": "Protection (id)", "explorers": "Explorateurs",
    "photos": "Photos", "commune": "Commune", "code_insee": "Code INSEE",
    "code_postal": "Code postal", "departement": "Département",
    "code_dept": "Code département",
}
# Ordre d'affichage préféré ; les colonnes hors liste suivent, dans l'ordre source.
_ORDER = list(_LABELS.keys())


def _is_empty(v) -> bool:
    if v is None:
        return True
    try:
        if pd.isna(v):
            return True
    except (TypeError, ValueError):
        pass
    return isinstance(v, str) and not v.strip()


def _ordered_columns(cols):
    known = [c for c in _ORDER if c in cols]
    rest = [c for c in cols if c not in _ORDER]
    return known + rest


_IMG_EXT = (".jpg", ".jpeg", ".png", ".heic", ".webp")


def _resolve_photo(value, base_dirs):
    """Résout le chemin d'une photo (champ `photos`) vers un fichier image
    existant. QField stocke un chemin relatif au projet ; au retour le fichier
    est sous le dossier du projet ou un sous-dossier DCIM. On essaie plusieurs
    emplacements (robustesse au round-trip QFieldCloud). Première photo si le
    champ en contient plusieurs (séparées par ; ou ,). None si introuvable."""
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    first = raw.replace(",", ";").split(";")[0].strip()
    if not first:
        return None
    p = Path(first)
    candidates = []
    if p.is_absolute():
        candidates.append(p)
    for base in base_dirs:
        if base is None:
            continue
        base = Path(base)
        candidates += [base / first, base / "DCIM" / first,
                       base / "DCIM" / p.name, base / p.name]
    for c in candidates:
        try:
            if c.is_file() and c.suffix.lower() in _IMG_EXT:
                return c
        except OSError:
            continue
    return None


def _photo_flowable(path, max_w_mm=110, max_h_mm=85):
    """RLImage mise à l'échelle (ratio préservé) pour tenir dans la fiche, ou
    None si l'image est illisible."""
    try:
        iw, ih = ImageReader(str(path)).getSize()
        if not iw or not ih:
            return None
        scale = min(max_w_mm * mm / iw, max_h_mm * mm / ih, 1.0)
        return RLImage(str(path), width=iw * scale, height=ih * scale)
    except Exception:
        return None


def generate_report(secteur_name: str,
                    cavites: gpd.GeoDataFrame,
                    output_path: Path,
                    attachments_dir=None) -> Path:
    """Rapport PDF : une fiche par cavité avec TOUS les champs saisis +
    coordonnées L93/WGS84/UTM, et la **photo** si le champ `photos` la référence.

    ``attachments_dir`` : dossier où chercher les photos (champ `photos` =
    chemin relatif au projet QField). Par défaut, le dossier du PDF.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(output_path), pagesize=A4,
                            topMargin=15 * mm, bottomMargin=15 * mm)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph(f"Rapport de prospection — {secteur_name}", styles["Title"]))
    story.append(Paragraph(f"Date : {date.today():%d/%m/%Y}", styles["Normal"]))
    story.append(Spacer(1, 12))

    n = 0 if cavites is None else len(cavites)
    story.append(Paragraph(f"Cavités relevées ({n})", styles["Heading2"]))
    story.append(Spacer(1, 8))

    if n == 0:
        story.append(Paragraph("Aucune cavité dans ce retour terrain.", styles["Normal"]))
        doc.build(story)
        return output_path

    geom_col = cavites.geometry.name
    attr_cols = _ordered_columns([c for c in cavites.columns if c != geom_col])

    for i, (idx, row) in enumerate(cavites.iterrows()):
        title = row.get("name") if "name" in cavites.columns else None
        if _is_empty(title):
            title = f"Cavité {i + 1}"
        story.append(Paragraph(str(title), styles["Heading3"]))

        data = []
        for c in attr_cols:
            v = row.get(c)
            if _is_empty(v):
                continue
            label = _LABELS.get(c, c)
            if isinstance(v, float) and v.is_integer():
                v = int(v)
            data.append([label, str(v)])

        # Coordonnées
        geom = row.geometry
        if geom is not None and not geom.is_empty:
            data.append(["Coordonnées L93 (X, Y)",
                         f"{geom.x:.1f} ; {geom.y:.1f}"])
            # WGS84 lat/lon — conversion pur Python (sans pyproj : évite le
            # crash proj_create au 2ᵉ run d'un algorithme dans le même process).
            try:
                lon, lat = _l93_to_wgs84(geom.x, geom.y)
                data.append(["Coordonnées WGS84 (lat, lon)",
                             f"{lat:.6f} ; {lon:.6f}"])
            except Exception:
                pass
            # UTM WGS84 (mètres) — grille usuelle des GPS de terrain. Le fuseau
            # est calculé d'après la longitude (France : 30N/31N/32N) et affiché
            # explicitement, sinon une zone à cheval donnerait un E/N trompeur.
            try:
                e, n, z = _l93_to_utm(geom.x, geom.y)
                data.append([f"Coordonnées UTM {z}N WGS84 (E, N, m)",
                             f"{e:.0f} ; {n:.0f}"])
            except Exception:
                pass

        if data:
            t = Table(data, colWidths=[60 * mm, 110 * mm])
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#1e3a5f")),
                ("TEXTCOLOR", (0, 0), (0, -1), colors.whitesmoke),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ]))
            story.append(t)

        # Photo (champ `photos`) — v1 : une image, mise à l'échelle pour tenir.
        if "photos" in cavites.columns:
            base_dirs = [attachments_dir, output_path.parent]
            photo = _resolve_photo(row.get("photos"), base_dirs)
            if photo is not None:
                flow = _photo_flowable(photo)
                if flow is not None:
                    story.append(Spacer(1, 4))
                    story.append(flow)
        story.append(Spacer(1, 10))

    doc.build(story)
    return output_path
