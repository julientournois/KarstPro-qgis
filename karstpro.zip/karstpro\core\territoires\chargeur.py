# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Lecture et validation des fichiers de déclaration de territoire (JSON).

Format JSON et convention de clés `_note` alignés sur l'existant
(`config/default_scoring.json`, `config/karst_schema.json`). Aucune dépendance
nouvelle.
"""
from __future__ import annotations

import json
from pathlib import Path

from karstpro.core.territoires.adaptateurs import ADAPTATEURS
from karstpro.core.territoires.fournisseurs import (
    Chaine, CrsFixe, CrsUtmParLongitude, SourceDeclarative,
)
from karstpro.core.territoires.registre import Territoire
from karstpro.core.territoires.types import Absente, ConfigurationInvalide

_RACINE_CONFIG = Path(__file__).resolve().parent.parent.parent / "config" / "territoires"

# Champs obligatoires par type. Le schéma est décrit en DONNÉES : ajouter un
# type de fournisseur oblige à déclarer ses champs, donc à les valider.
_CHAMPS_REQUIS = {
    "fixe": ("code",),
    "utm_par_longitude": ("zones",),
    "absente": ("raison",),
    "adaptateur": ("nom",),
    "chaine": ("maillons",),
    "wfs": ("url", "typename"),
    "wms": ("url", "couche"),
    "wmts": ("url", "couche"),
    "wcs": ("url", "couverture"),
    "arcgis": ("url",),
}


def _valider(nom_capacite: str, decl: dict, source: str) -> None:
    if not isinstance(decl, dict) or "type" not in decl:
        raise ConfigurationInvalide(
            f"{source} : capacité « {nom_capacite} » — déclaration sans champ « type ».")
    type_ = decl["type"]
    if type_ not in _CHAMPS_REQUIS:
        raise ConfigurationInvalide(
            f"{source} : capacité « {nom_capacite} » — type « {type_} » inconnu. "
            f"Types acceptés : {sorted(_CHAMPS_REQUIS)}.")
    manquants = [c for c in _CHAMPS_REQUIS[type_] if c not in decl]
    if manquants:
        raise ConfigurationInvalide(
            f"{source} : capacité « {nom_capacite} » (type « {type_} ») — "
            f"champ(s) obligatoire(s) manquant(s) : {manquants}.")
    if type_ == "adaptateur" and decl["nom"] not in ADAPTATEURS:
        raise ConfigurationInvalide(
            f"{source} : capacité « {nom_capacite} » — adaptateur "
            f"« {decl['nom']} » inconnu. Adaptateurs disponibles : "
            f"{sorted(ADAPTATEURS)}.")


def _construire(nom_capacite: str, decl: dict, source: str):
    _valider(nom_capacite, decl, source)
    type_ = decl["type"]
    if type_ == "absente":
        return Absente(decl["raison"])
    if type_ == "fixe":
        return CrsFixe(decl["code"])
    if type_ == "utm_par_longitude":
        return CrsUtmParLongitude(decl["zones"])
    if type_ == "adaptateur":
        return ADAPTATEURS[decl["nom"]]()
    if type_ == "chaine":
        return Chaine(tuple(
            _construire(nom_capacite, m, source) for m in decl["maillons"]))
    return SourceDeclarative(type_, decl)


def charger_territoire(chemin, cle: str) -> Territoire:
    chemin = Path(chemin)
    source = chemin.name
    try:
        data = json.loads(chemin.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigurationInvalide(f"{source} : illisible ({exc}).") from exc
    capacites = {
        nom: _construire(nom, decl, source)
        for nom, decl in data.get("capacites", {}).items()
        if not nom.startswith("_")
    }
    return Territoire(cle=cle, libelle=data.get("libelle", cle), capacites=capacites)


def get_territoire(cle: str) -> Territoire:
    """Charge un territoire par sa clé. Lève ConfigurationInvalide si le
    fichier est absent — pas de repli silencieux sur la France."""
    chemin = _RACINE_CONFIG / f"{cle}.json"
    if not chemin.exists():
        raise ConfigurationInvalide(
            f"Territoire « {cle} » inconnu : {chemin} introuvable.")
    return charger_territoire(chemin, cle=cle)
