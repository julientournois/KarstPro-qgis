# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Occupation du sol espagnole (SIOSE / INSPIRE Land Cover) — filtrage des
faux positifs de gouffres, équivalent de BD Topo côté France.

Service : ``servicios.idee.es/wfs-inspire/ocupacion-suelo``, couche
``lcv:LandCoverUnit``. Vecteur (polygones), classification CODIIGE portée par
``lcv:class`` sous forme d'un ``xlink:href`` vers la codelist IDEE.

Pourquoi un adaptateur et pas une entrée de config déclarative (cf. frontière
config/code de la spec territoires) : ce service impose une **pagination**
(2 000 entités par lot, ~30 000 sur une emprise d'étude), son GML INSPIRE
n'est pas du simple-feature lisible directement par GDAL, et le code de classe
doit être extrait par expression régulière. Trois formes de contrôle de flux,
donc du code.

⚠️ Pièges rencontrés lors de la mise au point (2026-08-02), tous éprouvés en
conditions réelles :

1. **Ne jamais confondre une requête en échec avec une fin de données.** Une
   première version cassait sa boucle sur « lot vide » ; un simple délai
   dépassé la faisait s'arrêter à 20 000 polygones sur 29 232 et conclure que
   32 % du territoire n'avait pas d'occupation du sol.
2. **Le service renvoie des HTTP 502 sporadiques** en fin de pagination. Ils
   sont transitoires : on réessaie, on ne s'arrête pas.
3. **``numberMatched`` n'est pas fiable** sur les requêtes ordinaires (il vaut
   ``numberReturned``). Le total ne s'obtient qu'avec ``RESULTTYPE=hits``.
4. **La bbox doit être reprojetée, jamais convertie à la main.** Une
   conversion approximative avait décalé l'emprise en longitude et ne couvrait
   que 20 % de la zone d'étude.
5. **Ordre des axes** : le WFS 2.0 INSPIRE attend ``lat,lon`` en EPSG:4258,
   et les ``gml:posList`` sont eux aussi en lat lon.

Mesuré sur Cangas de Onís (57,7 km², 30 855 candidats gouffres) : 74 % des
candidats tombent en forêt, 6 % en zone urbaine. Le filtrage retire ~80 % du
bruit — nécessaire, mais pas suffisant à lui seul : cf. JOURNAL_EXPERIENCES.md.
"""
from __future__ import annotations

import re
import time

_WFS = "https://servicios.idee.es/wfs-inspire/ocupacion-suelo"
_COUCHE = "lcv:LandCoverUnit"
_CRS_WFS = "EPSG:4258"          # ETRS89 géographique, axes lat/lon
# Réglages issus d'un banc d'essai réel (2026-08-02) sur l'emprise de Cangas.
# Le goulot est la GÉNÉRATION côté serveur, pas le transfert : 0,24 Mo/s, et
# restreindre les propriétés fait gagner 43 % de temps pour 3 % de volume.
#   - lots de 5000 : 140 entités/s contre 79 à 2000 (1,8x)   -> RETENU
#   - PROPERTYNAME : -43 % de temps                          -> RETENU
#
# ⚠️ Le PARALLÉLISME a été essayé puis ABANDONNÉ, mesures à l'appui. Un
# micro-banc d'essai (4 lots à STARTINDEX bas) annonçait -70 % et 0 échec ;
# l'exécution complète a donné 676 s et 63 % de couverture — plus LENT et
# incomplet, les lots 25000/30000/35000 épuisant leurs 6 réessais. Cause : un
# STARTINDEX élevé est coûteux côté serveur (il doit sauter N enregistrements),
# et des requêtes simultanées à offset élevé le saturent. Leçon : un banc
# d'essai sur les premiers lots ne représente pas le régime réel d'une
# pagination profonde.
_LOT = 5000
_PROPRIETES = "lcv:geometry,lcv:landCoverObservation"
# Seuil de découpe : au-delà, l'emprise est scindée en quadrants plutôt que
# paginée en profondeur. Mesuré sur le service (requêtes isolées, espacées) :
#   STARTINDEX=0     -> 26 s      STARTINDEX=25000 -> 53 s
#   STARTINDEX=30000 -> 58 s
# Le temps de réponse DOUBLE avec l'offset : le serveur doit sauter les N
# premiers enregistrements à chaque requête. Enchaînées, ces requêtes lentes
# le saturent et déclenchent les 502. Découper l'emprise ramène tous les
# offsets sous _LOT * 2, là où le service répond vite et sans erreur.
_SEUIL_DECOUPE = 10000
_PROFONDEUR_MAX = 4             # 4^4 = 256 quadrants au pire, garde-fou
# Les HTTP 502 sont FRÉQUENTS et transitoires : observés aux lots 22000,
# 32000, 34000 et 38000 sur trois exécutions réelles. Avec un budget de 3
# réessais et une attente linéaire (2/4/6 s), une mesure a été abandonnée à
# 95 % — sous le seuil de 90 %, cela aurait annulé TOUT le filtrage après dix
# minutes de récupération. Budget porté à 6 avec attente exponentielle
# plafonnée (2/4/8/16/32/32 s, ~95 s au pire par lot) : le coût d'un réessai
# est négligeable face à celui d'un abandon.
_MAX_ECHECS = 6
_ATTENTE_MAX = 32               # secondes, plafond du recul exponentiel
_COUVERTURE_MINIMALE = 0.90     # en deçà, on renvoie None plutôt qu'un filtre partiel

# Mémoïsation de la dernière emprise récupérée. `obstacles_siose` et
# `vegetation_siose` sont appelées l'une après l'autre sur la MÊME emprise par
# le pipeline : sans ce cache, la pagination complète (~10 min, ~40 000
# polygones) était exécutée DEUX fois, ajoutant 10 minutes inutiles à chaque
# préparation espagnole. Constaté en vérification réelle le 2026-08-02.
# Une seule entrée suffit : les deux appels sont consécutifs et la mémoire
# n'a pas à retenir plusieurs emprises d'étude.
_CACHE = {"cle": None, "gdf": None}

_RE_HITS = re.compile(r'numberMatched="(\d+)"')
_RE_POSLIST = re.compile(r"<gml:posList>([^<]+)</gml:posList>")
_RE_CODIIGE = re.compile(r"CODIIGEValue/(\d+)")


def famille_codiige(code: str) -> str:
    """Famille d'occupation du sol depuis un code CODIIGE.

    Seules deux familles servent au filtrage des gouffres :
    ``bati`` (toits : le LiDAR ne voit pas le sol) et ``eau`` (pas de retour),
    qui sont des faux positifs quasi certains ; et ``vegetation`` (canopée
    fermée), qui est un signal probabiliste — on marque sans supprimer.
    """
    if code.startswith("1"):
        return "bati"
    if code.startswith("3"):
        return "vegetation"
    if code.startswith("4") or code.startswith("5"):
        return "eau"
    return "autre"                     # 2xx agricole, etc. : sans effet


def _bbox_wfs(bbox, crs) -> str:
    """Reprojette `bbox` (dans `crs`) vers l'ordre lat,lon attendu par le WFS.

    Les 4 coins sont transformés, pas seulement les 2 coins diagonaux : une
    bbox UTM reprojetée en géographique ne garde pas ses extrêmes sur les
    mêmes coins. Même patron que `mdt_wcs_es._reproject_bbox`.
    """
    from pyproj import Transformer

    xmin, ymin, xmax, ymax = bbox
    if str(crs).upper() == _CRS_WFS:
        lon_min, lat_min, lon_max, lat_max = xmin, ymin, xmax, ymax
    else:
        tr = Transformer.from_crs(crs, _CRS_WFS, always_xy=True)
        xs, ys = [], []
        for x, y in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
            tx, ty = tr.transform(x, y)
            xs.append(tx)
            ys.append(ty)
        lon_min, lon_max = min(xs), max(xs)
        lat_min, lat_max = min(ys), max(ys)
    marge = 0.01                        # ~1 km, évite les bords francs
    return (f"{lat_min - marge:.5f},{lon_min - marge:.5f},"
            f"{lat_max + marge:.5f},{lon_max + marge:.5f},"
            f"urn:ogc:def:crs:EPSG::4258")


def _total_attendu(bbox_wfs: str, timeout: int) -> int:
    """Total réel via RESULTTYPE=hits — `numberMatched` ment sur les requêtes
    ordinaires (il y répète `numberReturned`)."""
    import requests

    r = requests.get(_WFS, params={
        "SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature",
        "TYPENAMES": _COUCHE, "RESULTTYPE": "hits",
        "BBOX": bbox_wfs}, timeout=timeout)
    m = _RE_HITS.search(r.text)
    return int(m.group(1)) if m else 0


def _polygones_du_lot(texte: str):
    """(geometrie, famille) pour chaque entité du lot. Les entités multi-parties
    (4 % observées) ne conservent que leur anneau extérieur principal — sans
    incidence sur un test d'appartenance ponctuel."""
    from shapely.geometry import Polygon

    for bloc in texte.split("<lcv:LandCoverUnit ")[1:]:
        pos = _RE_POSLIST.search(bloc)
        cod = _RE_CODIIGE.search(bloc)
        if not pos or not cod:
            continue
        v = [float(x) for x in pos.group(1).split()]
        # posList en lat lon -> shapely attend (x=lon, y=lat)
        pts = [(v[i + 1], v[i]) for i in range(0, len(v) - 1, 2)]
        if len(pts) < 4:
            continue
        yield Polygon(pts), famille_codiige(cod.group(1))


def fetch_siose_landcover(bbox, crs, feedback=None, timeout: int = 240):
    """Polygones d'occupation du sol SIOSE couvrant `bbox`.

    Args:
        bbox : (xmin, ymin, xmax, ymax) dans `crs`
        crs  : CRS de `bbox` ET du GeoDataFrame retourné
        feedback : objet optionnel avec `.pushInfo` / `.pushWarning`
        timeout : secondes par requête HTTP

    Returns:
        GeoDataFrame (polygones, colonne ``classe`` ∈ bati/vegetation/eau/autre)
        dans `crs`, ou **None** si la couverture obtenue est trop partielle
        pour filtrer honnêtement (< 90 % du total annoncé). Renvoyer un filtre
        incomplet serait pire que pas de filtre : il écarterait des candidats
        au hasard tout en donnant l'illusion d'un traitement complet.
        None également si le service est injoignable — jamais d'exception.
    """
    import geopandas as gpd
    import requests

    def log(msg, avert=False):
        if feedback:
            (feedback.pushWarning if avert else feedback.pushInfo)(msg)

    cle = (tuple(round(v, 3) for v in bbox), str(crs))
    if _CACHE["cle"] == cle:
        gdf = _CACHE["gdf"]
        log(f"  SIOSE : {0 if gdf is None else len(gdf)} polygone(s) déjà en "
            f"mémoire pour cette emprise — pas de nouvelle requête.")
        return gdf

    try:
        bwfs = _bbox_wfs(bbox, crs)
        attendu = _total_attendu(bwfs, timeout)
    except Exception as exc:
        log(f"  SIOSE injoignable ({exc}) — filtrage des gouffres impossible.",
            avert=True)
        _CACHE.update(cle=cle, gdf=None)
        return None
    if not attendu:
        log("  SIOSE : aucune donnée d'occupation du sol sur cette emprise.",
            avert=True)
        _CACHE.update(cle=cle, gdf=None)
        return None

    log(f"  SIOSE : {attendu} polygone(s) d'occupation du sol à récupérer...")

    def _un_lot(bbox_txt, start):
        """Récupère UN lot d'une emprise, avec réessais. Texte ou None."""
        for essai in range(1, _MAX_ECHECS + 1):
            try:
                r = requests.get(_WFS, params={
                    "SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature",
                    "TYPENAMES": _COUCHE, "COUNT": str(_LOT),
                    "STARTINDEX": str(start), "PROPERTYNAME": _PROPRIETES,
                    "BBOX": bbox_txt}, timeout=timeout)
                if r.status_code != 200:
                    raise RuntimeError(f"HTTP {r.status_code}")
                return r.text
            except Exception as exc:
                attente = min(2 ** essai, _ATTENTE_MAX)
                log(f"  SIOSE : échec (offset {start}, {exc}) — "
                    f"réessai {essai}/{_MAX_ECHECS} dans {attente} s")
                time.sleep(attente)
        return None

    def _quadrants(lat0, lon0, lat1, lon1):
        """Coupe une emprise en 4."""
        lam, lom = (lat0 + lat1) / 2, (lon0 + lon1) / 2
        return ((lat0, lon0, lam, lom), (lat0, lom, lam, lon1),
                (lam, lon0, lat1, lom), (lam, lom, lat1, lon1))

    def _txt(e):
        return (f"{e[0]:.5f},{e[1]:.5f},{e[2]:.5f},{e[3]:.5f},"
                f"urn:ogc:def:crs:EPSG::4258")

    geoms, classes = [], []

    def _recolter(emprise, n_attendu, profondeur=0):
        """Récupère une emprise, en la découpant si elle est trop peuplée.

        Découper plutôt que paginer profond : le temps de réponse double avec
        l'offset (26 s à 0, 58 s à 30000) et les requêtes lentes enchaînées
        saturent le service. Chaque quadrant reste sous le seuil, donc tous les
        offsets restent faibles.
        """
        if n_attendu > _SEUIL_DECOUPE and profondeur < _PROFONDEUR_MAX:
            for q in _quadrants(*emprise):
                nq = _total_attendu(_txt(q), timeout)
                if nq:
                    _recolter(q, nq, profondeur + 1)
            return
        for start in range(0, n_attendu, _LOT):
            texte = _un_lot(_txt(emprise), start)
            if texte is None:
                continue        # lot perdu ; la couverture finale le signalera
            for geom, fam in _polygones_du_lot(texte):
                geoms.append(geom)
                classes.append(fam)

    parts = [float(x) for x in bwfs.split(",")[:4]]
    _recolter(tuple(parts), attendu)

    # Les quadrants se recouvrent sur leurs bords : une entité à cheval est
    # renvoyée plusieurs fois. Sans dédoublonnage, la couverture dépasserait
    # 100 % et masquerait un éventuel manque réel.
    if geoms:
        vus, g2, c2 = set(), [], []
        for geom, fam in zip(geoms, classes):
            cle_g = (round(geom.bounds[0], 7), round(geom.bounds[1], 7),
                     round(geom.bounds[2], 7), round(geom.bounds[3], 7), fam)
            if cle_g in vus:
                continue
            vus.add(cle_g)
            g2.append(geom)
            c2.append(fam)
        geoms, classes = g2, c2

    couverture = len(geoms) / attendu if attendu else 0.0
    if couverture < _COUVERTURE_MINIMALE:
        log(f"  SIOSE : seulement {len(geoms)}/{attendu} polygone(s) récupérés "
            f"({100 * couverture:.0f} %) — filtrage abandonné plutôt que "
            f"partiel (il écarterait des candidats au hasard).", avert=True)
        _CACHE.update(cle=cle, gdf=None)
        return None

    gdf = gpd.GeoDataFrame({"classe": classes}, geometry=geoms, crs=_CRS_WFS)
    if str(crs).upper() != _CRS_WFS:
        gdf = gdf.to_crs(crs)
    # Une couverture partielle passe le seuil mais DÉGRADE le filtrage sans le
    # dire. Mesuré le 2026-08-02 sur Cangas : à 90 % de couverture il restait
    # 4 296 candidats, contre 2 312 à 100 % — presque le double de bruit, avec
    # pour seul signe une ligne d'information neutre. Le seuil est binaire, la
    # qualité est graduelle : on avertit explicitement entre les deux.
    detail = (f"{int((gdf['classe'] == 'vegetation').sum())} végétation, "
              f"{int((gdf['classe'] == 'bati').sum())} bâti")
    if couverture < 0.995:
        manquants = attendu - len(gdf)
        log(f"  ⚠ SIOSE : {len(gdf)}/{attendu} polygone(s) seulement "
            f"({100 * couverture:.1f} %) — {detail}. Filtrage PARTIEL : "
            f"{manquants} polygone(s) manquants laisseront passer des faux "
            f"positifs. Relancer plus tard donnera un résultat plus propre.",
            avert=True)
    else:
        log(f"  SIOSE : {len(gdf)} polygone(s) ({100 * couverture:.0f} % du "
            f"total) — {detail}.")
    _CACHE.update(cle=cle, gdf=gdf)
    return gdf


def obstacles_siose(bbox, crs, feedback=None):
    """Polygones bâti + eau : faux positifs de gouffres quasi certains.

    Équivalent espagnol de `geology.fetch_bdtopo_obstacles`. Renvoie un
    GeoDataFrame à colonne ``classe`` ('bati'/'eau'), tel qu'attendu par
    `shafts.flag_anthropic`, ou None si SIOSE est indisponible.
    """
    gdf = fetch_siose_landcover(bbox, crs, feedback=feedback)
    if gdf is None:
        return None
    return gdf[gdf["classe"].isin(("bati", "eau"))].copy()


def vegetation_siose(bbox, crs, feedback=None):
    """Polygones de végétation (canopée fermée) : signal PROBABILISTE.

    Équivalent espagnol de `geology.fetch_bdtopo_vegetation`. Renvoie un
    GeoDataFrame à colonne ``classe`` ('vegetation'), tel qu'attendu par
    `shafts.flag_vegetation` — qui marque `interet=0` sans jamais supprimer.
    """
    gdf = fetch_siose_landcover(bbox, crs, feedback=feedback)
    if gdf is None:
        return None
    return gdf[gdf["classe"] == "vegetation"].copy()
