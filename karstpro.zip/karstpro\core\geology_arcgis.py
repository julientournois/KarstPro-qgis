# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Géologie depuis un service ArcGIS **quelconque**, décrit par sa déclaration.

À distinguer de :func:`karstpro.core.geology_igme.fetch_igme_geology`, qui
connaît l'IGME espagnol — ses deux niveaux d'échelle, ses champs, son repli.
Ici rien n'est connu d'avance : l'URL, le champ de description et le CRS
viennent du territoire.

Le contrat de sortie est celui qu'attend le reste du pipeline : une couche
complète, avec une colonne ``DESCR``, sur laquelle
:func:`karstpro.core.geology.filter_karstifiable` dérive le sous-ensemble
carbonaté en cherchant « calcaire » / « dolomie ».
"""
import json
import urllib.parse
import urllib.request


def fetch_arcgis_polygones(url: str, bbox: tuple, crs: str,
                           champ_descr: str, timeout: float = 90.0):
    """Polygones d'une couche ArcGIS intersectant ``bbox``.

    Args:
        url: URL du point ``/query`` de la couche (le segment ``/rest/`` est
            obligatoire côté ArcGIS).
        bbox: (xmin, ymin, xmax, ymax) exprimée dans ``crs``.
        crs: CRS de travail, ex. ``"EPSG:3812"``. Passé en ``inSR`` ET ``outSR``
            pour que le service reprojette lui-même — une transformation de
            datum faite ici décalerait les contacts géologiques.
        champ_descr: champ portant la description lithologique. Il est copié
            dans ``DESCR``, seule colonne que ``filter_karstifiable`` regarde.

    Returns:
        GeoDataFrame (polygones, ``crs``) avec au moins ``DESCR``. Vide si le
        service ne renvoie rien.
    """
    import geopandas as gpd
    from shapely.geometry import shape

    epsg = int(str(crs).split(":")[-1])
    params = {
        "geometry": ",".join(str(v) for v in bbox),
        "geometryType": "esriGeometryEnvelope",
        "inSR": epsg, "outSR": epsg,
        "spatialRel": "esriSpatialRelIntersects",
        "outFields": "*",
        "returnGeometry": "true",
        "f": "geojson",
    }
    req = urllib.request.Request(
        url, data=urllib.parse.urlencode(params).encode("utf-8"))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    if "error" in data:
        raise RuntimeError(f"Service ArcGIS : {data['error']}")

    lignes, geoms = [], []
    for f in data.get("features", []):
        g = f.get("geometry")
        if not g:
            continue
        attrs = dict(f.get("properties") or {})
        # DESCR est le contrat ; on conserve le champ d'origine à côté, pour
        # que la couche livrée reste lisible dans QGIS avec son vocabulaire.
        attrs["DESCR"] = attrs.get(champ_descr, "")
        lignes.append(attrs)
        geoms.append(shape(g))

    if not lignes:
        return gpd.GeoDataFrame({"DESCR": []}, geometry=[], crs=crs)
    return gpd.GeoDataFrame(lignes, geometry=geoms, crs=crs)
