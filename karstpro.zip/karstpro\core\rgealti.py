# karstpro/core/rgealti.py
# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Signal de subsidence par différence LiDAR historique (RGE ALTI) / LiDAR HD.

Le RGE ALTI (IGN) intègre par endroits un LiDAR aérien ancien (souvent
2009-2016, campagnes "Directive Inondation" sur les vallées) — bien plus
ancien que notre LiDAR HD. La différence des deux MNT, une fois le biais
systématique de calibration/époque retiré (fond régional lissé), révèle un
affaissement relatif localisé : signature d'un soutirage karstique actif,
invisible à une lecture instantanée du MNT.

Investigation complète (protocole, chiffres, contrôles) : session du
2026-07-27/28, résumée dans le plan
docs/superpowers/plans/2026-07-28-signal-rgealti.md.
"""
from typing import List
from urllib.request import urlopen

import numpy as np
import rasterio

RGEALTI_WMS_URL = "https://data.geopf.fr/wms-r/wms"
RGEALTI_LAYER = "RGEALTI-MNT_PYR-ZIP_FXX_LAMB93_WMS"
MAX_TILE_PX = 3000  # marge sous la limite serveur (5010x5010)


def compute_tile_grid(width: int, max_tile: int = MAX_TILE_PX) -> List[int]:
    """Bornes de decoupage en tuiles <= max_tile le long d'un axe."""
    edges = list(range(0, width, max_tile)) + [width]
    return sorted(set(edges))


def download_rgealti_grid(left: float, bottom: float, right: float, top: float,
                          width: int, height: int, pixel_size: float,
                          max_tile: int = MAX_TILE_PX) -> np.ndarray:
    """Telecharge le RGE ALTI (WMS, float32 brut) sur l'emprise donnee,
    aligne pixel pour pixel sur la grille cible (origine haut-gauche,
    resolution identique au MNT du secteur -- meme convention que
    core.lidar.generate_pc_rasters).

    Une tuile qui echoue (reponse HTTP invalide, taille inattendue) est
    laissee a NaN plutot que d'interrompre tout le telechargement : mieux
    vaut une couverture partielle (visible en aval via rge_eligible) qu'un
    echec total sur un secteur immense.
    """
    full = np.full((height, width), np.nan, dtype="float32")
    col_edges = compute_tile_grid(width, max_tile)
    row_edges = compute_tile_grid(height, max_tile)

    for ci in range(len(col_edges) - 1):
        for ri in range(len(row_edges) - 1):
            c0, c1 = col_edges[ci], col_edges[ci + 1]
            r0, r1 = row_edges[ri], row_edges[ri + 1]
            w, h = c1 - c0, r1 - r0
            xmin = left + c0 * pixel_size
            xmax = left + c1 * pixel_size
            ymax = top - r0 * pixel_size
            ymin = top - r1 * pixel_size
            url = (
                f"{RGEALTI_WMS_URL}?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap"
                f"&LAYERS={RGEALTI_LAYER}&CRS=EPSG:2154"
                f"&BBOX={xmin},{ymin},{xmax},{ymax}"
                f"&WIDTH={w}&HEIGHT={h}&FORMAT=image/x-bil;bits=32&STYLES="
            )
            try:
                with urlopen(url, timeout=60) as resp:
                    data = resp.read()
            except Exception:
                continue
            expected = w * h * 4
            if len(data) != expected:
                continue
            arr = np.frombuffer(data, dtype="<f4").reshape(h, w)
            full[r0:r1, c0:c1] = arr
    return full


def estimate_roughness(elevation: np.ndarray) -> float:
    """Rugosité locale (écart-type d'un laplacien 3x3), robuste aux NaN.

    Une surface issue de corrélation photogrammétrique est nettement plus
    lisse (rugosité plus faible) qu'une surface LiDAR aérienne, qui capture
    du micro-relief même sur un terrain "plat". numpy pur (pas
    scipy.signal.convolve2d) : convention déjà établie dans
    core/pc_anomaly.py et core/shafts.py, scipy n'est pas une dépendance
    gérée (core/dependencies.py).
    """
    valid = ~np.isnan(elevation)
    filled = np.where(valid, elevation, 0.0)
    lap = np.zeros_like(filled)
    lap[1:-1, 1:-1] = (
        filled[:-2, 1:-1] + filled[2:, 1:-1]
        + filled[1:-1, :-2] + filled[1:-1, 2:]
        - 4 * filled[1:-1, 1:-1]
    )
    valid_full = np.zeros_like(valid)
    valid_full[1:-1, 1:-1] = (
        valid[:-2, 1:-1] & valid[2:, 1:-1]
        & valid[1:-1, :-2] & valid[1:-1, 2:] & valid[1:-1, 1:-1]
    )
    vals = lap[valid_full]
    return float(np.nanstd(vals)) if vals.size > 0 else float("nan")


# Seuil calibré empiriquement sur Marnaval/Bayard/Beurey/Sommelonne (tous
# LiDAR confirmé pendant l'investigation de session 2026-07-27/28) :
# rugosite mesuree 0.1221 (Beurey) a 0.1407 (Bayard), Marnaval 0.1309,
# Sommelonne 0.1263 -- marge > 2x au-dessus du seuil retenu. Aucun exemple
# negatif (secteur correlation) observe pour calibrer l'autre cote du
# seuil -- a surveiller a la premiere preparation hors Haute-Marne/Meuse,
# et a resserrer si un secteur LiDAR legitime est rejete a tort (log
# d'alerte recommande plutot qu'un rejet silencieux, cf. plan Task 4).
ROUGHNESS_THRESHOLD = 0.06


def is_secteur_eligible(rgealti_array: np.ndarray) -> bool:
    """Le secteur a-t-il un RGE ALTI de qualité LiDAR (pas de la corrélation) ?"""
    return estimate_roughness(rgealti_array) >= ROUGHNESS_THRESHOLD


def _resize_bilinear(coarse: np.ndarray, out_shape) -> np.ndarray:
    """Ré-échantillonnage bilinéaire numpy pur (pas scipy.ndimage.zoom,
    même convention que estimate_roughness) : la grille grossière
    (fond régional) est remontée à la résolution native en interpolant
    séparément lignes puis colonnes.
    """
    h2, w2 = coarse.shape
    H, W = out_shape
    row_idx = np.clip((np.arange(H) + 0.5) * h2 / H - 0.5, 0, h2 - 1)
    col_idx = np.clip((np.arange(W) + 0.5) * w2 / W - 0.5, 0, w2 - 1)
    r0 = np.floor(row_idx).astype(int)
    r1 = np.clip(r0 + 1, 0, h2 - 1)
    rf = (row_idx - r0)[:, None]
    c0 = np.floor(col_idx).astype(int)
    c1 = np.clip(c0 + 1, 0, w2 - 1)
    cf = (col_idx - c0)[None, :]

    top = coarse[r0][:, c0] * (1 - cf) + coarse[r0][:, c1] * cf
    bot = coarse[r1][:, c0] * (1 - cf) + coarse[r1][:, c1] * cf
    return top * (1 - rf) + bot * rf


def compute_residual(diff: np.ndarray, coarse_px: int = 50) -> np.ndarray:
    """Retire un biais systématique lentement variable (calibration/époque
    des deux relevés) par réduction en blocs (médiane, NaN ignorés) suivie
    d'un ré-échantillonnage bilinéaire -- rapide (pas de filtre plein
    format type generic_filter/median_filter sur toute la grille).
    """
    import warnings

    H, W = diff.shape
    h2, w2 = max(1, H // coarse_px), max(1, W // coarse_px)
    trimmed = diff[:h2 * coarse_px, :w2 * coarse_px]
    blocks = trimmed.reshape(h2, coarse_px, w2, coarse_px)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        coarse = np.nanmedian(blocks, axis=(1, 3))
    global_median = np.nanmedian(diff)
    coarse = np.where(np.isnan(coarse), global_median, coarse)
    fond = _resize_bilinear(coarse, (H, W))
    return diff - fond


def doline_contrast(residual: np.ndarray, transform, cx: float, cy: float,
                     ring_in_m: float = 15.0, ring_out_m: float = 60.0) -> float:
    """Moyenne du résidu près du centroïde (rayon ring_in_m) moins la
    médiane de la couronne (ring_in_m à ring_out_m). Négatif = affaissement
    relatif localisé (signal recherché).
    """
    H, W = residual.shape
    inv = ~transform
    col_f, row_f = inv * (cx, cy)
    col, row = int(col_f), int(row_f)
    px = abs(transform.a)
    ri, ro = int(round(ring_in_m / px)), int(round(ring_out_m / px))

    r0i, r1i = max(0, row - ri), min(H, row + ri + 1)
    c0i, c1i = max(0, col - ri), min(W, col + ri + 1)
    r0o, r1o = max(0, row - ro), min(H, row + ro + 1)
    c0o, c1o = max(0, col - ro), min(W, col + ro + 1)

    inner = residual[r0i:r1i, c0i:c1i]
    outer = residual[r0o:r1o, c0o:c1o].copy()
    outer[(r0i - r0o):(r1i - r0o), (c0i - c0o):(c1i - c0o)] = np.nan

    if np.sum(~np.isnan(inner)) < 3 or np.sum(~np.isnan(outer)) < 10:
        return float("nan")
    return float(np.nanmean(inner) - np.nanmedian(outer))


def sample_dolines_rgealti(dolines, mnt_path, rgealti_path):
    """Ajoute `rge_contrast_m` (résidu, négatif = affaissement relatif) et
    `rge_eligible` (bool, contrôle qualité du secteur) à `dolines`. Si le
    secteur n'est pas éligible (RGE ALTI = corrélation, pas LiDAR), toutes
    les valeurs de contraste restent NaN mais `rge_eligible=False` est quand
    même renseigné (utile pour le rapport / diagnostic, cf. plan Task 6).
    """
    out = dolines.copy()
    with rasterio.open(mnt_path) as mnt, rasterio.open(rgealti_path) as rge:
        z_lhd = mnt.read(1).astype("float32")
        nod = mnt.nodata
        if nod is not None:
            z_lhd = np.where(z_lhd == nod, np.nan, z_lhd)
        z_rge = rge.read(1).astype("float32")
        transform = mnt.transform

    eligible = is_secteur_eligible(z_rge)
    out["rge_eligible"] = eligible

    if not eligible:
        out["rge_contrast_m"] = np.nan
        return out

    diff = z_lhd - z_rge
    residual = compute_residual(diff, coarse_px=50)

    contrasts = [doline_contrast(residual, transform, geom.x, geom.y)
                 for geom in out.geometry.centroid]
    out["rge_contrast_m"] = contrasts
    return out


def fetch_rgealti_for_secteur(mnt_path, output_tif):
    """Telecharge et ecrit le RGE ALTI aligne sur le MNT d'un secteur.
    Idempotent : si output_tif existe deja, ne re-telecharge pas.
    """
    from pathlib import Path
    output_tif = Path(output_tif)
    if output_tif.exists():
        return output_tif

    with rasterio.open(mnt_path) as mnt:
        tr = mnt.transform
        arr = download_rgealti_grid(
            left=mnt.bounds.left, bottom=mnt.bounds.bottom,
            right=mnt.bounds.right, top=mnt.bounds.top,
            width=mnt.width, height=mnt.height, pixel_size=abs(tr.a),
        )
        profile = mnt.profile.copy()
        profile.update(driver="GTiff", dtype="float32", count=1, nodata=np.nan)
        with rasterio.open(output_tif, "w", **profile) as dst:
            dst.write(arr, 1)
    return output_tif
