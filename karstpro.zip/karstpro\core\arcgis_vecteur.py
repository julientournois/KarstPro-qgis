# Copyright (c) 2026 Julien Tournois
# Licence : PolyForm Noncommercial License 1.0.0
# Usage commercial interdit sans autorisation écrite — julien.tournois@gmail.com
# https://polyformproject.org/licenses/noncommercial/1.0.0
"""Entités d'une couche ArcGIS **quelconque**, rendues telles quelles.

À distinguer de :func:`karstpro.core.geology_arcgis.fetch_arcgis_polygones`, qui
sert la géologie et impose un contrat : polygones, colonne ``DESCR``, lue
ensuite par ``filter_karstifiable``. Ici il n'y a aucun contrat de colonne ni de
géométrie — points, lignes et polygones passent, les attributs sont ceux du
service. C'est ce qui permet à un territoire de déclarer ses propres couches de
contexte sans que le pipeline sache ce qu'elles contiennent.

**Pagination.** Le service wallon plafonne à ``maxRecordCount = 2000`` et
tronque **sans erreur** : lire une seule page rendrait un jeu incomplet en
silence sur toute emprise un peu large. On boucle donc sur ``resultOffset``
jusqu'à ce qu'une page revienne plus courte que demandé.

``returnIdsOnly`` est par ailleurs inutilisable pour compter sur ce service : il
a rendu 0 pour « Sites karstiques > 30m en surface », qui contient 744 objets.
"""
import json
import urllib.parse
import urllib.request
from karstpro.core.crs_thread import crs_pour


def fetch_arcgis_features(url: str, bbox: tuple, crs: str,
                          champs=None, timeout: float = 90.0,
                          page_size: int = 2000):
    """Entités d'une couche ArcGIS intersectant ``bbox``, toutes pages lues.

    Args:
        url: URL du point ``/query`` de la couche.
        bbox: (xmin, ymin, xmax, ymax) exprimée dans ``crs``.
        crs: CRS de travail. Passé en ``inSR`` ET ``outSR`` pour que le service
            reprojette lui-même — une transformation de datum faite ici
            décalerait les objets par rapport au MNT.
        champs: liste blanche de colonnes à conserver. ``None`` = tout garder.
        page_size: taille de page demandée ; doit rester ≤ au ``maxRecordCount``
            du service, qui l'abaisse silencieusement sinon.

    Returns:
        GeoDataFrame dans ``crs``, vide (et non ``None``) si l'emprise ne
        contient rien.
    """
    import geopandas as gpd
    from shapely.geometry import shape

    epsg = int(str(crs).split(":")[-1])
    lignes, geoms = [], []
    offset = 0
    while True:
        params = {
            "geometry": ",".join(str(v) for v in bbox),
            "geometryType": "esriGeometryEnvelope",
            "inSR": epsg, "outSR": epsg,
            "spatialRel": "esriSpatialRelIntersects",
            "outFields": "*",
            "returnGeometry": "true",
            "resultOffset": offset,
            "resultRecordCount": page_size,
            "f": "geojson",
        }
        req = urllib.request.Request(
            url, data=urllib.parse.urlencode(params).encode("utf-8"))
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        # Le service répond 200 avec un objet `error` : l'avaler rendrait une
        # couche vide indistinguable d'une zone réellement sans karst.
        if "error" in data:
            raise RuntimeError(f"Service ArcGIS : {data['error']}")
        page = data.get("features", [])
        for f in page:
            g = f.get("geometry")
            if not g:
                continue
            attrs = dict(f.get("properties") or {})
            if champs is not None:
                attrs = {c: attrs.get(c) for c in champs}
            lignes.append(attrs)
            geoms.append(shape(g))
        if len(page) < page_size:
            break
        offset += len(page)

    if not lignes:
        colonnes = {c: [] for c in (champs or [])}
        return gpd.GeoDataFrame(colonnes, geometry=[], crs=crs_pour(crs))
    return gpd.GeoDataFrame(lignes, geometry=geoms, crs=crs_pour(crs))
